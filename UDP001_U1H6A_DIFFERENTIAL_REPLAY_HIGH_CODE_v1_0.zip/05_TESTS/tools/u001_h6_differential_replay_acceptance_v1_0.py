#!/usr/bin/env python3
"""Independent category acceptance for U001 H6 differential replay."""

from __future__ import annotations

import argparse,csv,importlib.util,json,shutil,sys,tempfile
from pathlib import Path
from typing import Any

PROGRAM_NAME="u001_h6_differential_replay_acceptance";PROGRAM_VERSION="1.0.0"
class AcceptanceError(RuntimeError):pass

def load(path:Path,name:str)->Any:
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None:raise AcceptanceError("IMPORT")
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def read_csv(path:Path)->tuple[list[str],list[dict[str,str]]]:
    with path.open("r",encoding="utf-8-sig",newline="") as f:r=csv.DictReader(f);return list(r.fieldnames or []),list(r)

def write_csv(path:Path,header:list[str],rows:list[dict[str,str]])->None:
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=header,lineterminator="\n");w.writeheader();w.writerows([{column:row.get(column,"") for column in header} for row in rows])

def rehash_candidate(package:Path,replay:Any,filename:str)->None:
    manifest=json.loads((package/"u001_run_manifest.json").read_text())
    for item in manifest["Artifacts"]:
        if item["FileName"]==filename:
            path=package/filename;item["SizeBytes"]=path.stat().st_size;item["SHA256"]=replay.sha256(path)
    (package/"u001_run_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")

def case(root:Path,base:Path,replay:Any,rules:Path,kind:str)->dict[str,Any]:
    legacy=root/kind/"legacy";candidate=root/kind/"candidate";shutil.copytree(base,legacy);shutil.copytree(base,candidate)
    if kind=="representation":
        p=candidate/"u001_decoded_updates.csv";h,rows=read_csv(p);rows[0]["PhysicalValue"]=rows[0]["PhysicalValue"]+"00";write_csv(p,h,rows);rehash_candidate(candidate,replay,p.name)
    elif kind=="provenance":
        p=legacy/"u001_decoded_updates.csv";h,rows=read_csv(p);h.remove("SourceAdapterId");write_csv(p,h,rows)
    elif kind=="policy":
        p=candidate/"u001_signal_catalog.csv";h,rows=read_csv(p);rows[0]["HoldPolicy"]="NONE" if rows[0]["HoldPolicy"]!="NONE" else "HOLD_LAST_BOUNDED";write_csv(p,h,rows);rehash_candidate(candidate,replay,p.name)
    elif kind=="value":
        p=candidate/"u001_frame_values.csv";h,rows=read_csv(p);column=next(c for c in h if c.endswith("__value") and rows[0][c]);rows[0][column]=str(float(rows[0][column])+1.0);write_csv(p,h,rows);rehash_candidate(candidate,replay,p.name)
    elif kind=="row":
        p=candidate/"u001_frame_values.csv";h,rows=read_csv(p);write_csv(p,h,rows[:-1]);rehash_candidate(candidate,replay,p.name)
    out=root/kind/"out";return replay.replay(legacy,candidate,rules,out)

def validate(core_dir:Path,rules:Path,base:Path,out:Path)->dict[str,Any]:
    program=core_dir/"u001_h6_differential_replay_v1_0.py"
    if not program.is_file() or not rules.is_file() or not base.is_dir():raise AcceptanceError("INPUTS")
    replay=load(program,"h6_accept_replay");out.mkdir(parents=True,exist_ok=False);checks=0
    def check(v:bool,label:str)->None:
        nonlocal checks
        if not v:raise AcceptanceError(label)
        checks+=1
    replay.self_test();check(True,"T01_SELFTEST")
    exact=case(out,base,replay,rules,"exact");check(exact["Status"]=="ACCEPTABLE_EQUIVALENCE" and sum(exact["ClassCounts"].values())==0,"T02_EXACT")
    rep=case(out,base,replay,rules,"representation");check(rep["ClassCounts"]["APPROVED_REPRESENTATION_DIFFERENCE"]==1 and rep["Status"]=="ACCEPTABLE_EQUIVALENCE","T03_REPRESENTATION")
    prov=case(out,base,replay,rules,"provenance");check(prov["ClassCounts"]["APPROVED_ADDITIONAL_PROVENANCE"]>=1 and prov["Status"]=="ACCEPTABLE_EQUIVALENCE","T04_PROVENANCE")
    policy=case(out,base,replay,rules,"policy");check(policy["ClassCounts"]["POLICY_DIFFERENCE_REQUIRES_DECISION"]==1 and policy["Status"]=="DECISION_REQUIRED","T05_POLICY")
    value=case(out,base,replay,rules,"value");check(value["ClassCounts"]["VALUE_DIFFERENCE_BLOCKING"]==1 and value["Status"]=="BLOCKED","T06_VALUE")
    row=case(out,base,replay,rules,"row");check(row["ClassCounts"]["ROW_IDENTITY_DIFFERENCE_BLOCKING"]==1 and row["Status"]=="BLOCKED","T07_ROW")
    before={name:replay.sha256(base/name) for name in replay.FILES};case(out,base,replay,rules,"readonly");after={name:replay.sha256(base/name) for name in replay.FILES};check(before==after,"T08_READ_ONLY")
    receipt={"AcceptanceSchema":"U001_H6_DIFFERENTIAL_ACCEPTANCE_V1_0","CheckCount":checks,"Categories":6,"Status":"PASS","CompletionCode":0}
    (out/"u001_h6_acceptance_receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8");(out/"u001_h6_acceptance_capsule.txt").write_text(f"U1H6Q-T{checks}-C6-X0-C0\n",encoding="utf-8");return receipt

def self_test(core:Path,rules:Path,base:Path)->None:
    with tempfile.TemporaryDirectory(prefix="u1h6_") as t:validate(core,rules,base,Path(t)/"accept")

def main()->int:
    p=argparse.ArgumentParser();p.add_argument("--self-test",action="store_true");p.add_argument("--core-dir",type=Path,required=True);p.add_argument("--rules",type=Path,required=True);p.add_argument("--base-package",type=Path,required=True);p.add_argument("--out",type=Path);a=p.parse_args()
    try:
        if a.self_test:self_test(a.core_dir,a.rules,a.base_package);print("U001-H6-ACCEPTANCE-SELFTEST-PASS-8");return 0
        if a.out is None:p.error("--out required")
        r=validate(a.core_dir,a.rules,a.base_package,a.out);print(f"U1H6Q-T{r['CheckCount']}-C{r['Categories']}-X0-C0");return 0
    except Exception as exc:print(f"U1H6Q-ERROR-{type(exc).__name__}-{str(exc)[:180]}-X1-C7");return 7

if __name__=="__main__":raise SystemExit(main())
