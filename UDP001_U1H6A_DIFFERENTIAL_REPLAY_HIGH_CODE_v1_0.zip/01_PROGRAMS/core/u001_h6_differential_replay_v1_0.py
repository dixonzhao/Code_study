#!/usr/bin/env python3
"""Read-only semantic differential replay for Legacy and High-Code U001 packages."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


PROGRAM_NAME = "u001_h6_differential_replay"
PROGRAM_VERSION = "1.0.0"
FILES = ["u001_decoded_updates.csv","u001_frame_values.csv","u001_signal_catalog.csv","u001_quality_report.csv","u001_run_manifest.json","u001_review_view.csv"]
CLASSES = ["EXACT_MATCH","APPROVED_REPRESENTATION_DIFFERENCE","APPROVED_ADDITIONAL_PROVENANCE","POLICY_DIFFERENCE_REQUIRES_DECISION","VALUE_DIFFERENCE_BLOCKING","ROW_IDENTITY_DIFFERENCE_BLOCKING"]
DIFF_COLUMNS = ["FileName","RowNumber","Key","ColumnName","LegacyValue","CandidateValue","Classification","Reason"]


class H6Error(RuntimeError): pass


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()


def load_json(path: Path) -> dict[str,Any]:
    try: value=json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc: raise H6Error(f"JSON:{path.name}:{exc}") from exc
    if not isinstance(value,dict): raise H6Error(f"JSON_OBJECT:{path.name}")
    return value


def validate_package(folder: Path, role: str) -> None:
    if not folder.is_dir(): raise H6Error(f"{role}_FOLDER")
    missing=[name for name in FILES if not (folder/name).is_file()]
    if missing: raise H6Error(f"{role}_INVENTORY:{missing}")
    manifest=load_json(folder/FILES[4])
    if str(manifest.get("Status","")).upper() not in {"COMPLETE","ACCEPTED","PASS"}: raise H6Error(f"{role}_MANIFEST_STATUS")
    if role=="CANDIDATE":
        if manifest.get("ManifestSchema")!="U001_HANDOFF_PACKAGE_V1_0" or manifest.get("CompletionCode")!=0: raise H6Error("CANDIDATE_H5_CONTRACT")
        artifacts=manifest.get("Artifacts")
        if not isinstance(artifacts,list) or len(artifacts)!=5: raise H6Error("CANDIDATE_ARTIFACT_LIST")
        for item in artifacts:
            if not isinstance(item,dict): raise H6Error("CANDIDATE_ARTIFACT_ENTRY")
            path=folder/str(item.get("FileName",""))
            if not path.is_file() or path.stat().st_size!=item.get("SizeBytes") or sha256(path)!=item.get("SHA256"): raise H6Error(f"CANDIDATE_ARTIFACT_IDENTITY:{path.name}")


def _missing(value: str, tokens: set[str]) -> bool: return value.strip().lower() in tokens


def _numeric_equal(left: str, right: str, atol: float, rtol: float) -> bool:
    try: a=float(left); b=float(right)
    except ValueError: return False
    return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=atol+rtol*max(abs(a),abs(b))


def _key(row: dict[str,str], keys: list[str]) -> str: return "|".join(row.get(column,"") for column in keys)


def compare_csv(legacy: Path, candidate: Path, rule: dict[str,Any], writer: csv.DictWriter, counts: Counter[str], max_details: int) -> dict[str,int]:
    with legacy.open("r",encoding="utf-8-sig",newline="") as lf, candidate.open("r",encoding="utf-8-sig",newline="") as cf:
        lr=csv.DictReader(lf); cr=csv.DictReader(cf); lh=list(lr.fieldnames or []); ch=list(cr.fieldnames or [])
        keys=list(rule.get("KeyColumns",[])); ignored=set(rule.get("IgnoredColumns",[])); policy=set(rule.get("PolicyColumns",[])); numeric=set(rule.get("NumericColumns",[])); numeric_suffixes=tuple(str(x) for x in rule.get("NumericColumnSuffixes",[])); allowed_extra=set(rule.get("AllowedCandidateAdditionalColumns",[])); allowed_suffixes=tuple(str(x) for x in rule.get("AllowedCandidateAdditionalColumnSuffixes",[])); missing_tokens={str(x).lower() for x in rule.get("MissingTokens",["","na","n/a","null","none","nan"])}
        for key in keys:
            if key not in lh or key not in ch: raise H6Error(f"KEY_COLUMN:{legacy.name}:{key}")
        legacy_core=[c for c in lh if c not in ignored]
        missing_candidate=[c for c in legacy_core if c not in ch]
        if missing_candidate: raise H6Error(f"CANDIDATE_COLUMN_MISSING:{legacy.name}:{missing_candidate}")
        extras=[c for c in ch if c not in lh and c not in ignored]
        unapproved=[c for c in extras if c not in allowed_extra and not c.endswith(allowed_suffixes)]
        if unapproved: raise H6Error(f"CANDIDATE_COLUMN_UNAPPROVED:{legacy.name}:{unapproved}")
        for column in extras:
            counts["APPROVED_ADDITIONAL_PROVENANCE"]+=1
            if sum(counts[c] for c in CLASSES[1:])<=max_details: writer.writerow({"FileName":legacy.name,"RowNumber":"HEADER","Key":"","ColumnName":column,"LegacyValue":"","CandidateValue":"PRESENT","Classification":"APPROVED_ADDITIONAL_PROVENANCE","Reason":"approved candidate-only provenance column"})
        rows=0
        for number,pair in enumerate(itertools.zip_longest(lr,cr),start=1):
            left,right=pair; rows+=1
            if left is None or right is None:
                counts["ROW_IDENTITY_DIFFERENCE_BLOCKING"]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details: writer.writerow({"FileName":legacy.name,"RowNumber":number,"Key":_key(left or right or {},keys),"ColumnName":"<ROW>","LegacyValue":"MISSING" if left is None else "PRESENT","CandidateValue":"MISSING" if right is None else "PRESENT","Classification":"ROW_IDENTITY_DIFFERENCE_BLOCKING","Reason":"row count differs"})
                continue
            lk=_key(left,keys); rk=_key(right,keys)
            if lk!=rk:
                counts["ROW_IDENTITY_DIFFERENCE_BLOCKING"]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details: writer.writerow({"FileName":legacy.name,"RowNumber":number,"Key":f"{lk} != {rk}","ColumnName":"<KEY>","LegacyValue":lk,"CandidateValue":rk,"Classification":"ROW_IDENTITY_DIFFERENCE_BLOCKING","Reason":"semantic row key or row order differs"})
                continue
            for column in legacy_core:
                a=left.get(column,""); b=right.get(column,"")
                if a==b: continue
                if (_missing(a,missing_tokens) and _missing(b,missing_tokens)) or ((column in numeric or column.endswith(numeric_suffixes)) and _numeric_equal(a,b,float(rule.get("AbsoluteTolerance",1e-12)),float(rule.get("RelativeTolerance",1e-9)))):
                    classification="APPROVED_REPRESENTATION_DIFFERENCE"; reason="normalized missing token or numerically equivalent serialization"
                elif column in policy:
                    classification="POLICY_DIFFERENCE_REQUIRES_DECISION"; reason="declared policy field differs"
                else:
                    classification="VALUE_DIFFERENCE_BLOCKING"; reason="semantic value differs"
                counts[classification]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details: writer.writerow({"FileName":legacy.name,"RowNumber":number,"Key":lk,"ColumnName":column,"LegacyValue":a,"CandidateValue":b,"Classification":classification,"Reason":reason})
        return {"RowsCompared":rows,"LegacyColumns":len(lh),"CandidateColumns":len(ch)}


def compare_csv_keyed(legacy: Path,candidate: Path,rule:dict[str,Any],writer:csv.DictWriter,counts:Counter[str],max_details:int)->dict[str,int]:
    with legacy.open("r",encoding="utf-8-sig",newline="") as lf,candidate.open("r",encoding="utf-8-sig",newline="") as cf:
        lr=csv.DictReader(lf);cr=csv.DictReader(cf);lh=list(lr.fieldnames or []);ch=list(cr.fieldnames or []);keys=list(rule.get("KeyColumns",[]))
        if any(k not in lh or k not in ch for k in keys):raise H6Error(f"KEY_COLUMN:{legacy.name}")
        lrows=list(lr);crows=list(cr);lm={_key(r,keys):r for r in lrows};cm={_key(r,keys):r for r in crows}
        if len(lm)!=len(lrows) or len(cm)!=len(crows):raise H6Error(f"DUPLICATE_KEY:{legacy.name}")
        ignored=set(rule.get("IgnoredColumns",[]));policy=set(rule.get("PolicyColumns",[]));numeric=set(rule.get("NumericColumns",[]));numeric_suffixes=tuple(str(x) for x in rule.get("NumericColumnSuffixes",[]));allowed_extra=set(rule.get("AllowedCandidateAdditionalColumns",[]));allowed_suffixes=tuple(str(x) for x in rule.get("AllowedCandidateAdditionalColumnSuffixes",[]));missing_tokens={str(x).lower() for x in rule.get("MissingTokens",["","na","n/a","null","none","nan"])}
        missing_columns=[c for c in lh if c not in ignored and c not in ch]
        if missing_columns:raise H6Error(f"CANDIDATE_COLUMN_MISSING:{legacy.name}:{missing_columns}")
        extras=[c for c in ch if c not in lh and c not in ignored];unapproved=[c for c in extras if c not in allowed_extra and not c.endswith(allowed_suffixes)]
        if unapproved:raise H6Error(f"CANDIDATE_COLUMN_UNAPPROVED:{legacy.name}:{unapproved}")
        for column in extras:
            counts["APPROVED_ADDITIONAL_PROVENANCE"]+=1
            if sum(counts[c] for c in CLASSES[1:])<=max_details:writer.writerow({"FileName":legacy.name,"RowNumber":"HEADER","Key":"","ColumnName":column,"LegacyValue":"","CandidateValue":"PRESENT","Classification":"APPROVED_ADDITIONAL_PROVENANCE","Reason":"approved candidate-only provenance column"})
        for key in sorted(set(lm)|set(cm)):
            left=lm.get(key);right=cm.get(key)
            if left is None:
                if rule.get("AllowCandidateAdditionalRows"):
                    classification="APPROVED_ADDITIONAL_PROVENANCE";reason="approved candidate-only evidence row"
                else:classification="ROW_IDENTITY_DIFFERENCE_BLOCKING";reason="candidate-only semantic row"
                counts[classification]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details:writer.writerow({"FileName":legacy.name,"RowNumber":"KEYED","Key":key,"ColumnName":"<ROW>","LegacyValue":"MISSING","CandidateValue":"PRESENT","Classification":classification,"Reason":reason})
                continue
            if right is None:
                if rule.get("AllowCandidateMissingRowsAsPolicy"):
                    classification="POLICY_DIFFERENCE_REQUIRES_DECISION";reason="legacy evidence row is not reproduced by the candidate quality model"
                else:classification="ROW_IDENTITY_DIFFERENCE_BLOCKING";reason="candidate omitted legacy semantic row"
                counts[classification]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details:writer.writerow({"FileName":legacy.name,"RowNumber":"KEYED","Key":key,"ColumnName":"<ROW>","LegacyValue":"PRESENT","CandidateValue":"MISSING","Classification":classification,"Reason":reason})
                continue
            for column in [c for c in lh if c not in ignored]:
                a=left.get(column,"");b=right.get(column,"")
                if a==b:continue
                if (_missing(a,missing_tokens) and _missing(b,missing_tokens)) or ((column in numeric or column.endswith(numeric_suffixes)) and _numeric_equal(a,b,float(rule.get("AbsoluteTolerance",1e-12)),float(rule.get("RelativeTolerance",1e-9)))):classification="APPROVED_REPRESENTATION_DIFFERENCE";reason="numerically equivalent serialization"
                elif column in policy:classification="POLICY_DIFFERENCE_REQUIRES_DECISION";reason="declared policy field differs"
                else:classification="VALUE_DIFFERENCE_BLOCKING";reason="semantic value differs"
                counts[classification]+=1
                if sum(counts[c] for c in CLASSES[1:])<=max_details:writer.writerow({"FileName":legacy.name,"RowNumber":"KEYED","Key":key,"ColumnName":column,"LegacyValue":a,"CandidateValue":b,"Classification":classification,"Reason":reason})
        return {"RowsCompared":len(set(lm)|set(cm)),"LegacyColumns":len(lh),"CandidateColumns":len(ch)}


def _flatten(value: Any,prefix: str="") -> dict[str,Any]:
    out: dict[str,Any]={}
    if isinstance(value,dict):
        for key,item in value.items(): out.update(_flatten(item,f"{prefix}.{key}" if prefix else str(key)))
    elif isinstance(value,list): out[prefix]=value
    else: out[prefix]=value
    return out


def compare_json(legacy: Path,candidate: Path,rule: dict[str,Any],writer: csv.DictWriter,counts: Counter[str],max_details:int)->dict[str,int]:
    left=_flatten(load_json(legacy)); right=_flatten(load_json(candidate)); ignored=set(rule.get("IgnoredPaths",[])); policy=set(rule.get("PolicyPaths",[])); required=set(rule.get("RequiredPaths",[]));
    for path in required:
        if path not in left or path not in right: raise H6Error(f"MANIFEST_REQUIRED_PATH:{path}")
    for path in sorted(set(left)|set(right)):
        if path in ignored: continue
        if path not in left:
            classification="APPROVED_ADDITIONAL_PROVENANCE"; reason="candidate-only manifest provenance"
        elif path not in right:
            classification="VALUE_DIFFERENCE_BLOCKING"; reason="candidate omitted legacy manifest field"
        elif left[path]==right[path]: continue
        elif path in policy:
            classification="POLICY_DIFFERENCE_REQUIRES_DECISION"; reason="manifest policy differs"
        else:
            classification="VALUE_DIFFERENCE_BLOCKING"; reason="manifest semantic identity differs"
        counts[classification]+=1
        if sum(counts[c] for c in CLASSES[1:])<=max_details: writer.writerow({"FileName":legacy.name,"RowNumber":"JSON","Key":path,"ColumnName":path,"LegacyValue":json.dumps(left.get(path),ensure_ascii=False),"CandidateValue":json.dumps(right.get(path),ensure_ascii=False),"Classification":classification,"Reason":reason})
    return {"RowsCompared":len(set(left)|set(right)),"LegacyColumns":len(left),"CandidateColumns":len(right)}


def replay(legacy: Path,candidate: Path,rules_path: Path,out: Path)->dict[str,Any]:
    validate_package(legacy,"LEGACY"); validate_package(candidate,"CANDIDATE")
    rules=load_json(rules_path); file_rules=rules.get("Files")
    if rules.get("RulesSchema")!="U001_H6_DIFFERENTIAL_RULES_V1_0" or not isinstance(file_rules,dict): raise H6Error("RULES_SCHEMA")
    out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()): raise H6Error("OUTPUT_NOT_EMPTY")
    staging=Path(tempfile.mkdtemp(prefix=".u1h6_",dir=str(out.parent))); counts:Counter[str]=Counter(); summaries=[]; max_details=int(rules.get("MaxDetailedDifferences",10000))
    try:
        with (staging/"u001_h6_differences.csv").open("w",encoding="utf-8",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=DIFF_COLUMNS,lineterminator="\n"); writer.writeheader()
            for name in FILES:
                rule=file_rules.get(name)
                if not isinstance(rule,dict): raise H6Error(f"FILE_RULE:{name}")
                if name.endswith(".json"):result=compare_json(legacy/name,candidate/name,rule,writer,counts,max_details)
                elif rule.get("ComparisonMode")=="KEYED_SMALL":result=compare_csv_keyed(legacy/name,candidate/name,rule,writer,counts,max_details)
                else:result=compare_csv(legacy/name,candidate/name,rule,writer,counts,max_details)
                summaries.append({"FileName":name,**result})
        blocking=counts["VALUE_DIFFERENCE_BLOCKING"]+counts["ROW_IDENTITY_DIFFERENCE_BLOCKING"]
        decision=counts["POLICY_DIFFERENCE_REQUIRES_DECISION"]
        status="BLOCKED" if blocking else ("DECISION_REQUIRED" if decision else "ACCEPTABLE_EQUIVALENCE")
        summary_fields=["FileName","RowsCompared","LegacyColumns","CandidateColumns"]
        with (staging/"u001_h6_file_summary.csv").open("w",encoding="utf-8",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=summary_fields,lineterminator="\n");writer.writeheader();writer.writerows(summaries)
        manifest={"ManifestSchema":"U001_H6_DIFFERENTIAL_REPLAY_V1_0","ProgramName":PROGRAM_NAME,"ProgramVersion":PROGRAM_VERSION,"LegacyPackageSHA256":{n:sha256(legacy/n) for n in FILES},"CandidatePackageSHA256":{n:sha256(candidate/n) for n in FILES},"RulesSHA256":sha256(rules_path),"ClassCounts":{c:counts[c] for c in CLASSES[1:]},"DetailedDifferenceLimit":max_details,"Status":status,"CompletionCode":0,"CreatedUTC":datetime.now(timezone.utc).isoformat()}
        (staging/"u001_h6_replay_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
        capsule=f"U1H6-S{status[0]}-R{counts['APPROVED_REPRESENTATION_DIFFERENCE']}-A{counts['APPROVED_ADDITIONAL_PROVENANCE']}-P{decision}-V{counts['VALUE_DIFFERENCE_BLOCKING']}-K{counts['ROW_IDENTITY_DIFFERENCE_BLOCKING']}-X0-C0"
        (staging/"u001_h6_replay_capsule.txt").write_text(capsule+"\n",encoding="utf-8")
        for path in staging.iterdir(): os.replace(path,out/path.name)
        staging.rmdir(); return manifest
    except Exception:
        import shutil; shutil.rmtree(staging,ignore_errors=True); raise


def self_test()->None:
    assert len(FILES)==6 and len(CLASSES)==6
    assert _numeric_equal("1.0","1.000",1e-12,1e-9)
    assert _flatten({"a":{"b":1}})=={"a.b":1}


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--self-test",action="store_true");p.add_argument("--legacy",type=Path);p.add_argument("--candidate",type=Path);p.add_argument("--rules",type=Path);p.add_argument("--out",type=Path);a=p.parse_args()
    if a.self_test:self_test();print("U001-H6-REPLAY-SELFTEST-PASS-3");return 0
    if any(x is None for x in (a.legacy,a.candidate,a.rules,a.out)):p.error("--legacy --candidate --rules --out are required")
    try:
        result=replay(a.legacy,a.candidate,a.rules,a.out); c=result["ClassCounts"]; print(f"U1H6-S{result['Status'][0]}-R{c['APPROVED_REPRESENTATION_DIFFERENCE']}-A{c['APPROVED_ADDITIONAL_PROVENANCE']}-P{c['POLICY_DIFFERENCE_REQUIRES_DECISION']}-V{c['VALUE_DIFFERENCE_BLOCKING']}-K{c['ROW_IDENTITY_DIFFERENCE_BLOCKING']}-X0-C0");return 0
    except Exception as exc: print(f"U1H6-ERROR-{type(exc).__name__}-{str(exc)[:180]}-X1-C7");return 7


if __name__=="__main__":raise SystemExit(main())
