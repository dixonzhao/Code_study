#!/usr/bin/env python3
"""Reference PROCESS Module implementing one engineer-triggered action."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise RuntimeError("Request must contain one JSON object.")
    return value


def write_object(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def execute(request_path: Path, result_path: Path) -> int:
    request = read_object(request_path)
    if request.get("ContractId") != "U003_MODULE_ACTION_REQUEST":
        raise RuntimeError("Unsupported request contract.")
    if request.get("ActionId") != "WRITE_CONTEXT_SUMMARY":
        raise RuntimeError("Unsupported action.")
    context = request.get("Context")
    if not isinstance(context, dict):
        raise RuntimeError("Context must be one JSON object.")
    output_directory = Path(str(context["OutputDirectory"])).resolve()
    output_directory.mkdir(parents=True, exist_ok=True)
    framecount = int(context["CurrentCANFrameCount"])
    event_id = str(request.get("EventId", "NO_EVENT"))
    artifact_path = output_directory / f"u003_context_{event_id}_{framecount}.json"
    artifact = {
        "ArtifactId": "U003_ACTION_CONTEXT_SUMMARY",
        "ArtifactVersion": "0.1",
        "CreatedUtc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "RunId": request["RunId"],
        "EventId": event_id,
        "CurrentCANFrameCount": framecount,
        "Language": request["Language"],
    }
    write_object(artifact_path, artifact)
    result = {
        "ContractId": "U003_MODULE_ACTION_RESULT",
        "ContractVersion": "0.1",
        "RequestId": request["RequestId"],
        "RunId": request["RunId"],
        "EventId": request["EventId"],
        "ActionId": request["ActionId"],
        "ModuleId": request["ModuleId"],
        "ModuleVersion": request["ModuleVersion"],
        "Status": "SUCCESS",
        "Outputs": {
            "ArtifactPaths": [str(artifact_path)],
            "ActionSummary": f"Context summary written for FrameCount {framecount}.",
        },
        "Warnings": [],
        "RootCauseClaim": False,
    }
    write_object(result_path, result)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--result", type=Path)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    if not arguments.execute or arguments.request is None or arguments.result is None:
        raise RuntimeError("Use --execute --request <path> --result <path>.")
    return execute(arguments.request, arguments.result)


if __name__ == "__main__":
    raise SystemExit(main())
