#!/usr/bin/env python3
"""Governed discovery and validation runtime for U003 modules.

Manifest v0.2 adds engineer-triggered ``UserActions`` while retaining full
read compatibility with the accepted v0.1 lifecycle-only packages.  This
runtime validates package shape only; execution remains isolated elsewhere.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


RUNTIME_VERSION = "0.2"
CONTRACT_ID = "U003_MODULE_MANIFEST"
CONTRACT_VERSIONS = ("0.1", "0.2")
MODULE_SLOTS = (
    "IMPORT_ADAPTER",
    "EVIDENCE_VIEW",
    "REVIEW_ASSIST",
    "EXPORT",
)
EXECUTION_KINDS = ("DECLARATIVE", "PROCESS")
LIFECYCLE_HOOKS = (
    "ON_HANDOFF_LOADED",
    "ON_EVENT_SELECTED",
    "ON_REVIEW_SAVED",
    "ON_EXPORT",
)
PROCESS_TRANSPORTS = ("PYTHON_SOURCE", "NATIVE_EXECUTABLE")
PROTECTED_FIELDS = (
    "EventID",
    "CandidateId",
    "ReviewStartFrame",
    "PeakFrameCount",
    "ReviewEndFrame",
    "CandidateRank",
    "PriorityClass",
    "AnomalyScore",
    "ReviewData",
    "ReviewResult",
    "EngineerReviewMemo",
)
MODULE_ID_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9]*(\.[A-Za-z0-9_]+)+$")
SEMVER_PATTERN = re.compile(r"^([0-9]+)\.([0-9]+)\.([0-9]+)$")
ALGORITHM_CARD_PATTERN = re.compile(r"^[^/\\]+\.json$")
ACTION_ID_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]{2,63}$")


class ModuleContractError(RuntimeError):
    """Raised when a discovered module violates the governed contract."""


@dataclass(frozen=True)
class ModuleActionDescriptor:
    """One engineer-triggered action declared by a qualified Module package."""

    action_id: str
    display_name_en: str
    display_name_ja: str
    description_en: str
    description_ja: str
    required_context_fields: tuple[str, ...]
    produced_fields: tuple[str, ...]
    timeout_seconds: int

    def localized_name(self, language: str) -> str:
        if language.upper() == "JA" and self.display_name_ja.strip():
            return self.display_name_ja
        return self.display_name_en

    def localized_description(self, language: str) -> str:
        if language.upper() == "JA" and self.description_ja.strip():
            return self.description_ja
        return self.description_en


@dataclass(frozen=True)
class ModuleDescriptor:
    manifest_contract_version: str
    module_id: str
    module_version: str
    module_slot: str
    execution_kind: str
    display_name_en: str
    display_name_ja: str
    description_en: str
    description_ja: str
    lifecycle_hooks: tuple[str, ...]
    required_context_fields: tuple[str, ...]
    produced_fields: tuple[str, ...]
    enabled_by_default: bool
    manifest_path: str
    algorithm_card_path: str
    process_transport: str | None
    process_entry_path: str | None
    timeout_seconds: int | None
    user_actions: tuple[ModuleActionDescriptor, ...]
    package_sha256: str

    @property
    def semantic_version(self) -> tuple[int, int, int]:
        match = SEMVER_PATTERN.fullmatch(self.module_version)
        if match is None:
            raise ModuleContractError(f"Invalid semantic version: {self.module_version}")
        return tuple(int(value) for value in match.groups())

    def localized_name(self, language: str) -> str:
        """Return Japanese text when requested and available, otherwise English."""

        if language.upper() == "JA" and self.display_name_ja.strip():
            return self.display_name_ja
        return self.display_name_en

    def localized_description(self, language: str) -> str:
        """Use visible English fallback instead of returning an empty label."""

        if language.upper() == "JA" and self.description_ja.strip():
            return self.description_ja
        return self.description_en


@dataclass(frozen=True)
class ModuleCatalog:
    module_root: str
    descriptors: tuple[ModuleDescriptor, ...]
    selected_versions: dict[str, str]

    def to_json_payload(self) -> dict[str, Any]:
        return {
            "CatalogId": "U003_MODULE_CATALOG",
            "CatalogVersion": RUNTIME_VERSION,
            "ModuleRoot": self.module_root,
            "ModuleVersionCount": len(self.descriptors),
            "ModuleIdCount": len(self.selected_versions),
            "SelectedVersions": dict(sorted(self.selected_versions.items())),
            "Modules": [asdict(item) for item in self.descriptors],
        }


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise ModuleContractError(f"{label} is missing or is not a regular file: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise ModuleContractError(f"{label} is not valid JSON: {path}: {error}") from error
    if not isinstance(value, dict):
        raise ModuleContractError(f"{label} must contain one JSON object: {path}")
    return value


def _required_string(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ModuleContractError(f"Manifest field {key} must be a non-empty string.")
    return value.strip()


def _required_boolean(mapping: dict[str, Any], key: str) -> bool:
    value = mapping.get(key)
    if not isinstance(value, bool):
        raise ModuleContractError(f"Manifest field {key} must be boolean.")
    return value


def _unique_string_list(mapping: dict[str, Any], key: str) -> tuple[str, ...]:
    value = mapping.get(key)
    if not isinstance(value, list):
        raise ModuleContractError(f"Manifest field {key} must be an array.")
    normalized: list[str] = []
    for item in value:
        if not isinstance(item, str) or not item.strip():
            raise ModuleContractError(f"Manifest field {key} contains an invalid item.")
        normalized.append(item.strip())
    if len(set(normalized)) != len(normalized):
        raise ModuleContractError(f"Manifest field {key} contains duplicate items.")
    return tuple(normalized)


def _localized_text(mapping: dict[str, Any], key: str) -> tuple[str, str]:
    value = mapping.get(key)
    if not isinstance(value, dict):
        raise ModuleContractError(f"Manifest field {key} must be a localized object.")
    extra = set(value) - {"EN", "JA"}
    if extra:
        raise ModuleContractError(f"Manifest field {key} has unsupported keys: {sorted(extra)}")
    english = value.get("EN")
    japanese = value.get("JA", "")
    if not isinstance(english, str) or not english.strip():
        raise ModuleContractError(f"Manifest field {key}.EN must be non-empty.")
    if not isinstance(japanese, str):
        raise ModuleContractError(f"Manifest field {key}.JA must be a string.")
    return english.strip(), japanese.strip()


def _validate_user_actions(
    manifest: dict[str, Any],
    execution_kind: str,
) -> tuple[ModuleActionDescriptor, ...]:
    """Validate optional v0.2 engineer-triggered action declarations."""

    raw_actions = manifest.get("UserActions", [])
    if not isinstance(raw_actions, list):
        raise ModuleContractError("Manifest field UserActions must be an array.")
    if raw_actions and execution_kind != "PROCESS":
        raise ModuleContractError("Only PROCESS modules may declare UserActions.")

    actions: list[ModuleActionDescriptor] = []
    for index, raw_action in enumerate(raw_actions):
        if not isinstance(raw_action, dict):
            raise ModuleContractError(f"UserActions[{index}] must be an object.")
        action_id = _required_string(raw_action, "ActionId")
        if ACTION_ID_PATTERN.fullmatch(action_id) is None:
            raise ModuleContractError(f"User ActionId is invalid: {action_id}")
        name_en, name_ja = _localized_text(raw_action, "DisplayName")
        description_en, description_ja = _localized_text(raw_action, "Description")
        required_fields = _unique_string_list(raw_action, "RequiredContextFields")
        produced_fields = _unique_string_list(raw_action, "ProducedFields")
        protected_outputs = sorted(set(produced_fields) & set(PROTECTED_FIELDS))
        if protected_outputs:
            raise ModuleContractError(
                f"User Action produced fields are protected: {protected_outputs}"
            )
        timeout_value = raw_action.get("TimeoutSeconds")
        if isinstance(timeout_value, bool) or not isinstance(timeout_value, int):
            raise ModuleContractError("User Action TimeoutSeconds must be an integer.")
        if not 1 <= timeout_value <= 3600:
            raise ModuleContractError(
                "User Action TimeoutSeconds must be between 1 and 3600."
            )
        actions.append(
            ModuleActionDescriptor(
                action_id=action_id,
                display_name_en=name_en,
                display_name_ja=name_ja,
                description_en=description_en,
                description_ja=description_ja,
                required_context_fields=required_fields,
                produced_fields=produced_fields,
                timeout_seconds=timeout_value,
            )
        )
    identities = [action.action_id for action in actions]
    if len(set(identities)) != len(identities):
        raise ModuleContractError("UserActions contains duplicate ActionId values.")
    return tuple(actions)


def _hash_files(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.name.lower()):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        digest.update(b"\0")
    return digest.hexdigest()


def validate_module_manifest(manifest_path: Path, module_root: Path) -> ModuleDescriptor:
    """Validate one module package without importing or executing its code."""

    manifest_path = manifest_path.resolve()
    module_root = module_root.resolve()
    try:
        manifest_path.relative_to(module_root)
    except ValueError as error:
        raise ModuleContractError("Module manifest escapes the governed module root.") from error

    manifest = _read_json_object(manifest_path, "Module manifest")
    if manifest.get("ContractId") != CONTRACT_ID:
        raise ModuleContractError("Module manifest ContractId is not accepted.")
    manifest_contract_version = str(manifest.get("ContractVersion", ""))
    if manifest_contract_version not in CONTRACT_VERSIONS:
        raise ModuleContractError("Module manifest ContractVersion is not accepted.")

    module_id = _required_string(manifest, "ModuleId")
    module_version = _required_string(manifest, "ModuleVersion")
    module_slot = _required_string(manifest, "ModuleSlot")
    execution_kind = _required_string(manifest, "ExecutionKind")
    if MODULE_ID_PATTERN.fullmatch(module_id) is None:
        raise ModuleContractError(f"ModuleId is invalid: {module_id}")
    if SEMVER_PATTERN.fullmatch(module_version) is None:
        raise ModuleContractError(f"ModuleVersion is not MAJOR.MINOR.PATCH: {module_version}")
    if module_slot not in MODULE_SLOTS:
        raise ModuleContractError(f"ModuleSlot is not accepted: {module_slot}")
    if execution_kind not in EXECUTION_KINDS:
        raise ModuleContractError(f"ExecutionKind is not accepted: {execution_kind}")

    expected_directory = module_root / module_slot / module_id / module_version
    if manifest_path.parent != expected_directory.resolve():
        raise ModuleContractError(
            "Module directory must be <root>/<slot>/<ModuleId>/<ModuleVersion>."
        )

    name_en, name_ja = _localized_text(manifest, "DisplayName")
    description_en, description_ja = _localized_text(manifest, "Description")
    hooks = _unique_string_list(manifest, "LifecycleHooks")
    invalid_hooks = sorted(set(hooks) - set(LIFECYCLE_HOOKS))
    if invalid_hooks:
        raise ModuleContractError(f"Unsupported LifecycleHooks: {invalid_hooks}")
    required_fields = _unique_string_list(manifest, "RequiredContextFields")
    produced_fields = _unique_string_list(manifest, "ProducedFields")
    user_actions = _validate_user_actions(manifest, execution_kind)
    if manifest_contract_version == "0.1" and user_actions:
        raise ModuleContractError("Manifest v0.1 must not declare UserActions.")
    protected_mutation = _unique_string_list(manifest, "ProtectedFieldMutation")
    if protected_mutation:
        raise ModuleContractError(
            "ProtectedFieldMutation must remain empty; modules enrich but do not rewrite core evidence."
        )
    protected_outputs = sorted(set(produced_fields) & set(PROTECTED_FIELDS))
    if protected_outputs:
        raise ModuleContractError(f"ProducedFields contains protected fields: {protected_outputs}")

    algorithm_card_name = _required_string(manifest, "AlgorithmCard")
    if ALGORITHM_CARD_PATTERN.fullmatch(algorithm_card_name) is None:
        raise ModuleContractError("AlgorithmCard must be a local JSON filename.")
    algorithm_card_path = manifest_path.parent / algorithm_card_name
    algorithm_card = _read_json_object(algorithm_card_path, "Algorithm Card")
    for required_card_field in (
        "AlgorithmCardId",
        "Purpose",
        "RealityMeaning",
        "Inputs",
        "Outputs",
        "Assumptions",
        "Limitations",
        "Validation",
    ):
        if required_card_field not in algorithm_card:
            raise ModuleContractError(
                f"Algorithm Card field {required_card_field} is missing: {algorithm_card_path}"
            )

    process_transport: str | None = None
    process_entry_path: str | None = None
    timeout_seconds: int | None = None
    package_files = [manifest_path, algorithm_card_path]
    process = manifest.get("Process")
    if execution_kind == "PROCESS":
        if not isinstance(process, dict):
            raise ModuleContractError("PROCESS module requires a Process object.")
        process_transport = _required_string(process, "Transport")
        if process_transport not in PROCESS_TRANSPORTS:
            raise ModuleContractError(f"Process Transport is not accepted: {process_transport}")
        entry_name = _required_string(process, "EntryPoint")
        entry_path = (manifest_path.parent / entry_name).resolve()
        if entry_path.parent != manifest_path.parent or not entry_path.is_file():
            raise ModuleContractError("Process EntryPoint must be a local regular file.")
        timeout_value = process.get("TimeoutSeconds")
        if isinstance(timeout_value, bool) or not isinstance(timeout_value, int):
            raise ModuleContractError("Process TimeoutSeconds must be an integer.")
        if not 1 <= timeout_value <= 300:
            raise ModuleContractError("Process TimeoutSeconds must be between 1 and 300.")
        process_entry_path = str(entry_path)
        timeout_seconds = timeout_value
        package_files.append(entry_path)
    elif process is not None:
        raise ModuleContractError("DECLARATIVE module must not declare Process.")

    return ModuleDescriptor(
        manifest_contract_version=manifest_contract_version,
        module_id=module_id,
        module_version=module_version,
        module_slot=module_slot,
        execution_kind=execution_kind,
        display_name_en=name_en,
        display_name_ja=name_ja,
        description_en=description_en,
        description_ja=description_ja,
        lifecycle_hooks=hooks,
        required_context_fields=required_fields,
        produced_fields=produced_fields,
        enabled_by_default=_required_boolean(manifest, "EnabledByDefault"),
        manifest_path=str(manifest_path),
        algorithm_card_path=str(algorithm_card_path.resolve()),
        process_transport=process_transport,
        process_entry_path=process_entry_path,
        timeout_seconds=timeout_seconds,
        user_actions=user_actions,
        package_sha256=_hash_files(package_files),
    )


def discover_modules(module_root: Path) -> ModuleCatalog:
    """Discover every version, validate all packages, and select the newest version."""

    module_root = module_root.resolve()
    if not module_root.is_dir() or module_root.is_symlink():
        raise ModuleContractError(f"Module root is missing or invalid: {module_root}")
    manifest_paths = sorted(module_root.glob("*/*/*/module_manifest.json"))
    if not manifest_paths:
        raise ModuleContractError(f"No module manifests were found under: {module_root}")

    descriptors = tuple(
        validate_module_manifest(path, module_root)
        for path in manifest_paths
    )
    identities = [(item.module_id, item.module_version) for item in descriptors]
    if len(set(identities)) != len(identities):
        raise ModuleContractError("Duplicate ModuleId and ModuleVersion identity detected.")

    selected: dict[str, ModuleDescriptor] = {}
    for descriptor in descriptors:
        current = selected.get(descriptor.module_id)
        if current is None or descriptor.semantic_version > current.semantic_version:
            selected[descriptor.module_id] = descriptor
    selected_versions = {
        module_id: descriptor.module_version
        for module_id, descriptor in selected.items()
    }
    return ModuleCatalog(
        module_root=str(module_root),
        descriptors=tuple(
            sorted(
                descriptors,
                key=lambda item: (item.module_slot, item.module_id, item.semantic_version),
            )
        ),
        selected_versions=selected_versions,
    )


def write_catalog(catalog: ModuleCatalog, output_path: Path) -> None:
    output_path = output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    writing_path = output_path.with_name(output_path.name + ".writing")
    writing_path.write_text(
        json.dumps(catalog.to_json_payload(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    writing_path.replace(output_path)


def _write_fixture_module(
    module_root: Path,
    version: str,
    japanese_description: str,
) -> Path:
    module_directory = (
        module_root
        / "REVIEW_ASSIST"
        / "CameraRadar.U003.SelfTestLabels"
        / version
    )
    module_directory.mkdir(parents=True)
    manifest = {
        "ContractId": CONTRACT_ID,
        "ContractVersion": "0.1",
        "ModuleId": "CameraRadar.U003.SelfTestLabels",
        "ModuleVersion": version,
        "ModuleSlot": "REVIEW_ASSIST",
        "ExecutionKind": "DECLARATIVE",
        "DisplayName": {"EN": "Self-test labels", "JA": ""},
        "Description": {"EN": "Self-test description", "JA": japanese_description},
        "LifecycleHooks": ["ON_EVENT_SELECTED"],
        "RequiredContextFields": ["ReviewCode"],
        "ProducedFields": ["ReviewCodeLabelEN"],
        "ProtectedFieldMutation": [],
        "AlgorithmCard": "algorithm_card.json",
        "EnabledByDefault": True,
    }
    card = {
        "AlgorithmCardId": f"CameraRadar.U003.SelfTestLabels.{version}",
        "Purpose": "Validate module discovery.",
        "RealityMeaning": "Confirms the governed module boundary.",
        "Inputs": {"ReviewCode": "Synthetic code."},
        "Outputs": {"ReviewCodeLabelEN": "Synthetic label."},
        "Assumptions": [],
        "Limitations": [],
        "Validation": ["Discovered without importing code."],
    }
    manifest_path = module_directory / "module_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    (module_directory / "algorithm_card.json").write_text(
        json.dumps(card), encoding="utf-8"
    )
    return manifest_path


def _write_action_fixture_module(module_root: Path) -> Path:
    """Write one v0.2 PROCESS fixture proving the manual-action contract."""

    module_directory = (
        module_root
        / "EXPORT"
        / "CameraRadar.U003.SelfTestAction"
        / "0.1.0"
    )
    module_directory.mkdir(parents=True)
    manifest = {
        "ContractId": CONTRACT_ID,
        "ContractVersion": "0.2",
        "ModuleId": "CameraRadar.U003.SelfTestAction",
        "ModuleVersion": "0.1.0",
        "ModuleSlot": "EXPORT",
        "ExecutionKind": "PROCESS",
        "DisplayName": {"EN": "Self-test action", "JA": ""},
        "Description": {"EN": "Exercises a user action.", "JA": ""},
        "LifecycleHooks": [],
        "RequiredContextFields": [],
        "ProducedFields": [],
        "UserActions": [
            {
                "ActionId": "WRITE_CONTEXT_SUMMARY",
                "DisplayName": {"EN": "Write summary", "JA": "概要を出力"},
                "Description": {
                    "EN": "Writes a traceable context summary.",
                    "JA": "追跡可能なコンテキスト概要を出力します。",
                },
                "RequiredContextFields": ["OutputDirectory", "CurrentCANFrameCount"],
                "ProducedFields": ["ArtifactPaths", "ActionSummary"],
                "TimeoutSeconds": 60,
            }
        ],
        "ProtectedFieldMutation": [],
        "AlgorithmCard": "algorithm_card.json",
        "EnabledByDefault": False,
        "Process": {
            "Transport": "PYTHON_SOURCE",
            "EntryPoint": "implementation.py",
            "TimeoutSeconds": 10,
        },
    }
    card = {
        "AlgorithmCardId": "CameraRadar.U003.SelfTestAction.0.1.0",
        "Purpose": "Validate manual action discovery.",
        "RealityMeaning": "Confirms that engineer-triggered tools share one governed interface.",
        "Inputs": {"CurrentCANFrameCount": "Synthetic frame."},
        "Outputs": {"ArtifactPaths": "Synthetic output."},
        "Assumptions": [],
        "Limitations": [],
        "Validation": ["Validated without importing implementation code."],
    }
    manifest_path = module_directory / "module_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    (module_directory / "algorithm_card.json").write_text(
        json.dumps(card), encoding="utf-8"
    )
    (module_directory / "implementation.py").write_text(
        "raise SystemExit('fixture must not be imported')\n",
        encoding="utf-8",
    )
    return manifest_path


def run_self_test() -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    with tempfile.TemporaryDirectory(prefix="u003_u3m1_") as temporary:
        root = Path(temporary)
        module_root = root / "02_MODULES"
        first_path = _write_fixture_module(module_root, "0.1.0", "")
        second_path = _write_fixture_module(module_root, "0.2.0", "日本語説明")
        action_path = _write_action_fixture_module(module_root)

        first = validate_module_manifest(first_path, module_root)
        check(first.module_slot == "REVIEW_ASSIST", "slot preserved", "prevents cross-slot loading")
        check(first.execution_kind == "DECLARATIVE", "declarative kind", "does not execute code")
        check(first.localized_name("JA") == "Self-test labels", "name fallback", "blank JA uses EN")
        check(first.localized_description("JA") == "Self-test description", "description fallback", "blank JA uses EN")
        check(len(first.package_sha256) == 64, "package hash", "binds manifest and Algorithm Card")
        check(not first.process_entry_path, "no process entry", "declarative modules have no executable")

        second = validate_module_manifest(second_path, module_root)
        check(second.localized_description("JA") == "日本語説明", "Japanese selection", "uses JA when available")
        check(second.semantic_version == (0, 2, 0), "semantic version", "supports deterministic version ordering")

        catalog = discover_modules(module_root)
        check(len(catalog.descriptors) == 3, "all versions retained", "older versions and action packages remain selectable")
        check(len(catalog.selected_versions) == 2, "two module families", "groups versions by ModuleId")
        check(catalog.selected_versions[first.module_id] == "0.2.0", "latest selected", "newest semantic version is default")
        ordered_identities = [
            (item.module_slot, item.module_id, item.module_version)
            for item in catalog.descriptors
        ]
        check(ordered_identities == sorted(ordered_identities), "stable ordering", "catalog output is deterministic")

        catalog_path = root / "catalog.json"
        write_catalog(catalog, catalog_path)
        catalog_payload = _read_json_object(catalog_path, "Catalog")
        check(catalog_payload["ModuleVersionCount"] == 3, "catalog count", "records every discovered version")
        check(catalog_payload["ModuleIdCount"] == 2, "catalog family count", "records grouped module identities")
        check(catalog_payload["SelectedVersions"][first.module_id] == "0.2.0", "catalog selection", "persists default version")

        invalid_manifest = json.loads(first_path.read_text(encoding="utf-8"))
        invalid_manifest["ProducedFields"] = ["PeakFrameCount"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("protected fields" in str(error), "protected output rejected", "modules cannot rewrite evidence identity")
        else:
            raise AssertionError("protected output was accepted")

        invalid_manifest["ProducedFields"] = ["ReviewCodeLabelEN"]
        invalid_manifest["ProtectedFieldMutation"] = ["ReviewResult"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("must remain empty" in str(error), "mutation rejected", "engineer decision remains core-owned")
        else:
            raise AssertionError("protected mutation was accepted")

        invalid_manifest["ProtectedFieldMutation"] = []
        invalid_manifest["LifecycleHooks"] = ["UNKNOWN_HOOK"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("Unsupported LifecycleHooks" in str(error), "unknown hook rejected", "lifecycle remains fixed")
        else:
            raise AssertionError("unknown hook was accepted")

        action_module = validate_module_manifest(action_path, module_root)
        check(action_module.manifest_contract_version == "0.2", "v0.2 accepted", "manual actions use an explicit contract upgrade")
        check(len(action_module.user_actions) == 1, "action discovered", "GUI can enumerate engineer-triggered tools")
        action = action_module.user_actions[0]
        check(action.action_id == "WRITE_CONTEXT_SUMMARY", "action identity", "execution can bind an exact action")
        check(action.localized_name("JA") == "概要を出力", "action localization", "session language reaches action labels")
        check(action.timeout_seconds == 60, "action timeout", "longer interactive work remains bounded")
        check("ArtifactPaths" in action.produced_fields, "action outputs governed", "artifact handoff is explicit")

        invalid_action_manifest = json.loads(action_path.read_text(encoding="utf-8"))
        invalid_action_manifest["UserActions"][0]["ProducedFields"] = ["ReviewResult"]
        action_path.write_text(json.dumps(invalid_action_manifest), encoding="utf-8")
        try:
            validate_module_manifest(action_path, module_root)
        except ModuleContractError as error:
            check("protected" in str(error), "action mutation rejected", "manual tools cannot overwrite engineer decisions")
        else:
            raise AssertionError("protected action output was accepted")

        check(CONTRACT_ID == "U003_MODULE_MANIFEST", "contract identity", "prevents unrelated manifests")
        check(CONTRACT_VERSIONS == ("0.1", "0.2"), "contract versions", "keeps legacy packages while adding actions")
        check(len(MODULE_SLOTS) == 4, "four slots", "keeps U003 extension responsibilities bounded")
        check("ReviewResult" in PROTECTED_FIELDS, "review protected", "module suggestions cannot become final decisions")
        check("PeakFrameCount" in PROTECTED_FIELDS, "peak protected", "U002 candidate evidence is immutable")
        check("ON_EXPORT" in LIFECYCLE_HOOKS, "export hook governed", "optional reports have a fixed entry point")
        check(len(PROCESS_TRANSPORTS) == 2, "two transports", "supports development source and portable executable")

    if checks != 32:
        raise AssertionError(f"self-test count {checks} != 32")
    print("U003-U3M7-RUNTIME-SELFTEST-PASS-32 C-0")
    return 0


def print_catalog_summary(catalog: ModuleCatalog) -> None:
    process_count = sum(
        descriptor.execution_kind == "PROCESS"
        for descriptor in catalog.descriptors
    )
    enabled_count = sum(
        descriptor.enabled_by_default
        for descriptor in catalog.descriptors
    )
    japanese_count = sum(
        bool(descriptor.description_ja.strip())
        for descriptor in catalog.descriptors
    )
    print("Validated module catalog:")
    for descriptor in catalog.descriptors:
        print(
            f"  [{descriptor.module_slot}] {descriptor.module_id} "
            f"v{descriptor.module_version} | {descriptor.execution_kind} | "
            f"SHA256 {descriptor.package_sha256[:12]}"
        )
    print(
        f"U3M1R N-M{len(catalog.descriptors)}-G{len(catalog.selected_versions)}-"
        f"D{enabled_count}-P{process_count}-J{japanese_count}-X0 C-0"
    )


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--scan-root", type=Path)
    parser.add_argument("--catalog-output", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if arguments.self_test:
            return run_self_test()
        if arguments.scan_root is None:
            raise ModuleContractError("Use --self-test or provide --scan-root.")
        catalog = discover_modules(arguments.scan_root)
        if arguments.catalog_output is not None:
            write_catalog(catalog, arguments.catalog_output)
        print_catalog_summary(catalog)
        return 0
    except Exception as error:
        print(f"U3M1E K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
