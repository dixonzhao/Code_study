#!/usr/bin/env python3
"""Independent source acceptance gate for the U3M7 Module Action interface."""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path


GATE_VERSION = "0.1"


def run_gate(package_root: Path) -> int:
    package_root = package_root.resolve()
    program_root = package_root / "01_PROGRAMS"
    module_root = package_root / "02_MODULES"
    contract_root = package_root / "02_CONTROLS" / "contracts"
    if str(program_root) not in sys.path:
        sys.path.insert(0, str(program_root))

    import u003_evidence_review_workbench_v0_19 as workbench
    import u003_gui_shell_v0_6 as gui_shell
    import u003_module_action_gui_v0_1 as action_gui
    import u003_module_execution_coordinator_v0_3 as coordinator_module
    import u003_module_executor_v0_3 as executor
    import u003_module_manager_gui_v0_4 as manager
    import u003_module_plan_core_v0_2 as plan_core
    import u003_module_runtime_v0_2 as runtime

    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    check(package_root.is_dir(), "package root", "acceptance is bound to one update package")
    check(runtime.RUNTIME_VERSION == "0.2", "runtime version", "manifest v0.2 is active")
    check(executor.EXECUTOR_VERSION == "0.3", "executor version", "action request/result path is active")
    check(plan_core.PLAN_CORE_VERSION == "0.2", "plan version", "plans resolve v0.2 descriptors")
    check(manager.MANAGER_VERSION == "0.4", "manager version", "action inventory is visible")
    check(coordinator_module.COORDINATOR_VERSION == "0.3", "coordinator version", "manual actions are coordinated")
    check(action_gui.ACTION_GUI_VERSION == "0.1", "action GUI version", "engineer actions have a visual launcher")
    check(gui_shell.GUI_SHELL_VERSION == "0.6", "GUI shell version", "launcher is connected to review context")
    check(workbench.VERSION == "0.19", "composition version", "all active pieces are pinned")

    manifest_schema = json.loads(
        (contract_root / "u003_module_contract_v0_2.json").read_text(encoding="utf-8")
    )
    action_contract = json.loads(
        (contract_root / "u003_module_action_contract_bundle_v0_1.json").read_text(
            encoding="utf-8"
        )
    )
    check(manifest_schema["$id"] == "U003_MODULE_MANIFEST_V0_2", "manifest schema", "UserActions are formally versioned")
    check("UserActions" in manifest_schema["properties"], "action declaration", "package actions are machine-readable")
    check(action_contract["Request"]["ContractId"] == executor.ACTION_REQUEST_CONTRACT_ID, "request contract", "executor and contract agree")
    check(action_contract["Result"]["ContractId"] == executor.ACTION_RESULT_CONTRACT_ID, "result contract", "module and executor agree")
    check(action_contract["Execution"]["Caching"].startswith("Disabled"), "no action cache", "every click produces new evidence")

    catalog = runtime.discover_modules(module_root)
    sample_descriptor = plan_core.find_descriptor(
        catalog,
        "CameraRadar.U003.SampleArtifactAction",
        "0.1.0",
    )
    check(sample_descriptor.manifest_contract_version == "0.2", "sample manifest", "reference package exercises the new contract")
    check(sample_descriptor.execution_kind == "PROCESS", "sample isolation", "implementation runs outside the GUI process")
    check(len(sample_descriptor.user_actions) == 1, "sample action count", "one deterministic action is exposed")
    sample_action = sample_descriptor.user_actions[0]
    check(sample_action.action_id == "WRITE_CONTEXT_SUMMARY", "sample action identity", "selection binds an explicit action")
    check("OutputDirectory" in sample_action.required_context_fields, "output required", "artifacts cannot be written to an implicit location")
    check("ArtifactPaths" in sample_action.produced_fields, "artifact inventory", "generated files return through a fixed field")
    check(not (set(sample_action.produced_fields) & set(runtime.PROTECTED_FIELDS)), "protected boundary", "action cannot rewrite evidence or review state")

    with tempfile.TemporaryDirectory(prefix="u003_u3m7_gate_") as temporary:
        temporary_root = Path(temporary)
        coordinator = coordinator_module.ModuleExecutionCoordinator(
            module_root=module_root,
            run_root=temporary_root / "runs",
            language="JA",
        )
        plan = plan_core.empty_plan(module_root, "JA")
        plan = plan_core.add_or_replace_selection(plan, sample_descriptor)
        coordinator.activate_plan(plan)
        actions = coordinator.available_actions()
        check(len(actions) == 1, "active action count", "only selected plan actions are visible")
        check(actions[0].display_name == "コンテキスト概要を出力", "action language", "session JA selects Japanese display text")
        context = {
            "OutputDirectory": str(temporary_root / "artifacts"),
            "CurrentCANFrameCount": 41662,
        }
        first = coordinator.execute_user_action(
            module_id=sample_descriptor.module_id,
            action_id=sample_action.action_id,
            run_id="U3M7_GATE",
            event_id="C0001",
            context=context,
        )
        check(first.status == "SUCCESS", "first action", "reference action completes")
        check(len(first.outputs["ArtifactPaths"]) == 1, "first artifact", "result lists its output")
        artifact_path = Path(first.outputs["ArtifactPaths"][0])
        check(artifact_path.is_file(), "artifact exists", "listed output is physically present")
        artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
        check(artifact["CurrentCANFrameCount"] == 41662, "frame preserved", "artifact remains tied to review position")
        check(Path(first.trace_path).is_file(), "trace exists", "action evidence is auditable")
        trace = json.loads(Path(first.trace_path).read_text(encoding="utf-8"))
        check(trace["ActionId"] == sample_action.action_id, "trace action identity", "trace distinguishes action type")
        first_run = Path(first.run_directory)
        check((first_run / "module_action_request.json").is_file(), "request retained", "action input is retained")
        check((first_run / "module_action_result.json").is_file(), "result retained", "action output is retained")
        check((first_run / "stdout.txt").is_file(), "stdout retained", "diagnostic evidence is retained")
        check((first_run / "stderr.txt").is_file(), "stderr retained", "failure evidence path is stable")
        second = coordinator.execute_user_action(
            module_id=sample_descriptor.module_id,
            action_id=sample_action.action_id,
            run_id="U3M7_GATE",
            event_id="C0001",
            context={
                "OutputDirectory": str(temporary_root / "artifacts"),
                "CurrentCANFrameCount": 41663,
            },
        )
        check(first.run_directory != second.run_directory, "independent click", "manual actions are not cached")

    workbench_source = (program_root / "u003_evidence_review_workbench_v0_19.py").read_text(encoding="utf-8")
    gui_source = (program_root / "u003_gui_shell_v0_6.py").read_text(encoding="utf-8")
    check("u003_module_action_gui_v0_1" in workbench_source, "composition import", "release pins the action window")
    check("Module Actions" in gui_source, "toolbar connection", "engineer has a visible entry point")
    check("_module_action_context" in gui_source, "context bridge", "review state is converted to a serializable action request")
    check("CurrentFrameImagePath" in gui_source, "image context", "U3M8 can receive the current frame without direct GUI imports")
    check("SignalDataPath" in gui_source, "signal context", "U3M9 can receive the loaded source table")
    check("ProfileDirectory" in gui_source, "profile context", "interactive modules can persist reusable settings")
    check(callable(action_gui.ModuleActionWindow.run_selected), "action launcher", "selected action is executable from the child window")
    check(workbench.launch_capability()["ProgramVersion"] == "0.19", "launch capability", "external launch reports the active composition")

    print(
        f"U3M7G N-R{runtime.RUNTIME_VERSION}-E{executor.EXECUTOR_VERSION}-"
        f"P{plan_core.PLAN_CORE_VERSION}-C{coordinator_module.COORDINATOR_VERSION}-"
        f"G{gui_shell.GUI_SHELL_VERSION}-W{workbench.VERSION}-T{checks}-X0 C-0"
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        return run_gate(arguments.package_root)
    except Exception as error:
        print(f"U3M7GE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
