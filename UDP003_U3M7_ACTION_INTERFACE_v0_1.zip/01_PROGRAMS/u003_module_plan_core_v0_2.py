#!/usr/bin/env python3
"""Pure selection, ordering, persistence, and validation for U003 Module Plans."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import u003_module_runtime_v0_2 as runtime


PLAN_CORE_VERSION = "0.2"
PLAN_CONTRACT_ID = "U003_MODULE_PLAN"
PLAN_CONTRACT_VERSION = "0.1"
LANGUAGES = ("EN", "JA")


class ModulePlanError(RuntimeError):
    """Raised when a selected Module Plan is invalid or no longer reproducible."""


@dataclass(frozen=True)
class PlanSelection:
    """One exact module version placed in its governed slot order."""

    module_slot: str
    module_id: str
    module_version: str
    package_sha256: str


@dataclass(frozen=True)
class ModulePlan:
    """One immutable plan; execution is intentionally outside U3M4."""

    language: str
    module_root: str
    selections: tuple[PlanSelection, ...]
    plan_name: str = "U003 Module Plan"

    def selected_count(self) -> int:
        return len(self.selections)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def discover_catalog(module_root: Path) -> Any:
    """Use the accepted U3M1 validator instead of duplicating manifest rules."""

    return runtime.discover_modules(module_root)


def descriptors_by_family(catalog: Any) -> dict[str, tuple[Any, ...]]:
    grouped: dict[str, list[Any]] = {}
    for descriptor in catalog.descriptors:
        grouped.setdefault(descriptor.module_id, []).append(descriptor)
    return {
        module_id: tuple(
            sorted(items, key=lambda item: item.semantic_version, reverse=True)
        )
        for module_id, items in sorted(grouped.items())
    }


def find_descriptor(catalog: Any, module_id: str, module_version: str) -> Any:
    matches = [
        descriptor
        for descriptor in catalog.descriptors
        if descriptor.module_id == module_id
        and descriptor.module_version == module_version
    ]
    if len(matches) != 1:
        raise ModulePlanError(
            f"Module identity is not uniquely available: {module_id} {module_version}"
        )
    return matches[0]


def _slot_index(module_slot: str) -> int:
    try:
        return runtime.MODULE_SLOTS.index(module_slot)
    except ValueError as error:
        raise ModulePlanError(f"Unknown ModuleSlot: {module_slot}") from error


def normalize_selections(
    selections: Iterable[PlanSelection],
) -> tuple[PlanSelection, ...]:
    """Preserve within-slot order while enforcing the immutable slot boundary."""

    values = list(selections)
    identities = [item.module_id for item in values]
    if len(set(identities)) != len(identities):
        raise ModulePlanError("A ModuleId may appear only once in one plan.")
    indexed = list(enumerate(values))
    indexed.sort(key=lambda item: (_slot_index(item[1].module_slot), item[0]))
    return tuple(item for _index, item in indexed)


def empty_plan(module_root: Path, language: str = "EN") -> ModulePlan:
    normalized_language = language.upper()
    if normalized_language not in LANGUAGES:
        raise ModulePlanError("Language must be EN or JA.")
    return ModulePlan(
        language=normalized_language,
        module_root=str(module_root.resolve()),
        selections=(),
    )


def selection_from_descriptor(descriptor: Any) -> PlanSelection:
    return PlanSelection(
        module_slot=descriptor.module_slot,
        module_id=descriptor.module_id,
        module_version=descriptor.module_version,
        package_sha256=descriptor.package_sha256,
    )


def add_or_replace_selection(
    plan: ModulePlan,
    descriptor: Any,
) -> ModulePlan:
    """Select exactly one version for a ModuleId without crossing slot order."""

    replacement = selection_from_descriptor(descriptor)
    updated: list[PlanSelection] = []
    inserted = False
    for current in plan.selections:
        if current.module_id == replacement.module_id:
            updated.append(replacement)
            inserted = True
        else:
            updated.append(current)
    if not inserted:
        updated.append(replacement)
    return ModulePlan(
        language=plan.language,
        module_root=plan.module_root,
        selections=normalize_selections(updated),
        plan_name=plan.plan_name,
    )


def remove_selection(plan: ModulePlan, module_id: str) -> ModulePlan:
    return ModulePlan(
        language=plan.language,
        module_root=plan.module_root,
        selections=tuple(
            item for item in plan.selections if item.module_id != module_id
        ),
        plan_name=plan.plan_name,
    )


def move_within_slot(plan: ModulePlan, module_id: str, direction: int) -> ModulePlan:
    """Move one item by one position; crossing a slot boundary is rejected."""

    if direction not in (-1, 1):
        raise ModulePlanError("Move direction must be -1 or 1.")
    values = list(plan.selections)
    indices = [index for index, item in enumerate(values) if item.module_id == module_id]
    if len(indices) != 1:
        raise ModulePlanError(f"Selected ModuleId was not found: {module_id}")
    source_index = indices[0]
    target_index = source_index + direction
    if not 0 <= target_index < len(values):
        return plan
    if values[source_index].module_slot != values[target_index].module_slot:
        raise ModulePlanError("Modules cannot move across governed slot boundaries.")
    values[source_index], values[target_index] = values[target_index], values[source_index]
    return ModulePlan(
        language=plan.language,
        module_root=plan.module_root,
        selections=tuple(values),
        plan_name=plan.plan_name,
    )


def set_language(plan: ModulePlan, language: str) -> ModulePlan:
    normalized = language.upper()
    if normalized not in LANGUAGES:
        raise ModulePlanError("Language must be EN or JA.")
    return ModulePlan(
        language=normalized,
        module_root=plan.module_root,
        selections=plan.selections,
        plan_name=plan.plan_name,
    )


def recommended_plan(catalog: Any, language: str = "EN") -> ModulePlan:
    plan = empty_plan(Path(catalog.module_root), language)
    families = descriptors_by_family(catalog)
    for module_id in sorted(catalog.selected_versions):
        version = catalog.selected_versions[module_id]
        descriptor = find_descriptor(catalog, module_id, version)
        if descriptor.enabled_by_default:
            plan = add_or_replace_selection(plan, descriptor)
    return plan


def validate_plan(plan: ModulePlan, catalog: Any) -> ModulePlan:
    """Bind every selected identity and package hash to the current catalog."""

    if plan.language not in LANGUAGES:
        raise ModulePlanError("Plan language is invalid.")
    if Path(plan.module_root).resolve() != Path(catalog.module_root).resolve():
        raise ModulePlanError("Plan ModuleRoot differs from the scanned ModuleRoot.")
    normalized = normalize_selections(plan.selections)
    if normalized != plan.selections:
        raise ModulePlanError("Plan order crosses a governed ModuleSlot boundary.")
    for item in plan.selections:
        descriptor = find_descriptor(catalog, item.module_id, item.module_version)
        if descriptor.module_slot != item.module_slot:
            raise ModulePlanError(f"ModuleSlot changed: {item.module_id}")
        if descriptor.package_sha256 != item.package_sha256:
            raise ModulePlanError(f"Module package changed: {item.module_id}")
    return plan


def plan_payload(plan: ModulePlan) -> dict[str, Any]:
    slot_counts = {
        slot: sum(item.module_slot == slot for item in plan.selections)
        for slot in runtime.MODULE_SLOTS
    }
    within_slot_order = {slot: 0 for slot in runtime.MODULE_SLOTS}
    selected_modules = []
    for sequence, item in enumerate(plan.selections, start=1):
        within_slot_order[item.module_slot] += 1
        selected_modules.append(
            {
                "Sequence": sequence,
                "OrderWithinSlot": within_slot_order[item.module_slot],
                "ModuleSlot": item.module_slot,
                "ModuleId": item.module_id,
                "ModuleVersion": item.module_version,
                "PackageSha256": item.package_sha256,
            }
        )
    return {
        "ContractId": PLAN_CONTRACT_ID,
        "ContractVersion": PLAN_CONTRACT_VERSION,
        "PlanCoreVersion": PLAN_CORE_VERSION,
        "PlanName": plan.plan_name,
        "Language": plan.language,
        "ModuleRoot": plan.module_root,
        "ExecutionEnabled": False,
        "SelectedModuleCount": len(plan.selections),
        "SlotCounts": slot_counts,
        "SelectedModules": selected_modules,
        "SavedUtc": utc_now(),
    }


def write_plan(plan: ModulePlan, output_path: Path) -> None:
    output_path = output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    writing = output_path.with_name(output_path.name + ".writing")
    writing.write_text(
        json.dumps(plan_payload(plan), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    writing.replace(output_path)


def read_plan(plan_path: Path, catalog: Any) -> ModulePlan:
    try:
        payload = json.loads(plan_path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise ModulePlanError(f"Module Plan is not valid JSON: {error}") from error
    if not isinstance(payload, dict):
        raise ModulePlanError("Module Plan must contain one JSON object.")
    if payload.get("ContractId") != PLAN_CONTRACT_ID:
        raise ModulePlanError("Module Plan ContractId is not accepted.")
    if payload.get("ContractVersion") != PLAN_CONTRACT_VERSION:
        raise ModulePlanError("Module Plan ContractVersion is not accepted.")
    if payload.get("ExecutionEnabled") is not False:
        raise ModulePlanError("U3M4 plans must remain selection-only evidence.")
    selected = payload.get("SelectedModules")
    if not isinstance(selected, list):
        raise ModulePlanError("SelectedModules must be an array.")
    selections: list[PlanSelection] = []
    for index, item in enumerate(selected, start=1):
        if not isinstance(item, dict) or item.get("Sequence") != index:
            raise ModulePlanError("SelectedModules sequence is invalid.")
        try:
            selections.append(
                PlanSelection(
                    module_slot=str(item["ModuleSlot"]),
                    module_id=str(item["ModuleId"]),
                    module_version=str(item["ModuleVersion"]),
                    package_sha256=str(item["PackageSha256"]),
                )
            )
        except KeyError as error:
            raise ModulePlanError(f"Selected Module field is missing: {error}") from error
    if payload.get("SelectedModuleCount") != len(selections):
        raise ModulePlanError("SelectedModuleCount does not match the inventory.")
    plan = ModulePlan(
        language=str(payload.get("Language", "")),
        module_root=str(payload.get("ModuleRoot", "")),
        selections=tuple(selections),
        plan_name=str(payload.get("PlanName", "U003 Module Plan")),
    )
    return validate_plan(plan, catalog)


def localized_card_value(value: Any, language: str) -> Any:
    """Resolve future EN/JA card values while preserving plain legacy content."""

    if isinstance(value, dict) and set(value).issubset({"EN", "JA"}) and "EN" in value:
        japanese = value.get("JA")
        if language.upper() == "JA" and isinstance(japanese, str) and japanese.strip():
            return japanese
        return value.get("EN")
    if isinstance(value, dict):
        return {
            key: localized_card_value(item, language)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [localized_card_value(item, language) for item in value]
    return value
