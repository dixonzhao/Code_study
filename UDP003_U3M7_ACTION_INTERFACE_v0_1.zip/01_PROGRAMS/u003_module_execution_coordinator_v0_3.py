#!/usr/bin/env python3
"""Governed U003 Module-Plan execution and ReviewMemo composition.

This coordinator is the only GUI-facing execution boundary introduced by
U3M5.  It validates the exact selected plan, executes PROCESS modules through
the already accepted isolated child-process bridge, caches one result per
event/context/package identity, and composes human-editable memo suggestions.

It never changes event identity, frame boundaries, review disposition, source
evidence, or a module's RootCauseClaim=false requirement.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import u003_module_executor_v0_3 as executor
import u003_module_plan_core_v0_2 as plan_core
import u003_module_runtime_v0_2 as runtime


COORDINATOR_VERSION = "0.3"
EVENT_HOOK = "ON_EVENT_SELECTED"
MEMO_OUTPUT_FIELDS = ("SuggestedReviewMemo", "ReviewMemoSuggestion")


class ModuleCoordinationError(RuntimeError):
    """Raised when a selected plan cannot be executed reproducibly."""


@dataclass(frozen=True)
class ModuleEventResult:
    """One module's visible, traceable outcome for one review event."""

    module_id: str
    module_version: str
    status: str
    memo_suggestion: str
    trace_path: str
    cached: bool


@dataclass(frozen=True)
class EventExecutionReport:
    """Complete execution summary for one event and one active plan."""

    event_id: str
    selected_count: int
    process_eligible_count: int
    executed_count: int
    cached_count: int
    suggestion_count: int
    results: tuple[ModuleEventResult, ...]


@dataclass(frozen=True)
class QualifiedUserAction:
    """One action exposed by an exact Module version in the active plan."""

    module_slot: str
    module_id: str
    module_version: str
    action_id: str
    display_name: str
    description: str
    required_context_fields: tuple[str, ...]
    produced_fields: tuple[str, ...]


@dataclass(frozen=True)
class UserActionExecutionReport:
    """Visible result and trace identity for one explicit engineer click."""

    module_id: str
    module_version: str
    action_id: str
    status: str
    outputs: dict[str, Any]
    warnings: tuple[str, ...]
    trace_path: str
    run_directory: str


def _canonical_context(event: Any) -> dict[str, Any]:
    """Expose source columns plus governed review-domain values to modules."""

    original = getattr(event, "original", {})
    context = dict(original) if isinstance(original, dict) else {}
    context.update(
        {
            "EventID": str(event.event_id),
            "ReviewStartFrame": int(event.start_framecount),
            "PeakFrameCount": (
                int(event.peak_framecount)
                if event.peak_framecount is not None
                else None
            ),
            "ReviewEndFrame": int(event.end_framecount),
            "ReviewCode": str(event.review_result or ""),
            "ReviewMemo": str(event.memo or ""),
        }
    )
    return context


def _context_fingerprint(descriptor: Any, context: dict[str, Any]) -> str:
    """Hash only the fields declared by the module as required inputs."""

    controlled = {
        key: context.get(key)
        for key in descriptor.required_context_fields
    }
    payload = json.dumps(
        controlled,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _memo_from_outputs(outputs: dict[str, Any]) -> str:
    for field_name in MEMO_OUTPUT_FIELDS:
        value = outputs.get(field_name)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def append_unique_memo(existing: str, suggestions: list[str]) -> str:
    """Append exact new suggestions without rewriting engineer text."""

    composed = str(existing or "").strip()
    for suggestion in suggestions:
        normalized = suggestion.strip()
        if not normalized or normalized in composed:
            continue
        composed = f"{composed}\n{normalized}".strip() if composed else normalized
    return composed


class ModuleExecutionCoordinator:
    """Own plan activation, isolated execution, caching, and trace references."""

    def __init__(self, module_root: Path, run_root: Path, language: str) -> None:
        self.module_root = module_root.resolve()
        self.run_root = run_root.resolve()
        self.language = language.upper()
        if self.language not in executor.LANGUAGES:
            raise ModuleCoordinationError("Language must be EN or JA.")
        self.catalog = plan_core.discover_catalog(self.module_root)
        self.plan = plan_core.empty_plan(self.module_root, self.language)
        self._cache: dict[tuple[str, ...], ModuleEventResult] = {}

    def activate_plan(self, plan: Any) -> None:
        """Bind the plan to the current catalog and immutable session language."""

        rebound = plan_core.set_language(plan, self.language)
        self.plan = plan_core.validate_plan(rebound, self.catalog)

    def refresh_catalog(self) -> None:
        """Rescan packages, then fail closed if an active package changed."""

        refreshed = plan_core.discover_catalog(self.module_root)
        plan_core.validate_plan(self.plan, refreshed)
        self.catalog = refreshed

    def _descriptor(self, selection: Any) -> Any:
        descriptor = plan_core.find_descriptor(
            self.catalog,
            selection.module_id,
            selection.module_version,
        )
        if descriptor.package_sha256 != selection.package_sha256:
            raise ModuleCoordinationError(
                f"Selected module package changed: {selection.module_id}"
            )
        return descriptor

    def execute_event(self, event: Any, run_id: str) -> EventExecutionReport:
        """Execute eligible selected modules once for the current event context."""

        context = _canonical_context(event)
        results: list[ModuleEventResult] = []
        eligible_count = 0
        executed_count = 0
        cached_count = 0

        for selection in self.plan.selections:
            descriptor = self._descriptor(selection)
            if descriptor.execution_kind != "PROCESS":
                continue
            if EVENT_HOOK not in descriptor.lifecycle_hooks:
                continue
            eligible_count += 1
            fingerprint = _context_fingerprint(descriptor, context)
            cache_key = (
                str(run_id),
                str(event.event_id),
                descriptor.module_id,
                descriptor.module_version,
                descriptor.package_sha256,
                self.language,
                fingerprint,
            )
            cached_result = self._cache.get(cache_key)
            if cached_result is not None:
                results.append(
                    ModuleEventResult(
                        module_id=cached_result.module_id,
                        module_version=cached_result.module_version,
                        status=cached_result.status,
                        memo_suggestion=cached_result.memo_suggestion,
                        trace_path=cached_result.trace_path,
                        cached=True,
                    )
                )
                cached_count += 1
                continue

            request = executor.build_request(
                descriptor=descriptor,
                run_id=str(run_id),
                event_id=str(event.event_id),
                hook=EVENT_HOOK,
                language=self.language,
                context=context,
            )
            outcome = executor.execute_process_module(
                descriptor=descriptor,
                request=request,
                run_root=self.run_root,
                protected_fields=tuple(runtime.PROTECTED_FIELDS),
            )
            outputs = outcome.result.get("Outputs", {})
            memo = _memo_from_outputs(outputs) if isinstance(outputs, dict) else ""
            result = ModuleEventResult(
                module_id=descriptor.module_id,
                module_version=descriptor.module_version,
                status=str(outcome.result.get("Status", "")),
                memo_suggestion=memo,
                trace_path=str(outcome.run_directory / "module_trace.json"),
                cached=False,
            )
            self._cache[cache_key] = result
            results.append(result)
            executed_count += 1

        suggestions = [item.memo_suggestion for item in results if item.memo_suggestion]
        return EventExecutionReport(
            event_id=str(event.event_id),
            selected_count=len(self.plan.selections),
            process_eligible_count=eligible_count,
            executed_count=executed_count,
            cached_count=cached_count,
            suggestion_count=len(suggestions),
            results=tuple(results),
        )

    def available_actions(self) -> tuple[QualifiedUserAction, ...]:
        """Enumerate only actions belonging to exact versions in the active plan."""

        available: list[QualifiedUserAction] = []
        for selection in self.plan.selections:
            descriptor = self._descriptor(selection)
            for action in descriptor.user_actions:
                available.append(
                    QualifiedUserAction(
                        module_slot=descriptor.module_slot,
                        module_id=descriptor.module_id,
                        module_version=descriptor.module_version,
                        action_id=action.action_id,
                        display_name=action.localized_name(self.language),
                        description=action.localized_description(self.language),
                        required_context_fields=action.required_context_fields,
                        produced_fields=action.produced_fields,
                    )
                )
        return tuple(available)

    def execute_user_action(
        self,
        module_id: str,
        action_id: str,
        run_id: str,
        event_id: str,
        context: dict[str, Any],
    ) -> UserActionExecutionReport:
        """Execute one selected action once; manual actions are never cached."""

        selections = [
            selection
            for selection in self.plan.selections
            if selection.module_id == module_id
        ]
        if len(selections) != 1:
            raise ModuleCoordinationError(
                f"Action Module is not uniquely selected in the active plan: {module_id}"
            )
        descriptor = self._descriptor(selections[0])
        action = executor.find_action(descriptor, action_id)
        missing = [
            field_name
            for field_name in action.required_context_fields
            if field_name not in context or context[field_name] is None
        ]
        if missing:
            raise ModuleCoordinationError(
                f"Action context is incomplete: {', '.join(missing)}"
            )
        outcome = executor.execute_selected_action(
            module_root=self.module_root,
            run_root=self.run_root,
            module_id=descriptor.module_id,
            module_version=descriptor.module_version,
            action_id=action.action_id,
            run_id=str(run_id),
            event_id=str(event_id),
            language=self.language,
            context=context,
        )
        outputs = outcome.result.get("Outputs", {})
        warnings = outcome.result.get("Warnings", [])
        return UserActionExecutionReport(
            module_id=descriptor.module_id,
            module_version=descriptor.module_version,
            action_id=action.action_id,
            status=str(outcome.result.get("Status", "")),
            outputs=dict(outputs) if isinstance(outputs, dict) else {},
            warnings=tuple(str(item) for item in warnings),
            trace_path=str(outcome.run_directory / "module_trace.json"),
            run_directory=str(outcome.run_directory),
        )

    def apply_report_to_event(self, event: Any, report: EventExecutionReport) -> bool:
        """Compose suggestions into editable ReviewMemo and report if it changed."""

        suggestions = [
            item.memo_suggestion
            for item in report.results
            if item.memo_suggestion
        ]
        composed = append_unique_memo(str(event.memo or ""), suggestions)
        if composed == str(event.memo or ""):
            return False
        event.memo = composed
        return True


def run_self_test() -> int:
    """Exercise pure context, memo, and no-duplicate behavior."""

    from types import SimpleNamespace

    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    event = SimpleNamespace(
        event_id="C0001",
        start_framecount=100,
        peak_framecount=110,
        end_framecount=120,
        review_result="",
        memo="source memo",
        original={"CandidateReasonCode": "RADAR_LOSS", "CandidateScore": "2.4"},
    )
    context = _canonical_context(event)
    check(context["EventID"] == "C0001")
    check(context["PeakFrameCount"] == 110)
    check(context["CandidateReasonCode"] == "RADAR_LOSS")
    check(context["ReviewMemo"] == "source memo")
    check(append_unique_memo("", ["draft"]) == "draft")
    check(append_unique_memo("source", ["draft"]) == "source\ndraft")
    check(append_unique_memo("source\ndraft", ["draft"]) == "source\ndraft")
    check(_memo_from_outputs({"SuggestedReviewMemo": "  draft  "}) == "draft")
    check(_memo_from_outputs({"Other": "value"}) == "")
    check(MEMO_OUTPUT_FIELDS[0] not in runtime.PROTECTED_FIELDS)
    check("ReviewResult" in runtime.PROTECTED_FIELDS)
    check(EVENT_HOOK in runtime.LIFECYCLE_HOOKS)
    sample_action = QualifiedUserAction(
        module_slot="EXPORT",
        module_id="CameraRadar.U003.Sample",
        module_version="0.1.0",
        action_id="WRITE_OUTPUT",
        display_name="Write output",
        description="Writes one output.",
        required_context_fields=("OutputDirectory",),
        produced_fields=("ArtifactPaths",),
    )
    check(sample_action.action_id == "WRITE_OUTPUT")
    check("OutputDirectory" in sample_action.required_context_fields)
    check("ArtifactPaths" in sample_action.produced_fields)
    if checks != 15:
        raise AssertionError(f"self-test count {checks} != 15")
    print("U003-U3M7-COORDINATOR-SELFTEST-PASS-15 C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(run_self_test())
