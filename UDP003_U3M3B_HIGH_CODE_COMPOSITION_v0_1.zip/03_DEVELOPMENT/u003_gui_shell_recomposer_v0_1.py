#!/usr/bin/env python3
"""Reproduce the U003 GUI class from the accepted baseline without domain code.

This maintenance-only tool makes the large GUI extraction deterministic.  It
copies exactly one class from the accepted v0.13 source and supplies explicit
imports from the separately versioned Domain and Handoff cores.
"""

from __future__ import annotations

import argparse
import ast
from pathlib import Path


HEADER = '''#!/usr/bin/env python3
"""U003 GUI shell extracted from accepted v0.13.

The shell owns widgets, video decoding, synchronized table presentation and
engineer interaction. Review-domain and U002-handoff behavior belong to the
separate versioned cores imported below.
"""

from __future__ import annotations

import csv
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from u003_domain_core_v0_2 import (
    REVIEW_CODES,
    ReviewEvent,
    build_review_return_capsule,
    compact_text,
    find_column,
    framecount_to_video_index as map_framecount_to_video_index,
    highlight_target_framecount,
    nearest_sorted_index,
    normalized_name,
    parse_number,
    parse_review_events,
    read_delimited_file,
    video_index_to_framecount as map_video_index_to_framecount,
)
from u003_handoff_core_v0_2 import GovernedHandoffBatch


GUI_SHELL_VERSION = "0.1"
WORKBENCH_VERSION = "0.14"
VERSION = WORKBENCH_VERSION


'''

LEGACY_VIDEO_TO_FRAMECOUNT = '''    def video_index_to_framecount(self, video_index: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        delta = video_index - anchor_video
        if mode == "1:1":
            return anchor_fc + delta
        return anchor_fc + int(round(delta * rate / self.video_fps))
'''

DELEGATED_VIDEO_TO_FRAMECOUNT = '''    def video_index_to_framecount(self, video_index: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        return map_video_index_to_framecount(
            video_index,
            anchor_video,
            anchor_fc,
            rate,
            self.video_fps,
            mode,
        )
'''

LEGACY_FRAMECOUNT_TO_VIDEO = '''    def framecount_to_video_index(self, framecount: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        delta = framecount - anchor_fc
        if mode == "1:1":
            return anchor_video + delta
        return anchor_video + int(round(delta * self.video_fps / rate))
'''

DELEGATED_FRAMECOUNT_TO_VIDEO = '''    def framecount_to_video_index(self, framecount: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        return map_framecount_to_video_index(
            framecount,
            anchor_video,
            anchor_fc,
            rate,
            self.video_fps,
            mode,
        )
'''


class RecomposeError(RuntimeError):
    """Raised when the accepted baseline no longer has the expected class."""


def extract_class(source_path: Path, class_name: str) -> str:
    source = source_path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    matches = [
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == class_name
    ]
    if len(matches) != 1:
        raise RecomposeError(
            f"Expected exactly one {class_name} class, found {len(matches)}."
        )
    node = matches[0]
    lines = source.splitlines(keepends=True)
    return "".join(lines[node.lineno - 1 : node.end_lineno]).rstrip() + "\n"


def recompose(source_path: Path, output_path: Path) -> None:
    class_source = extract_class(source_path, "FrameCountVideoReviewer")
    replacements = (
        (LEGACY_VIDEO_TO_FRAMECOUNT, DELEGATED_VIDEO_TO_FRAMECOUNT),
        (LEGACY_FRAMECOUNT_TO_VIDEO, DELEGATED_FRAMECOUNT_TO_VIDEO),
    )
    for legacy_text, delegated_text in replacements:
        if class_source.count(legacy_text) != 1:
            raise RecomposeError("Accepted mapping method could not be delegated safely.")
        class_source = class_source.replace(legacy_text, delegated_text)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(HEADER + class_source, encoding="utf-8")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def main() -> int:
    arguments = parse_arguments()
    recompose(arguments.source, arguments.output)
    print("U3M3B-RECOMPOSE-PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
