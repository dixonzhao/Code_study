#!/usr/bin/env python3
"""Accept the U003 v0.14 high-code composition against frozen v0.13 behavior."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import u003_domain_core_v0_2 as domain
import u003_evidence_review_workbench_v0_14 as entry
import u003_gui_shell_v0_1 as gui
import u003_handoff_core_v0_2 as handoff


GATE_VERSION = "0.1"
LEGACY_SHA256 = "a9b4f4a14d43fd51dce0bc577c74a9482606a3d918c4c2fec935b56d99c56758"
DELEGATED_GUI_METHODS = {
    "video_index_to_framecount",
    "framecount_to_video_index",
}
DOMAIN_OWNED_NAMES = {
    "ReviewEvent",
    "build_review_return_capsule",
    "compact_event_number",
    "compact_text",
    "compress_integer_ranges",
    "find_column",
    "framecount_to_video_index",
    "highlight_target_framecount",
    "integer_range_tokens",
    "nearest_sorted_index",
    "normalized_name",
    "parse_number",
    "parse_review_events",
    "read_delimited_file",
    "video_index_to_framecount",
}
HANDOFF_OWNED_NAMES = {
    "GovernedHandoffBatch",
    "load_governed_handoff",
    "sha256_file",
}


class AcceptanceError(RuntimeError):
    """Raised when the refactored program differs from its accepted baseline."""


class StaticVar:
    """Minimal tkinter-variable substitute for headless mapping tests."""

    def __init__(self, value: object) -> None:
        self.value = value

    def get(self) -> object:
        return self.value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(path: Path, name: str) -> Any:
    path = path.resolve()
    if not path.is_file() or path.is_symlink():
        raise AcceptanceError(f"Python source is missing: {path}")
    specification = importlib.util.spec_from_file_location(name, path)
    if specification is None or specification.loader is None:
        raise AcceptanceError(f"Python source could not be loaded: {path}")
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


def event_signature(events: list[Any]) -> list[tuple[Any, ...]]:
    return [
        (
            event.event_id,
            event.start_framecount,
            event.peak_framecount,
            event.end_framecount,
            event.review_result,
            event.memo,
            dict(event.original),
            event.display_text(),
        )
        for event in events
    ]


def handoff_signature(value: Any) -> tuple[Any, ...]:
    return (
        value.run_id,
        value.batch_id,
        value.event_queue_path,
        value.review_data_path,
        value.candidate_count,
        value.review_data_row_count,
        value.frame_start,
        value.frame_end,
    )


def class_methods(source_path: Path, class_name: str) -> dict[str, ast.AST]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    classes = [
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == class_name
    ]
    if len(classes) != 1:
        raise AcceptanceError(
            f"Expected one {class_name} in {source_path.name}; found {len(classes)}."
        )
    return {
        node.name: node
        for node in classes[0].body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def top_level_owned_names(source_path: Path) -> set[str]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    return {
        node.name
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.name in DOMAIN_OWNED_NAMES | HANDOFF_OWNED_NAMES
    }


def write_handoff_fixture(root: Path, legacy: Any) -> Path:
    event_path = root / "event_queue.csv"
    review_path = root / "review_data.csv"
    event_fields = (
        "EventID",
        "ReviewStartFrame",
        "PeakFrameCount",
        "ReviewEndFrame",
        "ReviewResult",
        "ReviewMemo",
    )
    with event_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=event_fields)
        writer.writeheader()
        writer.writerows(
            [
                {
                    "EventID": "C0001",
                    "ReviewStartFrame": 100,
                    "PeakFrameCount": 103,
                    "ReviewEndFrame": 106,
                    "ReviewResult": "1",
                    "ReviewMemo": "first",
                },
                {
                    "EventID": "C0002",
                    "ReviewStartFrame": 104,
                    "PeakFrameCount": 108,
                    "ReviewEndFrame": 110,
                    "ReviewResult": "",
                    "ReviewMemo": "second",
                },
            ]
        )
    with review_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("FrameCount", "RadarDistance"))
        writer.writeheader()
        for framecount in range(100, 111):
            writer.writerow({"FrameCount": framecount, "RadarDistance": framecount / 10})
    descriptor = {
        "ContractId": legacy.HANDOFF_CONTRACT_ID,
        "ContractVersion": legacy.HANDOFF_CONTRACT_VERSION,
        "LocalOnlyNotRunEvidence": True,
        "RunId": "U3M3B_ACCEPTANCE",
        "CandidateCount": 2,
        "ReviewBatchCount": 1,
        "ReviewDataRowCount": 11,
        "Batches": [
            {
                "ReviewBatchId": "RB001",
                "CandidateCount": 2,
                "ReviewDataRowCount": 11,
                "FrameStart": 100,
                "FrameEnd": 110,
                "EventQueuePath": str(event_path),
                "EventQueueSha256": legacy.sha256_file(event_path),
                "ReviewDataPath": str(review_path),
                "ReviewDataSha256": legacy.sha256_file(review_path),
                "U003StartColumn": "ReviewStartFrame",
                "U003PeakColumn": "PeakFrameCount",
                "U003EndColumn": "ReviewEndFrame",
            }
        ],
    }
    descriptor_path = root / "handoff.json"
    descriptor_path.write_text(json.dumps(descriptor), encoding="utf-8")
    return descriptor_path


def compare_delimited_readers(root: Path, legacy: Any) -> list[tuple[Any, ...]]:
    fixtures = [
        ("utf8_comma.csv", "Name,Value\nalpha,1\n", "utf-8"),
        ("utf8_semicolon.csv", "Name;Value\nalpha;2\n", "utf-8"),
        ("cp932_tab.tsv", "Name\tMemo\nalpha\t確認\n", "cp932"),
        ("latin1.csv", "Name,Note\nalpha,caf\xe9\n", "latin-1"),
    ]
    results: list[tuple[Any, ...]] = []
    for name, content, encoding in fixtures:
        path = root / name
        path.write_bytes(content.encode(encoding))
        results.append(
            (
                name,
                legacy.read_delimited_file(path),
                domain.read_delimited_file(path),
            )
        )
    return results


def run_acceptance(legacy_path: Path, open_gui: bool, verbose: bool) -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(name)
        checks += 1
        if verbose:
            print(f"[CHECK {checks:03d}] {name} - {reason}")

    legacy_path = legacy_path.resolve()
    check(sha256_file(legacy_path) == LEGACY_SHA256, "legacy identity", "the accepted oracle cannot drift")
    legacy = load_module(legacy_path, "u003_legacy_v013_b")
    check(legacy.VERSION == "0.13", "legacy version", "the comparison target is explicit")
    check(entry.VERSION == "0.14", "entry version", "the high-code composition has a new identity")
    check(domain.DOMAIN_VERSION == "0.2", "domain version", "domain ownership is independently versioned")
    check(handoff.HANDOFF_CORE_VERSION == "0.2", "handoff version", "handoff ownership is independently versioned")
    check(gui.GUI_SHELL_VERSION == "0.1", "GUI shell version", "GUI ownership is independently versioned")

    gui_path = Path(gui.__file__).resolve()
    owned_duplicates = top_level_owned_names(gui_path)
    check(not owned_duplicates, "GUI ownership boundary", "the shell cannot redeclare Domain or Handoff owners")

    legacy_methods = class_methods(legacy_path, "FrameCountVideoReviewer")
    new_methods = class_methods(gui_path, "FrameCountVideoReviewer")
    check(legacy_methods.keys() == new_methods.keys(), "GUI method inventory", "no interaction method was lost or added silently")
    compared_methods = sorted(set(legacy_methods) - DELEGATED_GUI_METHODS)
    for method_name in compared_methods:
        check(
            ast.dump(legacy_methods[method_name], include_attributes=False)
            == ast.dump(new_methods[method_name], include_attributes=False),
            f"GUI method {method_name}",
            "method body is identical to accepted v0.13",
        )

    check(domain.REVIEW_CODES == legacy.REVIEW_CODES, "review codes", "engineer disposition semantics remain fixed")
    check(domain.EVENT_START_ALIASES == legacy.EVENT_START_ALIASES, "start aliases", "existing Event queues remain readable")
    check(domain.EVENT_PEAK_ALIASES == legacy.EVENT_PEAK_ALIASES, "peak aliases", "Peak identity remains readable")
    check(domain.EVENT_END_ALIASES == legacy.EVENT_END_ALIASES, "end aliases", "existing Event queues remain readable")

    for text in (None, "FrameCount", "ID_620_FrameCount", "camelCaseValue", "ＡＢＣ"):
        check(domain.normalized_name(text) == legacy.normalized_name(text), f"normalize {text}", "column resolution is unchanged")
    for text, limit in (("short", 40), ("a\n b\r c", 40), ("x" * 50, 40)):
        check(domain.compact_text(text, limit) == legacy.compact_text(text, limit), f"compact {limit}", "memo compression is unchanged")

    fields = [
        "EventID",
        "ReviewStartFrame",
        "PeakFrameCount",
        "ReviewEndFrame",
        "ReviewResult",
        "ReviewMemo",
    ]
    rows = [
        {
            "EventID": "C0001",
            "ReviewStartFrame": "100",
            "PeakFrameCount": "103",
            "ReviewEndFrame": "106",
            "ReviewResult": "1",
            "ReviewMemo": "first",
        },
        {
            "EventID": "C0002",
            "ReviewStartFrame": "104",
            "PeakFrameCount": "108",
            "ReviewEndFrame": "110",
            "ReviewResult": "",
            "ReviewMemo": "second",
        },
    ]
    legacy_parsed = legacy.parse_review_events(fields, rows)
    new_parsed = domain.parse_review_events(fields, rows)
    check(legacy_parsed[1:] == new_parsed[1:], "resolved columns", "column binding is unchanged")
    check(event_signature(legacy_parsed[0]) == event_signature(new_parsed[0]), "parsed Events", "Event state is unchanged")

    invalid_rows = [
        {"EventID": "X", "ReviewStartFrame": "5", "PeakFrameCount": "4", "ReviewEndFrame": "6"},
        {"EventID": "X", "ReviewStartFrame": "5", "PeakFrameCount": "bad", "ReviewEndFrame": "6"},
        {"EventID": "X", "ReviewStartFrame": "7", "PeakFrameCount": "7", "ReviewEndFrame": "6"},
    ]
    for index, invalid in enumerate(invalid_rows, start=1):
        messages = []
        for parser in (legacy.parse_review_events, domain.parse_review_events):
            try:
                parser(fields, [invalid])
            except RuntimeError as error:
                messages.append(str(error))
        check(len(messages) == 2 and messages[0] == messages[1], f"invalid Event {index}", "fail-close message is unchanged")

    legacy_events = [
        legacy.ReviewEvent(f"C{number:04d}", number, number, review_result="1")
        for number in list(range(1, 10)) + list(range(11, 17))
    ]
    legacy_events.append(legacy.ReviewEvent("C0010", 10, 10, review_result="4"))
    domain_events = [
        domain.ReviewEvent(f"C{number:04d}", number, number, review_result="1")
        for number in list(range(1, 10)) + list(range(11, 17))
    ]
    domain_events.append(domain.ReviewEvent("C0010", 10, 10, review_result="4"))
    expected_capsule = "RV260825T145605_N16-R16_C1-1-9_C1-11-16_C4-10"
    check(legacy.build_review_return_capsule(legacy_events, "260825T145605") == expected_capsule, "legacy capsule", "accepted low-bandwidth format is fixed")
    check(domain.build_review_return_capsule(domain_events, "260825T145605") == expected_capsule, "domain capsule", "refactored low-bandwidth format is fixed")

    for mapping_mode, rate in (("1:1", 20), ("Rate-based", 40)):
        legacy_mapper = object.__new__(legacy.FrameCountVideoReviewer)
        new_mapper = object.__new__(gui.FrameCountVideoReviewer)
        for instance in (legacy_mapper, new_mapper):
            instance.anchor_video_var = StaticVar("3")
            instance.anchor_framecount_var = StaticVar("100")
            instance.framecount_rate_var = StaticVar(str(rate))
            instance.mapping_mode_var = StaticVar(mapping_mode)
            instance.video_fps = 20.0
        for video_index in (0, 3, 4, 10, 100):
            check(
                legacy_mapper.video_index_to_framecount(video_index)
                == new_mapper.video_index_to_framecount(video_index),
                f"video mapping {mapping_mode}/{video_index}",
                "GUI delegation preserves FrameCount mapping",
            )
        for framecount in (97, 100, 102, 114, 200):
            check(
                legacy_mapper.framecount_to_video_index(framecount)
                == new_mapper.framecount_to_video_index(framecount),
                f"inverse mapping {mapping_mode}/{framecount}",
                "GUI delegation preserves inverse mapping",
            )

    with tempfile.TemporaryDirectory(prefix="u003_m3b_") as temporary:
        root = Path(temporary)
        for name, legacy_value, domain_value in compare_delimited_readers(root, legacy):
            check(legacy_value == domain_value, f"delimited reader {name}", "encoding and delimiter behavior are unchanged")
        descriptor_path = write_handoff_fixture(root, legacy)
        legacy_handoff = legacy.load_governed_handoff(descriptor_path)
        new_handoff = handoff.load_governed_handoff(descriptor_path)
        check(handoff_signature(legacy_handoff) == handoff_signature(new_handoff), "valid handoff", "U002 intake is unchanged")
        broken = json.loads(descriptor_path.read_text(encoding="utf-8"))
        broken["Batches"][0]["EventQueueSha256"] = "0" * 64
        descriptor_path.write_text(json.dumps(broken), encoding="utf-8")
        messages = []
        for loader in (legacy.load_governed_handoff, handoff.load_governed_handoff):
            try:
                loader(descriptor_path)
            except RuntimeError as error:
                messages.append(str(error))
        check(len(messages) == 2 and messages[0] == messages[1], "tampered handoff", "hash rejection is unchanged")

    legacy_capability = legacy.launch_capability()
    new_capability = entry.launch_capability()
    for key in set(legacy_capability) - {"ProgramVersion"}:
        check(legacy_capability[key] == new_capability[key], f"capability {key}", "U002 launch contract is unchanged")
    check(new_capability["ProgramVersion"] == "0.14", "capability version", "new composition is externally identifiable")

    entry_path = Path(entry.__file__).resolve()
    result = subprocess.run(
        [sys.executable, str(entry_path), "--self-test"],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    check(result.returncode == 0, "entry self-test exit", "the composed entry imports in a fresh process")
    check("U003-V014-SELFTEST-PASS-12" in result.stdout, "entry self-test capsule", "composition evidence is explicit")

    gui_opened = 0
    if open_gui:
        print("[ACTION] U003 v0.14 GUI will open. Confirm the title, then close it normally.")
        result = subprocess.run(
            [sys.executable, str(entry_path)],
            timeout=None,
            check=False,
        )
        check(result.returncode == 0, "GUI normal close", "the composed GUI launches and closes on the company host")
        gui_opened = 1

    method_count = len(legacy_methods)
    print(
        f"U3M3B N-L1-G{gui_opened}-E1-D1-H1-M{method_count}-T{checks}-X0 C-0"
    )
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--accept", action="store_true")
    parser.add_argument("--legacy", type=Path)
    parser.add_argument("--open-gui", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if not arguments.self_test and not arguments.accept:
            raise AcceptanceError("Use --self-test or --accept.")
        legacy_path = arguments.legacy or Path(__file__).with_name(
            "u003_evidence_review_workbench_v0_13.py"
        )
        return run_acceptance(
            legacy_path,
            open_gui=arguments.open_gui,
            verbose=arguments.accept,
        )
    except Exception as error:
        print(
            f"U3M3BE K-{type(error).__name__.upper()} D-{error} X1 C-7",
            file=sys.stderr,
        )
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
