#!/usr/bin/env python3
"""Qualification self-test for the S6 robust-score candidate Module."""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--module-root", required=True)
    parser.add_argument("--workspace-root", required=True)
    args = parser.parse_args()
    module_root = Path(args.module_root).resolve()
    workspace_root = Path(args.workspace_root).resolve()
    if module_root.name != "0.1.0" or workspace_root.name != "U-UDP002":
        return 7
    implementation = module_root / "implementation.py"
    spec = importlib.util.spec_from_file_location("u002_s6_candidates", implementation)
    if spec is None or spec.loader is None:
        return 7
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.semantic_selftest() != 29:
        return 7
    print("B4S6-ST-PASS-29 C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
