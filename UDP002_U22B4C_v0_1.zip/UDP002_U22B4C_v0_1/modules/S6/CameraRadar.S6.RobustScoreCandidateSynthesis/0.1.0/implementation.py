#!/usr/bin/env python3
"""Deterministic robust-score candidate synthesis for the U002 U22 runtime."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
from typing import Dict, List, Mapping, Optional, Sequence, Tuple


MODULE_ID = "CameraRadar.S6.RobustScoreCandidateSynthesis"
MODULE_VERSION = "0.1.0"
STAGE = "S6"
ARTIFACT_TYPE = "ANOMALY_CANDIDATES"
REQUIRED_ARTIFACT = "ROBUST_RESIDUAL_EVIDENCE"
CONTRACT_VERSION = "U22.0.1"
PROTOCOL = "U002_U22_MODULE_RUNTIME"
PROTOCOL_VERSION = "0.1"
RANKING_POLICY = "PEAK_SCORE_DESC_HIT_COUNT_DESC_START_ASC"


class ModuleError(RuntimeError):
    """Represent one deterministic, fail-closed Module failure."""


def stable(value: object) -> str:
    """Convert an exception into a compact machine-readable token."""

    text = re.sub(r"[^A-Z0-9_]+", "_", str(value).upper())
    return text.strip("_")[:96] or "INTERNAL"


def canonical_bytes(value: object) -> bytes:
    """Serialize governed JSON deterministically."""

    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    return (text + "\n").encode("utf-8")


def write_json(path: Path, value: object) -> None:
    """Write JSON atomically."""

    temporary = path.with_name(path.name + ".writing")
    temporary.write_bytes(canonical_bytes(value))
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    """Hash one file without loading the entire file into memory."""

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink()


def inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def load_json(path: Path, reason: str) -> Dict[str, object]:
    if not regular_file(path):
        raise ModuleError(reason + "_MISSING")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise ModuleError(reason + "_JSON") from exc
    if not isinstance(value, dict):
        raise ModuleError(reason + "_TYPE")
    return value


def safe_relative(value: object, field: str) -> PurePosixPath:
    text = str(value)
    if "\\" in text:
        raise ModuleError(field + "_SEPARATOR")
    path = PurePosixPath(text)
    if path.is_absolute() or not path.parts:
        raise ModuleError(field + "_PATH")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ModuleError(field + "_PATH")
    return path


def parse_boolean(value: object, field: str) -> bool:
    text = str(value if value is not None else "").strip().lower()
    if text in {"true", "false"}:
        return text == "true"
    try:
        number = float(text)
    except ValueError as exc:
        raise ModuleError("BOOLEAN_" + field) from exc
    if not math.isfinite(number) or number not in {0.0, 1.0}:
        raise ModuleError("BOOLEAN_" + field)
    return number == 1.0


def parse_integer(value: object, field: str) -> int:
    try:
        number = float(str(value).strip())
    except ValueError as exc:
        raise ModuleError("INTEGER_" + field) from exc
    if not math.isfinite(number) or not number.is_integer():
        raise ModuleError("INTEGER_" + field)
    return int(number)


def parse_finite(value: object, field: str) -> float:
    try:
        number = float(str(value).strip())
    except ValueError as exc:
        raise ModuleError("NUMBER_" + field) from exc
    if not math.isfinite(number):
        raise ModuleError("NUMBER_" + field)
    return number


def optional_float(value: object) -> Optional[float]:
    text = str(value if value is not None else "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except ValueError:
        return None
    return number if math.isfinite(number) else None


def csv_value(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, float):
        return format(value, ".12g")
    return value


def validate_request(request: Mapping[str, object]) -> None:
    expected = {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Stage": STAGE,
    }
    for field, expected_value in expected.items():
        if request.get(field) != expected_value:
            raise ModuleError("REQUEST_" + field.upper())
    if request.get("ExpectedOutputTypes") != [ARTIFACT_TYPE]:
        raise ModuleError("REQUEST_OUTPUT_TYPE")
    artifacts = request.get("InputArtifacts")
    if not isinstance(artifacts, list):
        raise ModuleError("REQUEST_INPUT_ARTIFACTS")
    observed = [str(item.get("ArtifactType")) for item in artifacts]
    if observed != [REQUIRED_ARTIFACT]:
        raise ModuleError("REQUEST_INPUT_ARTIFACT_TYPES")


def validate_configuration(value: object) -> Dict[str, object]:
    """Validate the complete visible S6 candidate policy."""

    if not isinstance(value, dict):
        raise ModuleError("CONFIGURATION_TYPE")
    required = {
        "EvidenceThreshold",
        "HitBurstGapFrames",
        "MinimumBurstHits",
        "CandidateMergeGapFrames",
        "MaximumCandidates",
        "ReviewPaddingFrames",
        "HighSeverityThreshold",
        "CriticalSeverityThreshold",
        "RankingPolicy",
    }
    if set(value) != required:
        raise ModuleError("CONFIGURATION_SHAPE")

    evidence_threshold = parse_finite(value["EvidenceThreshold"], "EVIDENCE_THRESHOLD")
    hit_gap = parse_integer(value["HitBurstGapFrames"], "HIT_BURST_GAP_FRAMES")
    minimum_hits = parse_integer(value["MinimumBurstHits"], "MINIMUM_BURST_HITS")
    merge_gap = parse_integer(value["CandidateMergeGapFrames"], "CANDIDATE_MERGE_GAP_FRAMES")
    maximum_candidates = parse_integer(value["MaximumCandidates"], "MAXIMUM_CANDIDATES")
    padding = parse_integer(value["ReviewPaddingFrames"], "REVIEW_PADDING_FRAMES")
    high = parse_finite(value["HighSeverityThreshold"], "HIGH_SEVERITY_THRESHOLD")
    critical = parse_finite(value["CriticalSeverityThreshold"], "CRITICAL_SEVERITY_THRESHOLD")

    if evidence_threshold <= 0.0:
        raise ModuleError("CONFIGURATION_EVIDENCE_THRESHOLD")
    if hit_gap < 1 or minimum_hits < 1:
        raise ModuleError("CONFIGURATION_BURST_POLICY")
    if merge_gap < hit_gap:
        raise ModuleError("CONFIGURATION_MERGE_GAP")
    if maximum_candidates < 1 or maximum_candidates > 40:
        raise ModuleError("CONFIGURATION_MAXIMUM_CANDIDATES")
    if padding < 0:
        raise ModuleError("CONFIGURATION_REVIEW_PADDING")
    if not evidence_threshold < high < critical:
        raise ModuleError("CONFIGURATION_SEVERITY_ORDER")
    if value["RankingPolicy"] != RANKING_POLICY:
        raise ModuleError("CONFIGURATION_RANKING_POLICY")

    return {
        "EvidenceThreshold": evidence_threshold,
        "HitBurstGapFrames": hit_gap,
        "MinimumBurstHits": minimum_hits,
        "CandidateMergeGapFrames": merge_gap,
        "MaximumCandidates": maximum_candidates,
        "ReviewPaddingFrames": padding,
        "HighSeverityThreshold": high,
        "CriticalSeverityThreshold": critical,
        "RankingPolicy": RANKING_POLICY,
    }


def artifact_record(request: Mapping[str, object]) -> Mapping[str, object]:
    matches = [
        item
        for item in request["InputArtifacts"]
        if item.get("ArtifactType") == REQUIRED_ARTIFACT
    ]
    if len(matches) != 1:
        raise ModuleError("ARTIFACT_COUNT_ROBUST_RESIDUAL_EVIDENCE")
    return matches[0]


def primary_csv(request: Mapping[str, object]) -> Tuple[Path, str]:
    """Resolve and hash-check the sole governed S5 primary payload."""

    record = artifact_record(request)
    run_root = Path(str(request["RunRoot"])).resolve()
    relative = safe_relative(record.get("ManifestRelativePath"), "MANIFEST")
    manifest_path = run_root.joinpath(*relative.parts).resolve()
    if not regular_file(manifest_path) or not inside(manifest_path, run_root):
        raise ModuleError("MANIFEST_MISSING_ROBUST_RESIDUAL_EVIDENCE")
    if sha256_file(manifest_path) != record.get("ManifestSha256"):
        raise ModuleError("MANIFEST_HASH_ROBUST_RESIDUAL_EVIDENCE")

    manifest = load_json(manifest_path, "MANIFEST")
    if manifest.get("ArtifactId") != record.get("ArtifactId"):
        raise ModuleError("ARTIFACT_ID_ROBUST_RESIDUAL_EVIDENCE")
    if manifest.get("ArtifactType") != REQUIRED_ARTIFACT:
        raise ModuleError("ARTIFACT_TYPE_ROBUST_RESIDUAL_EVIDENCE")
    candidates = [
        item
        for item in manifest.get("Payloads", [])
        if item.get("PayloadKind") == "PRIMARY"
        and item.get("MediaType") == "text/csv"
    ]
    if len(candidates) != 1:
        raise ModuleError("PRIMARY_CSV_COUNT_ROBUST_RESIDUAL_EVIDENCE")

    relative_payload = safe_relative(candidates[0].get("RelativePath"), "PAYLOAD")
    package_root = manifest_path.parent
    path = package_root.joinpath(*relative_payload.parts).resolve()
    if not regular_file(path) or not inside(path, package_root):
        raise ModuleError("PRIMARY_CSV_MISSING_ROBUST_RESIDUAL_EVIDENCE")
    if sha256_file(path) != candidates[0].get("Sha256"):
        raise ModuleError("PRIMARY_CSV_HASH_ROBUST_RESIDUAL_EVIDENCE")
    return path, str(manifest["ArtifactId"])


def required_source_columns() -> List[str]:
    return [
        "FrameCount",
        "CameraRadarResidual",
        "EvidenceScaleMeters",
        "SignedRobustScore",
        "RobustAnomalyScore",
        "EvidenceValid",
        "EvidenceReason",
        "EvidenceDirection",
    ]


def candidate_columns() -> List[str]:
    return [
        "CandidateId",
        "PriorityRank",
        "EvidenceStartFrame",
        "PeakFrameCount",
        "EvidenceEndFrame",
        "ReviewStartFrame",
        "ReviewEndFrame",
        "PeakRobustScore",
        "PeakSignedRobustScore",
        "PeakResidualMeters",
        "HitCount",
        "BurstCount",
        "EvidenceSpanFrames",
        "Severity",
        "CandidateReason",
        "EvidenceThreshold",
        "HitBurstGapFrames",
        "MinimumBurstHits",
        "CandidateMergeGapFrames",
        "ReviewPaddingFrames",
        "SourceArtifactId",
        "CandidateStatus",
        "RootCauseClaim",
    ]


def open_reader(path: Path) -> Tuple[object, csv.DictReader]:
    stream = path.open("r", encoding="utf-8-sig", newline="")
    reader = csv.DictReader(stream)
    header = reader.fieldnames or []
    missing = [name for name in required_source_columns() if name not in header]
    if missing:
        stream.close()
        raise ModuleError("CSV_COLUMN_" + missing[0])
    return stream, reader


def scan_evidence(
    input_path: Path,
    evidence_threshold: float,
) -> Tuple[List[Dict[str, object]], Dict[str, int]]:
    """Audit every S5 row and retain only threshold hits in memory."""

    stream, reader = open_reader(input_path)
    hits: List[Dict[str, object]] = []
    counts = {
        "FrameRows": 0,
        "EvidenceValidRows": 0,
        "EvidenceInvalidRows": 0,
        "ExceedanceRows": 0,
        "FrameStart": 0,
        "FrameEnd": 0,
    }
    previous: Optional[int] = None
    try:
        for row in reader:
            frame = parse_integer(row["FrameCount"], "FRAMECOUNT")
            if previous is not None and frame <= previous:
                raise ModuleError("FRAME_ORDER")
            if previous is None:
                counts["FrameStart"] = frame
            previous = frame
            counts["FrameEnd"] = frame
            counts["FrameRows"] += 1

            valid = parse_boolean(row["EvidenceValid"], "EVIDENCE_VALID")
            residual = optional_float(row["CameraRadarResidual"])
            scale = optional_float(row["EvidenceScaleMeters"])
            signed_score = optional_float(row["SignedRobustScore"])
            score = optional_float(row["RobustAnomalyScore"])

            if not valid:
                if signed_score is not None or score is not None:
                    raise ModuleError("INVALID_EVIDENCE_SCORE_PRESENT")
                counts["EvidenceInvalidRows"] += 1
                continue

            if residual is None or scale is None or signed_score is None or score is None:
                raise ModuleError("VALID_EVIDENCE_VALUE_MISSING")
            if scale <= 0.0 or score < 0.0:
                raise ModuleError("VALID_EVIDENCE_VALUE_RANGE")
            if not math.isclose(residual / scale, signed_score, rel_tol=1e-8, abs_tol=1e-8):
                raise ModuleError("SIGNED_SCORE_IDENTITY")
            if not math.isclose(abs(signed_score), score, rel_tol=1e-8, abs_tol=1e-8):
                raise ModuleError("ABSOLUTE_SCORE_IDENTITY")
            if row["EvidenceDirection"] != "TWO_SIDED_ABSOLUTE":
                raise ModuleError("EVIDENCE_DIRECTION")

            counts["EvidenceValidRows"] += 1
            if score >= evidence_threshold:
                hits.append({
                    "FrameCount": frame,
                    "RobustAnomalyScore": score,
                    "SignedRobustScore": signed_score,
                    "CameraRadarResidual": residual,
                })
                counts["ExceedanceRows"] += 1
    finally:
        stream.close()

    if counts["FrameRows"] == 0:
        raise ModuleError("ROBUST_RESIDUAL_EVIDENCE_EMPTY")
    return hits, counts


def group_hit_bursts(
    hits: Sequence[Mapping[str, object]],
    maximum_gap: int,
) -> List[List[Mapping[str, object]]]:
    """Group threshold hits by FrameCount proximity, not CSV adjacency."""

    if not hits:
        return []
    bursts: List[List[Mapping[str, object]]] = [[hits[0]]]
    for hit in hits[1:]:
        previous_frame = int(bursts[-1][-1]["FrameCount"])
        frame = int(hit["FrameCount"])
        if frame - previous_frame <= maximum_gap:
            bursts[-1].append(hit)
        else:
            bursts.append([hit])
    return bursts


def consolidate_bursts(
    bursts: Sequence[Sequence[Mapping[str, object]]],
    maximum_gap: int,
) -> List[List[Sequence[Mapping[str, object]]]]:
    """Consolidate accepted bursts into one review situation."""

    if not bursts:
        return []
    groups: List[List[Sequence[Mapping[str, object]]]] = [[bursts[0]]]
    for burst in bursts[1:]:
        previous_end = int(groups[-1][-1][-1]["FrameCount"])
        start = int(burst[0]["FrameCount"])
        if start - previous_end <= maximum_gap:
            groups[-1].append(burst)
        else:
            groups.append([burst])
    return groups


def severity(score: float, configuration: Mapping[str, object]) -> str:
    if score >= float(configuration["CriticalSeverityThreshold"]):
        return "CRITICAL"
    if score >= float(configuration["HighSeverityThreshold"]):
        return "HIGH"
    return "REVIEW"


def synthesize_candidates(
    hits: Sequence[Mapping[str, object]],
    frame_start: int,
    frame_end: int,
    configuration: Mapping[str, object],
    source_artifact_id: str,
) -> Tuple[List[Dict[str, object]], Dict[str, int]]:
    """Apply persistence, consolidation, ranking and the human-review cap."""

    raw_bursts = group_hit_bursts(
        hits,
        int(configuration["HitBurstGapFrames"]),
    )
    accepted_bursts = [
        burst
        for burst in raw_bursts
        if len(burst) >= int(configuration["MinimumBurstHits"])
    ]
    merged = consolidate_bursts(
        accepted_bursts,
        int(configuration["CandidateMergeGapFrames"]),
    )

    chronological: List[Dict[str, object]] = []
    padding = int(configuration["ReviewPaddingFrames"])
    for index, group in enumerate(merged, start=1):
        group_hits = [hit for burst in group for hit in burst]
        start = int(group_hits[0]["FrameCount"])
        end = int(group_hits[-1]["FrameCount"])
        peak = max(
            group_hits,
            key=lambda hit: (
                float(hit["RobustAnomalyScore"]),
                -int(hit["FrameCount"]),
            ),
        )
        peak_score = float(peak["RobustAnomalyScore"])
        chronological.append({
            "CandidateId": f"C{index:04d}",
            "PriorityRank": 0,
            "EvidenceStartFrame": start,
            "PeakFrameCount": int(peak["FrameCount"]),
            "EvidenceEndFrame": end,
            "ReviewStartFrame": max(frame_start, start - padding),
            "ReviewEndFrame": min(frame_end, end + padding),
            "PeakRobustScore": peak_score,
            "PeakSignedRobustScore": float(peak["SignedRobustScore"]),
            "PeakResidualMeters": float(peak["CameraRadarResidual"]),
            "HitCount": len(group_hits),
            "BurstCount": len(group),
            "EvidenceSpanFrames": end - start,
            "Severity": severity(peak_score, configuration),
            "CandidateReason": "ROBUST_RESIDUAL_SCORE_BURST",
            "EvidenceThreshold": float(configuration["EvidenceThreshold"]),
            "HitBurstGapFrames": int(configuration["HitBurstGapFrames"]),
            "MinimumBurstHits": int(configuration["MinimumBurstHits"]),
            "CandidateMergeGapFrames": int(configuration["CandidateMergeGapFrames"]),
            "ReviewPaddingFrames": padding,
            "SourceArtifactId": source_artifact_id,
            "CandidateStatus": "INVESTIGATION_CANDIDATE",
            "RootCauseClaim": 0,
        })

    ranked = sorted(
        chronological,
        key=lambda item: (
            -float(item["PeakRobustScore"]),
            -int(item["HitCount"]),
            int(item["EvidenceStartFrame"]),
        ),
    )
    maximum = int(configuration["MaximumCandidates"])
    exported = ranked[:maximum]
    for rank, item in enumerate(exported, start=1):
        item["PriorityRank"] = rank

    statistics = {
        "RawBurstCount": len(raw_bursts),
        "AcceptedBurstCount": len(accepted_bursts),
        "RejectedBurstCount": len(raw_bursts) - len(accepted_bursts),
        "CandidateCountBeforeTopK": len(chronological),
        "CandidateCountExported": len(exported),
        "TruncatedCandidateCount": max(0, len(chronological) - len(exported)),
    }
    return exported, statistics


def write_candidates(path: Path, candidates: Sequence[Mapping[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=candidate_columns(),
            lineterminator="\n",
        )
        writer.writeheader()
        for candidate in candidates:
            writer.writerow({
                name: csv_value(candidate.get(name))
                for name in candidate_columns()
            })


def package_manifest(
    request: Mapping[str, object],
    package_root: Path,
    primary_path: Path,
    quality_path: Path,
    candidates: Sequence[Mapping[str, object]],
    parent_id: str,
    metadata: Mapping[str, object],
) -> None:
    artifact_id = str(request["RunId"]) + "." + MODULE_ID + "." + str(request["Sequence"])
    manifest = {
        "ContractVersion": CONTRACT_VERSION,
        "ArtifactId": artifact_id,
        "ArtifactType": ARTIFACT_TYPE,
        "SchemaId": "U002_ANOMALY_CANDIDATES",
        "SchemaVersion": "0.1",
        "RunId": request["RunId"],
        "Stage": STAGE,
        "ProducerModuleId": MODULE_ID,
        "ProducerModuleVersion": MODULE_VERSION,
        "ParentArtifactIds": [parent_id],
        "Payloads": [
            {
                "RelativePath": primary_path.name,
                "MediaType": "text/csv",
                "RowCount": len(candidates),
                "Sha256": sha256_file(primary_path),
                "ByteSize": primary_path.stat().st_size,
                "PayloadKind": "PRIMARY",
            },
            {
                "RelativePath": quality_path.name,
                "MediaType": "application/json",
                "RowCount": None,
                "Sha256": sha256_file(quality_path),
                "ByteSize": quality_path.stat().st_size,
                "PayloadKind": "AUXILIARY",
            },
        ],
        "Metadata": dict(metadata),
    }
    write_json(package_root / "artifact_manifest.json", manifest)


def execute(request: Mapping[str, object]) -> Dict[str, object]:
    configuration = validate_configuration(request.get("Configuration"))
    input_path, parent_id = primary_csv(request)
    hits, counts = scan_evidence(
        input_path,
        float(configuration["EvidenceThreshold"]),
    )
    candidates, synthesis = synthesize_candidates(
        hits,
        counts["FrameStart"],
        counts["FrameEnd"],
        configuration,
        parent_id,
    )

    output_root = Path(str(request["OutputRoot"])).resolve()
    package_root = output_root / "artifact_01"
    package_root.mkdir(parents=True)
    primary_path = package_root / "anomaly_candidates.csv"
    write_candidates(primary_path, candidates)

    severity_counts = {"REVIEW": 0, "HIGH": 0, "CRITICAL": 0}
    for candidate in candidates:
        severity_counts[str(candidate["Severity"])] += 1
    quality = {
        "Contract": "U002_ANOMALY_CANDIDATES_QUALITY_V0_1",
        **counts,
        **synthesis,
        "SeverityCounts": severity_counts,
        "Configuration": dict(configuration),
        "CandidateInterpretation": "INVESTIGATION_CANDIDATES_FOR_HUMAN_REVIEW",
        "CandidateIsConfirmedEvent": False,
        "RootCauseClaim": False,
        "PersistenceApplied": True,
        "CandidateMergeApplied": True,
        "RankingApplied": True,
        "HumanReviewCapacityBounded": True,
    }
    quality_path = package_root / "anomaly_candidates_quality.json"
    write_json(quality_path, quality)
    package_manifest(
        request,
        package_root,
        primary_path,
        quality_path,
        candidates,
        parent_id,
        quality,
    )

    return {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "RunId": request["RunId"],
        "Sequence": request["Sequence"],
        "Stage": request["Stage"],
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Status": "SUCCEEDED",
        "ProducedPackages": ["artifact_01"],
        "Capsule": (
            "B4S6 N-R" + str(counts["FrameRows"])
            + "-V" + str(counts["EvidenceValidRows"])
            + "-H" + str(counts["ExceedanceRows"])
            + "-B" + str(synthesis["RawBurstCount"])
            + "-A" + str(synthesis["AcceptedBurstCount"])
            + "-C" + str(synthesis["CandidateCountExported"])
            + "-T" + str(synthesis["TruncatedCandidateCount"])
            + "-X0 C-0"
        ),
        "Diagnostics": [],
    }


def test_configuration(**overrides: object) -> Dict[str, object]:
    value: Dict[str, object] = {
        "EvidenceThreshold": 2.0,
        "HitBurstGapFrames": 20,
        "MinimumBurstHits": 2,
        "CandidateMergeGapFrames": 100,
        "MaximumCandidates": 40,
        "ReviewPaddingFrames": 400,
        "HighSeverityThreshold": 3.0,
        "CriticalSeverityThreshold": 5.0,
        "RankingPolicy": RANKING_POLICY,
    }
    value.update(overrides)
    return validate_configuration(value)


def test_hit(frame: int, score: float, signed: Optional[float] = None) -> Dict[str, object]:
    signed_score = score if signed is None else signed
    return {
        "FrameCount": frame,
        "RobustAnomalyScore": score,
        "SignedRobustScore": signed_score,
        "CameraRadarResidual": signed_score * 0.5,
    }


def semantic_selftest() -> int:
    checks: List[bool] = []

    def check(value: bool) -> None:
        if not value:
            raise AssertionError("SEMANTIC_SELFTEST")
        checks.append(True)

    configuration = test_configuration()
    check(configuration["MaximumCandidates"] == 40)
    check(severity(2.5, configuration) == "REVIEW")
    check(severity(3.0, configuration) == "HIGH")
    check(severity(5.0, configuration) == "CRITICAL")

    singleton = [test_hit(100, 2.1)]
    candidates, counts = synthesize_candidates(singleton, 0, 1000, configuration, "A")
    check(candidates == [])
    check(counts["RejectedBurstCount"] == 1)

    accepted = [test_hit(100, 2.1), test_hit(115, 3.2, -3.2)]
    candidates, counts = synthesize_candidates(accepted, 50, 200, configuration, "A")
    check(len(candidates) == 1)
    check(candidates[0]["EvidenceStartFrame"] == 100)
    check(candidates[0]["PeakFrameCount"] == 115)
    check(candidates[0]["EvidenceEndFrame"] == 115)
    check(candidates[0]["ReviewStartFrame"] == 50)
    check(candidates[0]["ReviewEndFrame"] == 200)
    check(candidates[0]["Severity"] == "HIGH")
    check(candidates[0]["HitCount"] == 2)
    check(candidates[0]["BurstCount"] == 1)
    check(counts["AcceptedBurstCount"] == 1)

    merge_hits = [
        test_hit(100, 2.1), test_hit(110, 2.2),
        test_hit(170, 3.2), test_hit(180, 3.1),
    ]
    candidates, counts = synthesize_candidates(merge_hits, 0, 1000, configuration, "A")
    check(len(candidates) == 1)
    check(candidates[0]["BurstCount"] == 2)
    check(candidates[0]["HitCount"] == 4)
    check(counts["RawBurstCount"] == 2)

    top_two = test_configuration(MaximumCandidates=2)
    rank_hits = [
        test_hit(100, 2.1), test_hit(110, 2.2),
        test_hit(300, 6.0), test_hit(310, 5.5),
        test_hit(500, 3.0), test_hit(510, 3.1),
    ]
    candidates, counts = synthesize_candidates(rank_hits, 0, 1000, top_two, "A")
    check(len(candidates) == 2)
    check(candidates[0]["EvidenceStartFrame"] == 300)
    check(candidates[1]["EvidenceStartFrame"] == 500)
    check(candidates[0]["PriorityRank"] == 1)
    check(counts["TruncatedCandidateCount"] == 1)
    check(candidate_columns()[0] == "CandidateId")
    check(candidate_columns()[-1] == "RootCauseClaim")
    check(ARTIFACT_TYPE == "ANOMALY_CANDIDATES")
    check(REQUIRED_ARTIFACT == "ROBUST_RESIDUAL_EVIDENCE")
    if len(checks) != 29:
        raise AssertionError("SELFTEST_COUNT")
    return len(checks)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request-json", required=True)
    parser.add_argument("--result-json", required=True)
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        request = load_json(Path(args.request_json), "REQUEST")
        validate_request(request)
        result = execute(request)
        write_json(Path(args.result_json), result)
        print(result["Capsule"])
        return 0
    except Exception as exc:
        print("B4S6 K-" + stable(exc) + "-X1 C-7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
