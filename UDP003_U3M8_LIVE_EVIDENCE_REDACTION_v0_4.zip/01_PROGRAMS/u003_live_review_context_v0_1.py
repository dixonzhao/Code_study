#!/usr/bin/env python3
"""File-based live review context bridge for interactive U003 Modules.

The bridge keeps action Modules isolated in child processes while allowing
them to follow the current U003 video frame and governed Event window.  The
JSON pointer is replaced atomically and references an immutable frame image.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


LIVE_CONTEXT_ID = "U003_LIVE_REVIEW_CONTEXT"
LIVE_CONTEXT_VERSION = "0.1"
DEFAULT_ROWS_BEFORE = 100
DEFAULT_ROWS_AFTER = 100


class LiveReviewContextError(RuntimeError):
    """Raised when live context cannot be published or validated."""


def safe_segment(value: str) -> str:
    """Return a stable filesystem-safe session segment."""

    compact = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip())
    return compact.strip("._-") or "U003_LOCAL_SESSION"


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    """Write one JSON object without exposing a partially written pointer."""

    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def validate_live_context(payload: dict[str, Any]) -> dict[str, Any]:
    """Fail closed on malformed live-context payloads."""

    if payload.get("ContractId") != LIVE_CONTEXT_ID:
        raise LiveReviewContextError("Live context ContractId is invalid.")
    if payload.get("ContractVersion") != LIVE_CONTEXT_VERSION:
        raise LiveReviewContextError("Live context ContractVersion is invalid.")
    if not isinstance(payload.get("Sequence"), int) or payload["Sequence"] < 1:
        raise LiveReviewContextError("Live context Sequence must be a positive integer.")
    if not isinstance(payload.get("CurrentCANFrameCount"), int):
        raise LiveReviewContextError("CurrentCANFrameCount must be an integer.")
    frame_path = Path(str(payload.get("CurrentFrameImagePath", "")))
    if not frame_path.is_file():
        raise LiveReviewContextError("CurrentFrameImagePath does not exist.")
    start = payload.get("DefaultRangeStartFrame")
    end = payload.get("DefaultRangeEndFrame")
    if not isinstance(start, int) or not isinstance(end, int) or start > end:
        raise LiveReviewContextError("Default review range is invalid.")
    if payload.get("RangeSource") not in {"EVENT", "CURRENT_FRAME"}:
        raise LiveReviewContextError("RangeSource is invalid.")
    return payload


def build_live_context(
    *,
    sequence: int,
    frame_image_path: Path,
    current_framecount: int,
    current_video_frame: int,
    event_id: str,
    event_start: int | None,
    event_peak: int | None,
    event_end: int | None,
    language: str,
) -> dict[str, Any]:
    """Create context with Event-first, current-frame-fallback range semantics."""

    has_event_range = (
        event_start is not None
        and event_end is not None
        and int(event_start) <= int(event_end)
    )
    if has_event_range:
        range_start = int(event_start)
        range_end = int(event_end)
        range_source = "EVENT"
    else:
        range_start = int(current_framecount) - DEFAULT_ROWS_BEFORE
        range_end = int(current_framecount) + DEFAULT_ROWS_AFTER
        range_source = "CURRENT_FRAME"
    peak = int(event_peak) if event_peak is not None else int(current_framecount)
    payload = {
        "ContractId": LIVE_CONTEXT_ID,
        "ContractVersion": LIVE_CONTEXT_VERSION,
        "Sequence": int(sequence),
        "PublishedMonotonicNanoseconds": time.monotonic_ns(),
        "CurrentFrameImagePath": str(frame_image_path.resolve()),
        "CurrentCANFrameCount": int(current_framecount),
        "CurrentVideoFrame": int(current_video_frame),
        "EventID": str(event_id or "NO_EVENT"),
        "ReviewStartFrame": int(event_start) if event_start is not None else None,
        "PeakFrameCount": int(event_peak) if event_peak is not None else None,
        "ReviewEndFrame": int(event_end) if event_end is not None else None,
        "RangeSource": range_source,
        "DefaultRangeStartFrame": range_start,
        "DefaultRangeEndFrame": range_end,
        "DefaultRowsBefore": DEFAULT_ROWS_BEFORE,
        "DefaultRowsAfter": DEFAULT_ROWS_AFTER,
        "PeakHighlightDefault": True,
        "PeakDataLabelDefault": False,
        "EffectivePeakFrame": peak,
        "Language": str(language).upper(),
    }
    return validate_live_context(payload)


@dataclass
class LiveReviewContextPublisher:
    """Publish frame snapshots only while one interactive action subscribes."""

    root: Path
    cv2: Any
    run_id: str
    language: str
    minimum_playback_interval_seconds: float = 0.20

    def __post_init__(self) -> None:
        self.session_root = (
            self.root.resolve() / safe_segment(self.run_id)
        )
        self.context_path = self.session_root / "live_review_context.json"
        self.sequence = 0
        self.active = False
        self.last_publish_clock = 0.0

    def start(self) -> Path:
        self.session_root.mkdir(parents=True, exist_ok=True)
        self.active = True
        return self.context_path

    def stop(self) -> None:
        self.active = False

    def publish(
        self,
        *,
        frame: Any,
        current_framecount: int,
        current_video_frame: int,
        event_id: str,
        event_start: int | None,
        event_peak: int | None,
        event_end: int | None,
        force: bool,
    ) -> Path | None:
        if not self.active:
            return None
        now = time.monotonic()
        if not force and now - self.last_publish_clock < self.minimum_playback_interval_seconds:
            return self.context_path
        self.sequence += 1
        frame_path = self.session_root / f"frame_{self.sequence:08d}.png"
        if not self.cv2.imwrite(str(frame_path), frame):
            raise LiveReviewContextError("OpenCV failed to publish the live frame image.")
        payload = build_live_context(
            sequence=self.sequence,
            frame_image_path=frame_path,
            current_framecount=current_framecount,
            current_video_frame=current_video_frame,
            event_id=event_id,
            event_start=event_start,
            event_peak=event_peak,
            event_end=event_end,
            language=self.language,
        )
        write_json_atomic(self.context_path, payload)
        self.last_publish_clock = now
        self._remove_old_frames(keep=3)
        return self.context_path

    def _remove_old_frames(self, keep: int) -> None:
        frames = sorted(self.session_root.glob("frame_*.png"))
        for path in frames[:-max(1, int(keep))]:
            try:
                path.unlink()
            except OSError:
                # A child process may be reading the previous immutable frame.
                pass


def run_self_test() -> int:
    """Exercise identity, range semantics, and fail-closed validation."""

    import tempfile
    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u003_live_context_") as temporary:
        root = Path(temporary)
        frame_path = root / "frame.png"
        frame_path.write_bytes(b"fixture")
        event_payload = build_live_context(
            sequence=1,
            frame_image_path=frame_path,
            current_framecount=150,
            current_video_frame=12,
            event_id="C001",
            event_start=100,
            event_peak=140,
            event_end=180,
            language="EN",
        )
        check(event_payload["RangeSource"] == "EVENT")
        check(event_payload["DefaultRangeStartFrame"] == 100)
        check(event_payload["DefaultRangeEndFrame"] == 180)
        check(event_payload["EffectivePeakFrame"] == 140)
        fallback = build_live_context(
            sequence=2,
            frame_image_path=frame_path,
            current_framecount=500,
            current_video_frame=20,
            event_id="NO_EVENT",
            event_start=None,
            event_peak=None,
            event_end=None,
            language="JA",
        )
        check(fallback["RangeSource"] == "CURRENT_FRAME")
        check(fallback["DefaultRangeStartFrame"] == 400)
        check(fallback["DefaultRangeEndFrame"] == 600)
        check(fallback["PeakHighlightDefault"] is True)
        check(fallback["PeakDataLabelDefault"] is False)
        check(safe_segment("LOCAL / CASE") == "LOCAL_CASE")
        output = root / "context.json"
        write_json_atomic(output, fallback)
        check(json.loads(output.read_text(encoding="utf-8"))["Sequence"] == 2)
        check(LIVE_CONTEXT_VERSION == "0.1")

        class FakeCV2:
            @staticmethod
            def imwrite(path: str, _frame: Any) -> bool:
                Path(path).write_bytes(b"frame")
                return True

        publisher = LiveReviewContextPublisher(
            root=root / "publisher",
            cv2=FakeCV2(),
            run_id="CASE / 01",
            language="EN",
            minimum_playback_interval_seconds=0.0,
        )
        check(publisher.start().name == "live_review_context.json")
        for framecount in range(10, 15):
            published = publisher.publish(
                frame=object(),
                current_framecount=framecount,
                current_video_frame=framecount - 10,
                event_id="C001",
                event_start=8,
                event_peak=12,
                event_end=20,
                force=True,
            )
        check(published is not None and published.is_file())
        check(publisher.sequence == 5)
        check(len(list(publisher.session_root.glob("frame_*.png"))) == 3)
        publisher.stop()
        check(
            publisher.publish(
                frame=object(),
                current_framecount=99,
                current_video_frame=99,
                event_id="NO_EVENT",
                event_start=None,
                event_peak=None,
                event_end=None,
                force=True,
            )
            is None
        )
    print(f"U003-LIVE-CONTEXT-SELFTEST-PASS-{checks} C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(run_self_test())
