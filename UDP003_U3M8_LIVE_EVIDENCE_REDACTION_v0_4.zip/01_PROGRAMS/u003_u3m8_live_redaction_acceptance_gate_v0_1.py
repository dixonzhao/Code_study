#!/usr/bin/env python3
"""Installed-source acceptance gate for U3M8 live evidence redaction."""

from __future__ import annotations

import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path


MODULE_ID = "CameraRadar.U003.FrameMask"
MODULE_VERSION = "0.4.0"


class GateError(RuntimeError):
    """Raised when installed U3M8 evidence is incomplete."""


def run_child(path: Path, expected: str) -> None:
    completed = subprocess.run(
        [sys.executable, str(path), "--self-test"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=90,
        check=False,
    )
    if completed.returncode != 0 or expected not in completed.stdout:
        raise GateError(
            f"Child self-test failed: {path.name}; rc={completed.returncode}; "
            f"stdout={completed.stdout[-500:]}; stderr={completed.stderr[-500:]}"
        )


def run_gate(root: Path) -> int:
    root = root.resolve()
    program_root = root / "01_PROGRAMS"
    module_root = (
        root
        / "02_MODULES"
        / "EVIDENCE_VIEW"
        / MODULE_ID
        / MODULE_VERSION
    )
    contract_path = (
        root
        / "02_CONTROLS"
        / "contracts"
        / "u003_live_review_context_contract_v0_1.json"
    )
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise GateError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    required = (
        program_root / "u003_evidence_review_workbench_v0_20.py",
        program_root / "u003_gui_shell_v0_7.py",
        program_root / "u003_module_action_gui_v0_2.py",
        program_root / "u003_live_review_context_v0_1.py",
        program_root / "u003_u3m8_live_redaction_acceptance_gate_v0_1.py",
        module_root / "module_manifest.json",
        module_root / "algorithm_card.json",
        module_root / "implementation.py",
        contract_path,
    )
    for path in required:
        check(path.is_file(), f"required file {path.name}", "installed topology is complete")

    sys.path.insert(0, str(program_root))
    workbench = importlib.import_module("u003_evidence_review_workbench_v0_20")
    shell = importlib.import_module("u003_gui_shell_v0_7")
    action_gui = importlib.import_module("u003_module_action_gui_v0_2")
    live = importlib.import_module("u003_live_review_context_v0_1")
    runtime = importlib.import_module("u003_module_runtime_v0_2")
    check(workbench.VERSION == "0.20", "workbench version", "latest composition launches")
    check(shell.GUI_SHELL_VERSION == "0.7", "GUI shell version", "live publishing is active")
    check(action_gui.ACTION_GUI_VERSION == "0.2", "action GUI version", "child action runs off the tkinter thread")
    check(live.LIVE_CONTEXT_VERSION == "0.1", "live context version", "file bridge is governed")

    manifest = json.loads((module_root / "module_manifest.json").read_text(encoding="utf-8"))
    card = json.loads((module_root / "algorithm_card.json").read_text(encoding="utf-8"))
    schema = json.loads(contract_path.read_text(encoding="utf-8"))
    check(manifest["ModuleId"] == MODULE_ID, "Module identity", "internal identity remains stable")
    check(manifest["ModuleVersion"] == MODULE_VERSION, "Module version", "new behavior is selectable")
    check(manifest["DisplayName"]["EN"] == "Evidence Image Redaction", "business name", "privacy wording removed")
    action = manifest["UserActions"][0]
    check(action["ActionId"] == "EXPORT_REDACTED_EVIDENCE", "action identity", "repeatable export has a clear name")
    check("LiveReviewContextPath" in action["RequiredContextFields"], "live context required", "the child follows U003")
    check("ExportRecords" in action["ProducedFields"], "multi-export evidence", "all frame exports remain traceable")
    check(card["AlgorithmCardId"].endswith("0.4.0"), "Algorithm Card version", "design and code agree")
    check(schema["$id"].endswith("0.1"), "context schema identity", "future Modules share one contract")

    descriptor = runtime.validate_module_manifest(module_root / "module_manifest.json", root / "02_MODULES")
    check(descriptor.module_id == MODULE_ID, "runtime discovery", "the existing registry accepts the package")
    check(len(descriptor.user_actions) == 1, "one governed action", "launcher inventory is deterministic")
    check(descriptor.user_actions[0].timeout_seconds == 3600, "interactive timeout", "one-hour bounded session remains available")

    shell_source = (program_root / "u003_gui_shell_v0_7.py").read_text(encoding="utf-8")
    action_source = (program_root / "u003_module_action_gui_v0_2.py").read_text(encoding="utf-8")
    module_source = (module_root / "implementation.py").read_text(encoding="utf-8")
    check("threading.Thread" in action_source, "non-blocking worker", "U003 tkinter loop is not occupied")
    check("_publish_live_review_context(force=True)" in shell_source, "manual navigation publish", "jumps update immediately")
    check("_publish_live_review_context(force=False)" in shell_source, "playback publish", "playback updates are throttled")
    check("refresh_from_live_context" in module_source, "child polling", "redaction window follows U003")
    check("self.root.destroy()" not in module_source.split("def export_pair", 1)[1].split("def execute", 1)[0], "repeat export", "export does not close the editor")
    check("ExportRecords" in module_source, "export inventory source", "multiple outputs are returned")

    fixture_frame = root / "04_TEMP" / "U3M8_GATE_FIXTURE.png"
    fixture_frame.parent.mkdir(parents=True, exist_ok=True)
    fixture_frame.write_bytes(b"fixture")
    event_context = live.build_live_context(
        sequence=1,
        frame_image_path=fixture_frame,
        current_framecount=150,
        current_video_frame=10,
        event_id="C001",
        event_start=100,
        event_peak=140,
        event_end=180,
        language="EN",
    )
    check(event_context["RangeSource"] == "EVENT", "Event range priority", "selected candidate controls chart range")
    check(event_context["DefaultRangeStartFrame"] == 100, "Event range start", "candidate boundary is preserved")
    check(event_context["DefaultRangeEndFrame"] == 180, "Event range end", "candidate boundary is preserved")
    fallback = live.build_live_context(
        sequence=2,
        frame_image_path=fixture_frame,
        current_framecount=500,
        current_video_frame=20,
        event_id="NO_EVENT",
        event_start=None,
        event_peak=None,
        event_end=None,
        language="JA",
    )
    check(fallback["DefaultRangeStartFrame"] == 400, "fallback before", "default is current minus 100")
    check(fallback["DefaultRangeEndFrame"] == 600, "fallback after", "default is current plus 100")
    check(fallback["PeakHighlightDefault"] is True, "peak highlight option", "future chart Module receives an explicit default")
    check(fallback["PeakDataLabelDefault"] is False, "peak label option", "labels are optional rather than forced")

    run_child(program_root / "u003_evidence_review_workbench_v0_20.py", "U003-V020-SELFTEST-PASS-24")
    check(True, "workbench self-test", "composition imports exact versions")
    run_child(program_root / "u003_live_review_context_v0_1.py", "U003-LIVE-CONTEXT-SELFTEST-PASS-17")
    check(True, "live-context self-test", "range and publisher behavior pass")
    run_child(program_root / "u003_module_action_gui_v0_2.py", "U003-ACTION-GUI-V02-SELFTEST-PASS-8")
    check(True, "action-GUI self-test", "background execution entry points pass")
    run_child(module_root / "implementation.py", "U003-U3M8-MODULE-SELFTEST-PASS-23")
    check(True, "redaction Module self-test", "geometry and output helpers pass")

    try:
        fixture_frame.unlink()
    except OSError:
        pass
    print(f"U3M8G N-M1-A1-L1-S1-E1-R1-T{checks}-X0 C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    return run_gate(arguments.root)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M8GE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
