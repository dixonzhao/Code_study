#!/usr/bin/env python3
"""U003 Evidence Review Workbench v0.20 source composition.

Version 0.20 keeps Module Actions isolated while allowing interactive child
tools to follow the current Review Workbench frame without blocking U003.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from u003_domain_core_v0_2 import DOMAIN_VERSION
from u003_gui_shell_v0_7 import FrameCountVideoReviewer, GUI_SHELL_VERSION
from u003_handoff_core_v0_2 import (
    HANDOFF_CONTRACT_ID,
    HANDOFF_CONTRACT_VERSION,
    HANDOFF_CORE_VERSION,
    load_governed_handoff,
)
from u003_localization_v0_2 import (
    LOCALIZATION_VERSION,
    Localizer,
    choose_session_language,
    normalize_language,
)
from u003_live_review_context_v0_1 import LIVE_CONTEXT_VERSION
from u003_module_action_gui_v0_2 import ACTION_GUI_VERSION
from u003_module_execution_coordinator_v0_3 import COORDINATOR_VERSION
from u003_module_manager_gui_v0_4 import MANAGER_VERSION
from u003_module_plan_core_v0_2 import PLAN_CORE_VERSION


VERSION = "0.20"
LAUNCH_INTERFACE_ID = "CameraRadar.U003.HandoffLauncher"
LAUNCH_INTERFACE_VERSION = "0.1"
CAPABILITY_OUTPUT_ENV = "U003_CAPABILITY_OUTPUT"


def launch_capability() -> dict[str, object]:
    """Return the stable automatic-launch contract for U002 and packaging."""

    return {
        "InterfaceId": LAUNCH_INTERFACE_ID,
        "InterfaceVersion": LAUNCH_INTERFACE_VERSION,
        "ProgramId": "CameraRadar.U003.EvidenceReviewWorkbench",
        "ProgramVersion": VERSION,
        "SupportedArguments": [
            "--handoff-descriptor",
            "--print-launch-capability",
            "--language",
        ],
        "AcceptedHandoffContractId": HANDOFF_CONTRACT_ID,
        "AcceptedHandoffContractVersion": HANDOFF_CONTRACT_VERSION,
    }


def emit_launch_capability() -> None:
    """Publish capability to stdout and an optional sidecar for windowed EXEs."""

    payload = json.dumps(launch_capability(), sort_keys=True, separators=(",", ":"))
    output_value = os.environ.get(CAPABILITY_OUTPUT_ENV, "").strip()
    if output_value:
        output_path = Path(output_value).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        writing = output_path.with_name(output_path.name + ".writing")
        if writing.exists():
            writing.unlink()
        writing.write_text(payload + "\n", encoding="utf-8")
        writing.replace(output_path)
    try:
        print(payload)
    except (AttributeError, OSError):
        pass


def run_self_test() -> int:
    """Check composition identity without opening tkinter or importing OpenCV."""

    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"Composition check {checks + 1} failed.")
        checks += 1

    capability = launch_capability()
    check(VERSION == "0.20")
    check(DOMAIN_VERSION == "0.2")
    check(HANDOFF_CORE_VERSION == "0.2")
    check(GUI_SHELL_VERSION == "0.7")
    check(PLAN_CORE_VERSION == "0.2")
    check(MANAGER_VERSION == "0.4")
    check(ACTION_GUI_VERSION == "0.2")
    check(LIVE_CONTEXT_VERSION == "0.1")
    check(LOCALIZATION_VERSION == "0.2")
    check(COORDINATOR_VERSION == "0.3")
    check(FrameCountVideoReviewer.__module__ == "u003_gui_shell_v0_7")
    check(capability["InterfaceId"] == LAUNCH_INTERFACE_ID)
    check(capability["InterfaceVersion"] == LAUNCH_INTERFACE_VERSION)
    check(capability["ProgramVersion"] == VERSION)
    check(capability["AcceptedHandoffContractId"] == HANDOFF_CONTRACT_ID)
    check(
        capability["AcceptedHandoffContractVersion"]
        == HANDOFF_CONTRACT_VERSION
    )
    check("--handoff-descriptor" in capability["SupportedArguments"])
    check("--print-launch-capability" in capability["SupportedArguments"])
    check("--language" in capability["SupportedArguments"])
    check(normalize_language("en") == "EN")
    check(normalize_language("ja") == "JA")
    check(Localizer("JA").text("Open Video") == "映像を開く")
    check(Localizer("EN").text("Open Video") == "Open Video")
    check(Localizer("JA").text("Module execution error") == "モジュール実行エラー")
    print(f"U003-V020-SELFTEST-PASS-{checks}")
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--print-launch-capability", action="store_true")
    parser.add_argument("--handoff-descriptor")
    parser.add_argument("--open-module-manager", action="store_true")
    parser.add_argument("--language", choices=["EN", "JA"])
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    if arguments.self_test:
        return run_self_test()
    if arguments.print_launch_capability:
        emit_launch_capability()
        return 0
    language = "EN"
    try:
        selected_language = arguments.language or choose_session_language()
        if selected_language is None:
            return 0
        language = normalize_language(selected_language)
        handoff = (
            load_governed_handoff(Path(arguments.handoff_descriptor))
            if arguments.handoff_descriptor
            else None
        )
        application = FrameCountVideoReviewer(language=language)
        if handoff is not None:
            application.load_handoff(handoff)
        if arguments.open_module_manager:
            application.root.after(250, application.open_module_manager)
        application.run()
        return 0
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        try:
            import tkinter as tk
            from tkinter import messagebox

            root = tk.Tk()
            root.withdraw()
            localizer = Localizer(language)
            messagebox.showerror(
                localizer.text("U003 Evidence Review Workbench error"),
                localizer.text(str(error)),
            )
            root.destroy()
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
