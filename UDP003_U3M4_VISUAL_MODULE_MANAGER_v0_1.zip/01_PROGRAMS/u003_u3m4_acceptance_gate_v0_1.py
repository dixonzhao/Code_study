#!/usr/bin/env python3
"""Accept the visual U003 Module Manager without enabling Module execution."""

from __future__ import annotations

import argparse
import ast
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import u003_evidence_review_workbench_v0_15 as entry
import u003_gui_shell_v0_2 as gui
import u003_module_manager_gui_v0_1 as manager
import u003_module_plan_core_v0_1 as plan_core
import u003_module_runtime_v0_1 as runtime


GATE_VERSION = "0.1"
EXPECTED_PREREQUISITES = {
    "u003_module_runtime_v0_1.py": "617b0a756acfbf1ce7db9f40f1e080ac0a2d22d5a35db8228518254f187bd370",
    "u003_module_executor_v0_1.py": "c374b0cdc0ca56228e0f67bd98ba8bfcfce90ae0fd98629adc45566125efaf27",
    "u003_gui_shell_v0_1.py": "73d3dc4bbc4f8e57f7d4b6d85b4752b39b8da0dce5d32cd837a21cd7f34ca739",
    "u003_evidence_review_workbench_v0_14.py": "829efc6054c68e5a51f95ce90f9802acdf7111e06cf1809b82b54670367b8d7a",
}
ALLOWED_CHANGED_METHODS = {"__init__", "_build_ui"}
EXPECTED_NEW_METHODS = {"_module_plan_changed", "open_module_manager"}


class AcceptanceError(RuntimeError):
    """Raised when U3M4 violates the accepted U003 or U3M1/U3M2 contracts."""


def sha256_file(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(path: Path, name: str) -> Any:
    specification = importlib.util.spec_from_file_location(name, path)
    if specification is None or specification.loader is None:
        raise AcceptanceError(f"Python source could not be loaded: {path}")
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


def class_methods(source_path: Path, class_name: str) -> dict[str, ast.AST]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    classes = [
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == class_name
    ]
    if len(classes) != 1:
        raise AcceptanceError(
            f"Expected one {class_name} in {source_path.name}; found {len(classes)}."
        )
    return {
        node.name: node
        for node in classes[0].body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def imported_modules(source_path: Path) -> set[str]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module)
    return names


def create_second_version(module_root: Path) -> None:
    source = (
        module_root
        / "REVIEW_ASSIST"
        / "CameraRadar.U003.ReviewDispositionLabels"
        / "0.1.0"
    )
    destination = source.parent / "0.2.0"
    shutil.copytree(source, destination)
    manifest_path = destination / "module_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["ModuleVersion"] = "0.2.0"
    manifest["Description"]["EN"] += " Version-selection fixture."
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    card_path = destination / "algorithm_card.json"
    card = json.loads(card_path.read_text(encoding="utf-8"))
    card["AlgorithmCardId"] = "CameraRadar.U003.ReviewDispositionLabels.0.2.0"
    card_path.write_text(json.dumps(card), encoding="utf-8")


def run_acceptance(open_gui: bool, verbose: bool) -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(name)
        checks += 1
        if verbose:
            print(f"[CHECK {checks:03d}] {name} - {reason}")

    program_root = Path(__file__).resolve().parent
    project_root = program_root.parent
    module_root = project_root / "02_MODULES"

    for file_name, expected_hash in EXPECTED_PREREQUISITES.items():
        path = program_root / file_name
        check(path.is_file(), f"prerequisite {file_name}", "the accepted predecessor is installed")
        check(sha256_file(path) == expected_hash, f"identity {file_name}", "the predecessor cannot drift")

    old_gui_path = program_root / "u003_gui_shell_v0_1.py"
    new_gui_path = Path(gui.__file__).resolve()
    old_methods = class_methods(old_gui_path, "FrameCountVideoReviewer")
    new_methods = class_methods(new_gui_path, "FrameCountVideoReviewer")
    check(len(old_methods) == 67, "old GUI inventory", "U3M3B method count remains fixed")
    check(set(new_methods) - set(old_methods) == EXPECTED_NEW_METHODS, "new GUI inventory", "only Module Manager integration methods were added")
    unchanged_methods = sorted(set(old_methods) - ALLOWED_CHANGED_METHODS)
    for method_name in unchanged_methods:
        check(
            ast.dump(old_methods[method_name], include_attributes=False)
            == ast.dump(new_methods[method_name], include_attributes=False),
            f"GUI method {method_name}",
            "unrelated review behavior is AST-identical to v0.14",
        )
    check("open_module_manager" in new_methods, "manager open action", "the main GUI exposes the child window")
    check("_module_plan_changed" in new_methods, "plan callback", "the main GUI receives visible selection count")

    manager_imports = imported_modules(Path(manager.__file__).resolve())
    check("u003_module_executor_v0_1" not in manager_imports, "manager execution isolation", "U3M4 cannot execute Module code")
    check(manager.MANAGER_VERSION == "0.1", "manager version", "visual ownership is independently versioned")
    check(plan_core.PLAN_CORE_VERSION == "0.1", "plan version", "plan semantics are independently versioned")
    check(entry.VERSION == "0.15", "entry version", "the new composition is identifiable")

    accepted_catalog = plan_core.discover_catalog(module_root)
    accepted_families = plan_core.descriptors_by_family(accepted_catalog)
    check(len(accepted_catalog.descriptors) == 2, "accepted Module versions", "both U3M1/U3M2 fixtures remain discoverable")
    check(len(accepted_families) == 2, "accepted Module families", "the GUI groups by ModuleId")
    check(all(len(items) == 1 for items in accepted_families.values()), "accepted version grouping", "current fixtures each have one version")

    with tempfile.TemporaryDirectory(prefix="u003_u3m4_") as temporary:
        root = Path(temporary)
        fixture_root = root / "02_MODULES"
        shutil.copytree(module_root, fixture_root)
        create_second_version(fixture_root)
        catalog = plan_core.discover_catalog(fixture_root)
        families = plan_core.descriptors_by_family(catalog)
        check(len(catalog.descriptors) == 3, "multi-version catalog", "every valid version remains available")
        check(len(families) == 2, "collapsed families", "the visual list stays compact")
        label_id = "CameraRadar.U003.ReviewDispositionLabels"
        memo_id = "CameraRadar.U003.SampleMemoDraft"
        check([item.module_version for item in families[label_id]] == ["0.2.0", "0.1.0"], "version order", "newest semantic version appears first")

        plan = plan_core.empty_plan(fixture_root, "EN")
        check(plan.selected_count() == 0, "empty default plan", "no Module changes existing behavior silently")
        recommended = plan_core.recommended_plan(catalog, "EN")
        check(recommended.selected_count() == 1, "recommended plan", "recommended Modules require an explicit action")
        check(recommended.selections[0].module_id == label_id, "recommended identity", "EnabledByDefault remains advisory")
        check(recommended.selections[0].module_version == "0.2.0", "recommended version", "latest valid version is proposed")

        memo_descriptor = plan_core.find_descriptor(catalog, memo_id, "0.1.0")
        plan = plan_core.add_or_replace_selection(recommended, memo_descriptor)
        check(plan.selected_count() == 2, "add second family", "one exact version per ModuleId is selected")
        old_label = plan_core.find_descriptor(catalog, label_id, "0.1.0")
        plan = plan_core.add_or_replace_selection(plan, old_label)
        check(plan.selected_count() == 2, "replace version", "selecting another version does not duplicate a family")
        check(next(item for item in plan.selections if item.module_id == label_id).module_version == "0.1.0", "selected old version", "older valid versions remain selectable")

        moved = plan_core.move_within_slot(plan, memo_id, -1)
        check(moved.selections[0].module_id == memo_id, "within-slot move", "engineer order is retained inside one slot")
        cross_slot = plan_core.ModulePlan(
            language="EN",
            module_root=str(fixture_root.resolve()),
            selections=(
                plan_core.PlanSelection("IMPORT_ADAPTER", "Test.Import", "0.1.0", "a" * 64),
                plan_core.PlanSelection("REVIEW_ASSIST", "Test.Review", "0.1.0", "b" * 64),
            ),
        )
        try:
            plan_core.move_within_slot(cross_slot, "Test.Review", -1)
        except plan_core.ModulePlanError as error:
            check("slot boundaries" in str(error), "cross-slot move rejected", "slot responsibility cannot be bypassed")
        else:
            raise AcceptanceError("cross-slot move was accepted")

        plan_path = root / "module_plan.json"
        plan_core.write_plan(moved, plan_path)
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
        check(payload["ExecutionEnabled"] is False, "execution disabled", "U3M4 is planning-only")
        check(payload["SelectedModuleCount"] == 2, "saved inventory", "plan count is explicit")
        reopened = plan_core.read_plan(plan_path, catalog)
        check(reopened.selections == moved.selections, "plan round trip", "saved exact versions and order are reproducible")
        payload["SelectedModules"][0]["PackageSha256"] = "0" * 64
        plan_path.write_text(json.dumps(payload), encoding="utf-8")
        try:
            plan_core.read_plan(plan_path, catalog)
        except plan_core.ModulePlanError as error:
            check("package changed" in str(error), "changed package rejected", "a plan cannot silently bind modified code")
        else:
            raise AcceptanceError("changed package was accepted")

        localized = plan_core.localized_card_value(
            {"Title": {"EN": "English", "JA": "日本語"}}, "JA"
        )
        check(localized["Title"] == "日本語", "card Japanese", "localized card fields use requested text")
        fallback = plan_core.localized_card_value(
            {"Title": {"EN": "English", "JA": ""}}, "JA"
        )
        check(fallback["Title"] == "English", "card fallback", "blank Japanese remains readable")
        check(bool(manager._card_lines(localized)), "card presentation", "Algorithm Card is rendered as readable sections")

    old_entry = load_module(
        program_root / "u003_evidence_review_workbench_v0_14.py",
        "u003_entry_v014_u3m4",
    )
    old_capability = old_entry.launch_capability()
    new_capability = entry.launch_capability()
    for key in set(old_capability) - {"ProgramVersion"}:
        check(old_capability[key] == new_capability[key], f"capability {key}", "U002 launch contract remains unchanged")
    check(new_capability["ProgramVersion"] == "0.15", "capability version", "the Module Manager build is externally identifiable")

    entry_path = Path(entry.__file__).resolve()
    result = subprocess.run(
        [sys.executable, str(entry_path), "--self-test"],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    check(result.returncode == 0, "entry self-test exit", "v0.15 imports in a fresh process")
    check("U003-V015-SELFTEST-PASS-14" in result.stdout, "entry self-test capsule", "composition evidence is explicit")

    gui_opened = 0
    if open_gui:
        print(
            "[ACTION] U003 v0.15 and Module Manager will open. Confirm two Module "
            "families are visible, then close the main U003 window."
        )
        result = subprocess.run(
            [sys.executable, str(entry_path), "--open-module-manager"],
            timeout=None,
            check=False,
        )
        check(result.returncode == 0, "GUI normal close", "the Module Manager opens on the company host")
        gui_opened = 1

    print(
        f"U3M4 N-L1-G{gui_opened}-P1-M2-V2-R1-S1-T{checks}-X0 C-0"
    )
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--accept", action="store_true")
    parser.add_argument("--open-gui", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if not arguments.self_test and not arguments.accept:
            raise AcceptanceError("Use --self-test or --accept.")
        return run_acceptance(
            open_gui=arguments.open_gui,
            verbose=arguments.accept,
        )
    except Exception as error:
        print(
            f"U3M4E K-{type(error).__name__.upper()} D-{error} X1 C-7",
            file=sys.stderr,
        )
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
