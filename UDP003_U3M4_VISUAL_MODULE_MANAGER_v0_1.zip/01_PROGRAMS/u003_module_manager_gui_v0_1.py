#!/usr/bin/env python3
"""Visual U003 Module Manager for discovery, selection, ordering, and plans."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

import u003_module_plan_core_v0_1 as plan_core


MANAGER_VERSION = "0.1"


def _card_lines(value: Any, indent: int = 0) -> list[str]:
    prefix = "  " * indent
    if isinstance(value, dict):
        lines: list[str] = []
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                lines.append(f"{prefix}{key}")
                lines.extend(_card_lines(item, indent + 1))
            else:
                lines.append(f"{prefix}{key}: {item}")
        return lines
    if isinstance(value, list):
        lines = []
        for item in value:
            if isinstance(item, (dict, list)):
                lines.append(f"{prefix}•")
                lines.extend(_card_lines(item, indent + 1))
            else:
                lines.append(f"{prefix}• {item}")
        return lines
    return [f"{prefix}{value}"]


class ModuleManagerWindow:
    """One reusable child window; it never executes Module code in U3M4."""

    def __init__(
        self,
        parent: Any,
        module_root: Path,
        language: str = "EN",
        on_plan_changed: Callable[[Any], None] | None = None,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.parent = parent
        self.module_root = module_root.resolve()
        self.on_plan_changed = on_plan_changed
        self.catalog: Any = None
        self.families: dict[str, tuple[Any, ...]] = {}
        self.plan = plan_core.empty_plan(self.module_root, language)
        self.available_ids: list[str] = []
        self.selected_ids: list[str] = []

        self.window = tk.Toplevel(parent)
        self.window.title(f"U003 Module Manager v{MANAGER_VERSION}")
        self.window.geometry("1180x720")
        self.window.minsize(980, 620)
        self.window.protocol("WM_DELETE_WINDOW", self.window.withdraw)

        self.language_var = tk.StringVar(value=self.plan.language)
        self.module_root_var = tk.StringVar(value=str(self.module_root))
        self.version_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value="Ready - selection only; execution is disabled in U3M4")
        self._build_ui()
        self.refresh_catalog()

    def _build_ui(self) -> None:
        ttk = self.ttk
        main = ttk.Frame(self.window, padding=10)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(2, weight=1)

        header = ttk.Frame(main)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="Module Root").grid(row=0, column=0, padx=(0, 6))
        ttk.Entry(header, textvariable=self.module_root_var, state="readonly").grid(
            row=0, column=1, sticky="ew"
        )
        ttk.Button(header, text="Choose…", command=self.choose_module_root).grid(
            row=0, column=2, padx=4
        )
        ttk.Button(header, text="Refresh", command=self.refresh_catalog).grid(
            row=0, column=3, padx=4
        )
        ttk.Label(header, text="Language").grid(row=0, column=4, padx=(14, 4))
        language_box = ttk.Combobox(
            header,
            textvariable=self.language_var,
            values=["EN", "JA"],
            state="readonly",
            width=5,
        )
        language_box.grid(row=0, column=5)
        language_box.bind("<<ComboboxSelected>>", self._language_changed)

        policy = ttk.LabelFrame(main, text="Governed behavior", padding=7)
        policy.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(
            policy,
            text=(
                "No Module is selected by default. One version per ModuleId. "
                "Reordering is allowed only inside the same fixed slot. "
                "U3M4 saves plans but does not execute Modules."
            ),
            wraplength=1080,
        ).pack(anchor="w")

        panes = ttk.Panedwindow(main, orient="horizontal")
        panes.grid(row=2, column=0, sticky="nsew")

        available = ttk.LabelFrame(panes, text="Available Module families", padding=7)
        available.columnconfigure(0, weight=1)
        available.rowconfigure(0, weight=1)
        self.available_tree = ttk.Treeview(
            available,
            columns=("slot", "name", "version", "kind", "recommended"),
            show="headings",
            selectmode="browse",
            height=15,
        )
        for column, heading, width in (
            ("slot", "Slot", 125),
            ("name", "Module", 220),
            ("version", "Version", 75),
            ("kind", "Kind", 90),
            ("recommended", "Recommended", 95),
        ):
            self.available_tree.heading(column, text=heading)
            self.available_tree.column(column, width=width, anchor="w")
        available_scroll = ttk.Scrollbar(
            available, orient="vertical", command=self.available_tree.yview
        )
        self.available_tree.configure(yscrollcommand=available_scroll.set)
        self.available_tree.grid(row=0, column=0, sticky="nsew")
        available_scroll.grid(row=0, column=1, sticky="ns")
        self.available_tree.bind("<<TreeviewSelect>>", self._available_selected)

        available_actions = ttk.Frame(available)
        available_actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        ttk.Label(available_actions, text="Version").pack(side="left")
        self.version_box = ttk.Combobox(
            available_actions,
            textvariable=self.version_var,
            state="readonly",
            width=10,
        )
        self.version_box.pack(side="left", padx=5)
        self.version_box.bind("<<ComboboxSelected>>", self._version_changed)
        ttk.Button(available_actions, text="Add / Replace", command=self.add_selected).pack(
            side="left", padx=3
        )
        ttk.Button(available_actions, text="View Algorithm Card", command=self.view_algorithm_card).pack(
            side="left", padx=3
        )

        self.description_text = self.tk.Text(
            available,
            height=7,
            wrap="word",
            state="disabled",
            background="#f5f5f5",
        )
        self.description_text.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(7, 0))

        selected = ttk.LabelFrame(panes, text="Active Module Plan", padding=7)
        selected.columnconfigure(0, weight=1)
        selected.rowconfigure(0, weight=1)
        self.selected_tree = ttk.Treeview(
            selected,
            columns=("sequence", "slot", "name", "version"),
            show="headings",
            selectmode="browse",
            height=15,
        )
        for column, heading, width in (
            ("sequence", "#", 35),
            ("slot", "Fixed Slot", 130),
            ("name", "Selected Module", 240),
            ("version", "Version", 75),
        ):
            self.selected_tree.heading(column, text=heading)
            self.selected_tree.column(column, width=width, anchor="w")
        selected_scroll = ttk.Scrollbar(
            selected, orient="vertical", command=self.selected_tree.yview
        )
        self.selected_tree.configure(yscrollcommand=selected_scroll.set)
        self.selected_tree.grid(row=0, column=0, sticky="nsew")
        selected_scroll.grid(row=0, column=1, sticky="ns")

        selected_actions = ttk.Frame(selected)
        selected_actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        ttk.Button(selected_actions, text="Remove", command=self.remove_selected).pack(side="left", padx=3)
        ttk.Button(selected_actions, text="Move Up", command=lambda: self.move_selected(-1)).pack(side="left", padx=3)
        ttk.Button(selected_actions, text="Move Down", command=lambda: self.move_selected(1)).pack(side="left", padx=3)
        ttk.Button(selected_actions, text="Clear", command=self.clear_plan).pack(side="left", padx=3)

        plan_actions = ttk.Frame(selected)
        plan_actions.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(plan_actions, text="Load Recommended", command=self.load_recommended).pack(side="left", padx=3)
        ttk.Button(plan_actions, text="Open Plan…", command=self.open_plan).pack(side="left", padx=3)
        ttk.Button(plan_actions, text="Save Plan…", command=self.save_plan).pack(side="left", padx=3)

        panes.add(available, weight=3)
        panes.add(selected, weight=2)

        ttk.Label(main, textvariable=self.status_var, relief="sunken", anchor="w").grid(
            row=3, column=0, sticky="ew", pady=(8, 0)
        )

    def show(self) -> None:
        self.window.deiconify()
        self.window.lift()
        self.window.focus_force()

    def choose_module_root(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askdirectory(
            title="Select U003 02_MODULES directory",
            initialdir=str(self.module_root),
            parent=self.window,
        )
        if selected:
            self.module_root = Path(selected).resolve()
            self.module_root_var.set(str(self.module_root))
            self.plan = plan_core.empty_plan(self.module_root, self.language_var.get())
            self.refresh_catalog()

    def refresh_catalog(self) -> None:
        try:
            self.catalog = plan_core.discover_catalog(self.module_root)
            self.families = plan_core.descriptors_by_family(self.catalog)
            self.plan = plan_core.validate_plan(self.plan, self.catalog)
            self._refresh_available_tree()
            self._refresh_selected_tree()
            self.status_var.set(
                f"Validated {len(self.catalog.descriptors)} versions in "
                f"{len(self.families)} Module families"
            )
        except Exception as error:
            self._show_error("Module discovery error", error)

    def _refresh_available_tree(self) -> None:
        self.available_tree.delete(*self.available_tree.get_children())
        self.available_ids = []
        language = self.language_var.get()
        for module_id, versions in self.families.items():
            latest = versions[0]
            self.available_ids.append(module_id)
            self.available_tree.insert(
                "",
                "end",
                iid=module_id,
                values=(
                    latest.module_slot,
                    latest.localized_name(language),
                    latest.module_version,
                    latest.execution_kind,
                    "Yes" if latest.enabled_by_default else "No",
                ),
            )

    def _refresh_selected_tree(self) -> None:
        self.selected_tree.delete(*self.selected_tree.get_children())
        self.selected_ids = []
        language = self.language_var.get()
        for sequence, item in enumerate(self.plan.selections, start=1):
            descriptor = plan_core.find_descriptor(
                self.catalog, item.module_id, item.module_version
            )
            self.selected_ids.append(item.module_id)
            self.selected_tree.insert(
                "",
                "end",
                iid=item.module_id,
                values=(
                    sequence,
                    item.module_slot,
                    descriptor.localized_name(language),
                    item.module_version,
                ),
            )
        if self.on_plan_changed is not None:
            self.on_plan_changed(self.plan)

    def _selected_available_descriptor(self) -> Any:
        selection = self.available_tree.selection()
        if len(selection) != 1:
            raise plan_core.ModulePlanError("Select one available Module family.")
        module_id = selection[0]
        version = self.version_var.get()
        return plan_core.find_descriptor(self.catalog, module_id, version)

    def _available_selected(self, _event: Any = None) -> None:
        selection = self.available_tree.selection()
        if len(selection) != 1:
            return
        module_id = selection[0]
        versions = self.families[module_id]
        values = [item.module_version for item in versions]
        self.version_box.configure(values=values)
        self.version_var.set(values[0])
        self._show_descriptor(versions[0])

    def _version_changed(self, _event: Any = None) -> None:
        try:
            self._show_descriptor(self._selected_available_descriptor())
        except Exception as error:
            self._show_error("Version selection error", error)

    def _show_descriptor(self, descriptor: Any) -> None:
        language = self.language_var.get()
        lines = [
            descriptor.localized_description(language),
            "",
            f"ModuleId: {descriptor.module_id}",
            f"Version: {descriptor.module_version}",
            f"Execution: {descriptor.execution_kind}",
            f"Hooks: {', '.join(descriptor.lifecycle_hooks) or 'None'}",
            f"Requires: {', '.join(descriptor.required_context_fields) or 'None'}",
            f"Produces: {', '.join(descriptor.produced_fields) or 'None'}",
            f"Package SHA-256: {descriptor.package_sha256}",
        ]
        self.description_text.configure(state="normal")
        self.description_text.delete("1.0", "end")
        self.description_text.insert("1.0", "\n".join(lines))
        self.description_text.configure(state="disabled")

    def add_selected(self) -> None:
        try:
            descriptor = self._selected_available_descriptor()
            self.plan = plan_core.add_or_replace_selection(self.plan, descriptor)
            self._refresh_selected_tree()
            self.status_var.set(
                f"Selected {descriptor.module_id} v{descriptor.module_version}; "
                "execution remains disabled in U3M4"
            )
        except Exception as error:
            self._show_error("Add Module error", error)

    def remove_selected(self) -> None:
        selection = self.selected_tree.selection()
        if len(selection) != 1:
            self._show_error("Remove Module error", plan_core.ModulePlanError("Select one active Module."))
            return
        self.plan = plan_core.remove_selection(self.plan, selection[0])
        self._refresh_selected_tree()

    def move_selected(self, direction: int) -> None:
        selection = self.selected_tree.selection()
        if len(selection) != 1:
            self._show_error("Move Module error", plan_core.ModulePlanError("Select one active Module."))
            return
        try:
            self.plan = plan_core.move_within_slot(self.plan, selection[0], direction)
            self._refresh_selected_tree()
            self.selected_tree.selection_set(selection[0])
        except Exception as error:
            self._show_error("Move Module error", error)

    def clear_plan(self) -> None:
        self.plan = plan_core.empty_plan(self.module_root, self.language_var.get())
        self._refresh_selected_tree()
        self.status_var.set("Active Module Plan cleared; no-Module behavior is active")

    def load_recommended(self) -> None:
        self.plan = plan_core.recommended_plan(self.catalog, self.language_var.get())
        self._refresh_selected_tree()
        self.status_var.set(
            f"Loaded {self.plan.selected_count()} recommended Modules; not executed"
        )

    def _language_changed(self, _event: Any = None) -> None:
        self.plan = plan_core.set_language(self.plan, self.language_var.get())
        self._refresh_available_tree()
        self._refresh_selected_tree()
        self._available_selected()

    def view_algorithm_card(self) -> None:
        try:
            descriptor = self._selected_available_descriptor()
            payload = json.loads(
                Path(descriptor.algorithm_card_path).read_text(encoding="utf-8-sig")
            )
            localized = plan_core.localized_card_value(
                payload, self.language_var.get()
            )
            popup = self.tk.Toplevel(self.window)
            popup.title(
                f"Algorithm Card - {descriptor.localized_name(self.language_var.get())}"
            )
            popup.geometry("820x650")
            popup.rowconfigure(0, weight=1)
            popup.columnconfigure(0, weight=1)
            text = self.tk.Text(popup, wrap="word", padx=14, pady=12)
            scroll = self.ttk.Scrollbar(popup, orient="vertical", command=text.yview)
            text.configure(yscrollcommand=scroll.set)
            text.grid(row=0, column=0, sticky="nsew")
            scroll.grid(row=0, column=1, sticky="ns")
            text.insert("1.0", "\n".join(_card_lines(localized)))
            text.configure(state="disabled")
        except Exception as error:
            self._show_error("Algorithm Card error", error)

    def save_plan(self) -> None:
        from tkinter import filedialog

        path = filedialog.asksaveasfilename(
            title="Save U003 Module Plan",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="u003_module_plan_v0_1.json",
            parent=self.window,
        )
        if path:
            try:
                plan_core.write_plan(self.plan, Path(path))
                self.status_var.set(f"Module Plan saved: {path}")
            except Exception as error:
                self._show_error("Save Module Plan error", error)

    def open_plan(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="Open U003 Module Plan",
            filetypes=[("JSON", "*.json"), ("All files", "*.*")],
            parent=self.window,
        )
        if path:
            try:
                self.plan = plan_core.read_plan(Path(path), self.catalog)
                self.language_var.set(self.plan.language)
                self._refresh_available_tree()
                self._refresh_selected_tree()
                self.status_var.set(f"Module Plan opened and validated: {path}")
            except Exception as error:
                self._show_error("Open Module Plan error", error)

    def _show_error(self, title: str, error: Exception) -> None:
        from tkinter import messagebox

        self.status_var.set(f"ERROR: {error}")
        messagebox.showerror(title, str(error), parent=self.window)
