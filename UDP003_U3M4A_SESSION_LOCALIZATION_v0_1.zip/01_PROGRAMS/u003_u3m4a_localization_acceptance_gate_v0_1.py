#!/usr/bin/env python3
"""Fail-close acceptance for U3M4A session localization and card presentation."""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


GATE_VERSION = "0.1"
PROGRAM_ROOT = Path(__file__).resolve().parent
U003_ROOT = PROGRAM_ROOT.parent
CONTRACT_PATH = (
    U003_ROOT
    / "02_CONTROLS"
    / "contracts"
    / "u003_session_localization_contract_v0_1.json"
)
PREDECESSORS = {
    "u003_gui_shell_v0_2.py": "61052e5005758a0b68a23fd0438aa15fe9d2007cf918cc0595adc54bebb0b065",
    "u003_module_manager_gui_v0_1.py": "b0d6a1c31f353316d81b1f02a355ddbb2337826d5566eeb96bbcd4866b943d23",
    "u003_evidence_review_workbench_v0_15.py": "10548bc861f9aa066128c13ef7d148ce394f84c797643f484025ac21662d9ef2",
    "u003_domain_core_v0_2.py": "6c25c2ef9b6e51be286291532cfddb44bfd0fdd20b827c230d3199e910f06bd7",
    "u003_handoff_core_v0_2.py": "cbd4c02b86e8df8ce10fdf4e15fdd31be49dd328a3f4c03d07754ec4bef5fd66",
    "u003_module_plan_core_v0_1.py": "8faa92354eb5f9de3e83bbe082b6d360971da40a9ebcc8a3a89b34e0f0c2ebe4",
}
NEW_FILES = (
    "u003_localization_v0_1.py",
    "u003_module_manager_gui_v0_2.py",
    "u003_gui_shell_v0_3.py",
    "u003_evidence_review_workbench_v0_16.py",
)
GUI_ALLOWED_CHANGED_METHODS = {
    "__init__",
    "_build_signal_window",
    "_build_ui",
    "_mapping_values",
    "_schedule_next_frame",
    "_show_error",
    "_show_info",
    "delete_current_event",
    "load_event_csv",
    "load_signal_csv",
    "open_module_manager",
    "open_video",
    "stop_playback",
    "toggle_play",
}
MANAGER_ALLOWED_CHANGED_METHODS = {
    "__init__",
    "_build_ui",
    "_refresh_available_tree",
    "_refresh_selected_tree",
    "_show_descriptor",
    "_show_error",
    "choose_module_root",
    "clear_plan",
    "load_recommended",
    "open_plan",
    "save_plan",
    "view_algorithm_card",
}


class AcceptanceError(RuntimeError):
    """Raised when U3M4A violates an accepted predecessor or new contract."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def class_methods(path: Path, class_name: str) -> dict[str, str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return {
                child.name: ast.dump(child, include_attributes=False)
                for child in node.body
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
    raise AcceptanceError(f"Class not found: {class_name} in {path.name}")


def static_widget_texts(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    texts: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        for keyword in node.keywords:
            if (
                keyword.arg == "text"
                and isinstance(keyword.value, ast.Constant)
                and isinstance(keyword.value.value, str)
                and any(character.isalpha() for character in keyword.value.value)
            ):
                texts.add(keyword.value.value)
    return texts


def fresh_capability(program_name: str) -> dict[str, Any]:
    result = subprocess.run(
        [sys.executable, "-B", str(PROGRAM_ROOT / program_name), "--print-launch-capability"],
        cwd=U003_ROOT.parent,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    if result.returncode != 0:
        raise AcceptanceError(
            f"Capability process failed for {program_name}: {result.stderr.strip()}"
        )
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if not lines:
        raise AcceptanceError(f"Capability output missing for {program_name}")
    return json.loads(lines[-1])


def fresh_self_test(program_name: str) -> tuple[int, str]:
    result = subprocess.run(
        [sys.executable, "-B", str(PROGRAM_ROOT / program_name), "--self-test"],
        cwd=U003_ROOT.parent,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    return result.returncode, result.stdout.strip()


def run_acceptance(verbose: bool) -> tuple[int, dict[str, int]]:
    if str(PROGRAM_ROOT) not in sys.path:
        sys.path.insert(0, str(PROGRAM_ROOT))

    localization = importlib.import_module("u003_localization_v0_1")
    manager = importlib.import_module("u003_module_manager_gui_v0_2")
    shell = importlib.import_module("u003_gui_shell_v0_3")
    entry = importlib.import_module("u003_evidence_review_workbench_v0_16")

    checks = 0
    groups = {
        "identity": 0,
        "language": 0,
        "lock": 0,
        "card": 0,
        "regression": 0,
        "entry": 0,
    }

    def check(condition: bool, group: str, label: str, meaning: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(f"{group}:{label}")
        checks += 1
        groups[group] += 1
        if verbose:
            print(f"[CHECK {checks:03d}] {label} - {meaning}")

    for name, expected_hash in PREDECESSORS.items():
        path = PROGRAM_ROOT / name
        check(path.is_file(), "identity", f"predecessor {name}", "accepted source exists")
        check(
            sha256_file(path) == expected_hash,
            "identity",
            f"identity {name}",
            "accepted source cannot drift",
        )
    for name in NEW_FILES:
        check(
            (PROGRAM_ROOT / name).is_file(),
            "identity",
            f"new component {name}",
            "the high-code localization component is installed",
        )
    check(CONTRACT_PATH.is_file(), "identity", "localization contract", "policy is explicit")
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8-sig"))
    check(
        contract.get("ContractId") == "CameraRadar.U003.SessionLocalization",
        "identity",
        "contract identity",
        "the GUI follows the approved localization contract",
    )

    check(localization.LOCALIZATION_VERSION == "0.1", "language", "localizer version", "presentation behavior is versioned")
    check(localization.normalize_language("en") == "EN", "language", "English normalization", "command-line input is deterministic")
    check(localization.normalize_language("ja") == "JA", "language", "Japanese normalization", "command-line input is deterministic")
    check(localization.Localizer("EN").text("Open Video") == "Open Video", "language", "English label", "English remains the source presentation")
    check(localization.Localizer("JA").text("Open Video") == "映像を開く", "language", "Japanese label", "Japanese presentation is available")
    check(localization.Localizer("JA").text("FrameCount") == "FrameCount", "language", "machine field preservation", "contract fields are never translated")
    check(localization.Localizer("JA").text("ModuleId") == "ModuleId", "language", "ModuleId preservation", "identity remains stable")
    check(localization.Localizer("JA").text("C:/case/input.csv") == "C:/case/input.csv", "language", "path preservation", "stored evidence is never translated")

    for source_name in ("u003_gui_shell_v0_3.py", "u003_module_manager_gui_v0_2.py"):
        visible = static_widget_texts(PROGRAM_ROOT / source_name)
        missing = sorted(visible - set(localization.JA_TEXT))
        check(not missing, "language", f"static labels {source_name}", "every user-facing static widget has Japanese text")

    check(manager.MANAGER_VERSION == "0.2", "lock", "manager version", "language lock is independently identifiable")
    check(shell.GUI_SHELL_VERSION == "0.3", "lock", "GUI version", "session localization is independently identifiable")
    manager_source = (PROGRAM_ROOT / "u003_module_manager_gui_v0_2.py").read_text(encoding="utf-8")
    shell_source = (PROGRAM_ROOT / "u003_gui_shell_v0_3.py").read_text(encoding="utf-8")
    entry_source = (PROGRAM_ROOT / "u003_evidence_review_workbench_v0_16.py").read_text(encoding="utf-8")
    check("language_var" not in manager_source, "lock", "no manager language variable", "the child window cannot change session language")
    check("_language_changed" not in manager_source, "lock", "no runtime language callback", "language cannot mutate after startup")
    check("plan_core.set_language(loaded_plan, self.language)" in manager_source, "lock", "opened plan is rebound", "saved plan cannot override session language")
    check("language=self.language" in shell_source, "lock", "shared language", "main GUI and Module Manager use one session language")
    check("choose_session_language()" in entry_source, "lock", "startup prompt", "interactive startup asks exactly once")
    check("FrameCountVideoReviewer(language=language)" in entry_source, "lock", "locked constructor input", "the selected language is passed into the GUI")
    check("--language" in entry.launch_capability()["SupportedArguments"], "lock", "automation language", "U002 or packaging can select a deterministic language")

    check(hasattr(manager, "AlgorithmCardViewer"), "card", "structured viewer", "Algorithm Card is not presented as one raw text dump")
    tabs = tuple(name for name, _fields in manager.AlgorithmCardViewer.TABS)
    check(tabs == ("Overview", "Method / Rules", "Interface", "Validation", "Limits"), "card", "engineering tabs", "purpose method interface evidence and limits are separated")
    viewer = manager.AlgorithmCardViewer.__new__(manager.AlgorithmCardViewer)
    viewer.localizer = localization.Localizer("JA")
    sample_card = {
        "Purpose": "P",
        "RealityMeaning": "R",
        "Rules": {"Threshold": 1.0},
        "Inputs": {"FrameCount": "integer"},
        "Outputs": {"ReviewMemo": "text"},
        "Assumptions": ["A"],
        "Validation": ["V"],
        "Limitations": ["L"],
    }
    overview = viewer.render_fields(sample_card, ("Purpose", "RealityMeaning"))
    interface = viewer.render_fields(sample_card, ("Inputs", "Outputs"))
    check("目的" in overview and "現実の意味" in overview, "card", "localized overview", "the real-world meaning remains visible")
    check("FrameCount: integer" in interface, "card", "readable interface", "dictionary fields become key/value rows")
    check("Raw JSON" in localization.JA_TEXT, "card", "advanced raw tab", "raw evidence remains available but is not the default presentation")
    check("notebook.add(raw" in manager_source, "card", "advanced raw placement", "raw JSON is retained only as a separate advanced tab")

    old_gui_methods = class_methods(PROGRAM_ROOT / "u003_gui_shell_v0_2.py", "FrameCountVideoReviewer")
    new_gui_methods = class_methods(PROGRAM_ROOT / "u003_gui_shell_v0_3.py", "FrameCountVideoReviewer")
    check(old_gui_methods.keys() == new_gui_methods.keys(), "regression", "GUI method inventory", "no review operation is removed or added")
    changed_gui = {name for name in old_gui_methods if old_gui_methods[name] != new_gui_methods[name]}
    check(changed_gui == GUI_ALLOWED_CHANGED_METHODS, "regression", "GUI change boundary", "only presentation-sensitive methods changed")
    for name in sorted(old_gui_methods.keys() - GUI_ALLOWED_CHANGED_METHODS):
        check(old_gui_methods[name] == new_gui_methods[name], "regression", f"GUI method {name}", "unrelated review logic is AST-identical")

    old_manager_methods = class_methods(PROGRAM_ROOT / "u003_module_manager_gui_v0_1.py", "ModuleManagerWindow")
    new_manager_methods = class_methods(PROGRAM_ROOT / "u003_module_manager_gui_v0_2.py", "ModuleManagerWindow")
    check(set(old_manager_methods) - set(new_manager_methods) == {"_language_changed"}, "regression", "removed manager method", "only runtime language switching was removed")
    changed_manager = {
        name
        for name in old_manager_methods.keys() & new_manager_methods.keys()
        if old_manager_methods[name] != new_manager_methods[name]
    }
    check(changed_manager == MANAGER_ALLOWED_CHANGED_METHODS, "regression", "manager change boundary", "changes are limited to localization and structured cards")
    for name in sorted(set(old_manager_methods) & set(new_manager_methods) - MANAGER_ALLOWED_CHANGED_METHODS):
        check(old_manager_methods[name] == new_manager_methods[name], "regression", f"manager method {name}", "selection and ordering logic is AST-identical")

    old_capability = fresh_capability("u003_evidence_review_workbench_v0_15.py")
    new_capability = fresh_capability("u003_evidence_review_workbench_v0_16.py")
    for key in (
        "InterfaceId",
        "InterfaceVersion",
        "ProgramId",
        "AcceptedHandoffContractId",
        "AcceptedHandoffContractVersion",
    ):
        check(old_capability[key] == new_capability[key], "entry", f"capability {key}", "U002 handoff compatibility remains stable")
    check(new_capability["ProgramVersion"] == "0.16", "entry", "program version", "the localized build is identifiable")
    old_arguments = set(old_capability["SupportedArguments"])
    new_arguments = set(new_capability["SupportedArguments"])
    check(new_arguments == old_arguments | {"--language"}, "entry", "capability extension", "only deterministic language selection was added")
    return_code, self_test_output = fresh_self_test("u003_evidence_review_workbench_v0_16.py")
    check(return_code == 0, "entry", "entry self-test exit", "the composition imports in a fresh process")
    check(self_test_output == "U003-V016-SELFTEST-PASS-20", "entry", "entry self-test capsule", "component identities and translations are explicit")

    return checks, groups


def capsule(checks: int, groups: dict[str, int], gui: int) -> str:
    return (
        "U3M4A "
        f"N-L2-G{gui}-I{groups['identity']}-J{groups['language']}-"
        f"K{groups['lock']}-A{groups['card']}-R{groups['regression']}-"
        f"E{groups['entry']}-T{checks}-X0 C-0"
    )


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--accept", action="store_true")
    parser.add_argument("--open-gui", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if not arguments.self_test and not arguments.accept:
            raise AcceptanceError("Use --self-test or --accept")
        checks, groups = run_acceptance(verbose=arguments.accept)
        gui = 0
        if arguments.open_gui:
            entry = importlib.import_module("u003_evidence_review_workbench_v0_16")
            return_code = entry.main(["--open-module-manager"])
            if return_code != 0:
                raise AcceptanceError("GUI launch returned non-zero")
            gui = 1
        print(capsule(checks, groups, gui))
        return 0
    except Exception as error:
        print(
            f"U3M4AE K-{type(error).__name__.upper()} D-{error} X1 C-7",
            file=sys.stderr,
        )
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
