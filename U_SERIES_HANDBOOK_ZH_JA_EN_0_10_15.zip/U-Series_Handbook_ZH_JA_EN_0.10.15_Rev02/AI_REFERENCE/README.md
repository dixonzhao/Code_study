# Shared AI references / 共通AI参考資料

Original synthetic SAMPLE templates and schemas from base0.10.15. These retain their original bytes, blank paths, placeholders and technical identifiers; they are not bound business Profiles. Read the EN or JA AI_PROFILE_GUIDE.md first. INDEX.json records original paths and hashes. Selected Module implementations and dependencies must be read from the compatible base package.

ベース0.10.15の元の合成SAMPLEテンプレートとschemaです。元のバイト、空のパス、仮値、技術識別子を保持しており、設定済み業務Profileではありません。先にJAまたはENのAI_PROFILE_GUIDE.mdを読んでください。原パスとhashはINDEX.jsonに記載しています。選択Moduleの実装と依存関係は対応ベースから参照します。
