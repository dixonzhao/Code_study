# U-Series：AI向けProfile生成ガイド

文書版：1.2 · 2026-09-15 · 対応ベースパッケージ：U-Series 0.10.15

Profileを生成するAIと、その成果物を受け取る保守担当者向けのガイドです。操作担当者は操作マニュアルから始めてください。本資料には業務用の個別Profileは含まれません。個別Profileは別途提供します。

## 1. 推奨モデル

**社内では、Claude Opus 5を明示的に指定したCopilot Studio AgentによるProfile生成を推奨します。推論強度を設定できる場合はMediumを選択してください。**

代替は **GPT-5.6 Sol Medium**、または参照するランキングで **SciCodeの総合スコアが50%を超えるモデル** です。この水準を下回るモデルによるProfile生成は推奨しません。これはモデル選定の推奨であり、U-Seriesが強制する実行制限でも、生成結果の正しさの保証でもありません。

参照元が示す総合スコアを使用し、主問題の解決率が50%を超えるという追加条件は設けません。代替モデルは、正確なモデル名・版、ランキングのリンク、総合スコア、評価日を記録してください。部分指標を総合スコアと言い換えたり、独自に合成スコアを作ったりしないでください。総合値が記載されていなければ未確認とします。上記の指定2モデルは、この推奨に従って直接選択でき、別途ランキングの審査は不要です。

### Copilot Studioでの利用

Agentの保守担当者が実際のモデル設定でClaude Opus 5を選び、保存します。新しいAgent画面ではBuild → Modelから選択します。選択可能なモデルは社内環境によって異なります。操作担当者は設定済みAgentを利用できます。

プロンプトに「あなたはOpus 5です」と書いても実際のモデルは切り替わりません。画面や接続設定に推論強度があればMediumを指定します。設定項目がなければ利用可能な設定を保ち、実際の状態を記録してください。本ガイドはAgentの作成、社内テナントでのモデル有効化、ファイル出力機能の確認を実施したものではありません。

本ガイド、記入済み要件表、必要な参考ファイルをAgentへ渡します。ZIPを納品するには、実際にファイルを作成してダウンロード可能にする機能が必要です。テキストしか出力できない場合は、その制限を説明し、ファイルごとの正確な内容と配置表を保守担当者へ提示します。未作成のZIPを「ダウンロード可能」と報告しないでください。実際の引き渡しではファイルを提供します。

## 2. 3種類の成果物

| 種類 | 役割 | 現状 |
| --- | --- | --- |
| ベースone-dir | 3つのEXE、ランタイム、プログラム群、合成SAMPLE | U-Series 0.10.15のパッケージ内容と操作範囲 |
| Working Profile | 各ワークベンチで開いて保存する入力・パラメータ・出力設定 | 個別のJSON読み込み口あり |
| プロジェクトProfile ZIP | 設定、正確なModuleと依存関係、定義、合意済み入力 | 納品規約あり。汎用ZIP自動インポート画面は未実装 |

ZIPをOpen Profileに渡して自動インストールできると説明しないでください。具体的なファイル配置表、対象ワークスペース、開くJSONを提示します。必要なModuleを既存の正式な入口から導入できなければ、不足する機能を保守担当者に報告してください。独自のインポート方式、修復ツール、ベース製品ソースの置換は作成しません。

## 3. 開始前に必要な資料

1. `02_PROFILE_INPUT_FORM.md`：目的、入力形式、信号の意味、Frame・時刻基準、必要な出力、人が判断する点。
2. 実際のベースフォルダーにある`PACKAGE_MANIFEST.json`、`PROFILE_ZIP_CONVENTION.md`と関連する`product/`ファイル。AIが社内PCを直接読めなければ、保守担当者が必要なファイルだけを提供します。
3. `../AI_REFERENCE/INDEX.json`と関連テンプレート。元の合成SAMPLE・schemaであり、パスを設定済みの業務Profileではありません。
4. 選択するModuleの実装、manifest、Algorithm Card、宣言された依存関係。添付の`MODULE_CATALOG.json`は所在確認用です。生成時は対象バージョンの実体を読みます。
5. 形式の参考になる成功済みProfile。入力と解析目的は今回の情報を優先し、過去のしきい値やSAMPLE設定を業務ルールとして自動継承しません。

ファイルから判明する内容は先に調べます。結果を左右する不足情報（バイト表記、単位、対象物の同一性、Frame基準など）はまとめて一度に確認してください。無関係な社内アーカイブ全体を求めたり、フィールドごとに確認を繰り返したりしません。

## 4. 参照する既存ファイル

以下はベース交付フォルダーからの相対パスです。`product/`は未使用のテンプレート、通常の作業結果は`workspaces/`に作られます。資材名に含まれる過去の版番号は識別子であり、ベース版に合わせるためだけに変更しません。

| 用途 | ファイル・入口 |
| --- | --- |
| U001作業設定 | `product/U-UDP001/03_CASES/SAMPLE_v0_10_7/CONTROL/profile_template.json` |
| U001信号選択・処理方針 | 同じディレクトリの`selection.json`、`semantic.csv`、`frame.csv`、`hold.csv` |
| U001の読み込み・保存 | `product/U-UDP001/01_PROGRAMS/gui/u001_workbench_gui_v0_6_5.py`と実際に呼び出すmodel/controller |
| SAMPLEのパス設定 | `support/sample_setup_v0_10_15.py`。読み取り参考用で、現在のSAMPLEを変更しません |
| U002編集用Profile | `product/U-UDP002/02_CONFIG/gui_profiles/SAMPLE_v0_10_7/profile_template.json` |
| U002信号対応 | `product/U-UDP002/02_CONFIG/signal_profiles/SAMPLE_v0_10_7/binding_template.json` |
| U002正式Run schema | `product/U-UDP002/00_CONTROL/contracts/u002_run_configuration_schema_v0_1.json` |
| U002 Module schema | 同じ契約ディレクトリの`u002_module_manifest_schema_v0_1.json` |
| U002ワークベンチ | `product/U-UDP002/01_PROGRAMS/gui/u002_thin_workbench_gui_v0_12_2.py` |
| U003ワークベンチ | `product/U-UDP003/01_PROGRAMS/u003_evidence_review_workbench_v0_22_0.py` |

Working Profileと正式Run設定は異なるJSON形式です。ContractId、版、実際の読み込み先を確認してschemaを選びます。正式Run設定は既存のU002保存・準備フローで生成し、未設定のテンプレートを受入済みRunと言い換えません。

## 5. U001 Working Profile

実際のワークベンチが保存する形式に従います。現行テンプレートは`U001_WORKBENCH_PROFILE_V0_1`で、Adapterは`CameraRadar.U001.MatlabCanCsvDbc`の`1.2.1`です。新しい入力がこの形式に適合する場合だけ使用します。

- `SourceFiles`の`CANDump`、`DBC1`、`DBC2`を設定し、`AdapterInputs`と`RawByteEncoding`を実入力に合わせます。HEX_TEXTとDECIMALはCSV内のバイト表記であり、画面言語ではありません。拡張子だけで判断しません。
- `SelectionProfilePath`は信号選択、`SemanticPolicyPath`、`FramePolicyPath`、`HoldPolicyPath`は対応する処理方針です。実schemaと既存例に基づき、単位、欠損値、保持ルールを創作しません。
- `OutputRoot`と新しい`RunId`を設定します。過去のRunと人によるレビュー結果を上書き・継承しません。
- 必要に応じて`U002Workspace`、`U002LaunchTarget`、`U002ConfigurationTemplate`、`U002BindingTemplate`、`U002RunId`を確認します。レビューには`U003LaunchTarget`、`ReviewVideoPath`、動画対応パラメータも使います。開発PCの絶対パスをコピーせず、実際の保存形式で確認してください。
- SAMPLEテンプレートには空のパス、仮の値、過去の説明フィールドがあります。実行用SAMPLEはsample_setupが設定します。構造の参考として扱い、新しいデータの事実とみなしません。

ZIPのファイル一覧は相対パスを使いますが、現在の作業設定には対象PC上の絶対パスが必要な場合があります。GUIで選び直す項目と保守担当者が設定する項目を示してください。ZIP内が相対パスであることは、全ワークベンチの可搬性を証明しません。

## 6. U002設定とModule計画

編集用SAMPLEテンプレートは`U002_GUI_SAVED_PROFILE`を使用します。正式Runは現行schemaとワークベンチ出力に従います。

1. 今回成功したU001 Runが生成し、下流の入口で受け入れられたPackageを使用します。ファイル名だけで同一性を判断しません。
2. `RunPurpose`、`RunScope`、Frame範囲とその業務上の理由を明記します。デモのFrame番号を流用しません。
3. 各`ModulePlan`に既存`ModuleId`、正確な`ModuleVersion`、`Stage`、`Sequence`、有効な`Configuration`を指定します。すべてのStageを埋める必要はありません。
4. 実在する信号名、単位、意味を対応付けます。生成元に関するhashは実ファイルから計算し、`BIND_TO_CURRENT_PRODUCER`などの仮値を残しません。
5. 各Moduleの実装、宣言依存、schema、Algorithm Card、登録・適格性確認の定義を追跡し、必要な依存関係を最後まで含めます。
6. 必要なアルゴリズムがなければ機能不足を報告します。新しいアルゴリズムに既存ModuleのID・版を付けたり、AIが書いたコードを受入済みと報告したりしません。

現在のSAMPLEはレーダー計測の有効性とカメラ幾何情報を扱います。すべてのcamera–radar差分解析に適するとは限りません。個別案件の目的、信号対応、抽出方針、しきい値は別途定義します。

## 7. U003レビューの対応付け

今回のU002解析が生成した引き継ぎからU003を開くことを優先します。イベント、信号、動画が同じRunに対応しているか確認し、動画開始フレーム、CAN FrameCountの基準点、対応比率を照合します。動画再生の成功だけでは同期の正しさは確認できません。

レビュー者が何を見るか、どう判定を記録するか、何を出力するかを説明します。AIは設定やレビュー手順を生成できますが、人が動画を確認したという結果を代筆しません。候補がなければそのまま報告し、イベントを作り出しません。

## 8. プロジェクトZIPの内容

具体的な名称は案件の実装に従います。以下は成果物の役割であり、新しい自動インポート形式ではありません。

| 内容 | 要点 |
| --- | --- |
| 配置・起動説明 | ベース版、解凍先、開くJSON、入力パスを設定する項目 |
| Profile設定 | 正確なID・版、各ワークベンチの設定、信号選択と処理方針 |
| Moduleと依存関係 | 元の実装と正確な版、必要な依存全体、schema、Algorithm Card、適格性確認の定義 |
| データまたは外部参照 | 合意した範囲のCAN/DBC/動画のみ。外部ファイルの所在と同一性を記載 |
| ファイル一覧 | Profile ID・版、必要なベース版、Module ID・版、相対パス、サイズ、SHA256 |
| 実行・確認説明 | 実施済み確認、対象環境で残る確認、エラー報告手順 |

ランタイムはベースから提供します。各ProfileにPython全体を重複同梱せず、無関係なケースや旧Runを含めません。同じModule版で内容が異なる場合は、黙って上書きせず報告します。manifestの名前と配置手順は実際の納品処理に合わせ、未対応の仮manifestや汎用インストーラーを提供しません。

## 9. 変更範囲に応じた確認

既存SAMPLE、schema、未変更の受入済みModuleの証拠を再利用します。関連するJSON項目、パス、単位・Frame基準、正確な依存、hashを確認します。設定を変更した場合は必要な小範囲を実際の入口と引き継ぎで実行し、最終候補で必要なGUI・出力確認をまとめて実施します。

追加確認は未解決の疑問に対応させます。テスト基盤を作り直したり、各段階で社内PCの再実行を求めたりしません。最初のエラーと実ログを保存し、依存する後続処理を止めます。確認の省略や値の推測でC7をC0に変えてはいけません。

ファイル生成、静的確認、ローカル実行、Windows実行、人によるレビュー、引き継ぎ完了を区別し、実際に完了した内容だけを報告します。モデルのスコアは業務確認の代わりにはなりません。

## 10. 操作担当者への返却

実際にダウンロードできるファイル、対応ベース版、配置表、起動入口、短い操作手順、出力先、確認済み・未確認の範囲を提示します。

失敗時は、プログラム・段階、Profile/Run ID、Machine Code原文、最初の具体的なエラー、表示されたログパスを返します。原データは合意した範囲だけを扱い、1つのエラーのために全アーカイブを求めません。

## 11. 出典と版の根拠

ベース版は0.10.15、公開commitは`220808af7519b391ab362014f77c260087bfde94`です。配置規約はベースパッケージに含まれるPROFILE_ZIP_CONVENTION.mdと実際の読み込み処理に従います。参考ファイルはINDEX.jsonに元のパスとhashを記録し、元のバイトを保持します。

モデルはプロジェクトとしての推奨であり、指定2モデルが特定のSciCodeスコアを取得したとの主張ではありません。公式設定資料の確認日は2026-09-15です。社内環境での利用可否は、その環境に依存します。

- [GPT-5.6 Sol](https://developers.openai.com/api/docs/models/gpt-5.6-sol)
- [Claude effort](https://platform.claude.com/docs/en/build-with-claude/effort)
- [Copilot Studio model selection](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/authoring-select-agent-model)
- [Copilot Studio availability](https://learn.microsoft.com/en-us/microsoft-copilot-studio/authoring-select-agent-model)
- [SciCode](https://scicode-bench.github.io/)
