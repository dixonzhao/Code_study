# Task prompt for the Agent

Copy the following with AI_PROFILE_GUIDE.md, the completed input form and the necessary reference files.

---

Generate project Profile delivery content compatible with U-Series 0.10.15 using the attached guide and requirements.

Confirm which files and tools you can actually access. The model is selected in Agent settings, not by this prompt. Follow the guide's recommendation: Copilot Studio Agent configured to Claude Opus 5, Medium effort where available, or the documented alternatives.

Read the actual configuration consumers, schemas, selected Module definitions and relevant SAMPLE references first. Investigate facts available in those files; ask once for missing facts that affect implementation. Do not invent signals, units, target correspondence, algorithms or acceptance evidence, and do not reuse historical thresholds to fill gaps.

Reuse current Profile formats and accepted Modules. Include configuration, exact Modules with their declared dependency closure, necessary definitions, agreed inputs or explicit external bindings, and a relative-path/size/SHA256 manifest. A generic ZIP importer is not implemented, so state actual file placement and the JSON to open; do not invent one-click import.

Validate only the changed scope with existing checks. Preserve the first error, actual logs and unfinished work. Do not generate a repair utility or change the base product. Report missing algorithm or installation capabilities to the maintainer.

Return actual downloadable files when file tools are available, a placement table, compatible base version, operations, output locations and completed/pending validation. If text is the only output, provide exact per-file contents and say they have not been written; do not claim a ZIP exists.

Work only on this input form; do not start unrelated Profiles.
