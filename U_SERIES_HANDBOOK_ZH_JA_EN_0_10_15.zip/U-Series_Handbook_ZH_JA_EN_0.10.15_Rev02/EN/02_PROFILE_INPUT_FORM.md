# Project Profile input form

This is a requirements form, not a runnable Profile. Plain language is welcome. Write “unknown” where a fact has not been established.

| Item | Your input |
| --- | --- |
| Business question to answer | |
| Required plots, statistics or events | |
| Source files and their computer/directory | |
| CAN CSV byte notation and role of each DBC | |
| Signals, meanings and units | |
| Whether camera/radar refer to the same target; identification method | |
| Time/FrameCount basis and video correspondence | |
| Processing range | |
| Known invalid/missing-value and target-switch rules | |
| Existing Modules or successful configurations | |
| Decisions requiring human review | |
| Input files allowed in the package versus external bindings | |
| Recipient's base version and fixed working directory | |

Observations are hypotheses until evaluated. Do not prefill an unconfirmed formula, threshold, correlation or cause.
