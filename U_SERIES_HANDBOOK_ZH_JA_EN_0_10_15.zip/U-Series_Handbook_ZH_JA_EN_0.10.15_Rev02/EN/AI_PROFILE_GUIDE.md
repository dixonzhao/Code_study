# U-Series: Profile generation guide for AI

Document 1.2 · 2026-09-15 · Base delivery: U-Series 0.10.15

For the AI generating a Profile and the maintainer receiving its output. Operators should start with the Operations Manual. This documentation kit does not include a project-specific business Profile; those are supplied separately.

## 1. Recommended models

**Recommended company workflow: use a Copilot Studio Agent explicitly configured to use Claude Opus 5. Select Medium effort where that setting is available.**

Alternatives: **GPT-5.6 Sol Medium**, or another model with a reported **overall SciCode score above 50%**. Models below that level are not recommended for Profile generation. This is a model-selection recommendation, not a restriction enforced by U-Series or a guarantee that generated configurations are correct.

Use the overall score reported by the referenced leaderboard. Do not add a separate requirement for a main-problem solve rate above 50%. For an alternative model, record its exact name/version, source link, overall score and evaluation date. Do not rename a submetric as an overall score or calculate an unofficial composite. If no overall score is reported, mark that claim unverified. The two explicitly named models may be selected directly under this recommendation; no additional benchmark review is required for them.

### Using a Copilot Studio Agent

The Agent maintainer selects Claude Opus 5 in the actual model settings and saves the change. In the new Agent experience, model selection is under Build → Model. Available models depend on the company environment; an operator can use an Agent that has already been configured.

Writing “you are Opus 5” in a prompt does not change the selected model. Choose Medium if the interface or connection exposes an effort setting; otherwise retain the available environment setting and record it accurately. This guide does not create an Agent, enable a model for a tenant, or verify the Agent's file-output tools.

Provide this guide, the completed input form and the necessary reference files. To deliver a ZIP, the Agent needs tools that actually create and expose downloadable files. If it can only return text, it must state that limitation and provide exact per-file contents and a file map for the maintainer. It must not claim a downloadable package exists until it does. Actual handover should provide downloadable files.

## 2. Three different objects

| Object | Purpose | Current support |
| --- | --- | --- |
| Base one-dir | Three EXEs, runtime, product library and synthetic SAMPLE | U-Series 0.10.15 package contents and operation scope |
| Working Profile | Configuration opened/saved by a workbench, with inputs, parameters and outputs | Specific JSON entry points exist |
| Project Profile ZIP | Configurations, exact Modules/dependencies, definitions and agreed inputs | Packaging convention exists; a generic automatic ZIP importer is not implemented |

Do not give a ZIP to Open Profile and claim it installs automatically. Supply a concrete file-placement table, target workspace and JSON to open. If the required Module cannot be installed through existing supported entry points, report the missing capability to the maintainer. Do not invent an importer, generate a repair utility or replace base product source files.

## 3. Required inputs

1. `02_PROFILE_INPUT_FORM.md`: objective, input format, signal meaning, frame/time basis, required outputs and human decisions.
2. The actual base directory's `PACKAGE_MANIFEST.json`, `PROFILE_ZIP_CONVENTION.md` and relevant `product/` files. If the AI cannot read the company computer, the maintainer supplies only the necessary files.
3. `../AI_REFERENCE/INDEX.json` and relevant reference templates. These are original synthetic SAMPLE/schema files, not an already bound business Profile.
4. Selected Module implementations, manifests, Algorithm Cards and declared dependencies. The included `MODULE_CATALOG.json` helps locate them; generation still requires reading the actual selected versions.
5. An existing successful Profile, if useful as a format example. Use current input evidence and objectives; do not inherit historical thresholds or SAMPLE settings as business rules.

Investigate what can be established from the supplied files first. Ask once for the missing facts that would change the result, such as byte notation, units, target identity or frame origin. Do not request an entire company archive or ask repeatedly about one field at a time.

## 4. Existing entry points

Paths below are relative to the base delivery. `product/` contains clean templates; normal work is created under `workspaces/`. Older version strings in resource directory names are retained identifiers and must not be renamed solely to match the base version.

| Purpose | File or entry point |
| --- | --- |
| U001 working Profile template | `product/U-UDP001/03_CASES/SAMPLE_v0_10_7/CONTROL/profile_template.json` |
| U001 signal selection and policies | Same directory: `selection.json`, `semantic.csv`, `frame.csv`, `hold.csv` |
| U001 field read/save behavior | `product/U-UDP001/01_PROGRAMS/gui/u001_workbench_gui_v0_6_5.py` and its actual model/controller calls |
| SAMPLE binding behavior | `support/sample_setup_v0_10_15.py`; read as a reference, do not modify the current SAMPLE |
| U002 editable Profile | `product/U-UDP002/02_CONFIG/gui_profiles/SAMPLE_v0_10_7/profile_template.json` |
| U002 signal binding | `product/U-UDP002/02_CONFIG/signal_profiles/SAMPLE_v0_10_7/binding_template.json` |
| U002 formal Run schema | `product/U-UDP002/00_CONTROL/contracts/u002_run_configuration_schema_v0_1.json` |
| U002 Module schema | Same contract directory: `u002_module_manifest_schema_v0_1.json` |
| U002 workbench | `product/U-UDP002/01_PROGRAMS/gui/u002_thin_workbench_gui_v0_12_2.py` |
| U003 workbench | `product/U-UDP003/01_PROGRAMS/u003_evidence_review_workbench_v0_22_0.py` |

A working Profile and a formal Run configuration are different JSON formats. Check ContractId, version and actual consumer before choosing a schema. Let the existing U002 save/prepare flow generate formal Run configuration; do not relabel an unbound template as an accepted Run.

## 5. U001 working Profile

Follow the actual workbench's saved format. The current template uses `U001_WORKBENCH_PROFILE_V0_1`; its Adapter is `CameraRadar.U001.MatlabCanCsvDbc` version `1.2.1`. Reuse that Adapter only when the new input actually matches its format.

- Bind `SourceFiles.CANDump`, `DBC1` and `DBC2`. Keep `AdapterInputs` and `RawByteEncoding` consistent with the actual source. HEX_TEXT and DECIMAL describe how bytes are written in the CSV, not the interface language. Do not infer this from the extension alone.
- Use `SelectionProfilePath` for signal selection and `SemanticPolicyPath`, `FramePolicyPath`, `HoldPolicyPath` for their respective policies. Derive fields and semantics from real schemas/examples; do not invent units, missing-value rules or holding behavior.
- Set `OutputRoot` and a new `RunId`. Preserve previous Runs and do not inherit their human review outcomes.
- Check downstream fields when required: `U002Workspace`, `U002LaunchTarget`, `U002ConfigurationTemplate`, `U002BindingTemplate`, `U002RunId`; review fields include `U003LaunchTarget`, `ReviewVideoPath` and video mapping parameters. Verify against the actual saved format, not a developer machine's paths.
- SAMPLE templates contain blank paths, placeholders and historical descriptive fields; sample_setup binds the runnable SAMPLE. Treat them as structural references, not statements about the new data.

Archive manifests use relative paths, but current working Profiles can require absolute paths on the target computer. State which fields must be selected in the GUI or bound by the maintainer. Relative paths inside a ZIP do not prove every workbench supports portable relative binding.

## 6. U002 configuration and Module plan

The editable SAMPLE template uses `U002_GUI_SAVED_PROFILE`. Formal Runs follow the current Run schema and workbench-produced configuration.

1. Select the Package produced by the current successful U001 Run and accepted by the downstream entry point. A filename alone does not establish its identity.
2. Define `RunPurpose`, `RunScope` and frame range, with a reason tied to the objective. Do not copy demonstration frame numbers.
3. Each `ModulePlan` item uses an existing `ModuleId`, exact `ModuleVersion`, `Stage`, `Sequence` and valid `Configuration`. It is not necessary to populate every numbered stage.
4. Bind actual signal names, units and meanings. Compute producer-related hashes from the actual files; never leave `BIND_TO_CURRENT_PRODUCER` as a final hash.
5. Trace each Module's implementation, declared dependencies, schema, Algorithm Card, registry and qualification definitions. Include the full declared dependency closure.
6. If the required algorithm does not exist, report the capability gap. Do not assign a new algorithm an old Module identity/version or describe AI-generated code as an already accepted Module.

The current SAMPLE analysis concerns radar measurement validity and camera geometry evidence. It is not automatically suitable for every camera–radar difference study. A project-specific objective, signal mapping, filtering policy and thresholds must be defined separately.

## 7. U003 review binding

Prefer opening U003 through the handoff produced by the current U002 analysis. Check that events, signals and video belong to that Run. Verify video frame origin, CAN FrameCount anchor and mapping ratio; successful video playback alone does not establish synchronization.

Explain what the reviewer should inspect, how to record a decision and which outputs to retain. AI can generate settings and review instructions; it must not claim a human watched the video. Report zero candidates honestly rather than manufacturing events.

## 8. Project ZIP contents

Names depend on the actual project implementation. This is a responsibility checklist, not a new automatic import format.

| Content | Requirements |
| --- | --- |
| Placement/start instructions | Base version, extraction location, JSON entry points and fields requiring source binding |
| Profile configurations | Exact ID/version, workbench settings, signal selection and processing policies |
| Modules and dependencies | Exact original implementation/version, dependency closure, schemas, Algorithm Cards and qualification definitions |
| Data or external source bindings | Only the agreed CAN/DBC/video scope; identify external files and their expected location |
| File manifest | Profile ID/version, required base version, Module ID/version; relative paths, byte counts and SHA256 |
| Run/check instructions | Completed checks, remaining environment validation and error return procedure |

The base supplies the runtime. Do not duplicate all of Python in every project Profile, include unrelated cases/old Runs, or silently overwrite different code under the same Module version. Manifest filename and installation steps must match the actual delivery implementation. Do not supply a placeholder manifest or generic installer presented as already supported.

## 9. Validate the changed scope

Reuse existing SAMPLE inputs, schemas and unchanged accepted Module evidence. Check relevant JSON fields, paths, units/frame basis, exact dependencies and hashes. When configuration changes, run a small relevant range through its real entry points and handoffs. Perform applicable final GUI/export acceptance on the complete candidate.

Each new check should answer an unresolved question. Do not rebuild test frameworks or require a company rerun at every stage. Preserve the first failure and actual log, stop dependent steps and never turn C7 into C0 by skipping checks or guessing missing values.

Distinguish file generation, static checks, local execution, Windows execution, human review and handover acceptance. Report only completed results. Model benchmark scores do not replace business validation.

## 10. Return to the operator

Deliver actual downloadable files, compatible base version, placement table, entry point, short action sequence, output locations and verified/pending scope.

For failure, return the workbench/stage, Profile/Run ID, full Machine Code, first specific error and displayed log path. Transfer original data only within the agreed scope; do not ask for a full archive to diagnose one error.

## 11. Sources and version basis

Base release: 0.10.15; public commit `220808af7519b391ab362014f77c260087bfde94`. Packaging behavior is defined by the base's PROFILE_ZIP_CONVENTION.md and actual consumers. Reference files retain their original bytes and paths in INDEX.json.

Model recommendations are project choices, not a claim that both named models have a particular SciCode score. Official settings references were checked on 2026-09-15. Availability in a specific company environment still depends on that environment.

- [GPT-5.6 Sol](https://developers.openai.com/api/docs/models/gpt-5.6-sol)
- [Claude effort](https://platform.claude.com/docs/en/build-with-claude/effort)
- [Copilot Studio model selection](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/authoring-select-agent-model)
- [Copilot Studio availability](https://learn.microsoft.com/en-us/microsoft-copilot-studio/authoring-select-agent-model)
- [SciCode](https://scicode-bench.github.io/)
