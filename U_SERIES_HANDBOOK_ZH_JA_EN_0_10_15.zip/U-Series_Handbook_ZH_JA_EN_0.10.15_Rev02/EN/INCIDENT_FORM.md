# Incident record

Write UNKNOWN where a fact is unavailable. Preserve error text and complete codes rather than paraphrasing them.

| Field | Value |
| --- | --- |
| Incident time | |
| Base package version | |
| EXE or script launched | |
| Profile ID and version | |
| Run ID and relevant Module versions | |
| Last action performed | |
| Expected result | |
| Actual result | |
| First occurrence or reproducible | |
| Recent configuration or file changes | |
| Actual log or report location | |
| If no log exists | NOT_CREATED / NOT_FOUND and exact system message |
| Receiving maintainer | |

## Complete Machine Code

```text
Paste every displayed code line unchanged
```

## First concrete error and relevant log excerpt

```text
Paste the exception name, message and relevant traceback
```

## Attachments

List the necessary logs, configurations, manifests and minimal reproduction evidence. Business data must stay within the organisation's approved scope.

## Resolution record

Record the evidence supporting the cause, exact change and owner, preserved previous state, actions checked and actual results, remaining issues and closure decision. Separate AI hypotheses from established facts.
