# U-Series diagnosis guide for the receiving AI Agent

Applies to U-Series 0.10.15. Revision 01, 2026-09-16.

Use this guide with `ERROR_CODE_INDEX.json`, `SOURCE_INDEX.json`, the incident form and the exact incident evidence. The receiving organisation owns the installation after handover. Diagnose without relying on the original developer or this conversation. Reply in the operator's language.

The recommended recipient workflow is an organisation-approved Copilot Studio Agent actually configured to use Claude Opus 5, with Medium effort where available. A model name in the prompt does not change the selected model. This guide supplies operating knowledge; it does not configure a tenant, grant file access or guarantee the correctness of a model's diagnosis.

## 1 Establish which system failed

Read the actual base version, Profile/Module identities, entry point and first failed action. Distinguish these contexts before interpreting a code:

| Context | Evidence to start with |
| --- | --- |
| Delivered U001/U002/U003 EXE | Program name, delivery root, startup log, exact dialog text |
| First SAMPLE preparation | `workspaces/SAMPLE/qualification.log`, presence of `prepared.json`, startup log |
| U001 source preparation | Working Profile, selected source and policy identities, the failed Run's report/log |
| U002 preparation or analysis | Formal Run JSON, Module plan and the first failed child/Module report |
| U003 review or export | Current event batch, review input/video mapping, selected action and displayed export path |
| Windows one-dir packaging | Complete `UGPK` output, `STEP`, `package_report.json`, `failure.log`, child build log |
| Source-transfer wrapper | Both full `UG22` lines and the JSON report named after `LOG-` |

A business error displayed by a workbench is not necessarily a `UG22` error. A `C3` or `C7` suffix without its prefix and originating tool is insufficient for diagnosis. Do not apply one tool's exit-code table to another tool.

## 2 Collect the smallest useful evidence

First request one incident record containing:

- Base version, program/entry point, Profile and Run IDs, selected Module versions if relevant.
- What the operator did, what was expected, what actually happened and the time of failure.
- Complete unedited Machine Code lines, the first concrete error and the relevant traceback, including the original exception before any wrapping `RuntimeError` or `CalledProcessError`.
- The real log/report path. If absent, record `NOT_CREATED` or `NOT_FOUND`; do not invent a location.
- The relevant saved configuration and a directory listing around the failed file, only when they help answer the current question.

Read the files already supplied before asking for more. Request a narrow log excerpt or a specific file rather than the full archive. Original recordings and business identifiers stay within the receiving organisation's approved data boundary; begin with logs, configuration and identities, and request a permitted minimal data example only if format or decoding cannot otherwise be resolved.

The `READ_ONLY_SOURCES` folder is reference material. Do not execute or install these copies. Match the installed release before using their line numbers. The preserved payload `MANIFEST.json` maps source file IDs to paths and hashes for this release; an older incident requires its own historical file map.

## 3 Locate the first failure

1. Classify the layer: operating-system launch, bundled runtime, workspace preparation, source/configuration, Module execution, handoff, review/export, or packaging.
2. Read the earliest concrete error at that layer. A later missing output may be a consequence, not the initiating cause.
3. Cite evidence by filename and the relevant key/line. Separate observed facts from plausible hypotheses.
4. Choose one discriminating check. State what each possible outcome would mean. Prefer existing reports and read-only inspection before requesting another execution.
5. Ask once for any remaining facts that would change the diagnosis. Do not guess paths, units, byte representation, models, source versions or code meanings.

Do not replay prepare/selftest/package operations merely to regenerate a status code. They may create or change workspaces. The supplied source wrapper's `diagnose` action is also a distinct interface with placement requirements; do not prescribe an invented `U001.exe --diagnose` command.

## 4 Interpret the supported code families

### Packaging

`UGPK_EXE3-RUNTIME1-SAMPLE1_GUI_PENDING_C0` reports that packaging completed with three native launchers, a runtime and SAMPLE. `GUI_PENDING` explicitly leaves GUI operation as a separate acceptance boundary.

`UGPK_C7 STEP=<step> <exception>` reports a packaging failure. Use `Step`, `FirstFailure`, `Checks`, `LogDirectory` and each child's `Log`, `ReturnCode` and `ReturnCodeHex` in `package_report.json`. The package builder writes `failure.log` after a caught failure in the main packaging block. Failures before that block can produce only `UGPK_C7 ...`; a missing log directory is therefore possible. Use the actual printed `REPORT=`, `[LOGS]` or traceback rather than assuming `logs/` must exist.

### Source-transfer wrapper

The current implementation retains the `UG22` family even though the base is 0.10.15. It is a code namespace, not a base-version detector.

- Phase `P`: prepare; `S`: selftest; `E`: execute (also the TC001 execution action); `D`: diagnose.
- A failed summary includes `K<Kind>`, `SG-<Step>`, `CF<count>`, `MS<count>` and `X<Unexpected>`, ending in `C7`. These locate the failure; they do not by themselves prove a root cause.
- A detail line beginning `UG22D_` may follow failures in any phase. Its `D` does not by itself prove that the user ran the diagnose action.
- `F...` identifies the first issue in the report. `SF...` identifies a mapped source file. They are different fields. `F000` is the fallback issue identity when the issue list is empty.
- `RC` is the child return code. `RCM<n>` represents a negative child code. Read it in that child's context.
- `EX` is an exception category, `LN` the mapped source line, `WX` a Windows error number and `ER` an errno. Read full messages in the report for a specific cause.
- `EH` and `AH` are abbreviated expected/actual file hashes for a conflict. Resolve the full manifest fields; a short hash fragment is not enough to replace a file safely.
- `LOG-<basename>` identifies the associated JSON report. `LOG-NONE` may occur if report initialization or saving failed.

The diagnostic reader selects a specific exception where possible. `EXUNK` and `DXUNPARSED` mean that a supported specific classification was not established; they do not mean the source is healthy. Read all `Errors`, `Reads`, `Tests` and child return codes, not only the selected short token. `DXMISSING`, `DXREAD`, `DXLIMIT` or `DXINCOMPLETE` describe a problem reading/parsing diagnostic evidence, not necessarily the original business cause.

**The diagnose action intentionally keeps the old incident at `Status: C7`.** A successful evidence read sets `DiagnosticReadSucceeded: true` and `BusinessAcceptanceChanged: false`. Do not interpret this as a new failed diagnostic execution, and do not change the original incident to C0 merely because it can now be explained.

For exception abbreviations and the remaining fields, read `ERROR_CODE_INDEX.json`. It is scoped to named implementations, not a universal catalogue of all Module errors.

## 5 Common diagnosis branches

### No window and no log

Confirm that the operator launched one of the supplied EXEs from the extracted complete folder. Read the exact Windows message and check the presence of the corresponding EXE, `runtime/python.exe`, `runtime/pythonw.exe`, `product` and `support`. If evidence points to an application-policy or access restriction, use the organisation's IT process. Do not advise disabling protection or installing an unrelated system Python. A failure before the launcher's logging setup can leave no application log.

### Workspace moved or preparation unfinished

The launcher stores its absolute workspace root in `workspaces/SAMPLE/prepared.json` and checks it on subsequent use. It also refuses a pre-existing workspace that lacks a completed preparation receipt. Preserve the used folder and its Runs. Establish whether it was moved or whether the original preparation failed; inspect `qualification.log` and the first startup traceback. Have the maintainer select a supported migration or a fresh unused delivery folder. Do not edit the receipt to conceal the mismatch or erase the unfinished folder before preserving evidence.

### Installed product changed

The launcher compares fixed product files with `PACKAGE_MANIFEST.json`. Find the exact file named by the error and compare its bytes/hash with the expected version. Determine whether this was an incomplete extraction, an intentional change or a version mix. Restore or issue a coherent package through the receiving maintainer. Do not edit the manifest to legitimise unknown bytes or disable the integrity check.

### Missing source, policy or Profile

Check the exact field named by the error, the saved configuration's actual consumer and the selected file. Separate a missing file from a wrong JSON contract or stale absolute path. Use the supported UI to correct working configuration. Do not rename a formal Run JSON as a workbench Profile or invent defaults to fill required scientific fields.

### Byte decoding or unexpected signal values

Confirm the Adapter identity, source export format, DBC identities and `RawByteEncoding`. In `HEX_TEXT`, `80` denotes 128; in `DECIMAL`, it denotes 80. Digit-only rows do not decide the format. Check a known permitted example and the relevant selected-signal/semantic/frame/hold policy. Avoid guessing that a successful parse establishes valid physical meaning.

### Dependency or native runtime failure

Use the launcher's actual `sys.executable`/runtime evidence and the missing DLL/module/component from the first error. Check whether the complete bundled runtime was delivered and whether versions match the manifest. Keep investigation inside the supplied runtime. A package rebuild or dependency replacement is a maintainer change with its own applicable acceptance; do not patch a used installation by a blanket pip upgrade.

### U002 preparation or Module failure

Confirm the successful U001 input identity, formal U002 Run JSON, selected frame range and exact Module ID/version/configuration. Read the first failed Module's manifest, schema and child log. An EMPTY stage may be intentional. Zero candidates may be a correct outcome. Do not lower thresholds or skip a failed stage merely to produce events or a success status.

### Review video or export problem

Confirm the current Run and event batch, video path, frame origin, CAN anchor and mapping ratio. Playback alone does not establish synchronization. For export, distinguish `Save Event Review`, `Save Screenshot` and `Export Reviews`. Use the real completion path, permissions and any file-lock evidence. A missing screenshot is not the same failure as a missing review CSV.

## 6 Propose a controlled correction

For every proposed correction, state the affected file/setting, why it addresses the observed failure, who should perform it, what existing evidence must be preserved, and how to restore the previous state.

Operators may follow supported configuration steps. The receiving maintainer owns code/runtime/integrity changes, migrations and package revisions. IT owns managed-environment permissions and application policy. If the Agent can edit or execute, obtain the relevant receiving-team approval before changing those items. Reading supplied diagnostic files does not imply permission to rewrite the installation.

Do not create a generic repairer that silently scans, deletes or rewrites files. Do not suppress exceptions, remove acceptance gates, rewrite historic reviews, switch unknown values to defaults or relabel failure as success. When a capability or an authoritative code definition is missing, identify the missing evidence and the responsible maintainer rather than manufacturing an answer.

## 7 Verify and close the incident

Use the narrowest check that answers the identified issue. After a configuration correction, repeat the affected preparation/execution step and its relevant downstream handoff. A change affecting the whole base, GUI launch, runtime or export needs the applicable complete acceptance on the final candidate. Do not repeat unrelated passed checks without a reason.

Report these states separately: files produced, static checks, local execution, target Windows execution, GUI handoff/export, human review and business acceptance. A saved ZIP, a C0 or an AI explanation is not evidence that all states passed.

Close the incident record with the cause supported by evidence, the exact change, the checks actually run and their results, output paths, version/Run identities and remaining limitations. If blocked, name the specific missing file, authority or observation. Route unresolved work to the receiving maintainer or IT, never to an unavailable original developer.

## 8 Required reply format

1. **Observed failure:** program, phase, code namespace, version and first concrete error.
2. **Evidence:** supplied files/keys/lines and what they establish.
3. **Assessment:** supported conclusion versus hypotheses; confidence and missing evidence.
4. **Next step:** one focused check or justified correction, operator/maintainer/IT owner, expected interpretation.
5. **Preservation and rollback:** only the items actually affected.
6. **Verification:** affected checks, actual results and remaining boundary.

If evidence is insufficient, make the next evidence request precise. Do not return a long list of speculative repairs.

## 9 Version maintenance

`SOURCE_INDEX.json` records paths, bytes and SHA256 for the included reference files. `ERROR_CODE_INDEX.json` cites the implementation symbols/lines used by this guide. After a base upgrade, the receiving maintainer must compare the relevant emitters and update the index when their meanings change. Do not copy source line numbers across versions without matching the file identity.

These references do not contain the incident's business recording or prove that a specific failure occurred. They explain the code that emits and interprets the supported diagnostics.

## 10 Worked interpretation examples

These examples illustrate reasoning; they are not incident records or proof of a fix.

**Only `UGPK_C7 RuntimeError`, with no log directory.** This establishes a packaging failure but not its cause. Ask for the complete console text and whether `STEP=`, `REPORT=` or `[LOGS]` appeared. Check the matching builder's pre-report checks and first traceback. Do not invent a missing package or state that a log must exist.

**A `UG22S` failure with `KCHILD`, `CF0`, `MS0` and `RC1`.** The wrapper reports a child failure during selftest. Zero file-conflict/missing counts do not prove that the runtime, child assertions or input are correct. Open the report's failing child stdout/stderr and identify its first concrete exception or test failure. `EXUNK-DXUNPARSED` requires the full evidence; it is not a specific root cause.

**A diagnose report with `Status: C7`, `DiagnosticReadSucceeded: true` and `BusinessAcceptanceChanged: false`.** Evidence reading succeeded while the original task remains failed. Explain the original cause if the evidence supports it. Do not rerun or repair the diagnostic reader merely to turn its retained status into C0.

**Only `C3`.** Ask for the full code, originating program/script, version and action. Locate that exact emitter's definition. Do not assign packaging, signal-decoding, file-lock or validation meanings to the suffix without evidence.
