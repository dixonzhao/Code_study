"""Extract bounded, actionable failure evidence without changing original reports."""
from pathlib import Path
import hashlib
import json
import os
import re

VERSION = '0.1.0'
MAX_LOG_BYTES = 16 * 1024 * 1024
EXCEPTIONS = dict(UnicodeDecodeError='UDE', UnicodeEncodeError='UEE',
                  ModuleNotFoundError='MNF', ImportError='IMP', NameError='NAM',
                  AttributeError='ATT', TypeError='TYP', ValueError='VAL',
                  KeyError='KEY', PermissionError='PER', OSError='OS',
                  FileNotFoundError='OS', TclError='TCL', CalledProcessError='SUB',
                  SubprocessError='SUB', TimeoutExpired='TIME', SystemExit='EXIT')
FRAME = re.compile(r'^\s*File "(.+)", line (\d+)(?:, in (.*))?$')
ERROR = re.compile(r'^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)(?::\s*(.*))?$')
TEST = re.compile(r'^(FAIL|ERROR): (test_[A-Za-z0-9_]+)(?:\s|$)')


def confined_file(root, value):
    """Check every path component, including junctions on Windows."""
    root = Path(root).absolute()
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    if '..' in path.parts or not path.is_relative_to(root):
        raise ValueError('OUTSIDE')
    for part in (path, *path.parents):
        if part.is_symlink() or getattr(part, 'is_junction', lambda: False)():
            raise ValueError('LINK')
        if part == root:
            break
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('OUTSIDE')
    return path


def read_bounded(root, value):
    path = confined_file(root, value)
    # The bounded read also detects a file growing after stat().
    with path.open('rb') as stream:
        data = stream.read(MAX_LOG_BYTES + 1)
    if len(data) > MAX_LOG_BYTES:
        raise ValueError('LIMIT')
    return data.decode('utf-8', errors='replace')


def source_frame(frames, manifest):
    rows = manifest.get('Files', []) + manifest.get('SupportFiles', [])
    for frame in reversed(frames):
        name = frame['File'].replace('\\', '/').casefold()
        matches = [row for row in rows if name == row['Path'].replace('\\', '/').casefold()
                   or name.endswith('/' + row['Path'].replace('\\', '/').casefold())]
        if not matches:
            matches = [row for row in rows if row['Path'].replace('\\', '/').rsplit('/', 1)[-1].casefold()
                       == name.rsplit('/', 1)[-1]]
        if len(matches) == 1:
            return dict(frame, Id=matches[0]['Id'], Path=matches[0]['Path'], Status='MAPPED')
    return dict(frames[-1] if frames else {}, Id='UNKNOWN', Status='UNKNOWN')


def exception_record(name, message, frames, manifest):
    short_name = name.rsplit('.', 1)[-1]
    record = dict(Exception=name, Code=EXCEPTIONS.get(short_name, 'UNK'),
                  Message=message, Frames=list(frames), Source=source_frame(frames, manifest))
    for label, pattern in (('WinError', r'\[WinError (-?\d+)\]'), ('Errno', r'\[Errno (-?\d+)\]')):
        match = re.search(pattern, message)
        if match:
            record[label] = int(match[1])
    if short_name in ('UnicodeDecodeError', 'UnicodeEncodeError'):
        match = re.search(r"'([A-Za-z0-9_.-]+)' codec", message)
        if match:
            record['Encoding'] = match[1]
        match = re.search(r'byte 0x([A-Fa-f0-9]{2})', message)
        if match:
            record['Byte'] = match[1].upper()
        match = re.search(r'position(?:s)? (\d+)', message)
        if match:
            record['Position'] = int(match[1])
    if short_name in ('ModuleNotFoundError', 'NameError', 'AttributeError'):
        match = re.search(r"(?:No module named|name|attribute) '([A-Za-z_][A-Za-z0-9_.]{0,63})'", message)
        if match:
            record['Symbol'] = match[1]
    return record


def parse_text(text, manifest):
    """Only actual traceback blocks and unittest headers count as evidence."""
    errors, tests, frames = [], [], []
    active = False
    for line in text.splitlines():
        test = TEST.match(line)
        if test:
            kind, name = test.groups()
            tests.append(dict(Kind=kind, Test=name,
                              Id=hashlib.sha256(name.encode('ascii')).hexdigest()[:8].upper()))
        if line.startswith('Traceback (most recent call last):'):
            frames = []
            active = True
            continue
        if not active:
            continue
        frame = FRAME.match(line)
        if frame:
            frames.append(dict(File=frame[1], Line=int(frame[2]), Function=frame[3]))
            continue
        error = ERROR.match(line)
        if error and (error[2] is not None or error[1].endswith(('Error', 'Exception', 'Exit', 'Interrupt'))):
            errors.append(exception_record(error[1], error[2] or '', frames, manifest))
            active = False
    return dict(Errors=errors, Tests=tests, IncompleteTraceback=active)


def summarize_child(root, item, manifest):
    result = dict(Errors=[], Tests=[], Reads=[])
    for channel in ('Stdout', 'Stderr'):
        value = item.get(channel, {})
        filename = value.get('File') if isinstance(value, dict) else None
        row = dict(Channel=channel, File=filename, Status='OK')
        try:
            if not isinstance(filename, str) or not filename:
                raise ValueError('MISSING')
            parsed = parse_text(read_bounded(root, filename), manifest)
            for kind in ('Errors', 'Tests'):
                result[kind].extend(dict(entry, Channel=channel, Step=item.get('Step')) for entry in parsed[kind])
            if parsed['IncompleteTraceback']:
                row['Status'] = 'INCOMPLETE'
        except FileNotFoundError:
            row['Status'] = 'MISSING'
        except (ValueError, OSError) as error:
            row['Status'] = str(error) if isinstance(error, ValueError) else 'READ'
        result['Reads'].append(row)
    if item.get('StartException'):
        result['Errors'].append(exception_record(item['StartException'], item.get('StartError', ''), [], manifest))
    result['UnhandledTraceback'] = bool(result['Errors'])
    result['UnparsedFailure'] = bool(item.get('ReturnCode') and not result['Errors'] and not result['Tests'])
    return result


def combine(children):
    result = dict(Errors=[], Tests=[], Reads=[])
    for item in children:
        dx = item.get('Diagnostic', {})
        for key in result:
            result[key].extend(dx.get(key, []))
    return result


def safe_memo(message):
    # Local reports retain the original; only this bounded text may be returned.
    value = re.sub(r"(['\"]).*?\1", '<value>', str(message))
    value = re.sub(r'(?:[A-Za-z]:[\\/]|/)[^\s,;]+', '<path>', value)
    return ' '.join(value.split())[:160]


def short_tokens(result):
    errors = result.get('Errors', [])
    specific = [e for e in errors if e['Code'] not in ('SUB', 'UNK')]
    chosen = (specific or [e for e in errors if e['Code'] != 'SUB'] or errors)
    tokens = ''
    if chosen:
        error = chosen[0]
        source = error['Source']
        tokens = '-EX' + error['Code'] + '-SF' + source['Id']
        if error['Code'] == 'UNK':
            tokens += '-DXUNPARSED'
        if source['Status'] == 'MAPPED':
            tokens += '-LN' + str(source['Line'])
        for key, prefix in (('WinError', 'WX'), ('Errno', 'ER'), ('Encoding', 'EC'),
                            ('Byte', 'BY'), ('Position', 'PS'), ('Symbol', 'SY')):
            if key in error:
                tokens += '-' + prefix + re.sub('[^A-Za-z0-9_.]', '', str(error[key]))[:64].upper()
        if len(errors) > 1:
            tokens += '-OE' + str(len(errors) - 1)
    else:
        tokens = '-EXUNK-DXUNPARSED'
    statuses = sorted({r['Status'] for r in result.get('Reads', []) if r['Status'] != 'OK'})
    for status in statuses:
        tokens += '-DX' + status
    return tokens


def read_report(root, path):
    data = json.loads(read_bounded(root, path))
    if not isinstance(data, dict):
        raise ValueError('REPORT_FORMAT')
    return data


def delivery_files(root, base, basename):
    """Do not descend into linked folders while looking for old receipts."""
    confined_file(root, base)
    for directory, dirs, files in os.walk(base, followlinks=False):
        parent = Path(directory)
        dirs[:] = [name for name in dirs if not (parent / name).is_symlink()
                   and not getattr(parent / name, 'is_junction', lambda: False)()]
        for name in files:
            if name == basename or basename == 'UG*.json' and name.startswith('UG') and name.endswith('.json'):
                yield confined_file(root, parent / name)


def historical_failure(root, basename=None):
    """Find an original failed receipt and its own versioned file map."""
    if basename is not None and not re.fullmatch(r'UG\d+[PSE]-[A-Fa-f0-9]{6}\.json', basename):
        raise ValueError('REPORT_BASENAME')
    transfer = root / 'U-UDP001/04_TEMP'
    archive = root / 'U-UDP001/A-Archive/04_TEMP'
    candidates = []
    # Only known delivery report directories, never arbitrary workspace files.
    for base in (transfer, archive):
        if not base.exists():
            continue
        confined_file(root, base)
        for path in delivery_files(root, base, basename or 'UG*.json'):
            if not re.fullmatch(r'U_SERIES_GUI_TRIAL_v\d+_\d+_\d+_REPORTS', path.parent.name):
                continue
            if not re.fullmatch(r'UG\d+[PSE]-[A-Fa-f0-9]{6}\.json', path.name):
                continue
            report = read_report(root, path)
            if report.get('Status') == 'C7':
                candidates.append((path.stat().st_mtime_ns, path, report))
    if not candidates:
        raise ValueError('FAILED_REPORT_MISSING')
    if basename and len(candidates) != 1:
        raise ValueError('REPORT_AMBIGUOUS')
    _, path, report = max(candidates, key=lambda row: row[0])
    version = report.get('Version', '')
    if not isinstance(version, str) or not re.fullmatch(r'\d+\.\d+\.\d+', version):
        raise ValueError('REPORT_VERSION')
    suffix = version.replace('.', '_')
    manifests = []
    for base in (transfer, archive):
        if base.exists():
            for candidate in delivery_files(root, base, 'MANIFEST.json'):
                if candidate.parent.name != f'U_SERIES_GUI_TRIAL_v{suffix}_payload':
                    continue
                value = read_report(root, candidate)
                if value.get('Version') == version:
                    manifests.append((candidate, value))
    identities = {json.dumps(value, sort_keys=True) for _, value in manifests}
    if len(identities) != 1:
        raise ValueError('MANIFEST_MISSING' if not identities else 'MANIFEST_AMBIGUOUS')
    manifest_path, manifest = manifests[0]
    children = report.get('Children', [])
    if not isinstance(children, list) or not all(isinstance(c, dict) for c in children):
        raise ValueError('REPORT_CHILDREN')
    for item in children:
        # prepare moves old report directories with their adjacent logs intact.
        # Rebase only a missing, confined reference with this receipt's exact name.
        for channel in ('Stdout', 'Stderr'):
            reference = item.get(channel, {})
            filename = reference.get('File') if isinstance(reference, dict) else None
            if not isinstance(filename, str):
                continue
            try:
                original = confined_file(root, filename)
                basename = original.name
                expected = re.fullmatch(re.escape(path.stem) + r'-\d+\.(out|err)\.txt', basename)
                relocated = confined_file(root, path.parent / basename)
                if not original.exists() and expected and relocated.is_file():
                    item[channel] = dict(reference, File=str(relocated), RebasedFrom=filename)
            except (ValueError, OSError):
                pass  # summarize_child records the original read restriction.
        item['Diagnostic'] = summarize_child(root, item, manifest)
    diagnostic = combine(children)
    if not diagnostic['Errors'] and report.get('Traceback'):
        diagnostic['Errors'] = parse_text(report['Traceback'], manifest)['Errors']
    return dict(OriginalReport=str(path), OriginalVersion=version,
                OriginalStatus=report['Status'], Manifest=str(manifest_path),
                OriginalSHA256=hashlib.sha256(confined_file(root, path).read_bytes()).hexdigest(),
                ChildReturnCode=report.get('ChildReturnCode', 0),
                Children=children, Diagnostic=diagnostic)
