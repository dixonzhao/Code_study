"""Entry shared by the three native launchers; all paths belong to this folder."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys
import traceback

BASE = Path(__file__).resolve().parent.parent
ENTRIES = {
    'U001': 'U-UDP001/u001_workbench_v0_6_5.py',
    'U002': 'U-UDP002/01_PROGRAMS/gui/u002_thin_workbench_gui_v0_12_2.py',
    'U003': 'U-UDP003/01_PROGRAMS/u003_evidence_review_workbench_v0_22_0.py',
}

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def bind_runtime():
    runtime = BASE / 'runtime'
    # GUI launchers use pythonw; child commands need the bundled console interpreter.
    if sys.platform == 'win32':
        if not Path(sys.executable).resolve().is_relative_to(runtime.resolve()):
            raise RuntimeError('Start with the bundled EXE/runtime.')
        sys.executable = str(runtime / 'python.exe')
    for variable, filename in (('TCL_LIBRARY', 'init.tcl'), ('TK_LIBRARY', 'tk.tcl')):
        matches = list((runtime / 'tcl').glob('*/' + filename))
        if len(matches) != 1:
            raise ValueError('Bundled Tcl/Tk component missing: ' + filename)
        os.environ[variable] = str(matches[0].parent)
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

def check_runtime():
    if sys.platform != 'win32':
        raise RuntimeError('Windows package checks must run on Windows.')
    bind_runtime()
    probe = runpy.run_path(str(BASE / 'support/runtime_probe_v0_10_15.py'))
    result = probe['inspect_runtime'](probe_window=False)
    if not result['Passed']:
        raise RuntimeError('Bundled dependency probe failed: ' + json.dumps(result))
    import cv2
    video = BASE / 'product/U-UDP003/03_INPUT/SAMPLE_v0_10_7/SAMPLE_VIDEO.avi'
    cap = cv2.VideoCapture(str(video))
    try:
        ok, frame = cap.read()
        if not ok or frame is None:
            raise RuntimeError('Bundled SAMPLE video cannot be decoded.')
    finally:
        cap.release()
    return {'Runtime': sys.executable, 'Dependencies': 'PASS', 'SampleVideo': 'PASS'}

def workspace():
    root = BASE / 'workspaces/SAMPLE/C-Code'
    receipt = root.parent / 'prepared.json'
    if receipt.exists():
        state = read(receipt)
        if state['Root'] != str(root):
            raise RuntimeError('This used workspace was moved. Keep its Runs and use a fresh delivery folder.')
        for row in read(BASE / 'PACKAGE_MANIFEST.json')['FixedProductFiles']:
            path = root / row['Path']
            if hashlib.sha256(path.read_bytes()).hexdigest() != row['SHA256']:
                raise RuntimeError('Installed product changed: ' + row['Path'])
        return root
    if root.exists():
        raise RuntimeError('An unfinished workspace remains; see logs before retrying with a fresh folder.')
    root.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(BASE / 'product', root)
    log = root.parent / 'qualification.log'
    with log.open('wb') as stream:
        result = subprocess.run([
            sys.executable, '-I', '-X', 'utf8', '-B',
            str(BASE / 'support/workspace_check_v0_10_15.py'),
            '--root', str(root), '--manifest', str(BASE / 'support/product_manifest.json'),
            '--output', str(root.parent / 'qualification'),
        ], cwd=root, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
    if result.returncode:
        raise RuntimeError('SAMPLE setup failed; see ' + str(log))
    receipt.write_text(json.dumps({'Root': str(root), 'Version': '0.10.15', 'Qualification': 'PASS'}), encoding='utf-8')
    return root

def launch(program, arguments):
    bind_runtime()
    root = workspace()
    sample = runpy.run_path(str(BASE / 'support/sample_setup_v0_10_15.py'))
    profile = sample['setup'](root)
    args = list(arguments)
    if program == 'U001':
        args = ['--gui', '--profile', str(profile), *args]
    elif program == 'U002':
        args = ['--workspace-root', str(root / 'U-UDP002'), *args]
        state = read(profile)
        status = Path(state['OutputRoot']) / state['RunId'] / 'u001_controller_status.json'
        if status.is_file() and read(status).get('Status') == 'SUCCEEDED':
            args += ['--run-config', str(sample['u002_configuration'](root))]
    os.environ['U003_WORKSPACE'] = str(root / 'U-UDP003/07_OUTPUT/PORTABLE_SAMPLE')
    entry = root / ENTRIES[program]
    sys.path.insert(0, str(entry.parent))
    sys.argv = [str(entry), *args]
    runpy.run_path(str(entry), run_name='__main__')
    return 0

def main():
    program = Path(sys.argv[0]).stem.upper()
    if program not in ENTRIES:
        raise ValueError('Launch U001.exe, U002.exe or U003.exe.')
    arguments = sys.argv[1:]
    (BASE / 'logs').mkdir(exist_ok=True)
    log = BASE / 'logs' / (program + '_' + datetime.now().strftime('%Y%m%dT%H%M%S_%f') + '.log')
    sys.stdout = sys.stderr = log.open('w', encoding='utf-8', buffering=1)
    try:
        if arguments[:1] == ['--package-check']:
            result = check_runtime()
            result.update(Program=program, Status='PASS', NativeLauncherEntered=True, GUI='PENDING')
            Path(arguments[1]).write_text(json.dumps(result, indent=2), encoding='utf-8')
            return 0
        return launch(program, arguments)
    except Exception:
        traceback.print_exc()
        if arguments[:1] != ['--package-check']:
            from tkinter import Tk, messagebox
            root = Tk()
            root.withdraw()
            try:
                messagebox.showerror(program, 'Startup failed. See log:\n' + str(log), parent=root)
            finally:
                root.destroy()
        return 7

