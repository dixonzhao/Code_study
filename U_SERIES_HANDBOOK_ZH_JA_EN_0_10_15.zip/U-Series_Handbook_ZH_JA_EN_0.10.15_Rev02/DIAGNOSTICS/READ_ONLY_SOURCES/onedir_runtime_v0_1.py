"""Build offline on Windows from the verified runtime; never copy a bare venv."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import json
import os
import runpy
import shutil
import struct
import subprocess
import sys
import sysconfig
import traceback
import uuid

HERE = Path(__file__).resolve().parent
VERSIONS = {"numpy": "2.3.5", "Pillow": "12.3.0", "openpyxl": "3.1.5", "opencv-python-headless": "4.13.0.92", "et_xmlfile": "2.0.0"}


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def linked(path):
    return path.is_symlink() or getattr(path, "is_junction", lambda: False)()


def copy_tree(source, target):
    """Copy runtime directories only, rejecting links and unrelated installed packages."""
    if linked(source):
        raise ValueError("RUNTIME_PATH_LINK: " + str(source))
    target.mkdir(parents=True, exist_ok=True)
    for path in source.iterdir():
        if path.name in ("site-packages", "__pycache__"):
            continue
        if linked(path):
            raise ValueError("RUNTIME_MEMBER_LINK: " + str(path))
        if path.is_dir():
            copy_tree(path, target / path.name)
        elif path.is_file():
            shutil.copyfile(path, target / path.name)


def collect_runtime(target):
    if sys.platform != "win32" or struct.calcsize("P") != 8 or sys.version_info < (3, 12):
        raise ValueError("PACKAGE_REQUIRES_WINDOWS_X64_PYTHON312_OR_LATER")
    base = Path(sys.base_prefix).resolve()
    site = Path(sysconfig.get_path("purelib")).resolve()
    if linked(base) or not (base / "python.exe").is_file():
        raise ValueError("FULL_BASE_RUNTIME_MISSING")
    for package, expected in VERSIONS.items():
        if importlib.metadata.version(package) != expected:
            raise ValueError("RUNTIME_DEPENDENCY_VERSION: " + package)
    target.mkdir()
    for name in ("Lib", "DLLs", "tcl"):
        source = base / name
        if not source.is_dir():
            raise ValueError("BASE_RUNTIME_COMPONENT_MISSING: " + name)
        copy_tree(source, target / name)
    root_files = [path for path in base.iterdir() if path.is_file() and (path.suffix.lower() == ".dll" or path.name in ("python.exe", "pythonw.exe") or path.name.lower().startswith("license"))]
    for path in root_files:
        if linked(path):
            raise ValueError("RUNTIME_ROOT_FILE_LINK")
        shutil.copyfile(path, target / path.name)
    if not (target / "pythonw.exe").is_file() or not list(target.glob("python3*.dll")):
        raise ValueError("FULL_BASE_RUNTIME_INCOMPLETE")
    packages = target / "Lib/site-packages"
    packages.mkdir(parents=True)
    counts = {}
    for package in VERSIONS:
        distribution = importlib.metadata.distribution(package)
        if not distribution.files:
            raise ValueError("DEPENDENCY_FILE_RECORD_MISSING: " + package)
        copied = 0
        for relative in distribution.files:
            if "__pycache__" in relative.parts or str(relative).endswith(".pyc"):
                continue
            source = Path(distribution.locate_file(relative)).resolve()
            # Console commands such as f2py are not used by the three GUI programs.
            if not source.is_relative_to(site):
                if source.parent == Path(sys.prefix).resolve() / "Scripts":
                    continue
                raise ValueError("DEPENDENCY_FILE_OUTSIDE_SITE: " + str(relative))
            if not source.is_file():
                raise ValueError("DEPENDENCY_FILE_MISSING: " + str(relative))
            destination = packages / source.relative_to(site)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists() and destination.read_bytes() != source.read_bytes():
                raise ValueError("DEPENDENCY_FILE_COLLISION: " + str(relative))
            shutil.copyfile(source, destination)
            copied += 1
        counts[package] = {"Version": distribution.version, "Files": copied}
    return {"Python": sys.version, "BasePrefix": str(base), "PreparedRuntime": sys.prefix, "Packages": counts}


