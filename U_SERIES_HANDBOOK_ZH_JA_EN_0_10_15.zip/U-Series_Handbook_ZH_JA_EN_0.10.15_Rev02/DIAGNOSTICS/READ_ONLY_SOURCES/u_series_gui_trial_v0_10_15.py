"""CMD delivery with bounded return capsules; business work remains inside each GUI."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
import traceback
import uuid

VERSION = "0.10.15"
BUNDLE = Path(__file__).resolve().parent
TRANSFER = BUNDLE.parent
PAYLOAD = BUNDLE / "U_SERIES_GUI_TRIAL_v0_10_15_payload"
REPORTS = "U_SERIES_GUI_TRIAL_v0_10_15_REPORTS"
PHASE = {"prepare": "P", "selftest": "S", "execute": "E", "diagnose": "D", "tc001": "E"}
DIAGNOSTICS = runpy.run_path(str(BUNDLE / "u_series_failure_diagnostics_v0_1.py"))
ENTRIES = {
    "U001": "U-UDP001/u001_workbench_v0_6_5.py",
    "U002": "U-UDP002/01_PROGRAMS/gui/u002_thin_workbench_gui_v0_12_2.py",
    "U003": "U-UDP003/01_PROGRAMS/u003_evidence_review_workbench_v0_22_0.py",
}
PROFILE = "U-UDP002/02_CONFIG/gui_profiles/u002_radar_loss_golden_reference_v0_1.json"


class DeliveryError(RuntimeError):
    def __init__(self, kind, message, issues=()):
        super().__init__(message)
        self.kind = kind
        self.issues = list(issues)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def child(root, relative):
    value = Path(relative)
    target = root / value
    if (
        value.is_absolute()
        or ".." in value.parts
        or target.is_symlink()
        or not target.resolve().is_relative_to(root.resolve())
    ):
        raise DeliveryError("PATH", "Unsafe destination: " + str(relative))
    return target


def workspace_root():
    root = TRANSFER.parent.parent.resolve()
    missing = [
        name
        for name in ("U-UDP001", "U-UDP002", "U-UDP003")
        if not (root / name).is_dir()
    ]
    location_ok = (
        TRANSFER.name.casefold() == "04_temp"
        and TRANSFER.parent.name.casefold() == "u-udp001"
    )
    if missing or not location_ok:
        raise DeliveryError(
            "ROOT",
            "Place the launcher directly in U-UDP001/04_TEMP. Missing: "
            + ", ".join(missing),
            [
                {
                    "Id": "F900",
                    "Kind": "ROOT",
                    "MissingWorkspaces": missing,
                    "TransferLocationValid": location_ok,
                }
            ],
        )
    return root


def require_runtime():
    if sys.version_info < (3, 12) or os.name != "nt":
        raise DeliveryError(
            "PYTHON",
            "Windows Python 3.12 or later is required; Python Launcher is not required.",
        )


def write_json(path, value):
    writing = path.with_suffix(path.suffix + ".writing")
    writing.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    writing.replace(path)


def payload_source(relative):
    return child(PAYLOAD, relative)


def audit(root, report, installed=False):
    manifest = json.loads((PAYLOAD / "MANIFEST.json").read_text(encoding="utf-8"))
    if manifest.get("Version") != VERSION:
        raise DeliveryError("PACKAGE", "Unexpected payload manifest version.")
    report["ManifestSHA256"] = digest(PAYLOAD / "MANIFEST.json")
    report["Inventory"] = []
    issues, plan = [], []
    report["Issues"] = issues
    for section, source_root in (
        ("SupportFiles", BUNDLE),
        ("Files", PAYLOAD),
        ("SeedFiles", PAYLOAD),
    ):
        for entry in manifest[section]:
            row = {
                "Id": entry["Id"],
                "Path": entry["Path"],
                "Section": section,
                "ExpectedSHA256": entry["SHA256"],
            }
            report["Inventory"].append(row)
            try:
                source = (
                    payload_source(entry["Path"])
                    if section in ("Files", "SeedFiles")
                    else child(source_root, entry["Path"])
                )
                if not source.is_file():
                    row["Kind"] = "MISSING"
                elif digest(source) != entry["SHA256"]:
                    row.update(Kind="PACKAGE", ActualSHA256=digest(source))
                elif section in ("Files", "SeedFiles"):
                    target = child(root, entry["Path"])
                    row["Target"] = str(target)
                    if target.exists():
                        actual = digest(target) if target.is_file() else "NOTFILE"
                        row["ActualSHA256"] = actual
                        row["Kind"] = (
                            "MATCH" if actual == entry["SHA256"] else "CONFLICT"
                        )
                        if section == "SeedFiles" and target.is_file():
                            row["Kind"] = "KEEP"
                        if (
                            section == "Files"
                            and not installed
                            and row["Kind"] == "CONFLICT"
                            and actual in entry.get("KnownPreviousSHA256", [])
                        ):
                            row["Kind"] = "UPGRADE"
                    else:
                        row["Kind"] = "MISSING" if installed else "NEW"
                    plan.append((source, target))
                else:
                    row["Kind"] = "MATCH"
            except (OSError, DeliveryError) as error:
                row.update(
                    Kind="PATH" if isinstance(error, DeliveryError) else "IO",
                    Error=str(error),
                )
            if row["Kind"] not in ("MATCH", "NEW", "UPGRADE", "KEEP"):
                issues.append(dict(row))
    report["PreservedWorkspaceState"] = []
    for entry in manifest.get("ExistingStateFiles", []):
        row = dict(entry)
        try:
            state = child(root, entry["Path"])
            row.update(
                Exists=state.exists(),
                ActualSHA256=digest(state) if state.is_file() else None,
            )
        except (OSError, DeliveryError) as error:
            row["ReadError"] = str(error)
        report["PreservedWorkspaceState"].append(row)
    profile_row = {"Id": "F901", "Path": PROFILE}
    try:
        profile = child(root, PROFILE)
        if not profile.is_file():
            profile_row["Kind"] = "MISSING"
        else:
            profile_row["ActualSHA256"] = digest(profile)
            value = json.loads(profile.read_text(encoding="utf-8-sig"))
            profile_row["Kind"] = "MATCH" if isinstance(value, dict) else "PROFILE"
    except (OSError, ValueError, DeliveryError) as error:
        profile_row.update(Kind="PROFILE", Error=str(error))
    report["Profile"] = profile_row
    if profile_row["Kind"] != "MATCH":
        issues.append(profile_row)
    report["UnmanagedLegacyFiles"] = [
        {"Path": name, "Exists": (root / name).exists()}
        for name in manifest.get("RetiredUnmanagedFiles", [])
    ]
    report["Issues"] = issues
    report["ManagedFiles"] = len(manifest["Files"])
    report["SeedFiles"] = len(manifest.get("SeedFiles", []))
    if issues:
        raise DeliveryError(
            issues[0]["Kind"],
            "Inventory audit failed; all detected issues are in the report.",
            issues,
        )
    print(
        "[CHECK] All required packet files, destination hashes and the existing U002 Profile passed."
    )
    return plan


def stream_summary(path):
    with path.open("rb") as stream:
        lines = sum(
            block.count(b"\n") for block in iter(lambda: stream.read(1024 * 1024), b"")
        )
        size = stream.tell()
        stream.seek(max(0, size - 8192))
        data = stream.read()
        if size and not data.endswith(b"\n"):
            lines += 1
        tail = data.decode("utf-8", errors="replace").splitlines()[-8:]
    return {
        "File": str(path),
        "Bytes": size,
        "Lines": lines,
        "Tail": tail,
        "TailWindowBytes": 8192,
    }


def child_environment():
    environment = dict(
        os.environ,
        PYTHONUTF8="1",
        PYTHONIOENCODING="utf-8",
        PYTHONDONTWRITEBYTECODE="1",
    )
    # A working launcher must not pass another installation's import settings
    # into the isolated project runtime or into pip/venv.
    environment.pop("PYTHONHOME", None)
    environment.pop("PYTHONPATH", None)
    environment.pop("__PYVENV_LAUNCHER__", None)
    return environment


def runtime_snapshot(root):
    executable = runtime_python(root)
    config = executable.parent.parent / "pyvenv.cfg"
    result = {
        "Executable": str(executable),
        "Exists": executable.is_file(),
        "LauncherPython": sys.executable,
        "LauncherBasePython": getattr(sys, "_base_executable", None),
    }
    if config.is_file():
        text = config.read_text(encoding="utf-8-sig", errors="replace")
        result["PyvenvConfig"] = text[:16384]
        values = {
            key.strip(): value.strip()
            for key, value in (
                line.split("=", 1) for line in text.splitlines() if "=" in line
            )
        }
        home = values.get("home", "").strip()
        result.update(Home=home, HomePythonExists=(Path(home) / "python.exe").is_file())
    return result


def check_runtime(root, report):
    report["RuntimeSnapshot"] = runtime_snapshot(root)
    code = "import sys; assert sys.version_info >= (3, 12); print('RUNTIME-START-PASS', sys.executable)"
    run(
        [runtime_python(root), "-I", "-X", "utf8", "-B", "-c", code],
        root,
        report,
        "RUNTIME",
        "RUNTIME-START-PASS",
    )


def delivery_failures(path):
    """Read bounded unittest headers; preserve full exceptions in the local log."""
    if path.is_symlink() or getattr(path, "is_junction", lambda: False)():
        raise ValueError("DIAGNOSTIC_LINK")
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError("DIAGNOSTIC_SIZE")
    text = path.read_bytes().decode("utf-8", errors="replace")
    found = []
    for match in re.finditer(
        r"^(FAIL|ERROR): (test_[A-Za-z0-9_]+).*?$(.*?)(?=^={5}|\Z)", text, re.M | re.S
    ):
        kind, name, body = match.groups()
        exceptions = re.findall(
            r"^([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception))(?::|$)", body, re.M
        )
        found.append(
            {
                "Kind": kind,
                "Test": name,
                "Id": hashlib.sha256(name.encode("ascii")).hexdigest()[:8].upper(),
                "Exception": exceptions[-1] if exceptions else "Unknown",
            }
        )
    return found


def failure_tokens(rows, prefix):
    # At most four IDs per kind keep manual return codes bounded.
    tokens = ""
    for kind, letter in (("FAIL", "F"), ("ERROR", "E")):
        ids = sorted({row["Id"] for row in rows if row["Kind"] == kind})
        if ids:
            tokens += "-" + prefix + letter + ".".join(ids[:4])
    return tokens


def previous_delivery_diagnostic(report):
    path = TRANSFER / "U_SERIES_GUI_TRIAL_v0_8_0_REPORTS/UG12S-256099-7.err.txt"
    report["HistoricalDeliveryLog"] = str(path)
    report["HistoricalDeliveryFailures"] = []
    try:
        report["HistoricalDeliveryFailures"] = delivery_failures(path)
        report["HistoricalDeliveryRead"] = 1
    except FileNotFoundError:
        report["HistoricalDeliveryRead"] = 2
    except (OSError, ValueError) as error:
        report["HistoricalDeliveryRead"] = 3
        report["HistoricalDeliveryReadError"] = str(error)


def run(command, root, report, step, marker=None):
    report["Step"] = step
    sequence = len(report["Children"]) + 1
    prefix = report["ReportPath"].with_suffix("")
    out = Path(str(prefix) + f"-{sequence}.out.txt")
    err = Path(str(prefix) + f"-{sequence}.err.txt")
    item = {
        "Step": step,
        "Command": [str(part) for part in command],
        "Cwd": str(root),
        "RequiredMarker": marker,
    }
    report["Children"].append(item)
    print("[RUN] " + step + " - full stdout and stderr are saved locally.", flush=True)
    with out.open("wb") as stdout, err.open("wb") as stderr:
        try:
            result = subprocess.run(
                item["Command"],
                cwd=root,
                stdout=stdout,
                stderr=stderr,
                check=False,
                env=child_environment(),
                timeout=(
                    None
                    if step in ("GUI", "INSTALL", "TC001-SETUP")
                    else (30 if step == "RUNTIME" else 900)
                ),
            )
            item["ReturnCode"] = result.returncode
        except (KeyboardInterrupt, subprocess.TimeoutExpired) as error:
            item.update(
                ReturnCode=130 if isinstance(error, KeyboardInterrupt) else 124,
                StartError=str(error), StartException=type(error).__name__,
            )
        except OSError as error:
            item.update(ReturnCode=127, StartError=str(error), StartException=type(error).__name__)
    item.update(Stdout=stream_summary(out), Stderr=stream_summary(err))
    report["ChildReturnCode"] = item["ReturnCode"]
    if step == "DEPS":
        with out.open(encoding="utf-8", errors="replace") as stream:
            for line in stream:
                try:
                    value = json.loads(line)
                except ValueError:
                    continue
                if (
                    isinstance(value, dict)
                    and value.get("Kind") == "UG22_DEPENDENCY_AUDIT"
                ):
                    item["DependencyAudit"] = value
                    report["FailedDependencies"] = [
                        row["Module"].upper().replace("_", "")
                        for row in value["Checks"]
                        if row["Status"] != "PASS"
                    ]
    manifest = json.loads((PAYLOAD / "MANIFEST.json").read_text(encoding="utf-8"))
    item["Diagnostic"] = DIAGNOSTICS["summarize_child"](root, item, manifest)
    report["Diagnostic"] = DIAGNOSTICS["combine"](report["Children"])
    # Keep the existing test-ID contract, now covering every step and stream.
    for logfile in (out, err):
        try:
            report.setdefault("DeliveryTestFailures", []).extend(delivery_failures(logfile))
        except (OSError, ValueError) as error:
            report.setdefault("DeliveryDiagnosticReadErrors", []).append(str(error))
    if step == "WORKSPACE":
        workspace_path = (
            Path(str(report["ReportPath"].with_suffix("")) + "_workspace")
            / "workspace.json"
        )
        try:
            workspace = json.loads(workspace_path.read_text(encoding="utf-8"))
            item["WorkspaceAudit"] = workspace
            if not workspace.get("Passed"):
                raise DeliveryError(
                    workspace.get("FailureKind", "CONFIG"),
                    "Workspace controls failed.",
                    workspace.get("Issues", []),
                )
        except (OSError, ValueError) as error:
            raise DeliveryError(
                "RESULT", "Workspace report missing or invalid."
            ) from error
    if item["ReturnCode"] == 0 and (item["Diagnostic"]["UnhandledTraceback"]
            or any(row["Status"] != "OK" for row in item["Diagnostic"]["Reads"])):
        raise DeliveryError("TRACEBACK", step + " emitted an unhandled traceback or unreadable diagnostic evidence.")
    if item["ReturnCode"] != 0:
        if step in ("RUNTIME", "DEPS") and item["ReturnCode"] in (103, 106, 107):
            reason = {
                103: "VENV_BASE_PYTHON_MISSING",
                106: "VENV_CONFIG_MISSING",
                107: "VENV_CONFIG_INVALID",
            }[item["ReturnCode"]]
            report["RuntimeSnapshot"] = runtime_snapshot(root)
            raise DeliveryError(
                reason,
                "The project Python could not start; inspect RuntimeSnapshot and child stderr.",
                [{"Id": "F902", "Kind": reason}],
            )
        kind = (
            "CANCEL"
            if item["ReturnCode"] == 130 or step == "GUI" and item["ReturnCode"] == 20
            else "CHILD"
        )
        raise DeliveryError(kind, step + " did not complete successfully.")
    if marker:
        with out.open("rb") as stream:
            item["MarkerFound"] = any(marker.encode("ascii") in line for line in stream)
        if not item["MarkerFound"]:
            raise DeliveryError(
                "RESULT",
                step + " exited zero but its required success evidence is missing.",
            )
    print("[PASS] " + step)


def runtime_python(root):
    return root / "U-UDP003/01_PROGRAMS/u_series_gui_runtime_v0_7_0/Scripts/python.exe"


def identity(root):
    value = digest(PAYLOAD / "MANIFEST.json") + str(root.resolve())
    python = runtime_python(root)
    value += digest(python) if python.is_file() else "NO-RUNTIME"
    controls = [
        root / PROFILE,
        root
        / "U-UDP002/02_CONFIG/workbench_links/u002_workbench_link_local_default_v0_1.json",
        root
        / "U-UDP002/02_CONFIG/workbench_links/u002_workbench_link_local_user_v0_1.json",
    ]
    controls += sorted((root / "U-UDP002/00_CONTROL/registry").rglob("*.json"))
    for control in controls:
        value += str(control.relative_to(root)) + (
            digest(control) if control.is_file() else "MISSING"
        )
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def archive_previous(root, report):
    namespace = runpy.run_path(str(BUNDLE / "cleanup_transfer_v0_10_15.py"))
    try:
        namespace["archive_retired"](
            root, TRANSFER, BUNDLE, PAYLOAD / "MANIFEST.json", report
        )
    except (OSError, ValueError) as error:
        raise DeliveryError(
            "CLEANUP", str(error), [{"Id": "F906", "Kind": "CLEANUP"}]
        ) from error


def migrate_known_sources(root, report):
    """Back up exact known baselines before replacing any active core source."""
    rows = [row for row in report["Inventory"] if row["Kind"] == "UPGRADE"]
    report["Upgraded"] = []
    report["Step"] = "MIGRATE"
    pending = []
    for row in rows:
        target = child(root, row["Path"])
        before = target.read_bytes()
        if hashlib.sha256(before).hexdigest() != row["ActualSHA256"]:
            raise DeliveryError(
                "CONFLICT",
                "Source changed after audit.",
                [dict(row, Kind="CONFLICT", ActualSHA256=digest(target))],
            )
        backup = child(
            root,
            "U-UDP001/A-Archive/GUI_TRIAL_CORE_v0_10_15/"
            + report["ReportPath"].stem
            + "/"
            + row["Id"]
            + "-"
            + row["ActualSHA256"][:8]
            + ".bak",
        )
        backup.parent.mkdir(parents=True, exist_ok=True)
        with backup.open("xb") as stream:
            stream.write(before)
        if digest(backup) != row["ActualSHA256"]:
            raise DeliveryError(
                "IO", "Backup verification failed; active source is unchanged."
            )
        record = {
            "Id": row["Id"],
            "Path": row["Path"],
            "Backup": str(backup),
            "BeforeSHA256": row["ActualSHA256"],
            "AfterSHA256": row["ExpectedSHA256"],
            "Status": "BACKED_UP",
        }
        report["Upgraded"].append(record)
        pending.append((row, target, record))
        write_json(
            report["ReportPath"], dict(report, ReportPath=str(report["ReportPath"]))
        )
    for row, target, record in pending:
        if digest(target) != row["ActualSHA256"]:
            raise DeliveryError(
                "CONFLICT",
                "Source changed during migration.",
                [dict(row, Kind="CONFLICT", ActualSHA256=digest(target))],
            )
        source = payload_source(row["Path"])
        data = source.read_bytes()
        if hashlib.sha256(data).hexdigest() != row["ExpectedSHA256"]:
            raise DeliveryError("PACKAGE", "Payload changed after audit.")
        temporary = target.with_name(
            row["Id"] + "." + report["ReportPath"].stem + ".new"
        )
        with temporary.open("xb") as stream:
            stream.write(data)
        if digest(temporary) != row["ExpectedSHA256"]:
            raise DeliveryError(
                "IO", "New file verification failed; active source is unchanged."
            )
        temporary.replace(target)
        record["Status"] = "UPGRADED"
        write_json(
            report["ReportPath"], dict(report, ReportPath=str(report["ReportPath"]))
        )


def prepare(root, report):
    plan = audit(root, report)
    python = runtime_python(root)
    if not python.is_file():
        run(
            [sys.executable, "-I", "-m", "venv", python.parent.parent],
            root,
            report,
            "VENV",
        )
    # Establish a runnable environment before changing any installed source.
    check_runtime(root, report)
    run(
        [
            python,
            "-I",
            "-m",
            "pip",
            "install",
            "--only-binary=:all:",
            "--index-url",
            "https://pypi.org/simple",
            "-r",
            BUNDLE / "requirements_gui_trial_v0_10_15.txt",
        ],
        root,
        report,
        "INSTALL",
    )
    run(
        [python, "-I", "-X", "utf8", "-B", BUNDLE / "runtime_probe_v0_10_15.py"],
        root,
        report,
        "DEPS",
        "DEPENDENCIES-PASS",
    )
    migrate_known_sources(root, report)
    report["InstalledNew"] = 0
    report["InstalledSeed"] = 0
    seeds = {
        row["Path"] for row in report["Inventory"] if row["Section"] == "SeedFiles"
    }
    for source, target in plan:
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(source.read_bytes())
            report[
                (
                    "InstalledSeed"
                    if target.relative_to(root).as_posix() in seeds
                    else "InstalledNew"
                )
            ] += 1
    audit(root, report, installed=True)
    sample = runpy.run_path(str(BUNDLE / "sample_setup_v0_10_15.py"))
    sample["setup"](root)
    sample["verify_inputs"](root)
    previous_delivery_diagnostic(report)
    archive_previous(root, report)
    print("[READY] Runtime: " + str(python.parent.parent))


def selftest(root, report):
    audit(root, report, installed=True)
    python = runtime_python(root)
    if not python.is_file():
        raise DeliveryError(
            "MISSING",
            "Prepare must create the runtime first.",
            [{"Id": "F902", "Kind": "MISSING"}],
        )
    checks = [
        (
            "DEPS",
            [python, "-I", "-X", "utf8", "-B", BUNDLE / "runtime_probe_v0_10_15.py"],
            "DEPENDENCIES-PASS",
        ),
        (
            "WORKSPACE",
            [
                python,
                "-B",
                BUNDLE / "workspace_check_v0_10_15.py",
                "--root",
                root,
                "--manifest",
                PAYLOAD / "MANIFEST.json",
                "--output",
                Path(str(report["ReportPath"].with_suffix("")) + "_workspace"),
            ],
            "WORKSPACE-READY-PASS",
        ),
        (
            "U001",
            [python, "-B", root / ENTRIES["U001"], "--self-test"],
            "U1G2-GUI-SELFTEST-PASS",
        ),
        (
            "HANDOFF",
            [
                python,
                "-B",
                root / "U-UDP002/01_PROGRAMS/gui/u002_current_run_handoff_v0_1_1.py",
            ],
            "U002-HANDOFF-BOUNDARY-SELFTEST-PASS",
        ),
        (
            "U003",
            [python, "-B", root / ENTRIES["U003"], "--self-test"],
            "U003-V0220-SELFTEST-PASS",
        ),
        (
            "REGRESSION",
            [python, "-B", BUNDLE / "verify_gui_trial_v0_10_15.py", "--root", root],
            "GUI-REPAIRS-REGRESSION-PASS",
        ),
        (
            "DELIVERY",
            [python, "-B", BUNDLE / "verify_delivery_files_v0_10_15.py"],
            "UG22-DELIVERY-TESTS-PASS",
        ),
    ]
    checks.append(("DIAGNOSTICS", [python, "-B", BUNDLE / "verify_failure_diagnostics_v0_1.py"], "FAILURE-DIAGNOSTICS-PASS"))
    checks.append(("SAMPLE", [python, "-B", BUNDLE / "sample_setup_v0_10_15.py", "--root", root], "SAMPLE-INPUTS-PASS-60"))
    for step, command, marker in checks:
        run(command, root, report, step, marker)
    report["SelftestPassed"] = True
    report["Identity"] = identity(root)


def verified_selftest(root, report):
    audit(root, report, installed=True)
    pointer = report["ReportPath"].parent / "LATEST_SELFTEST.json"
    try:
        previous = json.loads(pointer.read_text(encoding="utf-8"))
        if not isinstance(previous, dict):
            raise ValueError("Invalid selftest pointer type.")
        receipt_path = Path(previous.get("Receipt", ""))
        if (
            receipt_path.is_symlink()
            or receipt_path.resolve().parent != pointer.parent.resolve()
        ):
            raise ValueError(
                "Selftest receipt must be in the current report directory."
            )
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        if (
            not isinstance(receipt, dict)
            or not isinstance(receipt.get("Children"), list)
            or not all(isinstance(item, dict) for item in receipt["Children"])
        ):
            raise ValueError("Invalid selftest receipt schema.")
    except (OSError, ValueError):
        previous = {}
        receipt = {}
    children = receipt.get("Children", [])
    complete = (
        receipt.get("Status") == "C0"
        and receipt.get("SelftestPassed") is True
        and receipt.get("Identity") == identity(root)
        and [item.get("Step") for item in children]
        == ["DEPS", "WORKSPACE", "U001", "HANDOFF", "U003", "REGRESSION", "DELIVERY", "DIAGNOSTICS", "SAMPLE"]
        and all(
            item.get("ReturnCode") == 0 and item.get("MarkerFound") is True
            for item in children
        )
    )
    if (
        previous.get("Status") != "C0"
        or previous.get("Identity") != identity(root)
        or not complete
    ):
        raise DeliveryError(
            "SELFTEST",
            "A successful selftest for this exact package/root/runtime is required.",
            [{"Id": "F903", "Kind": "SELFTEST"}],
        )
    report["SelftestReceipt"] = previous


def execute(root, report, tc001=False):
    verified_selftest(root, report)
    run(
        [runtime_python(root), "-I", "-X", "utf8", "-B", BUNDLE / "runtime_probe_v0_10_15.py"],
        root,
        report,
        "DEPS",
        "DEPENDENCIES-PASS",
    )
    if tc001:
        run([runtime_python(root), "-I", "-X", "utf8", "-B", BUNDLE / "tc001_setup_v0_1.py", "--root", root, "--select-inputs"],
            root, report, "TC001-SETUP")
        summary = root / "U-UDP001/03_CASES/TC001_20260422/CONTROL/GUI_v0_10_9/preparation.json"
        if summary.is_file():
            print(summary.read_text(encoding="utf-8"), flush=True)
        print("[TC001] Opening editable setup. Configuration preparation is not data acceptance.", flush=True)
        command = [runtime_python(root), "-I", "-X", "utf8", "-B", BUNDLE / "tc001_setup_v0_1.py", "--root", root, "--open"]
    else:
        command = [runtime_python(root), "-I", "-X", "utf8", "-B", __file__, "choose"]
    run(command, root, report, "GUI", "GUI-ENTRY-RETURNED")
    report["LaunchCompleted"] = True


def choose(root):
    # Bind dependencies in this isolated GUI process before legacy GUI code
    # inserts fvr_vendor. Its later imports reuse these verified packages.
    dependencies = runpy.run_path(str(BUNDLE / "runtime_probe_v0_10_15.py"))[
        "inspect_runtime"
    ](probe_window=False)
    if not dependencies["Passed"]:
        print(json.dumps(dependencies))
        return 7
    import tkinter as tk
    from tkinter import ttk, messagebox

    selected = []
    window = tk.Tk()
    window.title("U-Series GUI Trial 0.10.15")
    window.geometry("540x300")
    ttk.Label(
        window,
        text="SAMPLE 0.10.15: open U001 and Run I0-I5. Choose Open U002 for analysis or Open U003 for source review; the current data loads automatically. Keep U001 open.",
        wraplength=410,
    ).pack(padx=18, pady=18)

    sample = runpy.run_path(str(BUNDLE / "sample_setup_v0_10_15.py"))
    sample_config = {}

    def select(program):
        try:
            if program == "U001":
                sample_config["U001"] = sample["setup"](root)
            elif program == "U002":
                sample_config["U002"] = sample["u002_configuration"](root)
            else:
                messagebox.showinfo("SAMPLE U003", "Open U003 from the U002 window after Execute succeeds. This passes the current Run's verified candidates and Review Data.", parent=window)
                return
        except Exception as error:
            messagebox.showerror("SAMPLE next step", str(error), parent=window)
            return
        selected.append(program)
        window.destroy()

    for program in ENTRIES:
        ttk.Button(
            window, text="Open " + program, command=lambda value=program: select(value)
        ).pack(fill="x", padx=30, pady=5)
    window.mainloop()
    if not selected:
        return 20
    program = selected[0]
    entry = root / ENTRIES[program]
    sys.path.insert(0, str(entry.parent))
    os.environ["U003_WORKSPACE"] = str(root / "U-UDP003/07_OUTPUT/SAMPLE_v0_10_7")
    sys.argv = [str(entry)]
    if program == "U001":
        sys.argv += ["--gui", "--profile", str(sample_config["U001"])]
    elif program == "U002":
        sys.argv += ["--workspace-root", str(root / "U-UDP002"), "--run-config", str(sample_config["U002"])]
    else:
        os.environ["U003_WORKSPACE"] = str(root / "U-UDP003/07_OUTPUT/GUI_TRIAL_LOCAL")
        sys.argv += ["--language", "EN"]
    try:
        runpy.run_path(str(entry), run_name="__main__")
    except SystemExit as error:
        if error.code not in (None, 0):
            raise
    print("GUI-ENTRY-RETURNED " + program)
    return 0


def diagnose(root, report):
    value = DIAGNOSTICS["historical_failure"](root, report.get("RequestedReport"))
    report.update(value, Kind="ORIGINAL_FAILURE", Step="DIAGNOSIS", Status="C7")
    report["DeliveryTestFailures"] = value["Diagnostic"]["Tests"]
    report["DiagnosticReadSucceeded"] = True
    report["BusinessAcceptanceChanged"] = False


def capsules(report):
    prefix = "UG22" + PHASE[report["Action"]]
    if report["Status"] == "C0":
        if report["Action"] == "prepare":
            count, new = report["ManagedFiles"], report["InstalledNew"]
            upgraded = len(report.get("Upgraded", []))
            fields = f"PF{count}-NI{new}-NU{upgraded}-NK{count-new-upgraded}-DI{report['InstalledSeed']}-AR{len(report['Archived'])}-AK{len(report.get('CleanupSkipped', []))}"
            fields += "-HD" + str(report.get("HistoricalDeliveryRead", 0))
            fields += failure_tokens(report.get("HistoricalDeliveryFailures", []), "H")
        elif report["Action"] == "selftest":
            fields = f"PF{report['ManagedFiles']}-NT{len(report['Children'])}-ST1"
        else:
            fields = "ST1-LA1"
        return [f"{prefix}_{fields}_X0-C0"]
    issues = report.get("Issues", [])
    conflicts = [item for item in issues if item.get("Kind") == "CONFLICT"]
    missing = [item for item in issues if item.get("Kind") == "MISSING"]
    main = f"{prefix}_K{report['Kind']}-SG-{report['Step']}-CF{len(conflicts)}-MS{len(missing)}_X{report['Unexpected']}-C7"
    first = issues[0] if issues else {"Id": "F000"}
    rc = report.get("ChildReturnCode", 0)
    detail = first["Id"] + "-RC" + (str(rc) if rc >= 0 else "M" + str(-rc))
    if conflicts and first.get("Kind") == "CONFLICT":
        detail += (
            "-EH"
            + first.get("ExpectedSHA256", "NA")[:8].upper()
            + "-AH"
            + first.get("ActualSHA256", "NA")[:8].upper()
        )
    if len(issues) > 1:
        detail += "-LI" + ".".join(item["Id"][1:] for item in issues[:12])
    if report.get("FailedDependencies"):
        detail += "-DP" + ".".join(report["FailedDependencies"])
    detail += DIAGNOSTICS["short_tokens"](report.get("Diagnostic", {}))
    detail += failure_tokens(report.get("DeliveryTestFailures", []), "T")
    return [main, "UG22D_" + detail + "_LOG-" + report["ReportPath"].name]


def cli(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=[*PHASE, "choose"])
    parser.add_argument("--report", help="Existing failed report basename; diagnose only")
    args = parser.parse_args(argv)
    action = args.action
    if args.report and action != "diagnose":
        parser.error("--report is only valid with diagnose")
    if action == "choose":
        require_runtime()
        return choose(workspace_root())
    phase = PHASE[action]
    report = {
        "Version": VERSION,
        "Action": action,
        "RequestedReport": args.report,
        "Status": "C7",
        "Unexpected": 0,
        "Step": "INIT",
        "Children": [],
        "Issues": [],
    }
    try:
        directory = child(TRANSFER, REPORTS)
        directory.mkdir(exist_ok=True)
        report["ReportPath"] = directory / (
            "UG22" + phase + "-" + uuid.uuid4().hex[:6].upper() + ".json"
        )
        write_json(report["ReportPath"], {"Status": "STARTED", "Action": action})
        if action in ("prepare", "selftest"):
            write_json(
                directory / "LATEST_SELFTEST.json",
                {"Status": "PENDING", "Action": action},
            )
        if action != "diagnose":
            require_runtime()
        root = workspace_root()
        report.update(
            Root=str(root),
            Python=sys.version,
            PythonExecutable=sys.executable,
            Step="AUDIT",
        )
        print("[ROOT] " + str(root))
        print("[REPORT] " + str(report["ReportPath"]))
        {"prepare": prepare, "selftest": selftest, "execute": execute, "diagnose": diagnose, "tc001": lambda root, report: execute(root, report, tc001=True)}[action](
            root, report
        )
        if action != "diagnose":
            report["Status"] = "C0"
    except (Exception, KeyboardInterrupt) as error:
        kind = (
            error.kind
            if isinstance(error, DeliveryError)
            else ("CANCEL" if isinstance(error, KeyboardInterrupt) else "UNEXPECTED")
        )
        if isinstance(error, OSError):
            kind = "LOCK" if getattr(error, "winerror", None) in (32, 33) else "IO"
        report.update(
            Kind=kind,
            Unexpected=int(kind == "UNEXPECTED"),
            Error=str(error),
            Traceback=traceback.format_exc(),
        )
        if isinstance(error, DeliveryError) and error.issues:
            report["Issues"] = error.issues
        if report.get("Root") and action != "diagnose":
            root = Path(report["Root"])
            snapshot = {
                "RootWritableHint": os.access(root, os.W_OK),
                "TransferWritableHint": os.access(TRANSFER, os.W_OK),
                "RuntimeExists": runtime_python(root).is_file(),
                "EntryExists": {
                    key: (root / value).is_file() for key, value in ENTRIES.items()
                },
                "LockAssessment": "Only an actual OS sharing/lock error confirms a lock; writability hints do not rule one out.",
            }
            try:
                audit(root, snapshot, installed=action != "prepare")
            except Exception as audit_error:
                snapshot["AuditError"] = str(audit_error)
            report["FailureSnapshot"] = snapshot
    if "ReportPath" not in report:
        print(f"UG22{phase}_KREPORT-SG-INIT-CF0-MS0_X1-C7\nUG22D_F000-RC0_LOG-NONE")
        return 7
    if report["Status"] != "C0":
        diagnostic = report.setdefault("Diagnostic", {"Errors": [], "Tests": [], "Reads": []})
        if not diagnostic.get("Errors") and report.get("Traceback"):
            try:
                manifest = json.loads((PAYLOAD / "MANIFEST.json").read_text(encoding="utf-8"))
                diagnostic["Errors"] = DIAGNOSTICS["parse_text"](report["Traceback"], manifest)["Errors"]
            except (OSError, ValueError):
                diagnostic["Reads"].append({"Status": "MANIFEST"})
        report["Memo"] = DIAGNOSTICS["safe_memo"](report.get("Error", "Original failure retained; see root exception fields."))
    lines = capsules(report)
    report["Capsules"] = lines
    try:
        serializable = dict(report, ReportPath=str(report["ReportPath"]))
        write_json(report["ReportPath"], serializable)
        if action == "selftest":
            write_json(
                report["ReportPath"].parent / "LATEST_SELFTEST.json",
                {
                    "Status": report["Status"],
                    "Identity": report.get("Identity"),
                    "Receipt": str(report["ReportPath"]),
                },
            )
    except OSError:
        print(f"UG22{phase}_KREPORT-SG-SAVE-CF0-MS0_X1-C7\nUG22D_F000-RC0_LOG-NONE")
        return 7
    if report["Status"] != "C0":
        print("\n--- COPY ERROR DETAILS AND MACHINE CODES BELOW ---", flush=True)
        print("Step: " + str(report.get("Step")) + " | " + str(report.get("Error")), flush=True)
        for item in report.get("Children", []):
            if item.get("ReturnCode") == 0 and item.get("MarkerFound", True):
                continue
            print("Child: " + item["Step"] + " | return code " + str(item.get("ReturnCode")), flush=True)
            for stream_name in ("Stdout", "Stderr"):
                logfile = item.get(stream_name, {}).get("File")
                if logfile and Path(logfile).is_file():
                    from collections import deque
                    with Path(logfile).open(encoding="utf-8", errors="replace") as stream:
                        tail = deque(stream, maxlen=80)
                    print("[" + stream_name + "] " + logfile, flush=True)
                    print("".join(tail), flush=True)
        print(report.get("Traceback", ""), flush=True)
    print("\n".join(lines))
    return 0 if report["Status"] == "C0" else 7


if __name__ == "__main__":
    raise SystemExit(cli())
