"""Build the complete Windows folder offline from the verified source bundle."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import platform
import runpy
import shutil
import subprocess
import sys
import traceback
import uuid
sys.path.insert(0, str(Path(__file__).resolve().parent))
from onedir_runtime_v0_1 import collect_runtime

HERE = Path(__file__).resolve().parent
VERSION = '0.10.15'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def assemble_product(destination, bundle):
    payload = bundle / 'U_SERIES_GUI_TRIAL_v0_10_15_payload'
    manifest = json.loads((payload / 'MANIFEST.json').read_text(encoding='utf-8'))
    destination.mkdir(parents=True)
    for row in manifest['Files'] + manifest['SeedFiles']:
        source = payload / row['Path']
        if sha(source) != row['SHA256']:
            raise ValueError('Source identity changed: ' + row['Path'])
        target = destination / 'product' / row['Path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    # The default profile is synthetic; no profile from the company workspace is read.
    template = destination / 'product/U-UDP002/02_CONFIG/gui_profiles/SAMPLE_v0_10_7/profile_template.json'
    profile = json.loads(template.read_text(encoding='utf-8'))
    profile.update(ContractId='U002_GUI_RUN_PROFILE', ProfileId='PORTABLE_SAMPLE', ProfileVersion='0.1.0',
                   DisplayName='Synthetic SAMPLE', InputPackage='', RunPurpose='SMOKE', RunScope='FRAME_RANGE',
                   FrameStart=0, FrameEnd=59, PostRun={'Action': 'PROMPT_U003', 'ReviewArtifactType': 'U003_REVIEW_PACKAGE'},
                   RunIdPolicy={'Mode': 'USER_CONFIRMED', 'SuggestedPrefix': 'SAMPLE_U002_0107'})
    write(destination / 'product/U-UDP002/02_CONFIG/gui_profiles/u002_radar_loss_golden_reference_v0_1.json', profile)
    support = destination / 'support'
    support.mkdir()
    for name in ('sample_setup_v0_10_15.py', 'workspace_check_v0_10_15.py', 'runtime_probe_v0_10_15.py', 'onedir_launcher_v0_1.py'):
        shutil.copyfile(bundle / name, support / name)
    write(support / 'product_manifest.json', manifest)
    write(support / 'U_SERIES_GUI_TRIAL_v0_10_15_payload/MANIFEST.json', manifest)
    shutil.copyfile(bundle / 'ONEDIR_GUIDE_JA.txt', destination / 'START_HERE_JA.txt')
    shutil.copyfile(bundle / 'PROFILE_ZIP_CONVENTION.md', destination / 'PROFILE_ZIP_CONVENTION.md')
    write(destination / 'profiles/SAMPLE.json', {
        'ProfileId': 'SAMPLE', 'ProfileVersion': '0.1.0', 'RequiredBaseVersion': VERSION,
        'Inputs': 'Only declared synthetic SAMPLE CAN, DBC and video in product/',
        'CompanyData': False, 'HumanReview': 'NOT_PERFORMED',
    })
    # Only immutable program files are checked on reuse; generated/editable seed configs remain editable.
    write(destination / 'PACKAGE_MANIFEST.json', {
        'PackageVersion': VERSION, 'Platform': 'Windows-x64', 'ContractVersion': manifest['ContractVersion'],
        'FixedProductFiles': manifest['Files'], 'DefaultProfile': 'SAMPLE', 'WindowsGUI': 'PENDING',
    })
    return manifest

def make_launchers(destination):
    from pip._vendor.distlib.scripts import ScriptMaker
    maker = ScriptMaker(None, str(destination))
    maker.variants = {''}
    maker.executable = r'<launcher_dir>\runtime\python.exe'
    # gui=True changes python.exe to pythonw.exe once. Supplying pythonw would produce pythonww.
    # The bootstrap imports only this folder's support.
    maker.script_template = '''import sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[0]).resolve().parent / "support"))
from onedir_launcher_v0_1 import main
if __name__ == "__main__":
    sys.exit(main())
'''
    for program in ('U001', 'U002', 'U003'):
        maker.make(program + ' = onedir_launcher_v0_1:main', options={'gui': True, 'interpreter_args': ['-I', '-X', 'utf8', '-B']})
        if not (destination / (program + '.exe')).is_file():
            raise RuntimeError('Native launcher not generated: ' + program)
        expected = b'#!<launcher_dir>\\runtime\\pythonw.exe -I -X utf8 -B\n'
        if (destination / (program + '.exe')).read_bytes().count(expected) != 1:
            raise RuntimeError('Generated launcher interpreter differs from bundled pythonw.exe: ' + program)
    shutil.copyfile(HERE / 'DISTLIB_LICENSE.txt', destination / 'DISTLIB_LICENSE.txt')

def show_log(path):
    print('[LOG] ' + str(path), flush=True)
    with path.open('rb') as stream:
        stream.seek(max(0, path.stat().st_size - 6000))
        lines = stream.read().decode('utf-8', errors='replace').splitlines()
    print('\n'.join(lines[-24:]) or '(process produced no console output)', flush=True)

def run_logged(command, cwd, report, log_dir, step, timeout=120):
    report['Step'] = step
    log = log_dir / (step + '.log')
    child = {'Step': step, 'Command': [str(item) for item in command], 'Log': str(log)}
    report['Checks'].append(child)
    print('[RUN] ' + step, flush=True)
    with log.open('wb') as stream:
        try:
            result = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
        except Exception as error:
            child['Error'] = type(error).__name__ + ': ' + str(error)
            stream.write(traceback.format_exc().encode('utf-8'))
            raise
    child['ReturnCode'] = result.returncode
    child['ReturnCodeHex'] = '0x%08X' % (result.returncode & 0xffffffff)
    if result.returncode:
        print('[FAIL] %s RC=%s (%s)' % (step, result.returncode, child['ReturnCodeHex']), flush=True)
        show_log(log)
    else:
        print('[PASS] ' + step, flush=True)
    return child


def package(root):
    if sys.platform != 'win32':
        raise RuntimeError('PACKAGE_REQUIRES_WINDOWS: run the package command on the Windows build computer.')
    if platform.machine().upper() not in ('AMD64', 'X86_64'):
        raise RuntimeError('PACKAGE_REQUIRES_WINDOWS_X64')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '_' + uuid.uuid4().hex[:6]
    batch = root / 'U_SERIES_DELIVERY' / stamp
    output = batch / ('U-Series_' + VERSION)
    batch.mkdir(parents=True)
    log_dir = batch / 'logs'
    log_dir.mkdir()
    report = {'Version': VERSION, 'Status': 'C7', 'WindowsGUI': 'PENDING', 'Output': str(output),
              'LogDirectory': str(log_dir), 'Checks': [], 'Step': 'ASSEMBLE'}
    print('[LOGS] ' + str(log_dir), flush=True)
    try:
        assemble_product(output, HERE)
        report['Step'] = 'RUNTIME_COPY'
        report['Runtime'] = collect_runtime(output / 'runtime')
        report['Step'] = 'CREATE_LAUNCHERS'
        make_launchers(output)
        (output / 'logs').mkdir(exist_ok=True)
        checks = []
        for program in ('U001', 'U002', 'U003'):
            check = batch / (program + '_native_check.json')
            child = run_logged([str(output / (program + '.exe')), '--package-check', str(check)],
                               output, report, log_dir, 'NATIVE_' + program)
            if child['ReturnCode'] or not check.is_file():
                # Reveal Python/bootstrap errors without treating a console run as native acceptance.
                try:
                    run_logged([str(output / 'runtime/python.exe'), '-I', '-X', 'utf8', '-B',
                                str(output / (program + '.exe')), '--package-check', str(batch / (program + '_diagnostic.json'))],
                               output, report, log_dir, 'CONSOLE_DIAGNOSTIC_' + program)
                except Exception as diagnostic_error:
                    print('[DIAGNOSTIC] ' + str(diagnostic_error), flush=True)
                for path in sorted((output / 'logs').glob(program + '_*.log'))[-2:]:
                    show_log(path)
                report['Step'] = 'NATIVE_' + program
                raise RuntimeError('%s native startup RC=%s (%s); check report exists=%s; logs: %s' %
                                   (program, child['ReturnCode'], child['ReturnCodeHex'], check.is_file(), log_dir))
            data = json.loads(check.read_text(encoding='utf-8'))
            if data.get('Status') != 'PASS' or data.get('Program') != program:
                raise RuntimeError(program + ' native startup report did not match')
            checks.append(data)
        # Qualify a disposable copy; the deliverable remains a clean, unopened workspace template.
        validation = batch / 'validation/C-Code'
        shutil.copytree(output / 'product', validation,
                        ignore=lambda _, names: [name for name in names if name.casefold() == 'desktop.ini'])
        child = run_logged([str(output / 'runtime/python.exe'), '-I', '-X', 'utf8', '-B',
            str(output / 'support/workspace_check_v0_10_15.py'), '--root', str(validation),
            '--manifest', str(output / 'support/product_manifest.json'), '--output', str(batch / 'validation/qualification')],
            validation, report, log_dir, 'QUALIFICATION', timeout=600)
        if child['ReturnCode']:
            raise RuntimeError('Bundled module qualification RC=%s; see %s' % (child['ReturnCode'], child['Log']))
        shutil.move(str(output / 'logs'), str(batch / 'native_startup_logs'))
        rows = [{'Path': p.relative_to(output).as_posix(), 'Bytes': p.stat().st_size, 'SHA256': sha(p)}
                for p in sorted(output.rglob('*')) if p.is_file()]
        write(output / 'DELIVERY_FILES.json', {'Version': VERSION, 'Files': rows, 'WindowsNativeChecks': 'PASS', 'WindowsGUI': 'PENDING'})
        report.update(Status='C0', Step='COMPLETE', NativeLaunchers=checks, Files=len(rows))
        print('UGPK_EXE3-RUNTIME1-SAMPLE1_GUI_PENDING_C0', flush=True)
        print('OUTPUT=' + str(output), flush=True)
    except Exception as error:
        report['FirstFailure'] = type(error).__name__ + ': ' + str(error)
        (batch / 'failure.log').write_text(traceback.format_exc(), encoding='utf-8')
        print('UGPK_C7 STEP=' + report['Step'] + ' ' + report['FirstFailure'], flush=True)
        show_log(batch / 'failure.log')
    finally:
        write(batch / 'package_report.json', report)
        print('REPORT=' + str(batch / 'package_report.json'), flush=True)
    return 0 if report['Status'] == 'C0' else 7

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    args = parser.parse_args()
    try:
        raise SystemExit(package(args.root.resolve()))
    except Exception as error:
        print('UGPK_C7 ' + str(error), flush=True)
        raise SystemExit(7)
