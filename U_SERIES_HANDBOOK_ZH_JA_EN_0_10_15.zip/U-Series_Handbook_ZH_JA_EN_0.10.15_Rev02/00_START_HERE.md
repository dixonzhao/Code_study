# U-Series Handbook 0.10.15 — Detailed revision 02

## 中文

先阅读 `ZH/U-Series_Handbook_ZH_0.10.15.pdf`（71 页），同目录提供可编辑 Word。第 8、10、11 章包含 U001、U002、U003 的新版架构图；单独的三图 PDF 位于 `DIAGRAMS/U-Series_Architecture_ZH_0.10.15.pdf`。

本包包含中文、日文及英文手册。Profile 生成与故障诊断的专用提示词、需求表提供日文和英文版本；中文操作与维护说明参见手册第 15–22 章。`DIAGNOSTICS/` 中的共享英文技术资料可交给接收方配置的 Agent 阅读。

## 日本語

詳細版：82 ページ。第 8・10・11 章に、現行実装に合わせて再作成した U001・U002・U003 の構成図を収録しました。各ステージの入出力、Module の設定・成果物、操作例、障害診断を説明します。構成図だけの PDF は `DIAGRAMS/U-Series_Architecture_JA_0.10.15.pdf` です。

`JA/U-Series_Handbook_JA_0.10.15.pdf` から始めてください。編集用 Word ファイルも同じフォルダーにあります。初めての利用者は第 3～5 章、詳しい操作は第 6～14 章、Profile と拡張は第 15～19 章を参照します。

**障害時は、元の開発者への連絡を前提にしません。** `JA/INCIDENT_FORM.md` に記録し、`JA/AI_DIAGNOSTIC_PROMPT.md` を設定済みの Claude Opus 5 Agent に渡してください。最初は `DIAGNOSTICS/AI_DIAGNOSTIC_KNOWLEDGE_0.10.15.txt` を添付すれば診断ガイドと索引をまとめて渡せます。共有の `DIAGNOSTICS/` には、AI が読む英語の診断ガイド、コード索引、バージョンに対応する参照ソースがあります。Agent は日本語で回答するよう指定されています。保守上の判断は引継ぎ先の担当者が行います。

新しい Profile の作成には、`JA/AI_PROFILE_GUIDE.md`、`JA/02_PROFILE_INPUT_FORM.md`、`JA/03_AGENT_PROMPT.md` と `AI_REFERENCE/` を使用します。

## English

Detailed edition: 71 pages. Chapters 8, 10 and 11 include redrawn U001, U002 and U003 architecture diagrams matching the current implementation. The handbook explains stage inputs/outputs, Module configuration and artifacts, operating examples and diagnosis. Standalone diagrams: `DIAGRAMS/U-Series_Architecture_EN_0.10.15.pdf`.

Start with `EN/U-Series_Handbook_EN_0.10.15.pdf`. An editable Word file is in the same folder. Chapters 3–5 cover first use, 6–14 detailed operation, and 15–19 Profiles and extension.

**Incident handling does not depend on contacting the original developer.** Complete `EN/INCIDENT_FORM.md` and give `EN/AI_DIAGNOSTIC_PROMPT.md` to the configured Claude Opus 5 Agent. Start by attaching `DIAGNOSTICS/AI_DIAGNOSTIC_KNOWLEDGE_0.10.15.txt`, which combines the guide and indexes. Shared `DIAGNOSTICS/` contains the AI diagnosis guide, code index and matching read-only implementation references. The receiving maintainer owns maintenance decisions.

For a new Profile, use `EN/AI_PROFILE_GUIDE.md`, `EN/02_PROFILE_INPUT_FORM.md`, `EN/03_AGENT_PROMPT.md` and `AI_REFERENCE/`.

## Package scope

This is documentation and AI reference material for U-Series 0.10.15. It does not install or update the program, runtime or a business Profile. `DIAGNOSTICS/READ_ONLY_SOURCES/` must not be executed or copied into an installation as a repair. The historical structural reference PDF and private development records are not included. The Chinese handbook is included with the Japanese and English editions.
