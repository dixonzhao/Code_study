#!/usr/bin/env python3
"""Interactive multi-region screenshot masking Module for U003."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROFILE_ID = "U003_FRAME_MASK_PROFILE"
PROFILE_VERSION = "0.1"
ACTION_ID = "CREATE_MASKED_SCREENSHOT"


@dataclass(frozen=True)
class NormalizedRectangle:
    """Resolution-independent rectangle using values from 0.0 through 1.0."""

    x0: float
    y0: float
    x1: float
    y1: float

    def normalized(self) -> "NormalizedRectangle":
        left, right = sorted((max(0.0, min(1.0, self.x0)), max(0.0, min(1.0, self.x1))))
        top, bottom = sorted((max(0.0, min(1.0, self.y0)), max(0.0, min(1.0, self.y1))))
        if right - left <= 0.0001 or bottom - top <= 0.0001:
            raise ValueError("Mask rectangle is too small.")
        return NormalizedRectangle(left, top, right, bottom)

    def to_payload(self) -> dict[str, float]:
        value = self.normalized()
        return {"X0": value.x0, "Y0": value.y0, "X1": value.x1, "Y1": value.y1}

    @classmethod
    def from_payload(cls, value: Any) -> "NormalizedRectangle":
        if not isinstance(value, dict):
            raise ValueError("Rectangle must be one JSON object.")
        return cls(
            float(value["X0"]),
            float(value["Y0"]),
            float(value["X1"]),
            float(value["Y1"]),
        ).normalized()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def read_json_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON file must contain one object: {path}")
    return value


def write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for index in range(1, 1000):
        candidate = path.with_name(f"{path.stem}_{index:03d}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError("No free output suffix remains from _001 to _999.")


def profile_payload(
    profile_name: str,
    rectangles: list[NormalizedRectangle],
    source_width: int,
    source_height: int,
) -> dict[str, Any]:
    return {
        "ProfileId": PROFILE_ID,
        "ProfileVersion": PROFILE_VERSION,
        "ProfileName": profile_name.strip() or "U003 Frame Mask",
        "CoordinateSystem": "NORMALIZED_IMAGE_XY",
        "ReferenceImageWidth": int(source_width),
        "ReferenceImageHeight": int(source_height),
        "Rectangles": [rectangle.to_payload() for rectangle in rectangles],
        "SavedUtc": utc_now(),
    }


def read_profile(path: Path) -> tuple[str, list[NormalizedRectangle]]:
    payload = read_json_object(path)
    if payload.get("ProfileId") != PROFILE_ID:
        raise RuntimeError("Selected JSON is not a U003 Frame Mask Profile.")
    if payload.get("ProfileVersion") != PROFILE_VERSION:
        raise RuntimeError("Frame Mask Profile version is not accepted.")
    raw_rectangles = payload.get("Rectangles")
    if not isinstance(raw_rectangles, list):
        raise RuntimeError("Profile Rectangles must be an array.")
    rectangles = [NormalizedRectangle.from_payload(item) for item in raw_rectangles]
    return str(payload.get("ProfileName", "U003 Frame Mask")), rectangles


def apply_black_masks(image: Any, rectangles: list[NormalizedRectangle]) -> Any:
    """Return a copy with only the declared rectangles changed to black."""

    result = image.copy()
    height, width = result.shape[:2]
    for rectangle in rectangles:
        value = rectangle.normalized()
        x0 = max(0, min(width - 1, int(round(value.x0 * width))))
        y0 = max(0, min(height - 1, int(round(value.y0 * height))))
        x1 = max(x0 + 1, min(width, int(round(value.x1 * width))))
        y1 = max(y0 + 1, min(height, int(round(value.y1 * height))))
        result[y0:y1, x0:x1] = 0
    return result


def load_rgb_image(path: Path) -> Any:
    """Load through Pillow when available, otherwise use the existing OpenCV host."""

    try:
        import numpy as np
        from PIL import Image

        with Image.open(path) as source:
            return np.array(source.convert("RGB"), copy=True)
    except ImportError:
        import cv2

        bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if bgr is None:
            raise RuntimeError(f"Image could not be read: {path}")
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def write_rgb_image(path: Path, image: Any) -> None:
    """Write RGB image data without requiring one particular image library."""

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image

        Image.fromarray(image).save(path)
        return
    except ImportError:
        import cv2

        bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        if not cv2.imwrite(str(path), bgr):
            raise RuntimeError(f"Image could not be written: {path}")


def resize_rgb(image: Any, width: int, height: int) -> Any:
    """Resize RGB data through Pillow or the company OpenCV environment."""

    try:
        import numpy as np
        from PIL import Image

        source = Image.fromarray(image)
        resampling = Image.Resampling.LANCZOS if width < image.shape[1] else Image.Resampling.BILINEAR
        return np.array(source.resize((width, height), resampling), copy=True)
    except ImportError:
        import cv2

        interpolation = cv2.INTER_AREA if width < image.shape[1] else cv2.INTER_LINEAR
        return cv2.resize(image, (width, height), interpolation=interpolation)


class MaskEditor:
    """Small child-process GUI for drawing, reviewing, and persisting masks."""

    def __init__(
        self,
        image: Any,
        language: str,
        profile_directory: Path,
        output_directory: Path,
        framecount: int,
        source_path: Path,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.image = image
        self.language = language.upper()
        self.profile_directory = profile_directory
        self.output_directory = output_directory
        self.framecount = framecount
        self.source_path = source_path
        self.rectangles: list[NormalizedRectangle] = []
        self.selected_index: int | None = None
        self.drag_start: tuple[float, float] | None = None
        self.drag_item: int | None = None
        self.photo = None
        self.image_box = (0.0, 0.0, 1.0, 1.0)
        self.export_result: dict[str, Any] | None = None
        self.current_profile_path: Path | None = None

        self.root = tk.Tk()
        self.root.title(self._text("U003 Frame Privacy Mask", "U003 フレーム匿名化マスク"))
        self.root.geometry("1260x820")
        self.root.minsize(900, 620)
        self.root.protocol("WM_DELETE_WINDOW", self.root.destroy)

        self.profile_name_var = tk.StringVar(value="U003 Frame Mask")
        self.status_var = tk.StringVar(
            value=self._text(
                "Drag on the image to add a black-mask region.",
                "画像上をドラッグして黒塗り領域を追加してください。",
            )
        )
        self._build_ui()
        self._load_last_profile_if_available()

    def _text(self, english: str, japanese: str) -> str:
        return japanese if self.language == "JA" else english

    def _build_ui(self) -> None:
        ttk = self.ttk
        main = ttk.Frame(self.root, padding=8)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(main)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(toolbar, text=self._text("Profile name", "Profile名")).pack(side="left")
        ttk.Entry(toolbar, textvariable=self.profile_name_var, width=24).pack(side="left", padx=5)
        ttk.Button(toolbar, text=self._text("Open Profile", "Profileを開く"), command=self.open_profile).pack(side="left", padx=3)
        ttk.Button(toolbar, text=self._text("Save Profile As", "Profileを別名保存"), command=self.save_profile_as).pack(side="left", padx=3)
        ttk.Button(toolbar, text=self._text("Delete Selected", "選択領域を削除"), command=self.delete_selected).pack(side="left", padx=3)
        ttk.Button(toolbar, text=self._text("Clear All", "全削除"), command=self.clear_all).pack(side="left", padx=3)
        ttk.Button(toolbar, text=self._text("Export Pair", "2画像を出力"), command=self.export_pair).pack(side="right", padx=3)

        panes = ttk.Panedwindow(main, orient="horizontal")
        panes.grid(row=1, column=0, sticky="nsew")
        image_panel = ttk.Frame(panes)
        image_panel.columnconfigure(0, weight=1)
        image_panel.rowconfigure(0, weight=1)
        self.canvas = self.tk.Canvas(image_panel, background="#111111", highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.bind("<Configure>", lambda _event: self.render())
        self.canvas.bind("<ButtonPress-1>", self.drag_begin)
        self.canvas.bind("<B1-Motion>", self.drag_move)
        self.canvas.bind("<ButtonRelease-1>", self.drag_end)

        list_panel = ttk.LabelFrame(panes, text=self._text("Mask regions", "マスク領域"), padding=7)
        list_panel.columnconfigure(0, weight=1)
        list_panel.rowconfigure(0, weight=1)
        self.listbox = self.tk.Listbox(list_panel, exportselection=False, width=34)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(list_panel, orient="vertical", command=self.listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.listbox.configure(yscrollcommand=scrollbar.set)
        self.listbox.bind("<<ListboxSelect>>", self.list_selected)
        ttk.Label(
            list_panel,
            text=self._text(
                "Normalized coordinates are reusable across images with the same layout.",
                "正規化座標は同じレイアウトの画像で再利用できます。",
            ),
            wraplength=260,
        ).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        panes.add(image_panel, weight=4)
        panes.add(list_panel, weight=1)

        ttk.Label(main, textvariable=self.status_var, relief="sunken", anchor="w").grid(
            row=2, column=0, sticky="ew", pady=(6, 0)
        )

    def run(self) -> dict[str, Any] | None:
        self.root.mainloop()
        return self.export_result

    def _load_last_profile_if_available(self) -> None:
        last_path = self.profile_directory / "u003_frame_mask_last_profile.json"
        if not last_path.is_file():
            return
        try:
            name, rectangles = read_profile(last_path)
            self.profile_name_var.set(name)
            self.rectangles = rectangles
            self.current_profile_path = last_path
            self.refresh_list()
            self.status_var.set(
                self._text(
                    f"Restored {len(rectangles)} masks from the last Profile.",
                    f"前回Profileから{len(rectangles)}件のマスクを復元しました。",
                )
            )
        except Exception as error:
            self.status_var.set(f"Profile warning: {error}")

    def display_geometry(self) -> tuple[float, float, float, float]:
        canvas_width = max(1, self.canvas.winfo_width())
        canvas_height = max(1, self.canvas.winfo_height())
        image_height, image_width = self.image.shape[:2]
        scale = min(canvas_width / image_width, canvas_height / image_height)
        display_width = max(1, int(round(image_width * scale)))
        display_height = max(1, int(round(image_height * scale)))
        left = (canvas_width - display_width) / 2.0
        top = (canvas_height - display_height) / 2.0
        return left, top, float(display_width), float(display_height)

    def render(self) -> None:
        left, top, width, height = self.display_geometry()
        self.image_box = (left, top, width, height)
        display = resize_rgb(self.image, int(width), int(height))
        ppm = f"P6 {int(width)} {int(height)} 255\n".encode("ascii") + display.tobytes()
        self.photo = self.tk.PhotoImage(data=ppm, format="PPM")
        self.canvas.delete("all")
        self.canvas.create_image(left, top, image=self.photo, anchor="nw")
        for index, rectangle in enumerate(self.rectangles):
            value = rectangle.normalized()
            color = "#ffcc00" if index == self.selected_index else "#ff3333"
            self.canvas.create_rectangle(
                left + value.x0 * width,
                top + value.y0 * height,
                left + value.x1 * width,
                top + value.y1 * height,
                outline=color,
                width=3,
            )

    def canvas_to_normalized(self, x: float, y: float) -> tuple[float, float]:
        left, top, width, height = self.image_box
        nx = max(0.0, min(1.0, (x - left) / width))
        ny = max(0.0, min(1.0, (y - top) / height))
        return nx, ny

    def drag_begin(self, event: Any) -> None:
        left, top, width, height = self.image_box
        if not (left <= event.x <= left + width and top <= event.y <= top + height):
            return
        self.drag_start = self.canvas_to_normalized(event.x, event.y)
        self.drag_item = self.canvas.create_rectangle(
            event.x, event.y, event.x, event.y, outline="#00e5ff", width=3
        )

    def drag_move(self, event: Any) -> None:
        if self.drag_start is None or self.drag_item is None:
            return
        left, top, width, height = self.image_box
        start_x = left + self.drag_start[0] * width
        start_y = top + self.drag_start[1] * height
        current_x = max(left, min(left + width, event.x))
        current_y = max(top, min(top + height, event.y))
        self.canvas.coords(self.drag_item, start_x, start_y, current_x, current_y)

    def drag_end(self, event: Any) -> None:
        if self.drag_start is None:
            return
        try:
            end = self.canvas_to_normalized(event.x, event.y)
            rectangle = NormalizedRectangle(
                self.drag_start[0], self.drag_start[1], end[0], end[1]
            ).normalized()
            self.rectangles.append(rectangle)
            self.selected_index = len(self.rectangles) - 1
            self.refresh_list()
            self.status_var.set(
                self._text(
                    f"Added mask region {len(self.rectangles)}.",
                    f"マスク領域{len(self.rectangles)}を追加しました。",
                )
            )
        except ValueError as error:
            self.status_var.set(str(error))
            self.render()
        finally:
            self.drag_start = None
            self.drag_item = None

    def refresh_list(self) -> None:
        self.listbox.delete(0, "end")
        for index, rectangle in enumerate(self.rectangles, start=1):
            value = rectangle.normalized()
            self.listbox.insert(
                "end",
                f"{index:02d}: ({value.x0:.3f}, {value.y0:.3f}) - ({value.x1:.3f}, {value.y1:.3f})",
            )
        if self.selected_index is not None and self.selected_index < len(self.rectangles):
            self.listbox.selection_set(self.selected_index)
        self.render()

    def list_selected(self, _event: Any = None) -> None:
        selected = self.listbox.curselection()
        self.selected_index = int(selected[0]) if selected else None
        self.render()

    def delete_selected(self) -> None:
        if self.selected_index is None or not 0 <= self.selected_index < len(self.rectangles):
            return
        del self.rectangles[self.selected_index]
        self.selected_index = None
        self.refresh_list()

    def clear_all(self) -> None:
        self.rectangles = []
        self.selected_index = None
        self.refresh_list()

    def open_profile(self) -> None:
        from tkinter import filedialog, messagebox

        path = filedialog.askopenfilename(
            title=self._text("Open Frame Mask Profile", "Frame Mask Profileを開く"),
            initialdir=str(self.profile_directory),
            filetypes=[("JSON", "*.json")],
            parent=self.root,
        )
        if not path:
            return
        try:
            name, rectangles = read_profile(Path(path))
            self.profile_name_var.set(name)
            self.rectangles = rectangles
            self.selected_index = None
            self.current_profile_path = Path(path).resolve()
            self.refresh_list()
        except Exception as error:
            messagebox.showerror("Profile error", str(error), parent=self.root)

    def save_profile(self, path: Path) -> Path:
        height, width = self.image.shape[:2]
        payload = profile_payload(
            self.profile_name_var.get(), self.rectangles, width, height
        )
        write_json_atomic(path, payload)
        return path

    def save_profile_as(self) -> None:
        from tkinter import filedialog, messagebox

        path = filedialog.asksaveasfilename(
            title=self._text("Save Frame Mask Profile", "Frame Mask Profileを保存"),
            initialdir=str(self.profile_directory),
            initialfile="u003_frame_mask_profile.json",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            parent=self.root,
        )
        if not path:
            return
        try:
            self.current_profile_path = self.save_profile(Path(path).resolve())
            self.status_var.set(f"Profile saved: {self.current_profile_path}")
        except Exception as error:
            messagebox.showerror("Profile error", str(error), parent=self.root)

    def export_pair(self) -> None:
        from tkinter import messagebox

        if not self.rectangles:
            messagebox.showwarning(
                self._text("No mask regions", "マスク領域なし"),
                self._text("Add at least one mask region first.", "マスク領域を1件以上追加してください。"),
                parent=self.root,
            )
            return
        try:
            stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
            base = f"U003_FC{self.framecount}_{stamp}"
            original_path = unique_path(self.output_directory / f"{base}_original.png")
            masked_path = unique_path(self.output_directory / f"{base}_masked.png")
            applied_profile_path = unique_path(
                self.output_directory / f"{base}_mask_profile.json"
            )
            self.output_directory.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.source_path, original_path)
            masked = apply_black_masks(self.image, self.rectangles)
            write_rgb_image(masked_path, masked)
            self.save_profile(applied_profile_path)
            last_profile_path = self.profile_directory / "u003_frame_mask_last_profile.json"
            self.save_profile(last_profile_path)
            self.export_result = {
                "ArtifactPaths": [
                    str(original_path),
                    str(masked_path),
                    str(applied_profile_path),
                ],
                "OriginalScreenshotPath": str(original_path),
                "MaskedScreenshotPath": str(masked_path),
                "MaskProfilePath": str(applied_profile_path),
                "ActionSummary": self._text(
                    f"Created original and masked screenshots with {len(self.rectangles)} regions at FrameCount {self.framecount}.",
                    f"FrameCount {self.framecount}で{len(self.rectangles)}領域の元画像と匿名化画像を作成しました。",
                ),
            }
            self.root.destroy()
        except Exception as error:
            messagebox.showerror("Export error", str(error), parent=self.root)


def execute(request_path: Path, result_path: Path) -> int:
    request = read_json_object(request_path)
    if request.get("ContractId") != "U003_MODULE_ACTION_REQUEST":
        raise RuntimeError("Unsupported request contract.")
    if request.get("ActionId") != ACTION_ID:
        raise RuntimeError("Unsupported action identity.")
    context = request.get("Context")
    if not isinstance(context, dict):
        raise RuntimeError("Context must be one JSON object.")
    source_path = Path(str(context["CurrentFrameImagePath"])).resolve()
    image = load_rgb_image(source_path)
    output_directory = Path(str(context["OutputDirectory"])).resolve()
    profile_directory = Path(str(context["ProfileDirectory"])).resolve()
    output_directory.mkdir(parents=True, exist_ok=True)
    profile_directory.mkdir(parents=True, exist_ok=True)
    editor = MaskEditor(
        image=image,
        language=str(request["Language"]),
        profile_directory=profile_directory,
        output_directory=output_directory,
        framecount=int(context["CurrentCANFrameCount"]),
        source_path=source_path,
    )
    outputs = editor.run()
    result = {
        "ContractId": "U003_MODULE_ACTION_RESULT",
        "ContractVersion": "0.1",
        "RequestId": request["RequestId"],
        "RunId": request["RunId"],
        "EventId": request["EventId"],
        "ActionId": request["ActionId"],
        "ModuleId": request["ModuleId"],
        "ModuleVersion": request["ModuleVersion"],
        "Status": "SUCCESS" if outputs is not None else "NO_RESULT",
        "Outputs": outputs or {},
        "Warnings": [],
        "RootCauseClaim": False,
    }
    write_json_atomic(result_path, result)
    return 0


def run_self_test() -> int:
    import numpy as np

    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    rectangle = NormalizedRectangle(0.8, 0.7, 0.2, 0.1).normalized()
    check(rectangle.x0 == 0.2 and rectangle.x1 == 0.8)
    check(rectangle.y0 == 0.1 and rectangle.y1 == 0.7)
    payload = rectangle.to_payload()
    check(NormalizedRectangle.from_payload(payload) == rectangle)
    image = np.full((100, 200, 3), 255, dtype=np.uint8)
    masked = apply_black_masks(image, [NormalizedRectangle(0.25, 0.2, 0.75, 0.8)])
    check(bool((masked[20:80, 50:150] == 0).all()))
    check(bool((masked[0:10, 0:10] == 255).all()))
    check(bool((image == 255).all()))
    with tempfile.TemporaryDirectory(prefix="u003_u3m8_") as temporary:
        root = Path(temporary)
        profile_path = root / "profile.json"
        write_json_atomic(profile_path, profile_payload("test", [rectangle], 200, 100))
        name, loaded = read_profile(profile_path)
        check(name == "test")
        check(loaded == [rectangle])
        check(read_json_object(profile_path)["CoordinateSystem"] == "NORMALIZED_IMAGE_XY")
        source_path = root / "source.png"
        masked_path = root / "masked.png"
        write_rgb_image(source_path, image)
        write_rgb_image(masked_path, masked)
        check(True)
        check(True)
        check(source_path.is_file())
        check(masked_path.is_file())
        check(unique_path(masked_path).name == "masked_001.png")
    check(PROFILE_ID == "U003_FRAME_MASK_PROFILE")
    check(ACTION_ID == "CREATE_MASKED_SCREENSHOT")
    print(f"U003-U3M8-MODULE-SELFTEST-PASS-{checks} C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--result", type=Path)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    if arguments.self_test:
        return run_self_test()
    if not arguments.execute or arguments.request is None or arguments.result is None:
        raise RuntimeError("Use --self-test or --execute --request <path> --result <path>.")
    return execute(arguments.request, arguments.result)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M8E K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
