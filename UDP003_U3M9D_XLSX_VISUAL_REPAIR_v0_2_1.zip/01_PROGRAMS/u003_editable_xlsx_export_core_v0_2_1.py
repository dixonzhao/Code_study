#!/usr/bin/env python3
"""U003 editable XLSX chart export core.

This module converts one governed U003 Review Data window into a normal Excel
workbook.  The workbook contains copied source cells, native editable charts,
and trace metadata.  It deliberately contains no tkinter code; U3M9C will add
the human-facing action window after this core is qualified.

The implementation favors explicit validation and readable code over clever
abstractions.  Missing measurements remain blank and are never changed to zero.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
import re
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence


ENGINE_ID = "CameraRadar.U003.EditableXlsxExportCore"
ENGINE_VERSION = "0.2.1"
PROFILE_CONTRACT_ID = "U003_EDITABLE_XLSX_CHART_PROFILE"
PROFILE_CONTRACT_VERSION = "0.1"
LIVE_CONTEXT_ID = "U003_LIVE_REVIEW_CONTEXT"
LIVE_CONTEXT_VERSION = "0.1"

MAX_CHARTS = 12
MAX_SERIES_PER_CHART = 12
MAX_WINDOW_ROWS = 20001
WINDOWS_SAFE_PATH_LIMIT = 240
DEFAULT_TABLE_STYLE = "TableStyleMedium2"
ALLOWED_TABLE_STYLES = {
    "TableStyleLight9",
    "TableStyleMedium2",
    "TableStyleMedium9",
}


class EditableXlsxExportError(RuntimeError):
    """Raised when governed input cannot produce a trustworthy workbook."""


@dataclass(frozen=True)
class ReviewTable:
    """CSV rows in their governed Review Data order."""

    path: Path
    encoding: str
    delimiter: str
    columns: tuple[str, ...]
    rows: tuple[dict[str, Any], ...]
    framecounts: tuple[int, ...]


@dataclass(frozen=True)
class SelectedWindow:
    """One event-first or current-row-fallback slice."""

    source: str
    start_index: int
    end_index: int
    rows: tuple[dict[str, Any], ...]
    start_framecount: int
    end_framecount: int
    requested_peak_framecount: int
    effective_peak_framecount: int


@dataclass(frozen=True)
class ExportResult:
    """Stable result returned to the future U003 action adapter."""

    workbook_path: Path
    profile_id: str
    profile_version: str
    range_source: str
    row_count: int
    start_framecount: int
    end_framecount: int
    requested_peak_framecount: int
    effective_peak_framecount: int
    chart_count: int
    copied_columns: tuple[str, ...]
    language: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "EngineId": ENGINE_ID,
            "EngineVersion": ENGINE_VERSION,
            "Status": "SPASS",
            "WorkbookPath": str(self.workbook_path.resolve()),
            "ProfileId": self.profile_id,
            "ProfileVersion": self.profile_version,
            "RangeSource": self.range_source,
            "RowCount": self.row_count,
            "StartFrameCount": self.start_framecount,
            "EndFrameCount": self.end_framecount,
            "RequestedPeakFrameCount": self.requested_peak_framecount,
            "EffectivePeakFrameCount": self.effective_peak_framecount,
            "ChartCount": self.chart_count,
            "CopiedColumns": list(self.copied_columns),
            "Language": self.language,
        }


def require(condition: bool, message: str) -> None:
    """Fail closed with one actionable error."""

    if not condition:
        raise EditableXlsxExportError(message)


def read_json_object(path: Path, label: str) -> dict[str, Any]:
    """Read one UTF-8 JSON object."""

    require(path.is_file(), f"{label} does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise EditableXlsxExportError(f"{label} is not valid UTF-8 JSON: {error}") from error
    require(isinstance(payload, dict), f"{label} root must be a JSON object.")
    return payload


def sha256_file(path: Path) -> str:
    """Return the exact input identity used by the trace sheet."""

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_filename(value: str, fallback: str) -> str:
    """Create one portable path segment without hiding the original identity."""

    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip()).strip("._-")
    return cleaned[:80] or fallback


def compact_output_path(output_directory: Path, output_name: str) -> tuple[Path, bool]:
    """Return a Windows-safe XLSX path while retaining a short identity hash.

    Excel and some company Windows environments still reject paths close to the
    traditional 260-character MAX_PATH limit.  The directory is user-owned, so
    only the filename is compacted.  The digest makes two compacted names with
    the same visible prefix remain collision resistant.
    """

    directory = output_directory.resolve()
    cleaned = safe_filename(output_name, "U3_export.xlsx")
    if not cleaned.lower().endswith(".xlsx"):
        cleaned = f"{Path(cleaned).stem}.xlsx"
    available = WINDOWS_SAFE_PATH_LIMIT - len(str(directory)) - 1
    require(
        available >= 24,
        "Output directory path is too long for reliable Windows Excel access. "
        "Choose a shorter output directory.",
    )
    if len(cleaned) <= available:
        return directory / cleaned, False
    digest = hashlib.sha256(cleaned.encode("utf-8")).hexdigest()[:8]
    suffix = f"_{digest}.xlsx"
    stem_budget = max(8, available - len(suffix))
    compacted = f"{Path(cleaned).stem[:stem_budget]}{suffix}"
    return directory / compacted, True


def localized_text(value: Any, language: str, label: str) -> str:
    """Resolve JA text with the approved EN fallback."""

    require(isinstance(value, dict), f"{label} must contain localized text.")
    english = str(value.get("EN", "")).strip()
    japanese = str(value.get("JA", "")).strip()
    require(bool(english), f"{label}.EN must not be blank.")
    return japanese if language == "JA" and japanese else english


def validate_profile(profile: dict[str, Any]) -> dict[str, Any]:
    """Validate the contract fields used by the export engine."""

    require(profile.get("ContractId") == PROFILE_CONTRACT_ID, "Profile ContractId is invalid.")
    require(
        profile.get("ContractVersion") == PROFILE_CONTRACT_VERSION,
        "Profile ContractVersion is invalid.",
    )
    profile_id = str(profile.get("ProfileId", ""))
    require(
        re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{2,79}", profile_id) is not None,
        "ProfileId is invalid.",
    )
    require(
        re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", str(profile.get("ProfileVersion", "")))
        is not None,
        "ProfileVersion must use semantic version form.",
    )
    localized_text(profile.get("DisplayName"), "EN", "DisplayName")

    range_policy = profile.get("RangePolicy")
    require(isinstance(range_policy, dict), "RangePolicy must be an object.")
    require(
        range_policy.get("FallbackMode") == "CURRENT_ROW_WINDOW",
        "RangePolicy.FallbackMode must be CURRENT_ROW_WINDOW.",
    )
    for name in ("BeforeRows", "AfterRows"):
        value = range_policy.get(name)
        require(isinstance(value, int) and 0 <= value <= 10000, f"RangePolicy.{name} is invalid.")
    require(isinstance(range_policy.get("EventRangePriority"), bool), "EventRangePriority is invalid.")
    require(
        isinstance(range_policy.get("AllowEngineerOverride"), bool),
        "AllowEngineerOverride is invalid.",
    )

    charts = profile.get("Charts")
    require(isinstance(charts, list), "Charts must be an array.")
    require(1 <= len(charts) <= MAX_CHARTS, f"Charts must contain 1 to {MAX_CHARTS} definitions.")
    chart_ids: set[str] = set()
    for chart_index, chart in enumerate(charts, start=1):
        label = f"Charts[{chart_index}]"
        require(isinstance(chart, dict), f"{label} must be an object.")
        chart_id = str(chart.get("ChartId", ""))
        require(re.fullmatch(r"[A-Z][A-Z0-9_]{2,39}", chart_id) is not None, f"{label}.ChartId is invalid.")
        require(chart_id not in chart_ids, f"ChartId is duplicated: {chart_id}")
        chart_ids.add(chart_id)
        localized_text(chart.get("Title"), "EN", f"{label}.Title")
        localized_text(chart.get("XAxisTitle"), "EN", f"{label}.XAxisTitle")
        localized_text(chart.get("YAxisTitle"), "EN", f"{label}.YAxisTitle")
        require(bool(str(chart.get("XAxisColumn", "")).strip()), f"{label}.XAxisColumn is blank.")
        series = chart.get("Series")
        require(isinstance(series, list), f"{label}.Series must be an array.")
        require(
            1 <= len(series) <= MAX_SERIES_PER_CHART,
            f"{label}.Series must contain 1 to {MAX_SERIES_PER_CHART} definitions.",
        )
        series_columns: set[str] = set()
        for series_index, series_item in enumerate(series, start=1):
            series_label = f"{label}.Series[{series_index}]"
            require(isinstance(series_item, dict), f"{series_label} must be an object.")
            column = str(series_item.get("Column", "")).strip()
            require(bool(column), f"{series_label}.Column is blank.")
            require(column not in series_columns, f"{label} duplicates series column {column}.")
            series_columns.add(column)
            localized_text(series_item.get("DisplayName"), "EN", f"{series_label}.DisplayName")
            require(
                re.fullmatch(r"#[0-9A-Fa-f]{6}", str(series_item.get("Color", ""))) is not None,
                f"{series_label}.Color is invalid.",
            )
        peak_policy = chart.get("PeakPolicy")
        require(isinstance(peak_policy, dict), f"{label}.PeakPolicy must be an object.")
        require(isinstance(peak_policy.get("Highlight"), bool), f"{label}.PeakPolicy.Highlight is invalid.")
        require(isinstance(peak_policy.get("DataLabel"), bool), f"{label}.PeakPolicy.DataLabel is invalid.")
        primary = peak_policy.get("PrimarySeriesColumn")
        require(primary is None or primary in series_columns, f"{label} Peak primary series is not plotted.")

    output_policy = profile.get("OutputPolicy")
    require(isinstance(output_policy, dict), "OutputPolicy must be an object.")
    require(output_policy.get("LanguageSource") == "U003_SESSION", "LanguageSource is invalid.")
    require(output_policy.get("JapaneseFallback") == "EN", "JapaneseFallback is invalid.")
    for required_true in ("IncludeSourceData", "NativeEditableCharts", "BlankMissingValues"):
        require(output_policy.get(required_true) is True, f"OutputPolicy.{required_true} must be true.")
    table_style = str(output_policy.get("TableStyle", DEFAULT_TABLE_STYLE))
    require(table_style in ALLOWED_TABLE_STYLES, "OutputPolicy.TableStyle is not approved.")
    return profile


def validate_live_context(context: dict[str, Any]) -> dict[str, Any]:
    """Validate the subset published by U003 that controls this export."""

    require(context.get("ContractId") == LIVE_CONTEXT_ID, "Live context ContractId is invalid.")
    require(context.get("ContractVersion") == LIVE_CONTEXT_VERSION, "Live context version is invalid.")
    require(isinstance(context.get("CurrentCANFrameCount"), int), "CurrentCANFrameCount must be an integer.")
    language = str(context.get("Language", "EN")).upper()
    require(language in {"EN", "JA"}, "Live context Language must be EN or JA.")
    return context


def detect_csv_format(path: Path) -> tuple[str, str]:
    """Detect common company CSV encodings and delimiters without pandas."""

    raw = path.read_bytes()[:65536]
    require(bool(raw), f"Review Data CSV is empty: {path}")
    decoded = None
    selected_encoding = ""
    for encoding in ("utf-8-sig", "utf-8", "cp932"):
        try:
            decoded = raw.decode(encoding)
            selected_encoding = encoding
            break
        except UnicodeDecodeError:
            continue
    require(decoded is not None, "Review Data CSV is not UTF-8 or CP932 text.")
    try:
        dialect = csv.Sniffer().sniff(decoded, delimiters=",\t;")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","
    return selected_encoding, delimiter


def parse_cell(text: str | None) -> Any:
    """Convert ordinary numeric text while preserving missingness and labels."""

    if text is None:
        return None
    stripped = str(text).strip()
    if stripped == "" or stripped.lower() in {"nan", "none", "null"}:
        return None
    try:
        integer = int(stripped)
        return integer
    except ValueError:
        pass
    try:
        number = float(stripped)
        return number if math.isfinite(number) else None
    except ValueError:
        return stripped


def read_review_table(path: Path) -> ReviewTable:
    """Read Review Data and require one monotonic exact FrameCount domain."""

    require(path.is_file(), f"Review Data CSV does not exist: {path}")
    encoding, delimiter = detect_csv_format(path)
    with path.open("r", encoding=encoding, newline="") as stream:
        reader = csv.DictReader(stream, delimiter=delimiter)
        raw_columns = reader.fieldnames or []
        columns = tuple(str(column).strip() for column in raw_columns)
        require(bool(columns), "Review Data CSV has no header.")
        require(len(columns) == len(set(columns)), "Review Data CSV contains duplicate headers.")
        require("FrameCount" in columns, "Review Data CSV requires exact FrameCount column.")
        rows: list[dict[str, Any]] = []
        framecounts: list[int] = []
        for source_row_number, raw_row in enumerate(reader, start=2):
            parsed = {column: parse_cell(raw_row.get(column)) for column in columns}
            frame_value = parsed.get("FrameCount")
            require(
                isinstance(frame_value, int) and not isinstance(frame_value, bool),
                f"FrameCount at CSV row {source_row_number} is not an integer.",
            )
            if framecounts:
                require(
                    frame_value > framecounts[-1],
                    "Review Data FrameCount must be strictly increasing and unique.",
                )
            framecounts.append(frame_value)
            rows.append(parsed)
    require(bool(rows), "Review Data CSV contains no data rows.")
    return ReviewTable(
        path=path.resolve(),
        encoding=encoding,
        delimiter=delimiter,
        columns=columns,
        rows=tuple(rows),
        framecounts=tuple(framecounts),
    )


def choose_window(
    table: ReviewTable,
    profile: dict[str, Any],
    context: dict[str, Any],
    *,
    start_frame: int | None = None,
    end_frame: int | None = None,
    before_rows: int | None = None,
    after_rows: int | None = None,
) -> SelectedWindow:
    """Apply explicit override, Event-first, then current-row fallback semantics."""

    policy = profile["RangePolicy"]
    allow_override = bool(policy["AllowEngineerOverride"])
    if any(value is not None for value in (start_frame, end_frame, before_rows, after_rows)):
        require(allow_override, "This Profile does not allow engineer range overrides.")

    explicit_range = start_frame is not None or end_frame is not None
    require(not explicit_range or (start_frame is not None and end_frame is not None), "Explicit range requires both boundaries.")

    source = ""
    if explicit_range:
        require(start_frame <= end_frame, "Explicit StartFrame must not exceed EndFrame.")
        selected_start = int(start_frame)
        selected_end = int(end_frame)
        source = "ENGINEER_OVERRIDE"
        left = bisect.bisect_left(table.framecounts, selected_start)
        right = bisect.bisect_right(table.framecounts, selected_end) - 1
    else:
        event_start = context.get("ReviewStartFrame")
        event_end = context.get("ReviewEndFrame")
        valid_event = (
            bool(policy["EventRangePriority"])
            and isinstance(event_start, int)
            and isinstance(event_end, int)
            and event_start <= event_end
        )
        if valid_event:
            source = "EVENT"
            left = bisect.bisect_left(table.framecounts, event_start)
            right = bisect.bisect_right(table.framecounts, event_end) - 1
        else:
            source = "CURRENT_ROW_WINDOW"
            current = int(context["CurrentCANFrameCount"])
            nearest = min(
                max(bisect.bisect_left(table.framecounts, current), 0),
                len(table.framecounts) - 1,
            )
            if nearest > 0 and abs(table.framecounts[nearest - 1] - current) <= abs(table.framecounts[nearest] - current):
                nearest -= 1
            before = int(policy["BeforeRows"] if before_rows is None else before_rows)
            after = int(policy["AfterRows"] if after_rows is None else after_rows)
            require(0 <= before <= 10000 and 0 <= after <= 10000, "Row window override is invalid.")
            left = max(0, nearest - before)
            right = min(len(table.rows) - 1, nearest + after)

    require(0 <= left < len(table.rows), "Selected range starts outside Review Data.")
    require(0 <= right < len(table.rows), "Selected range ends outside Review Data.")
    require(left <= right, "Selected range has no Review Data rows.")
    row_count = right - left + 1
    require(row_count <= MAX_WINDOW_ROWS, f"Selected range exceeds {MAX_WINDOW_ROWS} rows.")

    requested_peak = context.get("PeakFrameCount")
    if not isinstance(requested_peak, int):
        requested_peak = context.get("EffectivePeakFrame")
    if not isinstance(requested_peak, int):
        requested_peak = int(context["CurrentCANFrameCount"])
    window_frames = table.framecounts[left : right + 1]
    peak_position = bisect.bisect_left(window_frames, requested_peak)
    peak_position = min(peak_position, len(window_frames) - 1)
    if peak_position > 0 and abs(window_frames[peak_position - 1] - requested_peak) <= abs(window_frames[peak_position] - requested_peak):
        peak_position -= 1
    effective_peak = window_frames[peak_position]

    return SelectedWindow(
        source=source,
        start_index=left,
        end_index=right,
        rows=table.rows[left : right + 1],
        start_framecount=table.framecounts[left],
        end_framecount=table.framecounts[right],
        requested_peak_framecount=int(requested_peak),
        effective_peak_framecount=int(effective_peak),
    )


def required_columns(profile: dict[str, Any], available: Sequence[str]) -> tuple[str, ...]:
    """Return a narrow human-readable union of all plotted source columns."""

    selected: list[str] = ["FrameCount"]
    for chart in profile["Charts"]:
        selected.append(str(chart["XAxisColumn"]))
        for series in chart["Series"]:
            selected.append(str(series["Column"]))
    unique = tuple(dict.fromkeys(selected))
    missing = [column for column in unique if column not in available]
    require(not missing, "Review Data is missing Profile columns: " + ", ".join(missing))
    return unique


def set_sheet_title(sheet: Any, title: str, end_column: int, color: str) -> None:
    """Apply one restrained company-facing title band."""

    from openpyxl.styles import Alignment, Font, PatternFill

    sheet.merge_cells(start_row=1, start_column=1, end_row=2, end_column=max(2, end_column))
    cell = sheet.cell(row=1, column=1, value=title)
    cell.fill = PatternFill("solid", fgColor=color)
    cell.font = Font(color="FFFFFF", bold=True, size=16)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    for row in sheet.iter_rows(min_row=1, max_row=2, min_col=1, max_col=max(2, end_column)):
        for band_cell in row:
            band_cell.fill = PatternFill("solid", fgColor=color)


def style_header(row: Iterable[Any], color: str = "1F4E78") -> None:
    """Style one table header without depending on an Excel template."""

    from openpyxl.styles import Alignment, Font, PatternFill

    for cell in row:
        cell.fill = PatternFill("solid", fgColor=color)
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(vertical="center")


def localized_trace_label(key: str, language: str) -> str:
    """Use stable keys while making the displayed workbook readable."""

    japanese = {
        "Purpose": "目的",
        "RangeSource": "範囲ソース",
        "StartFrameCount": "開始FrameCount",
        "EndFrameCount": "終了FrameCount",
        "RequestedPeakFrameCount": "要求Peak FrameCount",
        "EffectivePeakFrameCount": "実効Peak FrameCount",
        "RowCount": "行数",
        "CopiedColumns": "コピー列",
        "ExternalLinks": "外部リンク",
    }
    return japanese.get(key, key) if language == "JA" else key


def unique_sheet_name(base: str, used: set[str]) -> str:
    """Create one legal and unique Excel sheet name."""

    safe = re.sub(r"[\\/*?:\[\]]", "_", base).strip() or "Chart"
    safe = safe[:31]
    candidate = safe
    counter = 2
    while candidate in used:
        suffix = f"_{counter}"
        candidate = safe[: 31 - len(suffix)] + suffix
        counter += 1
    used.add(candidate)
    return candidate


def axis_title_with_unit(chart: dict[str, Any], language: str) -> str:
    """Combine the engineer-editable Y-axis label and physical unit once."""

    title = localized_text(chart["YAxisTitle"], language, "Chart.YAxisTitle").strip()
    unit = str(chart.get("Unit", "")).strip()
    if not unit or unit.lower() in title.lower():
        return title
    return f"{title} ({unit})"


def nice_integer_step(start: int, end: int, target_labels: int = 10) -> int:
    """Choose a readable integer FrameCount interval for the numeric X axis."""

    span = max(1, int(end) - int(start))
    raw = max(1.0, span / max(2, target_labels))
    magnitude = 10 ** math.floor(math.log10(raw))
    normalized = raw / magnitude
    if normalized <= 1:
        nice = 1
    elif normalized <= 2:
        nice = 2
    elif normalized <= 5:
        nice = 5
    else:
        nice = 10
    return max(1, int(nice * magnitude))


def peak_marker_height(
    rows: Sequence[dict[str, Any]],
    plotted_columns: Sequence[str],
) -> float:
    """Place one Peak marker slightly above the visible engineering traces."""

    values: list[float] = []
    for row in rows:
        for column in plotted_columns:
            value = row.get(column)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                number = float(value)
                if math.isfinite(number):
                    values.append(number)
    require(bool(values), "Peak marker requires at least one finite plotted value.")
    lower = min(values)
    upper = max(values)
    span = upper - lower
    padding = max(span * 0.06, abs(upper) * 0.02, 0.1)
    return upper + padding


def build_workbook(
    *,
    table: ReviewTable,
    window: SelectedWindow,
    profile: dict[str, Any],
    profile_path: Path,
    context_path: Path,
    language: str,
    output_path: Path,
) -> ExportResult:
    """Write copied data, native charts and trace metadata to one XLSX."""

    try:
        from openpyxl import Workbook, load_workbook
        from openpyxl.chart import Reference, ScatterChart, Series
        from openpyxl.chart.label import DataLabelList
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.table import Table, TableStyleInfo
    except ImportError as error:
        raise EditableXlsxExportError(
            "openpyxl is required for native editable XLSX output. "
            "The U003 packaged runtime must include openpyxl."
        ) from error

    copied_columns = required_columns(profile, table.columns)
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Summary"
    source = workbook.create_sheet("Source Data")
    helpers = workbook.create_sheet("Chart Helpers")
    profile_sheet = workbook.create_sheet("Chart Profile")
    trace = workbook.create_sheet("Trace")
    used_sheet_names = {sheet.title for sheet in workbook.worksheets}

    display_name = localized_text(profile["DisplayName"], language, "DisplayName")
    set_sheet_title(summary, display_name, 8, "1F4E78")
    summary_rows = [
        ("Status", "Synthetic" if "Sample" in profile["ProfileId"] else "U003 governed export"),
        ("Profile", f"{profile['ProfileId']} v{profile['ProfileVersion']}"),
        ("Range source", window.source),
        ("FrameCount range", f"{window.start_framecount}–{window.end_framecount}"),
        ("Effective Peak", window.effective_peak_framecount),
        ("Rows", len(window.rows)),
        ("Charts", len(profile["Charts"])),
        ("Rule", "Copied data + native editable Excel charts"),
    ]
    summary.append([])
    summary.append([])
    summary.append(["Field", "Value"])
    for item in summary_rows:
        summary.append(list(item))
    style_header(summary[4])
    for cell in summary[5:13]:
        cell[0].fill = PatternFill("solid", fgColor="D9EAF7")
        cell[0].font = Font(bold=True)
    summary.column_dimensions["A"].width = 24
    summary.column_dimensions["B"].width = 66

    source.append(list(copied_columns))
    for row in window.rows:
        source.append([row.get(column) for column in copied_columns])
    style_header(source[1])
    source.freeze_panes = "A2"
    source.auto_filter.ref = source.dimensions
    source_table = Table(displayName="U003SourceData", ref=source.dimensions)
    source_table.tableStyleInfo = TableStyleInfo(
        name=str(profile["OutputPolicy"].get("TableStyle", DEFAULT_TABLE_STYLE)),
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    source.add_table(source_table)
    for column_index, column_name in enumerate(copied_columns, start=1):
        source.column_dimensions[source.cell(1, column_index).column_letter].width = min(
            34,
            max(13, len(column_name) + 2),
        )
    peak_excel_row = 2 + next(
        index
        for index, row in enumerate(window.rows)
        if int(row["FrameCount"]) == window.effective_peak_framecount
    )
    for cell in source[peak_excel_row]:
        cell.fill = PatternFill("solid", fgColor="FFF2CC")
        cell.font = Font(color="C00000", bold=True)

    set_sheet_title(profile_sheet, "Chart Profile", 6, "1F4E78")
    profile_sheet.append([])
    profile_sheet.append([])
    profile_sheet.append(["ChartId", "Title", "Unit", "X-axis", "Series", "Peak"])
    for chart in profile["Charts"]:
        profile_sheet.append(
            [
                chart["ChartId"],
                localized_text(chart["Title"], language, "Chart.Title"),
                chart["Unit"],
                chart["XAxisColumn"],
                ", ".join(item["Column"] for item in chart["Series"]),
                chart["PeakPolicy"]["PrimarySeriesColumn"] or "OFF",
            ]
        )
    style_header(profile_sheet[4])
    profile_sheet.freeze_panes = "A5"
    for letter, width in {"A": 28, "B": 42, "C": 12, "D": 24, "E": 58, "F": 28}.items():
        profile_sheet.column_dimensions[letter].width = width

    source_column_index = {name: index + 1 for index, name in enumerate(copied_columns)}
    helpers.append(["ChartId", "PeakFrameCount", "PeakDisplayY"])
    style_header(helpers[1], color="A61C00")
    for chart_number, chart_definition in enumerate(profile["Charts"], start=1):
        chart_id = chart_definition["ChartId"]
        sheet_name = unique_sheet_name(f"Chart {chart_id}", used_sheet_names)
        chart_sheet = workbook.create_sheet(sheet_name)
        title = localized_text(chart_definition["Title"], language, "Chart.Title")
        set_sheet_title(chart_sheet, title, 12, "1F4E78")

        line_chart = ScatterChart()
        line_chart.title = title
        line_chart.style = 13
        line_chart.height = 12
        line_chart.width = 23
        line_chart.scatterStyle = "line"
        line_chart.x_axis.title = localized_text(
            chart_definition["XAxisTitle"], language, "Chart.XAxisTitle"
        )
        line_chart.y_axis.title = axis_title_with_unit(chart_definition, language)
        line_chart.x_axis.numFmt = "0"
        line_chart.x_axis.scaling.min = window.start_framecount
        line_chart.x_axis.scaling.max = window.end_framecount
        line_chart.x_axis.majorUnit = nice_integer_step(
            window.start_framecount,
            window.end_framecount,
        )
        line_chart.legend.position = "t"
        if hasattr(line_chart, "display_blanks"):
            line_chart.display_blanks = "gap"

        x_column = source_column_index[chart_definition["XAxisColumn"]]
        categories = Reference(
            source,
            min_col=x_column,
            min_row=2,
            max_row=1 + len(window.rows),
        )
        for series_definition in chart_definition["Series"]:
            column = source_column_index[series_definition["Column"]]
            data_reference = Reference(
                source,
                min_col=column,
                min_row=2,
                max_row=1 + len(window.rows),
            )
            series = Series(
                data_reference,
                categories,
                title=localized_text(
                    series_definition["DisplayName"], language, "Series.DisplayName"
                ),
            )
            color = str(series_definition["Color"]).lstrip("#")
            series.graphicalProperties.line.solidFill = color
            series.graphicalProperties.line.width = 22000
            series.marker.symbol = "none"
            line_chart.series.append(series)

        peak_policy = chart_definition["PeakPolicy"]
        primary_column = peak_policy.get("PrimarySeriesColumn")
        if bool(peak_policy.get("Highlight")) and primary_column:
            plotted_columns = [str(item["Column"]) for item in chart_definition["Series"]]
            helper_row = chart_number + 1
            helpers.cell(row=helper_row, column=1, value=chart_id)
            helpers.cell(row=helper_row, column=2, value=window.effective_peak_framecount)
            helpers.cell(
                row=helper_row,
                column=3,
                value=peak_marker_height(window.rows, plotted_columns),
            )
            peak_x = Reference(helpers, min_col=2, min_row=helper_row, max_row=helper_row)
            peak_y = Reference(helpers, min_col=3, min_row=helper_row, max_row=helper_row)
            peak_series = Series(peak_y, peak_x, title="Peak")
            peak_series.graphicalProperties.line.noFill = True
            peak_series.marker.symbol = "circle"
            peak_series.marker.size = 8
            peak_series.marker.graphicalProperties.solidFill = "C00000"
            peak_series.marker.graphicalProperties.line.solidFill = "C00000"
            if bool(peak_policy.get("DataLabel")):
                peak_series.dLbls = DataLabelList()
                peak_series.dLbls.showSerName = True
            line_chart.series.append(peak_series)

        chart_sheet.add_chart(line_chart, "A4")
        chart_sheet[30][0].value = (
            "Source: 'Source Data'. Values, titles, axes, series and this chart object "
            "remain editable in Excel."
        )
        chart_sheet[30][0].alignment = Alignment(wrap_text=True)
        chart_sheet.column_dimensions["A"].width = 100

    helpers.sheet_state = "hidden"

    set_sheet_title(trace, "Trace and Provenance", 6, "317D6B")
    trace.append([])
    trace.append([])
    trace.append(["Field", "Value"])
    trace_rows = [
        ("Purpose", "U003 editable XLSX export"),
        ("EngineId", ENGINE_ID),
        ("EngineVersion", ENGINE_VERSION),
        ("ProfileId", profile["ProfileId"]),
        ("ProfileVersion", profile["ProfileVersion"]),
        ("ProfileSHA256", sha256_file(profile_path)),
        ("ReviewDataPath", str(table.path)),
        ("ReviewDataSHA256", sha256_file(table.path)),
        ("LiveContextPath", str(context_path.resolve())),
        ("LiveContextSHA256", sha256_file(context_path)),
        ("RangeSource", window.source),
        ("StartFrameCount", window.start_framecount),
        ("EndFrameCount", window.end_framecount),
        ("RequestedPeakFrameCount", window.requested_peak_framecount),
        ("EffectivePeakFrameCount", window.effective_peak_framecount),
        ("RowCount", len(window.rows)),
        ("CopiedColumns", " | ".join(copied_columns)),
        ("Language", language),
        ("ExternalLinks", "NONE"),
        ("GeneratedUTC", datetime.now(timezone.utc).isoformat()),
    ]
    for key, value in trace_rows:
        trace.append([localized_trace_label(key, language), value])
    style_header(trace[4], color="317D6B")
    for row in trace.iter_rows(min_row=5, max_row=4 + len(trace_rows), min_col=1, max_col=1):
        row[0].fill = PatternFill("solid", fgColor="DDEBF7")
        row[0].font = Font(bold=True)
    trace.column_dimensions["A"].width = 30
    trace.column_dimensions["B"].width = 92
    trace.freeze_panes = "A5"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)

    # Reopen the exact artifact to verify it is readable and still owns charts.
    verified = load_workbook(output_path, data_only=False)
    expected_sheets = 5 + len(profile["Charts"])
    require(len(verified.sheetnames) == expected_sheets, "Saved workbook sheet count changed.")
    chart_sheet_count = sum(1 for sheet in verified.worksheets if len(sheet._charts) == 1)
    require(chart_sheet_count == len(profile["Charts"]), "Saved workbook native chart count changed.")
    require(len(verified["Source Data"].tables) == 1, "Source Data Excel Table is missing.")
    require(verified["Chart Helpers"].sheet_state == "hidden", "Chart helper sheet is not hidden.")
    require(not getattr(verified, "_external_links", []), "Saved workbook contains external links.")
    radar_blank_columns = [
        index + 1
        for index, name in enumerate(copied_columns)
        if "Radar" in name or "radar" in name
    ]
    if radar_blank_columns:
        # This is an invariant check, not a requirement that every dataset has missing Radar rows.
        for source_row_index, source_row in enumerate(window.rows, start=2):
            for column_index in radar_blank_columns:
                column_name = copied_columns[column_index - 1]
                if source_row.get(column_name) is None:
                    require(
                        verified["Source Data"].cell(source_row_index, column_index).value is None,
                        "Missing Radar value was not preserved as blank.",
                    )

    return ExportResult(
        workbook_path=output_path.resolve(),
        profile_id=str(profile["ProfileId"]),
        profile_version=str(profile["ProfileVersion"]),
        range_source=window.source,
        row_count=len(window.rows),
        start_framecount=window.start_framecount,
        end_framecount=window.end_framecount,
        requested_peak_framecount=window.requested_peak_framecount,
        effective_peak_framecount=window.effective_peak_framecount,
        chart_count=len(profile["Charts"]),
        copied_columns=copied_columns,
        language=language,
    )


def export_editable_xlsx(
    *,
    review_data_path: Path,
    live_context_path: Path,
    profile_path: Path,
    output_directory: Path,
    output_name: str | None = None,
    language_override: str | None = None,
    start_frame: int | None = None,
    end_frame: int | None = None,
    before_rows: int | None = None,
    after_rows: int | None = None,
) -> ExportResult:
    """Public high-code API used later by the U003 Module implementation."""

    profile = validate_profile(read_json_object(profile_path, "Chart Profile"))
    context = validate_live_context(read_json_object(live_context_path, "Live Review Context"))
    table = read_review_table(review_data_path)
    language = str(language_override or context.get("Language", "EN")).upper()
    require(language in {"EN", "JA"}, "Export language must be EN or JA.")
    window = choose_window(
        table,
        profile,
        context,
        start_frame=start_frame,
        end_frame=end_frame,
        before_rows=before_rows,
        after_rows=after_rows,
    )
    if output_name is None:
        timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
        event_id = safe_filename(str(context.get("EventID", "NO_EVENT")), "NO_EVENT")
        output_name = f"U3_{event_id}_{timestamp}.xlsx"
    require(output_name.lower().endswith(".xlsx"), "Output filename must end with .xlsx.")
    output_path, _path_compacted = compact_output_path(output_directory, output_name)
    return build_workbook(
        table=table,
        window=window,
        profile=profile,
        profile_path=profile_path,
        context_path=live_context_path,
        language=language,
        output_path=output_path,
    )


def write_result_json(path: Path, result: ExportResult) -> None:
    """Write the exact action result atomically for future module integration."""

    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(result.as_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def run_self_test() -> int:
    """Exercise contract, range, missingness, localization and native charts."""

    from openpyxl import load_workbook

    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u3m9d_") as temporary:
        root = Path(temporary)
        review_path = root / "review.csv"
        review_path.write_text(
            "FrameCount,CameraDistance_m,RadarDistance_m,CameraLateralPosition_m\n"
            "100,21.0,19.0,0.4\n"
            "102,20.8,18.7,0.6\n"
            "104,20.6,,0.9\n"
            "106,20.4,,1.2\n"
            "108,20.2,18.0,0.5\n",
            encoding="utf-8",
        )
        context_path = root / "live_context.json"
        context = {
            "ContractId": LIVE_CONTEXT_ID,
            "ContractVersion": LIVE_CONTEXT_VERSION,
            "Sequence": 1,
            "CurrentCANFrameCount": 104,
            "EventID": "C001",
            "ReviewStartFrame": 101,
            "PeakFrameCount": 105,
            "ReviewEndFrame": 108,
            "EffectivePeakFrame": 105,
            "Language": "JA",
        }
        context_path.write_text(json.dumps(context), encoding="utf-8")
        profile_path = root / "profile.json"
        profile = {
            "ContractId": PROFILE_CONTRACT_ID,
            "ContractVersion": PROFILE_CONTRACT_VERSION,
            "ProfileId": "CameraRadar.U003.SelfTest",
            "ProfileVersion": "0.1.0",
            "DisplayName": {"EN": "Self-test plot", "JA": "自己診断グラフ"},
            "RangePolicy": {
                "EventRangePriority": True,
                "FallbackMode": "CURRENT_ROW_WINDOW",
                "BeforeRows": 1,
                "AfterRows": 1,
                "AllowEngineerOverride": True,
            },
            "Charts": [
                {
                    "ChartId": "DISTANCE",
                    "Title": {"EN": "Distance", "JA": "距離"},
                    "XAxisColumn": "FrameCount",
                    "XAxisTitle": {"EN": "FrameCount", "JA": "FrameCount"},
                    "YAxisTitle": {"EN": "Distance (m)", "JA": "距離 (m)"},
                    "Unit": "m",
                    "Series": [
                        {
                            "Column": "CameraDistance_m",
                            "DisplayName": {"EN": "Camera", "JA": "Camera"},
                            "Color": "#2E75B6",
                        },
                        {
                            "Column": "RadarDistance_m",
                            "DisplayName": {"EN": "Radar", "JA": "Radar"},
                            "Color": "#ED7D31",
                        },
                    ],
                    "PeakPolicy": {
                        "Highlight": True,
                        "DataLabel": False,
                        "PrimarySeriesColumn": "CameraDistance_m",
                    },
                }
            ],
            "OutputPolicy": {
                "LanguageSource": "U003_SESSION",
                "JapaneseFallback": "EN",
                "IncludeSourceData": True,
                "NativeEditableCharts": True,
                "BlankMissingValues": True,
                "OpenOutputFolder": False,
                "TableStyle": "TableStyleMedium2",
            },
        }
        profile_path.write_text(json.dumps(profile), encoding="utf-8")
        output_directory = root / "output"
        result = export_editable_xlsx(
            review_data_path=review_path,
            live_context_path=context_path,
            profile_path=profile_path,
            output_directory=output_directory,
            output_name="selftest.xlsx",
        )
        check(result.workbook_path.is_file())
        check(result.range_source == "EVENT")
        check(result.row_count == 4)
        check(result.start_framecount == 102)
        check(result.end_framecount == 108)
        check(result.requested_peak_framecount == 105)
        check(result.effective_peak_framecount == 104)
        check(result.chart_count == 1)
        check(result.language == "JA")
        check(result.copied_columns == ("FrameCount", "CameraDistance_m", "RadarDistance_m"))
        workbook = load_workbook(result.workbook_path, data_only=False)
        check("Source Data" in workbook.sheetnames)
        check("Chart DISTANCE" in workbook.sheetnames)
        check(len(workbook["Chart DISTANCE"]._charts) == 1)
        check(workbook["Source Data"]["C3"].value is None)
        check(workbook["Source Data"]["C4"].value is None)
        check(len(workbook["Source Data"].tables) == 1)
        check(workbook["Chart Helpers"].sheet_state == "hidden")
        chart = workbook["Chart DISTANCE"]._charts[0]
        check(type(chart).__name__ == "ScatterChart")
        check(chart.legend.position == "t")
        check(chart.x_axis.majorUnit == 1.0)
        check(len(chart.series) == 3)
        check(chart.series[-1].marker.symbol == "circle")
        check(float(workbook["Chart Helpers"]["C2"].value) > 20.8)
        check(workbook["Summary"]["A1"].value == "自己診断グラフ")
        check(not workbook._external_links)
        result_path = root / "result.json"
        write_result_json(result_path, result)
        result_payload = json.loads(result_path.read_text(encoding="utf-8"))
        check(result_payload["Status"] == "SPASS")
        check(result_payload["EffectivePeakFrameCount"] == 104)

        fallback_context = dict(context)
        fallback_context.update(
            {
                "ReviewStartFrame": None,
                "ReviewEndFrame": None,
                "PeakFrameCount": None,
                "CurrentCANFrameCount": 106,
                "EffectivePeakFrame": 106,
                "Language": "EN",
            }
        )
        context_path.write_text(json.dumps(fallback_context), encoding="utf-8")
        fallback = export_editable_xlsx(
            review_data_path=review_path,
            live_context_path=context_path,
            profile_path=profile_path,
            output_directory=output_directory,
            output_name="fallback.xlsx",
        )
        check(fallback.range_source == "CURRENT_ROW_WINDOW")
        check(fallback.row_count == 3)
        check(fallback.start_framecount == 104)
        check(fallback.end_framecount == 108)
        check(fallback.requested_peak_framecount == 106)
        check(fallback.effective_peak_framecount == 106)
        # Derive the padding from the resolved temporary-root length.  A fixed
        # padding is invalid because Windows and macOS have different temp-root
        # lengths, while the production path limit itself is platform-neutral.
        forced_available = 40
        target_directory_length = WINDOWS_SAFE_PATH_LIMIT - 1 - forced_available
        padding_length = target_directory_length - len(str(root.resolve())) - 1
        if padding_length < 1:
            raise AssertionError("self-test temporary root is unexpectedly long")
        compaction_directory = root / ("D" * padding_length)
        compacted, changed = compact_output_path(
            compaction_directory,
            "A" * 300 + ".xlsx",
        )
        check(changed)
        check(len(str(compacted)) <= WINDOWS_SAFE_PATH_LIMIT)

    print(f"U3M9D-CORE-SELFTEST-PASS-{checks} C-0")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--review-data", type=Path)
    parser.add_argument("--live-context", type=Path)
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--output-name")
    parser.add_argument("--result-json", type=Path)
    parser.add_argument("--language", choices=("EN", "JA"))
    parser.add_argument("--start-frame", type=int)
    parser.add_argument("--end-frame", type=int)
    parser.add_argument("--before-rows", type=int)
    parser.add_argument("--after-rows", type=int)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return run_self_test()
    required = {
        "--review-data": args.review_data,
        "--live-context": args.live_context,
        "--profile": args.profile,
        "--out": args.out,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing:
        raise EditableXlsxExportError("Missing arguments: " + ", ".join(missing))
    result = export_editable_xlsx(
        review_data_path=args.review_data,
        live_context_path=args.live_context,
        profile_path=args.profile,
        output_directory=args.out,
        output_name=args.output_name,
        language_override=args.language,
        start_frame=args.start_frame,
        end_frame=args.end_frame,
        before_rows=args.before_rows,
        after_rows=args.after_rows,
    )
    if args.result_json is not None:
        write_result_json(args.result_json, result)
    print(
        "U3M9D-RUN "
        f"N-R{result.row_count}-C{result.chart_count}-S{result.start_framecount}-"
        f"E{result.end_framecount}-P{result.effective_peak_framecount}-X0 C-0"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except EditableXlsxExportError as error:
        print(f"U3M9D-ERROR K-{type(error).__name__.upper()} D-{error} X1 C-7")
        raise SystemExit(7)
