#!/usr/bin/env python3
"""Reusable Catalog/Mapping browser for U001 source capability inventories.

The GUI operates only on the lightweight capability catalog.  It does not open
or decode the payload source.  Selected catalog identities are saved as a
versioned Selection Profile and compiled into a controlled H2 adapter request.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from u001_selection_profile_compiler_v1_0 import (
    REQUIRED_CATALOG_COLUMNS,
    SELECTION_REQUEST_SCHEMA,
    SelectionError,
    compile_selection,
)


PROGRAM_NAME = "u001_catalog_mapping_gui"
PROGRAM_VERSION = "1.0.0"


class CatalogError(RuntimeError):
    """Fail-closed catalog model or GUI error."""


def _read_catalog(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            fieldnames = reader.fieldnames or []
            missing = [name for name in REQUIRED_CATALOG_COLUMNS if name not in fieldnames]
            if missing:
                raise CatalogError("CATALOG_COLUMNS:" + ".".join(missing))
            rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise CatalogError(f"CATALOG_READ:{exc}") from exc
    if not rows:
        raise CatalogError("CATALOG_EMPTY")
    identities = [row["CatalogItemId"].strip() for row in rows]
    if any(not identity for identity in identities):
        raise CatalogError("CATALOG_ID_EMPTY")
    if len(identities) != len(set(identities)):
        raise CatalogError("CATALOG_ID_DUPLICATE")
    return rows


def _is_true(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes"}


def _search_text(row: dict[str, str]) -> str:
    preferred = (
        "CatalogItemId",
        "SourceType",
        "ObservationFamily",
        "SourceChannel",
        "SourceMessageId",
        "SourceMessageName",
        "SourceSignalName",
        "CanonicalNameCandidate",
        "OriginalUnit",
        "ValueKindHint",
        "SearchText",
    )
    return " ".join(row.get(key, "") for key in preferred).lower()


@dataclass
class CatalogModel:
    rows: list[dict[str, str]]
    selected_ids: set[str] = field(default_factory=set)
    frame_key_id: str = ""

    @classmethod
    def load(cls, path: Path) -> "CatalogModel":
        model = cls(_read_catalog(path))
        candidates = model.frame_candidates()
        if candidates:
            model.frame_key_id = candidates[0]
        return model

    @property
    def index(self) -> dict[str, dict[str, str]]:
        return {row["CatalogItemId"]: row for row in self.rows}

    def decodable_rows(self) -> list[dict[str, str]]:
        return [
            row
            for row in self.rows
            if _is_true(row.get("TechnicallyDecodable", ""))
            and _is_true(row.get("SourceGroupComplete", ""))
        ]

    def frame_candidates(self) -> list[str]:
        preferred: list[str] = []
        other: list[str] = []
        for row in self.decodable_rows():
            signal = row["SourceSignalName"].lower().replace("_", "")
            target = preferred if signal in {"framecount", "framecounter"} else other
            if "frame" in signal or "sync" in signal:
                target.append(row["CatalogItemId"])
        return preferred + other

    def filter_rows(
        self,
        query: str = "",
        channel: str = "ALL",
        value_kind: str = "ALL",
        decodable_only: bool = True,
    ) -> list[dict[str, str]]:
        words = [word for word in query.lower().split() if word]
        result = []
        for row in self.rows:
            if decodable_only and not (
                _is_true(row.get("TechnicallyDecodable", ""))
                and _is_true(row.get("SourceGroupComplete", ""))
            ):
                continue
            if channel != "ALL" and row.get("SourceChannel", "") != channel:
                continue
            if value_kind != "ALL" and row.get("ValueKindHint", "") != value_kind:
                continue
            searchable = _search_text(row)
            if not all(word in searchable for word in words):
                continue
            result.append(row)
        return result

    def toggle(self, item_id: str) -> None:
        if item_id not in self.index:
            raise CatalogError("SELECTION_NOT_IN_CATALOG")
        if item_id in self.selected_ids:
            self.selected_ids.remove(item_id)
        else:
            row = self.index[item_id]
            if not _is_true(row.get("TechnicallyDecodable", "")):
                raise CatalogError("SELECTION_NOT_DECODABLE")
            self.selected_ids.add(item_id)

    def select_rows(self, rows: Iterable[dict[str, str]]) -> None:
        for row in rows:
            if _is_true(row.get("TechnicallyDecodable", "")):
                self.selected_ids.add(row["CatalogItemId"])

    def clear_rows(self, rows: Iterable[dict[str, str]]) -> None:
        for row in rows:
            self.selected_ids.discard(row["CatalogItemId"])

    def profile_request(
        self,
        profile_id: str,
        profile_version: str,
        profile_status: str,
        chunk_rows: int,
        max_in_flight: int,
        memory_mb: int,
        shard_rows: int,
    ) -> dict[str, Any]:
        if not profile_id.strip() or not profile_version.strip():
            raise CatalogError("PROFILE_IDENTITY")
        if not self.selected_ids:
            raise CatalogError("SELECTION_EMPTY")
        if not self.frame_key_id:
            raise CatalogError("FRAME_KEY_EMPTY")
        return {
            "SelectionRequestSchema": SELECTION_REQUEST_SCHEMA,
            "ProfileId": profile_id.strip(),
            "ProfileVersion": profile_version.strip(),
            "ProfileStatus": profile_status.strip().upper(),
            "SelectedCatalogItemIds": [
                row["CatalogItemId"]
                for row in self.rows
                if row["CatalogItemId"] in self.selected_ids
            ],
            "FrameKeyCatalogItemId": self.frame_key_id,
            "ResourcePolicy": {
                "ChunkRows": int(chunk_rows),
                "WorkerCount": 1,
                "MaxInFlightChunks": int(max_in_flight),
                "MaxResidentMemoryMB": int(memory_mb),
                "OutputShardRows": int(shard_rows),
            },
        }

    def load_profile(self, value: dict[str, Any]) -> None:
        if value.get("SelectionRequestSchema") != SELECTION_REQUEST_SCHEMA:
            raise CatalogError("PROFILE_SCHEMA")
        raw_ids = value.get("SelectedCatalogItemIds")
        if not isinstance(raw_ids, list):
            raise CatalogError("PROFILE_SELECTION")
        selected = {str(item) for item in raw_ids}
        missing = sorted(selected - set(self.index))
        if missing:
            raise CatalogError("PROFILE_CATALOG_MISMATCH:" + ".".join(missing[:10]))
        frame_key = str(value.get("FrameKeyCatalogItemId", ""))
        if frame_key not in self.index:
            raise CatalogError("PROFILE_FRAME_KEY")
        self.selected_ids = selected
        self.frame_key_id = frame_key


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def launch_gui(catalog_path: Path, base_request_path: Path | None = None) -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    model = CatalogModel.load(catalog_path)
    root = tk.Tk()
    root.title("U001 Catalog / Mapping Selection")
    root.geometry("1500x860")
    root.minsize(1050, 650)

    search_var = tk.StringVar()
    channel_var = tk.StringVar(value="ALL")
    kind_var = tk.StringVar(value="ALL")
    decodable_var = tk.BooleanVar(value=True)
    summary_var = tk.StringVar()
    detail_var = tk.StringVar(value="Select one catalog row to inspect source details.")
    profile_id_var = tk.StringVar(value="U001_SELECTION_PROFILE")
    profile_version_var = tk.StringVar(value="1.0.0")
    profile_status_var = tk.StringVar(value="PROVISIONAL")
    frame_var = tk.StringVar(value=model.frame_key_id)
    chunk_var = tk.StringVar(value="5000")
    inflight_var = tk.StringVar(value="2")
    memory_var = tk.StringVar(value="512")
    shard_var = tk.StringVar(value="250000")
    base_request_var = tk.StringVar(value="" if base_request_path is None else str(base_request_path))
    current_visible: list[dict[str, str]] = []

    root.columnconfigure(0, weight=1)
    root.rowconfigure(2, weight=1)

    source_frame = ttk.LabelFrame(root, text="Capability Catalog — inventory only; payload is not decoded")
    source_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
    source_frame.columnconfigure(1, weight=1)
    ttk.Label(source_frame, text="Catalog").grid(row=0, column=0, sticky="w", padx=6, pady=5)
    ttk.Entry(source_frame, textvariable=tk.StringVar(value=str(catalog_path)), state="readonly").grid(
        row=0, column=1, sticky="ew", padx=6, pady=5
    )
    ttk.Label(source_frame, textvariable=summary_var).grid(row=1, column=0, columnspan=2, sticky="w", padx=6, pady=5)

    filter_frame = ttk.Frame(root)
    filter_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=5)
    filter_frame.columnconfigure(1, weight=1)
    ttk.Label(filter_frame, text="Search").grid(row=0, column=0, padx=(0, 5))
    search_entry = ttk.Entry(filter_frame, textvariable=search_var)
    search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 8))
    ttk.Label(filter_frame, text="Channel").grid(row=0, column=2, padx=4)
    channels = ["ALL"] + sorted({row["SourceChannel"] for row in model.rows})
    ttk.Combobox(filter_frame, textvariable=channel_var, values=channels, state="readonly", width=9).grid(row=0, column=3)
    ttk.Label(filter_frame, text="Value kind").grid(row=0, column=4, padx=4)
    kinds = ["ALL"] + sorted({row["ValueKindHint"] for row in model.rows})
    ttk.Combobox(filter_frame, textvariable=kind_var, values=kinds, state="readonly", width=12).grid(row=0, column=5)
    ttk.Checkbutton(filter_frame, text="Decodable only", variable=decodable_var).grid(row=0, column=6, padx=8)

    content = ttk.Panedwindow(root, orient="horizontal")
    content.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
    table_frame = ttk.Frame(content)
    mapping_frame = ttk.Frame(content, padding=8)
    content.add(table_frame, weight=4)
    content.add(mapping_frame, weight=2)

    columns = ("selected", "channel", "can_id", "message", "signal", "unit", "kind")
    tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="extended")
    headings = {
        "selected": "Use",
        "channel": "CH",
        "can_id": "CAN ID",
        "message": "Message",
        "signal": "Signal",
        "unit": "Unit",
        "kind": "Type",
    }
    widths = {"selected": 52, "channel": 55, "can_id": 80, "message": 185, "signal": 230, "unit": 75, "kind": 90}
    for name in columns:
        tree.heading(name, text=headings[name])
        tree.column(name, width=widths[name], stretch=name in {"message", "signal"})
    tree.grid(row=0, column=0, sticky="nsew")
    table_frame.rowconfigure(0, weight=1)
    table_frame.columnconfigure(0, weight=1)
    vertical = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
    horizontal = ttk.Scrollbar(table_frame, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
    vertical.grid(row=0, column=1, sticky="ns")
    horizontal.grid(row=1, column=0, sticky="ew")

    button_frame = ttk.Frame(table_frame)
    button_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))

    def values_for(row: dict[str, str]) -> tuple[str, ...]:
        return (
            "✓" if row["CatalogItemId"] in model.selected_ids else "",
            row["SourceChannel"],
            row["SourceMessageId"],
            row["SourceMessageName"],
            row["SourceSignalName"],
            row["OriginalUnit"],
            row["ValueKindHint"],
        )

    def refresh() -> None:
        nonlocal current_visible
        current_visible = model.filter_rows(
            search_var.get(), channel_var.get(), kind_var.get(), decodable_var.get()
        )
        tree.delete(*tree.get_children())
        for row in current_visible:
            tree.insert("", "end", iid=row["CatalogItemId"], values=values_for(row))
        effective = set(model.selected_ids)
        if model.frame_key_id:
            effective.add(model.frame_key_id)
        message_groups = {
            (model.index[item]["SourceChannel"], model.index[item]["SourceMessageId"])
            for item in effective
            if item in model.index
        }
        summary_var.set(
            f"Catalog variables: {len(model.rows)}   Decodable: {len(model.decodable_rows())}   "
            f"Visible: {len(current_visible)}   User selected: {len(model.selected_ids)}   "
            f"Effective with FrameCount: {len(effective)}   Message groups: {len(message_groups)}"
        )

    def toggle_current(_event: Any = None) -> None:
        focus = tree.focus()
        if not focus:
            return
        try:
            model.toggle(focus)
            tree.item(focus, values=values_for(model.index[focus]))
            refresh()
        except CatalogError as exc:
            messagebox.showerror("Selection error", str(exc))

    def show_detail(_event: Any = None) -> None:
        focus = tree.focus()
        if not focus or focus not in model.index:
            return
        row = model.index[focus]
        detail_var.set(
            "\n".join(
                [
                    f"Catalog item: {focus}",
                    f"Candidate: {row['CanonicalNameCandidate']}",
                    f"Source: CH{row['SourceChannel']} {row['SourceMessageId']} / {row['SourceMessageName']}",
                    f"Signal: {row['SourceSignalName']} [{row['OriginalUnit']}] {row['ValueKindHint']}",
                    f"Byte columns: {row.get('SourceByteColumns', '')}",
                    f"Decodable: {row['TechnicallyDecodable']}  Complete group: {row['SourceGroupComplete']}",
                ]
            )
        )

    tree.bind("<Double-1>", toggle_current)
    tree.bind("<space>", toggle_current)
    tree.bind("<<TreeviewSelect>>", show_detail)

    ttk.Button(button_frame, text="Select visible", command=lambda: (model.select_rows(current_visible), refresh())).pack(side="left", padx=3)
    ttk.Button(button_frame, text="Clear visible", command=lambda: (model.clear_rows(current_visible), refresh())).pack(side="left", padx=3)
    ttk.Button(button_frame, text="Select all decodable", command=lambda: (model.select_rows(model.decodable_rows()), refresh())).pack(side="left", padx=3)
    ttk.Button(button_frame, text="Clear all", command=lambda: (model.selected_ids.clear(), refresh())).pack(side="left", padx=3)

    mapping_frame.columnconfigure(1, weight=1)
    ttk.Label(mapping_frame, text="Selection Profile", font=("TkDefaultFont", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
    form_rows = [
        ("Profile ID", profile_id_var),
        ("Version", profile_version_var),
    ]
    row_number = 1
    for label, variable in form_rows:
        ttk.Label(mapping_frame, text=label).grid(row=row_number, column=0, sticky="w", padx=(0, 6), pady=3)
        ttk.Entry(mapping_frame, textvariable=variable).grid(row=row_number, column=1, sticky="ew", pady=3)
        row_number += 1
    ttk.Label(mapping_frame, text="Status").grid(row=row_number, column=0, sticky="w", pady=3)
    ttk.Combobox(mapping_frame, textvariable=profile_status_var, values=["PROVISIONAL", "APPROVED"], state="readonly").grid(row=row_number, column=1, sticky="ew", pady=3)
    row_number += 1
    ttk.Label(mapping_frame, text="Frame key").grid(row=row_number, column=0, sticky="w", pady=3)
    frame_combo = ttk.Combobox(mapping_frame, textvariable=frame_var, values=model.frame_candidates(), state="readonly")
    frame_combo.grid(row=row_number, column=1, sticky="ew", pady=3)
    row_number += 1

    ttk.Separator(mapping_frame).grid(row=row_number, column=0, columnspan=2, sticky="ew", pady=8)
    row_number += 1
    ttk.Label(mapping_frame, text="Bounded resource policy", font=("TkDefaultFont", 10, "bold")).grid(row=row_number, column=0, columnspan=2, sticky="w")
    row_number += 1
    resource_rows = [
        ("Chunk rows", chunk_var),
        ("Workers (qualified)", tk.StringVar(value="1")),
        ("Max in-flight chunks", inflight_var),
        ("Memory target MB", memory_var),
        ("Output shard rows", shard_var),
    ]
    for label, variable in resource_rows:
        ttk.Label(mapping_frame, text=label).grid(row=row_number, column=0, sticky="w", pady=3)
        state = "readonly" if label == "Workers (qualified)" else "normal"
        ttk.Entry(mapping_frame, textvariable=variable, state=state).grid(row=row_number, column=1, sticky="ew", pady=3)
        row_number += 1

    ttk.Separator(mapping_frame).grid(row=row_number, column=0, columnspan=2, sticky="ew", pady=8)
    row_number += 1
    ttk.Label(mapping_frame, textvariable=detail_var, justify="left", wraplength=430).grid(row=row_number, column=0, columnspan=2, sticky="nw", pady=4)
    mapping_frame.rowconfigure(row_number, weight=1)
    row_number += 1

    def current_profile() -> dict[str, Any]:
        model.frame_key_id = frame_var.get()
        return model.profile_request(
            profile_id_var.get(),
            profile_version_var.get(),
            profile_status_var.get(),
            int(chunk_var.get()),
            int(inflight_var.get()),
            int(memory_var.get()),
            int(shard_var.get()),
        )

    def save_profile() -> None:
        try:
            profile = current_profile()
            path = filedialog.asksaveasfilename(
                title="Save Selection Profile",
                defaultextension=".json",
                filetypes=[("JSON", "*.json")],
                initialfile="u001_selection_profile.json",
            )
            if path:
                _write_json(Path(path), profile)
        except (CatalogError, ValueError, OSError) as exc:
            messagebox.showerror("Save failed", str(exc))

    def open_profile() -> None:
        path = filedialog.askopenfilename(title="Open Selection Profile", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            value = json.loads(Path(path).read_text(encoding="utf-8"))
            model.load_profile(value)
            profile_id_var.set(str(value.get("ProfileId", "")))
            profile_version_var.set(str(value.get("ProfileVersion", "")))
            profile_status_var.set(str(value.get("ProfileStatus", "PROVISIONAL")))
            frame_var.set(model.frame_key_id)
            policy = value.get("ResourcePolicy", {})
            chunk_var.set(str(policy.get("ChunkRows", 5000)))
            inflight_var.set(str(policy.get("MaxInFlightChunks", 2)))
            memory_var.set(str(policy.get("MaxResidentMemoryMB", 512)))
            shard_var.set(str(policy.get("OutputShardRows", 250000)))
            refresh()
        except (OSError, UnicodeError, json.JSONDecodeError, CatalogError) as exc:
            messagebox.showerror("Open failed", str(exc))

    def choose_base_request() -> None:
        path = filedialog.askopenfilename(title="Open base H2 adapter request", filetypes=[("JSON", "*.json")])
        if path:
            base_request_var.set(path)

    def compile_request() -> None:
        try:
            profile = current_profile()
            base_path = Path(base_request_var.get())
            if not base_path.is_file():
                raise CatalogError("BASE_REQUEST_NOT_SELECTED")
            output = filedialog.askdirectory(title="Choose empty output folder parent")
            if not output:
                return
            output_dir = Path(output) / f"{profile['ProfileId']}_{profile['ProfileVersion']}_COMPILED"
            with tempfile.TemporaryDirectory(prefix="u001_mapping_gui_") as temporary:
                profile_path = Path(temporary) / "selection.json"
                _write_json(profile_path, profile)
                result = compile_selection(catalog_path, base_path, profile_path, output_dir)
            messagebox.showinfo(
                "Compile complete",
                f"Selected {result['UserSelectedCount']} + {result['MandatoryDependencyCount']} dependency.\n{output_dir}",
            )
        except (CatalogError, SelectionError, ValueError, OSError) as exc:
            messagebox.showerror("Compile failed", str(exc))

    ttk.Label(mapping_frame, text="Base H2 request").grid(row=row_number, column=0, sticky="w", pady=3)
    ttk.Entry(mapping_frame, textvariable=base_request_var).grid(row=row_number, column=1, sticky="ew", pady=3)
    row_number += 1
    action_frame = ttk.Frame(mapping_frame)
    action_frame.grid(row=row_number, column=0, columnspan=2, sticky="ew", pady=(8, 0))
    ttk.Button(action_frame, text="Open profile", command=open_profile).pack(side="left", padx=3)
    ttk.Button(action_frame, text="Save profile", command=save_profile).pack(side="left", padx=3)
    ttk.Button(action_frame, text="Base request...", command=choose_base_request).pack(side="left", padx=3)
    ttk.Button(action_frame, text="Compile H2 request", command=compile_request).pack(side="right", padx=3)

    for variable in (search_var, channel_var, kind_var, decodable_var):
        variable.trace_add("write", lambda *_args: refresh())
    frame_var.trace_add("write", lambda *_args: setattr(model, "frame_key_id", frame_var.get()))
    refresh()
    search_entry.focus_set()
    root.mainloop()


def _write_catalog_fixture(path: Path) -> None:
    rows = []
    for channel, can_id, message, signal, kind in (
        (2, "0x221", "Camera", "Distance", "FLOAT"),
        (1, "0x380", "Radar", "DistanceToObject", "FLOAT"),
        (2, "0x620", "Frame", "FrameCount", "INTEGER"),
        (2, "0x221", "Camera", "ObjectType", "ENUM"),
    ):
        item_id = f"CAN.CH{channel}.ID{int(can_id, 16):X}.{signal}"
        row = {name: "" for name in REQUIRED_CATALOG_COLUMNS}
        row.update(
            {
                "CatalogItemId": item_id,
                "SourceAdapterId": "Synthetic.Adapter",
                "SourceAdapterVersion": "1.0.0",
                "SourceType": "CAN",
                "ObservationFamily": "TABULAR_SIGNAL_UPDATE",
                "SourceChannel": str(channel),
                "SourceMessageId": can_id,
                "SourceMessageName": message,
                "SourceSignalName": signal,
                "CanonicalNameCandidate": f"CH{channel}_ID{int(can_id, 16):X}_{signal}",
                "OriginalUnit": "m" if "Distance" in signal else "",
                "ValueKindHint": kind,
                "SourceGroupComplete": "1",
                "TechnicallyDecodable": "1",
            }
        )
        rows.append(row)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REQUIRED_CATALOG_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_catalog_gui_") as temporary:
        catalog_path = Path(temporary) / "catalog.csv"
        _write_catalog_fixture(catalog_path)
        model = CatalogModel.load(catalog_path)
        check(len(model.rows) == 4, "T01")
        check(len(model.decodable_rows()) == 4, "T02")
        check(model.frame_key_id == "CAN.CH2.ID620.FrameCount", "T03")
        check(len(model.filter_rows(query="distance")) == 2, "T04")
        check(len(model.filter_rows(channel="1")) == 1, "T05")
        check(len(model.filter_rows(value_kind="FLOAT")) == 2, "T06")
        distance_rows = model.filter_rows(query="distance")
        model.select_rows(distance_rows)
        check(len(model.selected_ids) == 2, "T07")
        model.toggle("CAN.CH2.ID221.Distance")
        check(len(model.selected_ids) == 1, "T08")
        model.toggle("CAN.CH2.ID221.Distance")
        profile = model.profile_request("PROFILE", "1.0.0", "APPROVED", 5000, 2, 512, 250000)
        check(len(profile["SelectedCatalogItemIds"]) == 2, "T09")
        check(profile["FrameKeyCatalogItemId"] == "CAN.CH2.ID620.FrameCount", "T10")
        check(profile["ResourcePolicy"]["WorkerCount"] == 1, "T11")
        clone = CatalogModel.load(catalog_path)
        clone.load_profile(profile)
        check(clone.selected_ids == model.selected_ids, "T12")
        check(clone.frame_key_id == model.frame_key_id, "T13")
        clone.clear_rows(clone.rows)
        check(not clone.selected_ids, "T14")

    if checks != 14:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-CATALOG-MAPPING-GUI-MODEL-SELFTEST-PASS-14")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 Catalog / Mapping GUI")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--gui", action="store_true")
    parser.add_argument("--catalog", type=Path)
    parser.add_argument("--base-request", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.catalog is None:
            raise CatalogError("CATALOG_ARGUMENT")
        launch_gui(args.catalog, args.base_request)
        return 0
    except (CatalogError, SelectionError, AssertionError, OSError, csv.Error) as exc:
        print(f"U1MAPE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
