#!/usr/bin/env python3
"""Compile a capability-catalog selection into an executable adapter request.

This module is source-neutral.  It never decodes payload data and never decides
which business signals are important.  It validates an engineer's explicit
selection, adds visible mandatory dependencies, and records a bounded resource
policy before a Source Adapter is allowed to decode the payload.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_selection_profile_compiler"
PROGRAM_VERSION = "1.0.0"
SELECTION_REQUEST_SCHEMA = "U001_SELECTION_PROFILE_REQUEST_V0_1"
COMPILED_PROFILE_SCHEMA = "U001_COMPILED_SELECTION_PROFILE_V0_1"
ADAPTER_REQUEST_SCHEMA = "U001_INPUT_ADAPTER_REQUEST_V0_1"

REQUIRED_CATALOG_COLUMNS = [
    "CatalogItemId",
    "SourceAdapterId",
    "SourceAdapterVersion",
    "SourceType",
    "ObservationFamily",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "OriginalUnit",
    "ValueKindHint",
    "SourceGroupComplete",
    "TechnicallyDecodable",
]

SELECTED_CATALOG_COLUMNS = REQUIRED_CATALOG_COLUMNS + [
    "SelectionReason",
    "SelectionOrder",
]

OUTPUT_PROFILE = "u001_compiled_selection_profile.json"
OUTPUT_CATALOG = "u001_selected_signal_catalog.csv"
OUTPUT_REQUEST = "u001_h2_controlled_request.json"
OUTPUT_QUALITY = "u001_selection_compile_quality.json"
OUTPUT_CAPSULE = "u001_selection_compile_capsule.txt"


class SelectionError(RuntimeError):
    """Fail-closed catalog/selection error."""


def _load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise SelectionError(f"{label}_JSON:{exc}") from exc
    if not isinstance(value, dict):
        raise SelectionError(f"{label}_NOT_OBJECT")
    return value


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _prepare_empty_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise SelectionError("OUTPUT_NOT_EMPTY")


def _read_catalog(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            fieldnames = reader.fieldnames or []
            missing = [name for name in REQUIRED_CATALOG_COLUMNS if name not in fieldnames]
            if missing:
                raise SelectionError("CATALOG_COLUMNS:" + ".".join(missing))
            rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise SelectionError(f"CATALOG_READ:{exc}") from exc
    if not rows:
        raise SelectionError("CATALOG_EMPTY")
    identities = [row["CatalogItemId"].strip() for row in rows]
    if any(not item for item in identities) or len(identities) != len(set(identities)):
        raise SelectionError("CATALOG_IDENTITY")
    return rows


def _positive_integer(value: Any, label: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool):
        raise SelectionError(label)
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise SelectionError(label) from exc
    if not minimum <= result <= maximum:
        raise SelectionError(label)
    return result


def _resource_policy(request: dict[str, Any]) -> dict[str, int | str]:
    raw = request.get("ResourcePolicy", {})
    if not isinstance(raw, dict):
        raise SelectionError("RESOURCE_POLICY")
    worker_count = _positive_integer(raw.get("WorkerCount", 1), "WORKER_COUNT", 1, 8)
    if worker_count != 1:
        raise SelectionError("WORKER_COUNT_NOT_QUALIFIED")
    return {
        "ChunkRows": _positive_integer(raw.get("ChunkRows", 5000), "CHUNK_ROWS", 100, 100000),
        "WorkerCount": worker_count,
        "MaxInFlightChunks": _positive_integer(
            raw.get("MaxInFlightChunks", 2), "MAX_IN_FLIGHT_CHUNKS", 1, 32
        ),
        "MaxResidentMemoryMB": _positive_integer(
            raw.get("MaxResidentMemoryMB", 512), "MAX_RESIDENT_MEMORY_MB", 128, 4096
        ),
        "OutputShardRows": _positive_integer(
            raw.get("OutputShardRows", 250000), "OUTPUT_SHARD_ROWS", 1000, 5000000
        ),
        "WriteOrderPolicy": "SOURCE_ORDER",
    }


def _parse_can_id(value: str) -> str:
    text = value.strip()
    try:
        number = int(text, 16)
    except ValueError as exc:
        raise SelectionError(f"CATALOG_CAN_ID:{text}") from exc
    return f"0x{number:X}"


def compile_selection(
    catalog_path: Path,
    base_request_path: Path,
    selection_request_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    _prepare_empty_directory(output_dir)
    rows = _read_catalog(catalog_path)
    base_request = _load_json(base_request_path, "BASE_REQUEST")
    selection_request = _load_json(selection_request_path, "SELECTION_REQUEST")

    if base_request.get("RequestSchemaVersion") != ADAPTER_REQUEST_SCHEMA:
        raise SelectionError("BASE_REQUEST_SCHEMA")
    if selection_request.get("SelectionRequestSchema") != SELECTION_REQUEST_SCHEMA:
        raise SelectionError("SELECTION_REQUEST_SCHEMA")

    profile_id = str(selection_request.get("ProfileId", "")).strip()
    profile_version = str(selection_request.get("ProfileVersion", "")).strip()
    profile_status = str(selection_request.get("ProfileStatus", "PROVISIONAL")).strip().upper()
    if not profile_id or not profile_version:
        raise SelectionError("PROFILE_IDENTITY")
    if profile_status not in {"APPROVED", "PROVISIONAL"}:
        raise SelectionError("PROFILE_STATUS")

    requested = selection_request.get("SelectedCatalogItemIds")
    if not isinstance(requested, list) or not requested:
        raise SelectionError("SELECTION_EMPTY")
    requested_ids = [str(item).strip() for item in requested]
    if any(not item for item in requested_ids) or len(requested_ids) != len(set(requested_ids)):
        raise SelectionError("SELECTION_IDENTITY")

    frame_item_id = str(selection_request.get("FrameKeyCatalogItemId", "")).strip()
    if not frame_item_id:
        raise SelectionError("FRAME_KEY_EMPTY")

    catalog = {row["CatalogItemId"].strip(): row for row in rows}
    missing = sorted(set(requested_ids + [frame_item_id]) - set(catalog))
    if missing:
        raise SelectionError("SELECTION_NOT_IN_CATALOG:" + ".".join(missing[:10]))

    effective_ids = list(requested_ids)
    if frame_item_id not in effective_ids:
        effective_ids.append(frame_item_id)

    selected_rows: list[dict[str, Any]] = []
    selected_signals: list[dict[str, Any]] = []
    for order, item_id in enumerate(effective_ids):
        row = catalog[item_id]
        if row["TechnicallyDecodable"].strip() != "1":
            raise SelectionError(f"NOT_DECODABLE:{item_id}")
        if row["SourceGroupComplete"].strip() != "1":
            raise SelectionError(f"SOURCE_GROUP_INCOMPLETE:{item_id}")
        reason = "USER_SELECTED" if item_id in requested_ids else "MANDATORY_DEPENDENCY"
        selected_rows.append(
            {
                **{name: row.get(name, "") for name in REQUIRED_CATALOG_COLUMNS},
                "SelectionReason": reason,
                "SelectionOrder": order,
            }
        )
        selected_signals.append(
            {
                "Channel": int(row["SourceChannel"]),
                "CAN_ID": _parse_can_id(row["SourceMessageId"]),
                "SignalName": row["SourceSignalName"],
                "CanonicalName": row["CanonicalNameCandidate"],
                "Required": True,
                "CatalogItemId": item_id,
                "SelectionReason": reason,
            }
        )

    frame_row = catalog[frame_item_id]
    resource_policy = _resource_policy(selection_request)
    compiled_request = deepcopy(base_request)
    configuration = dict(compiled_request.get("Configuration", {}))
    configuration.update(
        {
            "SelectionMode": "CONTROLLED_PROFILE",
            "SelectedSignals": selected_signals,
            "FrameKey": {
                "Channel": int(frame_row["SourceChannel"]),
                "CAN_ID": _parse_can_id(frame_row["SourceMessageId"]),
                "SignalName": frame_row["SourceSignalName"],
            },
            **resource_policy,
        }
    )
    compiled_request["Configuration"] = configuration

    catalog_hash = _sha256(catalog_path)
    compiled_profile = {
        "CompiledProfileSchema": COMPILED_PROFILE_SCHEMA,
        "ProfileId": profile_id,
        "ProfileVersion": profile_version,
        "ProfileStatus": profile_status,
        "SourceAdapterId": selected_rows[0]["SourceAdapterId"],
        "SourceAdapterVersion": selected_rows[0]["SourceAdapterVersion"],
        "CatalogSHA256": catalog_hash,
        # This is observed from the current catalog.  It is never a vehicle-
        # or adapter-specific constant and may change for every source.
        "CatalogRowCount": len(rows),
        "UserSelectedCount": len(requested_ids),
        "MandatoryDependencyCount": len(effective_ids) - len(requested_ids),
        "EffectiveSelectedCount": len(effective_ids),
        "FrameKeyCatalogItemId": frame_item_id,
        "SelectedCatalogItemIds": effective_ids,
        "SelectionReasons": {
            row["CatalogItemId"]: row["SelectionReason"] for row in selected_rows
        },
        "ResourcePolicy": resource_policy,
        "Status": "COMPILED",
        "CompletionCode": 0,
    }

    with (output_dir / OUTPUT_CATALOG).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=SELECTED_CATALOG_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selected_rows)
    _write_json(output_dir / OUTPUT_PROFILE, compiled_profile)
    _write_json(output_dir / OUTPUT_REQUEST, compiled_request)
    quality = {
        "QualitySchema": "U001_SELECTION_COMPILE_QUALITY_V0_1",
        "CatalogRowCount": len(rows),
        "UserSelectedCount": len(requested_ids),
        "MandatoryDependencyCount": len(effective_ids) - len(requested_ids),
        "EffectiveSelectedCount": len(effective_ids),
        "UnqualifiedParallelWorkerCount": 0,
        "WholeFileMemoryLoadRequired": False,
        "Errors": [],
    }
    _write_json(output_dir / OUTPUT_QUALITY, quality)
    capsule = (
        f"U1SEL-V{len(rows)}-U{len(requested_ids)}-"
        f"D{len(effective_ids) - len(requested_ids)}-E{len(effective_ids)}-X0-C0"
    )
    (output_dir / OUTPUT_CAPSULE).write_text(capsule + "\n", encoding="utf-8")
    return compiled_profile


def _write_fixture(root: Path) -> tuple[Path, Path, Path]:
    catalog_path = root / "catalog.csv"
    catalog_rows = []
    for channel, can_id, signal, unit in (
        (2, "0x221", "Distance", "m"),
        (1, "0x380", "DistanceToObject", "m"),
        (2, "0x620", "FrameCount", "count"),
    ):
        item_id = f"CAN.CH{channel}.ID{int(can_id, 16):X}.{signal}"
        catalog_rows.append(
            {
                "CatalogItemId": item_id,
                "SourceAdapterId": "Synthetic.Adapter",
                "SourceAdapterVersion": "1.0.0",
                "SourceType": "CAN",
                "ObservationFamily": "TABULAR_SIGNAL_UPDATE",
                "SourceChannel": channel,
                "SourceMessageId": can_id,
                "SourceMessageName": signal + "Message",
                "SourceSignalName": signal,
                "CanonicalNameCandidate": f"CH{channel}_ID{int(can_id, 16):X}_{signal}",
                "OriginalUnit": unit,
                "ValueKindHint": "INTEGER" if signal == "FrameCount" else "FLOAT",
                "SourceGroupComplete": 1,
                "TechnicallyDecodable": 1,
            }
        )
    with catalog_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REQUIRED_CATALOG_COLUMNS)
        writer.writeheader()
        writer.writerows(catalog_rows)

    base_path = root / "base.json"
    _write_json(
        base_path,
        {
            "RequestSchemaVersion": ADAPTER_REQUEST_SCHEMA,
            "RequestId": "SELFTEST_REQUEST",
            "DatasetId": "SELFTEST_DATASET",
            "RunId": "SELFTEST_RUN",
            "SegmentId": "FULL_SOURCE",
            "SourceId": "SOURCE_001",
            "Inputs": [],
            "Configuration": {},
        },
    )
    selection_path = root / "selection.json"
    _write_json(
        selection_path,
        {
            "SelectionRequestSchema": SELECTION_REQUEST_SCHEMA,
            "ProfileId": "SELFTEST_PROFILE",
            "ProfileVersion": "1.0.0",
            "ProfileStatus": "APPROVED",
            "SelectedCatalogItemIds": [
                "CAN.CH2.ID221.Distance",
                "CAN.CH1.ID380.DistanceToObject",
            ],
            "FrameKeyCatalogItemId": "CAN.CH2.ID620.FrameCount",
            "ResourcePolicy": {
                "ChunkRows": 5000,
                "WorkerCount": 1,
                "MaxInFlightChunks": 2,
                "MaxResidentMemoryMB": 512,
                "OutputShardRows": 250000,
            },
        },
    )
    return catalog_path, base_path, selection_path


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_selection_compiler_") as temporary:
        root = Path(temporary)
        catalog, base, selection = _write_fixture(root)
        output = root / "output"
        result = compile_selection(catalog, base, selection, output)
        check(result["Status"] == "COMPILED", "T01")
        check(result["UserSelectedCount"] == 2, "T02")
        check(result["MandatoryDependencyCount"] == 1, "T03")
        check(result["EffectiveSelectedCount"] == 3, "T04")
        check(result["ResourcePolicy"]["MaxResidentMemoryMB"] == 512, "T05")
        check(result["ResourcePolicy"]["WorkerCount"] == 1, "T06")
        request = _load_json(output / OUTPUT_REQUEST, "OUTPUT_REQUEST")
        check(request["Configuration"]["SelectionMode"] == "CONTROLLED_PROFILE", "T07")
        check(len(request["Configuration"]["SelectedSignals"]) == 3, "T08")
        check(request["Configuration"]["FrameKey"]["SignalName"] == "FrameCount", "T09")
        selected_rows = _read_catalog(output / OUTPUT_CATALOG)
        check(len(selected_rows) == 3, "T10")
        check(selected_rows[-1]["SelectionReason"] == "MANDATORY_DEPENDENCY", "T11")
        check((output / OUTPUT_CAPSULE).read_text().strip() == "U1SEL-V3-U2-D1-E3-X0-C0", "T12")
        quality = _load_json(output / OUTPUT_QUALITY, "QUALITY")
        check(
            quality["WholeFileMemoryLoadRequired"] is False
            and quality["CatalogRowCount"] == len(_read_catalog(catalog))
            and result["CatalogRowCount"] == len(_read_catalog(catalog)),
            "T13",
        )

        bad_selection = _load_json(selection, "SELECTION")
        bad_selection["ResourcePolicy"]["WorkerCount"] = 4
        bad_path = root / "bad_selection.json"
        _write_json(bad_path, bad_selection)
        failed = False
        try:
            compile_selection(catalog, base, bad_path, root / "bad_output")
        except SelectionError as exc:
            failed = str(exc) == "WORKER_COUNT_NOT_QUALIFIED"
        check(failed, "T14")

    if checks != 14:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-SELECTION-PROFILE-COMPILER-SELFTEST-PASS-14")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 Selection Profile Compiler")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--compile", action="store_true")
    parser.add_argument("--catalog", type=Path)
    parser.add_argument("--base-request", type=Path)
    parser.add_argument("--selection-request", type=Path)
    parser.add_argument("--out", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        required = (args.catalog, args.base_request, args.selection_request, args.out)
        if any(value is None for value in required):
            raise SelectionError("COMPILE_ARGUMENTS")
        result = compile_selection(
            args.catalog,
            args.base_request,
            args.selection_request,
            args.out,
        )
        print(
            f"U1SEL-V{result['CatalogRowCount']}-"
            f"U{result['UserSelectedCount']}-D{result['MandatoryDependencyCount']}-"
            f"E{result['EffectiveSelectedCount']}-X0-C0"
        )
        return 0
    except (SelectionError, AssertionError, OSError, csv.Error) as exc:
        print(f"U1SELE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
