#!/usr/bin/env python3
"""Source-specific primitives for MATLAB-format CAN CSV and DBC files.

This module is intentionally independent of U001 analysis and frame-hold logic.
It reads source structure, parses DBC definitions and decodes real CAN updates
in original source order.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence


PROGRAM_NAME = "u001_matlab_can_csv_dbc_core"
PROGRAM_VERSION = "1.1.0"
CAN_COLUMN_RE = re.compile(r"^ID([0-9A-Fa-f]+)_(\d+)_(\d+)_(\d+)$")
BO_RE = re.compile(r"^\s*BO_\s+(\d+)\s+([^:]+):\s*(\d+)\s*(\S*)")
SG_RE = re.compile(
    r'^\s*SG_\s+([^\s:]+)(?:\s+[mM]\d*)?\s*:\s*'
    r'(\d+)\|(\d+)@([01])([+-])\s*'
    r'\(\s*([^,]+)\s*,\s*([^\)]+)\s*\)\s*'
    r'\[\s*([^|]*)\|([^\]]*)\]\s*'
    r'"([^"]*)"\s*(.*)$'
)
VAL_RE = re.compile(r"^\s*VAL_\s+(\d+)\s+(\S+)\s+(.*?)\s*;\s*$")
VAL_PAIR_RE = re.compile(r'(-?\d+)\s+"((?:[^"\\]|\\.)*)"')


class CanAdapterError(RuntimeError):
    """Fail-closed source adapter error."""


@dataclass(frozen=True)
class TextFormatInfo:
    encoding: str
    delimiter: str
    header_row_index: int
    columns: list[str]
    sample_bytes_read: int
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class MatlabCanColumn:
    original_name: str
    can_id: int
    can_id_hex: str
    channel: int
    dlc: int
    byte_index: int


@dataclass(frozen=True)
class SourceMessageGroup:
    can_id: int
    can_id_hex: str
    channel: int
    dlc: int
    byte_columns_by_index: dict[int, str]
    complete: bool
    first_column_position: int
    warnings: list[str] = field(default_factory=list)


@dataclass
class DbcSignal:
    signal_name: str
    start_bit: int
    bit_length: int
    byte_order: str
    is_signed: bool
    factor: float
    offset: float
    minimum: float | None
    maximum: float | None
    unit: str
    receivers: list[str]
    value_map: dict[int, str] = field(default_factory=dict)


@dataclass
class DbcMessage:
    raw_message_id: int
    can_id: int
    can_id_hex: str
    is_extended: bool
    message_name: str
    dlc: int
    transmitter: str
    signals: list[DbcSignal] = field(default_factory=list)


@dataclass(frozen=True)
class DbcParseResult:
    channel: int
    encoding: str
    messages: list[DbcMessage]
    warning_count: int


@dataclass(frozen=True)
class SelectedSignal:
    channel: int
    can_id: int
    can_id_hex: str
    message_name: str
    signal_name: str
    canonical_name: str
    required: bool
    source_group: SourceMessageGroup
    dbc_signal: DbcSignal
    selection_order: int


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_matlab_can_column(name: str) -> MatlabCanColumn | None:
    match = CAN_COLUMN_RE.fullmatch(name.strip())
    if match is None:
        return None
    can_text, channel_text, dlc_text, byte_text = match.groups()
    can_id = int(can_text, 16)
    channel = int(channel_text)
    dlc = int(dlc_text)
    byte_index = int(byte_text)
    if channel < 0 or dlc <= 0 or dlc > 64 or byte_index < 0:
        raise CanAdapterError(f"CAN_COLUMN_RANGE:{name}")
    return MatlabCanColumn(
        original_name=name,
        can_id=can_id,
        can_id_hex=f"0x{can_id:X}",
        channel=channel,
        dlc=dlc,
        byte_index=byte_index,
    )


def _decode_sample(sample: bytes) -> tuple[str, str]:
    failures = []
    for encoding in ("utf-8-sig", "utf-8", "cp932", "shift_jis"):
        try:
            return sample.decode(encoding), encoding
        except UnicodeDecodeError as exc:
            failures.append(f"{encoding}:{exc.start}")
    raise CanAdapterError(f"SOURCE_ENCODING:{'|'.join(failures)}")


def _parse_line(line: str, delimiter: str) -> list[str]:
    return next(csv.reader([line], delimiter=delimiter))


def detect_text_format(path: Path, max_sample_bytes: int = 4_194_304) -> TextFormatInfo:
    if not path.is_file():
        raise CanAdapterError("SOURCE_FILE")
    with path.open("rb") as stream:
        sample = stream.read(max_sample_bytes)
    if not sample:
        raise CanAdapterError("SOURCE_EMPTY")
    text, encoding = _decode_sample(sample)
    lines = text.splitlines()
    if not lines:
        raise CanAdapterError("SOURCE_NO_LINES")

    sniffer_delimiter = None
    try:
        sniffer_delimiter = csv.Sniffer().sniff(text[:65536], delimiters=",\t;").delimiter
    except csv.Error:
        pass

    candidates: list[tuple[int, int, int, str, list[str], int]] = []
    delimiters = (",", "\t", ";")
    for row_index, line in enumerate(lines[:200]):
        for delimiter_order, delimiter in enumerate(delimiters):
            try:
                columns = _parse_line(line, delimiter)
            except csv.Error:
                continue
            can_count = sum(parse_matlab_can_column(column) is not None for column in columns)
            if can_count:
                candidates.append((can_count, len(columns), -delimiter_order, delimiter, columns, row_index))
    if not candidates:
        raise CanAdapterError("CAN_HEADER_NOT_FOUND")
    candidates.sort(reverse=True, key=lambda item: (item[0], item[1], item[2], -item[5]))
    can_count, _, _, delimiter, columns, header_row_index = candidates[0]
    warnings: list[str] = []
    if sniffer_delimiter is not None and sniffer_delimiter != delimiter:
        warnings.append(f"SNIFFER_DISAGREEMENT:{repr(sniffer_delimiter)}->{repr(delimiter)}")
    if can_count < 1:
        raise CanAdapterError("CAN_HEADER_EMPTY")
    return TextFormatInfo(
        encoding=encoding,
        delimiter=delimiter,
        header_row_index=header_row_index,
        columns=[column.strip() for column in columns],
        sample_bytes_read=len(sample),
        warnings=warnings,
    )


def discover_source_message_groups(columns: Sequence[str]) -> list[SourceMessageGroup]:
    grouped: dict[tuple[int, int, int], dict[int, str]] = {}
    positions: dict[tuple[int, int, int], int] = {}
    warnings: dict[tuple[int, int, int], list[str]] = {}
    for position, name in enumerate(columns):
        parsed = parse_matlab_can_column(name)
        if parsed is None:
            continue
        key = (parsed.channel, parsed.can_id, parsed.dlc)
        positions.setdefault(key, position)
        grouped.setdefault(key, {})
        warnings.setdefault(key, [])
        if parsed.byte_index in grouped[key]:
            warnings[key].append(f"DUPLICATE_BYTE_INDEX:{parsed.byte_index}")
        else:
            grouped[key][parsed.byte_index] = parsed.original_name

    result = []
    for channel, can_id, dlc in sorted(grouped, key=lambda key: positions[key]):
        byte_columns = grouped[(channel, can_id, dlc)]
        expected = set(range(dlc))
        actual = set(byte_columns)
        group_warnings = list(warnings[(channel, can_id, dlc)])
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        if missing:
            group_warnings.append("MISSING_BYTES:" + ".".join(str(value) for value in missing))
        if extra:
            group_warnings.append("EXTRA_BYTES:" + ".".join(str(value) for value in extra))
        complete = not group_warnings and actual == expected
        result.append(
            SourceMessageGroup(
                can_id=can_id,
                can_id_hex=f"0x{can_id:X}",
                channel=channel,
                dlc=dlc,
                byte_columns_by_index=dict(sorted(byte_columns.items())),
                complete=complete,
                first_column_position=positions[(channel, can_id, dlc)],
                warnings=group_warnings,
            )
        )
    return result


def load_dbc_text(path: Path) -> tuple[str, str]:
    if not path.is_file():
        raise CanAdapterError("DBC_FILE")
    payload = path.read_bytes()
    if not payload:
        raise CanAdapterError("DBC_EMPTY")
    return _decode_sample(payload)


def normalize_dbc_message_id(raw_message_id: int) -> tuple[int, bool]:
    if raw_message_id < 0:
        raise CanAdapterError("DBC_MESSAGE_ID")
    if raw_message_id & 0x80000000:
        return raw_message_id & 0x1FFFFFFF, True
    return raw_message_id, raw_message_id > 0x7FF


def _optional_float(text: str) -> float | None:
    stripped = text.strip()
    if not stripped:
        return None
    try:
        value = float(stripped)
    except ValueError as exc:
        raise CanAdapterError(f"DBC_FLOAT:{stripped}") from exc
    if not math.isfinite(value):
        raise CanAdapterError(f"DBC_FLOAT_NONFINITE:{stripped}")
    return value


def parse_dbc(path: Path, channel: int) -> DbcParseResult:
    text, encoding = load_dbc_text(path)
    messages: list[DbcMessage] = []
    current: DbcMessage | None = None
    value_maps: dict[tuple[int, str], dict[int, str]] = {}
    warning_count = 0

    for line in text.splitlines():
        bo_match = BO_RE.match(line)
        if bo_match:
            raw_id = int(bo_match.group(1))
            can_id, extended = normalize_dbc_message_id(raw_id)
            current = DbcMessage(
                raw_message_id=raw_id,
                can_id=can_id,
                can_id_hex=f"0x{can_id:X}",
                is_extended=extended,
                message_name=bo_match.group(2).strip(),
                dlc=int(bo_match.group(3)),
                transmitter=bo_match.group(4).strip(),
            )
            messages.append(current)
            continue

        sg_match = SG_RE.match(line)
        if sg_match:
            if current is None:
                warning_count += 1
                continue
            start_bit = int(sg_match.group(2))
            bit_length = int(sg_match.group(3))
            if bit_length <= 0:
                raise CanAdapterError(f"DBC_BIT_LENGTH:{sg_match.group(1)}")
            factor = _optional_float(sg_match.group(6))
            offset = _optional_float(sg_match.group(7))
            if factor is None or offset is None:
                raise CanAdapterError(f"DBC_SCALE:{sg_match.group(1)}")
            receiver_text = sg_match.group(11).strip()
            receivers = [item.strip() for item in receiver_text.split(",") if item.strip()]
            current.signals.append(
                DbcSignal(
                    signal_name=sg_match.group(1),
                    start_bit=start_bit,
                    bit_length=bit_length,
                    byte_order="little_endian" if sg_match.group(4) == "1" else "big_endian",
                    is_signed=sg_match.group(5) == "-",
                    factor=factor,
                    offset=offset,
                    minimum=_optional_float(sg_match.group(8)),
                    maximum=_optional_float(sg_match.group(9)),
                    unit=sg_match.group(10),
                    receivers=receivers,
                )
            )
            continue

        val_match = VAL_RE.match(line)
        if val_match:
            raw_id = int(val_match.group(1))
            can_id, _ = normalize_dbc_message_id(raw_id)
            mapping = {
                int(number): label.replace(r'\"', '"').replace(r"\\\\", "\\")
                for number, label in VAL_PAIR_RE.findall(val_match.group(3))
            }
            value_maps[(can_id, val_match.group(2))] = mapping

    identities: set[tuple[int, str]] = set()
    for message in messages:
        for signal in message.signals:
            identity = (message.can_id, signal.signal_name)
            if identity in identities:
                raise CanAdapterError(f"DBC_DUPLICATE_SIGNAL:{message.can_id_hex}:{signal.signal_name}")
            identities.add(identity)
            signal.value_map.update(value_maps.get(identity, {}))

    if not messages:
        raise CanAdapterError(f"DBC_NO_MESSAGES:CH{channel}")
    return DbcParseResult(channel=channel, encoding=encoding, messages=messages, warning_count=warning_count)


def _validate_payload(payload: bytes | Sequence[int]) -> list[int]:
    values = list(payload)
    if not values:
        raise CanAdapterError("PAYLOAD_EMPTY")
    if any(isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 255 for value in values):
        raise CanAdapterError("PAYLOAD_BYTE")
    return values


def extract_raw_unsigned(
    payload: bytes | Sequence[int], start_bit: int, bit_length: int, byte_order: str
) -> int:
    values = _validate_payload(payload)
    if start_bit < 0 or bit_length <= 0 or bit_length > 64:
        raise CanAdapterError("BIT_RANGE")
    if byte_order == "little_endian":
        if start_bit + bit_length > len(values) * 8:
            raise CanAdapterError("BIT_OUT_OF_PAYLOAD")
        packed = int.from_bytes(bytes(values), byteorder="little", signed=False)
        return (packed >> start_bit) & ((1 << bit_length) - 1)
    if byte_order != "big_endian":
        raise CanAdapterError("BYTE_ORDER")

    position = start_bit
    result = 0
    for _ in range(bit_length):
        byte_index = position // 8
        bit_index = position % 8
        if byte_index < 0 or byte_index >= len(values):
            raise CanAdapterError("BIT_OUT_OF_PAYLOAD")
        result = (result << 1) | ((values[byte_index] >> bit_index) & 1)
        position = position + 15 if bit_index == 0 else position - 1
    return result


def apply_signedness(raw_unsigned: int, bit_length: int, is_signed: bool) -> int:
    if raw_unsigned < 0 or bit_length <= 0:
        raise CanAdapterError("SIGNEDNESS_INPUT")
    limit = 1 << bit_length
    if raw_unsigned >= limit:
        raise CanAdapterError("SIGNEDNESS_RANGE")
    if is_signed and raw_unsigned & (1 << (bit_length - 1)):
        return raw_unsigned - limit
    return raw_unsigned


def decode_physical_value(payload: bytes | Sequence[int], signal: DbcSignal) -> tuple[int, float]:
    raw_unsigned = extract_raw_unsigned(payload, signal.start_bit, signal.bit_length, signal.byte_order)
    raw_code = apply_signedness(raw_unsigned, signal.bit_length, signal.is_signed)
    physical = raw_code * signal.factor + signal.offset
    if not math.isfinite(physical):
        raise CanAdapterError("PHYSICAL_NONFINITE")
    return raw_code, physical


def parse_byte_cell(value: Any) -> int:
    if value is None:
        raise CanAdapterError("BYTE_BLANK")
    text = str(value).strip()
    if not text:
        raise CanAdapterError("BYTE_BLANK")
    try:
        if text.lower().startswith("0x"):
            number = int(text, 16)
        else:
            numeric = float(text)
            if not math.isfinite(numeric) or not numeric.is_integer():
                raise ValueError(text)
            number = int(numeric)
    except ValueError as exc:
        raise CanAdapterError(f"BYTE_FORMAT:{text}") from exc
    if not 0 <= number <= 255:
        raise CanAdapterError(f"BYTE_RANGE:{text}")
    return number


def canonical_name(channel: int, can_id: int, signal_name: str) -> str:
    raw = f"CH{channel}_ID{can_id:X}_{signal_name}"
    sanitized = re.sub(r"[^A-Za-z0-9_]", "_", raw)
    sanitized = re.sub(r"_+", "_", sanitized).strip("_")
    if not sanitized:
        raise CanAdapterError("CANONICAL_NAME_EMPTY")
    return sanitized


def _dbc_index(dbc_results: Iterable[DbcParseResult]) -> dict[tuple[int, int], DbcMessage]:
    result: dict[tuple[int, int], DbcMessage] = {}
    for parsed in dbc_results:
        for message in parsed.messages:
            key = (parsed.channel, message.can_id)
            if key in result:
                raise CanAdapterError(f"DBC_DUPLICATE_MESSAGE:CH{parsed.channel}:{message.can_id_hex}")
            result[key] = message
    return result


def resolve_selection(
    groups: Sequence[SourceMessageGroup],
    dbc_results: Sequence[DbcParseResult],
    selection_mode: str,
    requested: Sequence[dict[str, Any]],
) -> list[SelectedSignal]:
    group_index = {(group.channel, group.can_id): group for group in groups}
    dbc_index = _dbc_index(dbc_results)
    selected: list[SelectedSignal] = []

    if selection_mode == "ALL_TECHNICALLY_ELIGIBLE":
        order = 0
        for group in sorted(groups, key=lambda item: item.first_column_position):
            message = dbc_index.get((group.channel, group.can_id))
            if message is None or not group.complete:
                continue
            for signal in message.signals:
                selected.append(
                    SelectedSignal(
                        channel=group.channel,
                        can_id=group.can_id,
                        can_id_hex=group.can_id_hex,
                        message_name=message.message_name,
                        signal_name=signal.signal_name,
                        canonical_name=canonical_name(group.channel, group.can_id, signal.signal_name),
                        required=False,
                        source_group=group,
                        dbc_signal=signal,
                        selection_order=order,
                    )
                )
                order += 1
    elif selection_mode == "CONTROLLED_PROFILE":
        if not requested:
            raise CanAdapterError("CONTROLLED_SELECTION_EMPTY")
        for order, item in enumerate(requested):
            if not isinstance(item, dict):
                raise CanAdapterError("SELECTION_ITEM")
            try:
                channel = int(item["Channel"])
                can_value = item["CAN_ID"]
                if isinstance(can_value, bool):
                    raise ValueError(can_value)
                if isinstance(can_value, int):
                    can_id = can_value
                else:
                    can_text = str(can_value).strip()
                    can_id = int(can_text, 16)
                signal_name = str(item["SignalName"])
            except (KeyError, TypeError, ValueError) as exc:
                raise CanAdapterError(f"SELECTION_FIELDS:{order}") from exc
            required = bool(item.get("Required", False))
            group = group_index.get((channel, can_id))
            message = dbc_index.get((channel, can_id))
            if group is None or message is None or not group.complete:
                if required:
                    raise CanAdapterError(f"REQUIRED_SELECTION_UNAVAILABLE:{order}")
                continue
            signal = next((candidate for candidate in message.signals if candidate.signal_name == signal_name), None)
            if signal is None:
                if required:
                    raise CanAdapterError(f"REQUIRED_SIGNAL_UNAVAILABLE:{order}")
                continue
            name = str(item.get("CanonicalName") or canonical_name(channel, can_id, signal_name))
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
                raise CanAdapterError(f"CANONICAL_NAME:{name}")
            selected.append(
                SelectedSignal(
                    channel=channel,
                    can_id=can_id,
                    can_id_hex=f"0x{can_id:X}",
                    message_name=message.message_name,
                    signal_name=signal.signal_name,
                    canonical_name=name,
                    required=required,
                    source_group=group,
                    dbc_signal=signal,
                    selection_order=order,
                )
            )
    else:
        raise CanAdapterError(f"SELECTION_MODE:{selection_mode}")

    identities = [(item.channel, item.can_id, item.signal_name) for item in selected]
    names = [item.canonical_name for item in selected]
    if len(identities) != len(set(identities)):
        raise CanAdapterError("SELECTION_DUPLICATE")
    if len(names) != len(set(names)):
        raise CanAdapterError("CANONICAL_NAME_COLLISION")
    if not selected:
        raise CanAdapterError("NO_SELECTED_SIGNALS")
    return selected


def iter_source_rows(path: Path, format_info: TextFormatInfo) -> Iterator[tuple[int, dict[str, str]]]:
    with path.open("r", encoding=format_info.encoding, newline="") as stream:
        for _ in range(format_info.header_row_index):
            next(stream, None)
        reader = csv.DictReader(stream, delimiter=format_info.delimiter)
        if reader.fieldnames is None:
            raise CanAdapterError("SOURCE_HEADER")
        normalized = [field.strip() if field is not None else "" for field in reader.fieldnames]
        if normalized != format_info.columns:
            raise CanAdapterError("SOURCE_HEADER_CHANGED")
        for index, row in enumerate(reader):
            yield index, {str(key).strip(): value for key, value in row.items() if key is not None}


def resolve_provenance_columns(columns: Sequence[str]) -> tuple[str | None, str | None]:
    def key(value: str) -> str:
        return re.sub(r"[^a-z0-9]", "", value.lower())

    mapping = {key(column): column for column in columns}
    datetime_column = next(
        (mapping[name] for name in ("datetime", "sourcedatetime", "dateandtime") if name in mapping),
        None,
    )
    time_us_column = next(
        (mapping[name] for name in ("timeus", "sourcetimeus", "microseconds") if name in mapping),
        None,
    )
    return datetime_column, time_us_column


def classify_message_cells(row: dict[str, str], group: SourceMessageGroup) -> tuple[str, list[int] | None]:
    cells = [row.get(group.byte_columns_by_index[index], "") for index in range(group.dlc)]
    present = [str(value).strip() != "" for value in cells]
    if not any(present):
        return "NO_UPDATE", None
    if not all(present):
        return "INCOMPLETE_MESSAGE", None
    try:
        return "DECODED_UPDATE", [parse_byte_cell(value) for value in cells]
    except CanAdapterError:
        return "INVALID_BYTE", None


def value_kind_hint(signal: DbcSignal) -> str:
    if signal.value_map:
        return "ENUM"
    if signal.bit_length == 1 and signal.factor == 1 and signal.offset == 0:
        return "BOOLEAN"
    if signal.factor.is_integer() and signal.offset.is_integer():
        return "INTEGER"
    return "FLOAT"


def signal_to_catalog_row(selected: SelectedSignal) -> dict[str, Any]:
    signal = selected.dbc_signal
    group = selected.source_group
    return {
        "SourceAdapterId": "CameraRadar.U001.MatlabCanCsvDbc",
        "SourceAdapterVersion": "1.1.0",
        "SourceType": "CAN",
        "SourceChannel": selected.channel,
        "SourceMessageId": selected.can_id_hex,
        "SourceMessageName": selected.message_name,
        "SourceSignalName": selected.signal_name,
        "CanonicalNameCandidate": selected.canonical_name,
        "OriginalUnit": signal.unit,
        "ValueKindHint": value_kind_hint(signal),
        "DecodeDefinition": (
            f"{signal.start_bit}|{signal.bit_length}|{signal.byte_order}|"
            f"{'SIGNED' if signal.is_signed else 'UNSIGNED'}|{signal.factor}|{signal.offset}"
        ),
        "MessageDLC": group.dlc,
        "StartBit": signal.start_bit,
        "BitLength": signal.bit_length,
        "ByteOrder": signal.byte_order,
        "Signed": int(signal.is_signed),
        "Scale": signal.factor,
        "Offset": signal.offset,
        "DBCMinimum": "" if signal.minimum is None else signal.minimum,
        "DBCMaximum": "" if signal.maximum is None else signal.maximum,
        "EnumerationMap": json.dumps(signal.value_map, ensure_ascii=False, sort_keys=True),
        "SourceGroupComplete": int(group.complete),
        "SourceByteColumns": "|".join(group.byte_columns_by_index.values()),
        "Required": int(selected.required),
        "SelectionOrder": selected.selection_order,
    }


def serialize_dataclass(value: Any) -> Any:
    if hasattr(value, "__dataclass_fields__"):
        return {key: serialize_dataclass(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: serialize_dataclass(item) for key, item in value.items()}
    if isinstance(value, list):
        return [serialize_dataclass(item) for item in value]
    return value


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    parsed = parse_matlab_can_column("ID221_2_8_0")
    check(parsed is not None and parsed.can_id == 0x221 and parsed.channel == 2, "T01")
    columns = [f"ID221_2_8_{index}" for index in range(8)]
    groups = discover_source_message_groups(columns)
    check(len(groups) == 1 and groups[0].complete, "T02")
    incomplete = discover_source_message_groups(columns[:-1])
    check(len(incomplete) == 1 and not incomplete[0].complete, "T03")
    check(extract_raw_unsigned([0x34, 0x12], 0, 16, "little_endian") == 0x1234, "T04")
    check(apply_signedness(0xFF, 8, True) == -1, "T05")
    check(extract_raw_unsigned([0xAB, 0xCD], 7, 16, "big_endian") == 0xABCD, "T06")
    check(apply_signedness(0x8000, 16, True) == -32768, "T07")
    signal = DbcSignal("X", 0, 16, "little_endian", False, 0.1, -1.0, None, None, "m", [])
    check(decode_physical_value([100, 0], signal) == (100, 9.0), "T08")
    check(parse_byte_cell("0xFF") == 255 and parse_byte_cell("12.0") == 12, "T09")
    check(canonical_name(2, 0x251, "ID251_Distance") == "CH2_ID251_ID251_Distance", "T10")

    with tempfile.TemporaryDirectory(prefix="u001_h2_core_") as temporary:
        root = Path(temporary)
        dbc = root / "DBC2.dbc"
        dbc.write_text(
            'VERSION ""\n'
            'BO_ 1568 FrameMessage: 8 Vector\n'
            ' SG_ FrameCount : 0|16@1+ (1,0) [0|65535] "count" Vector\n'
            'BO_ 545 CameraTarget: 8 Vector\n'
            ' SG_ Distance : 0|16@1+ (0.01,0) [0|655.35] "m" Vector\n'
            ' SG_ SignedX : 23|16@0- (0.1,-1) [-3277.8|3275.7] "m" Vector\n'
            ' SG_ Flag : 32|1@1+ (1,0) [0|1] "" Vector\n'
            'VAL_ 545 Flag 0 "Off" 1 "On" ;\n',
            encoding="utf-8",
        )
        result = parse_dbc(dbc, 2)
        check(len(result.messages) == 2, "T11")
        check(result.messages[1].signals[0].byte_order == "little_endian", "T12")
        check(result.messages[1].signals[1].byte_order == "big_endian", "T13")
        check(result.messages[1].signals[1].is_signed, "T14")
        check(result.messages[1].signals[0].factor == 0.01, "T15")
        check(result.messages[1].signals[2].value_map == {0: "Off", 1: "On"}, "T16")

        source = root / "CANDump.csv"
        header = [
            "DateTime",
            "Time[us]",
            *[f"ID620_2_8_{index}" for index in range(8)],
            *[f"ID221_2_8_{index}" for index in range(8)],
        ]
        rows = [
            ["", "", 100, 0, 0, 0, 0, 0, 0, 0, 210, 4, 0, 0, 1, 0, 0, 0],
            ["", "", "", "", "", "", "", "", "", "", 220, 4, 0, 0, 0, 0, 0, 0],
            ["", "", 101, 0, 0, 0, 0, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ]
        with source.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(header)
            writer.writerows(rows)
        detected = detect_text_format(source)
        check(detected.delimiter == "," and detected.header_row_index == 0, "T17")
        source_groups = discover_source_message_groups(detected.columns)
        check(len(source_groups) == 2 and all(group.complete for group in source_groups), "T18")
        selected = resolve_selection(source_groups, [result], "ALL_TECHNICALLY_ELIGIBLE", [])
        check(len(selected) == 4, "T19")
        controlled = resolve_selection(
            source_groups,
            [result],
            "CONTROLLED_PROFILE",
            [{"Channel": 2, "CAN_ID": "0x221", "SignalName": "Distance", "Required": True}],
        )
        check(len(controlled) == 1 and controlled[0].canonical_name == "CH2_ID221_Distance", "T20")
        source_rows = list(iter_source_rows(source, detected))
        check(len(source_rows) == 3 and source_rows[2][0] == 2, "T21")
        camera_group = next(group for group in source_groups if group.can_id == 0x221)
        check(classify_message_cells(source_rows[0][1], camera_group)[0] == "DECODED_UPDATE", "T22")
        check(classify_message_cells(source_rows[2][1], camera_group)[0] == "NO_UPDATE", "T23")
        date_column, time_column = resolve_provenance_columns(detected.columns)
        check(date_column == "DateTime" and time_column == "Time[us]", "T24")

    if checks != 24:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H2-CAN-DBC-CORE-SELFTEST-PASS-24")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 MATLAB CAN CSV + DBC core")
    parser.add_argument("--self-test", action="store_true", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    _parser().parse_args(argv)
    try:
        self_test()
        return 0
    except (CanAdapterError, AssertionError) as exc:
        print(f"U1H2CE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
