#!/usr/bin/env python3
"""U001 source adapter for MATLAB-format CAN CSV and channel DBC files.

The adapter is deliberately narrow.  It discovers source structure, decodes
real message updates, and emits a canonical long update stream in original
source order.  Frame assignment, semantic invalid-value policy, forward hold,
wide frame construction, camera arbitration, and analysis are not performed
here.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

from u001_matlab_can_csv_dbc_core_v1_0 import (
    CanAdapterError,
    DbcParseResult,
    SelectedSignal,
    classify_message_cells,
    decode_physical_value,
    detect_text_format,
    discover_source_message_groups,
    iter_source_rows,
    parse_dbc,
    resolve_provenance_columns,
    resolve_selection,
    sha256_file,
    signal_to_catalog_row,
    value_kind_hint,
)


ADAPTER_ID = "CameraRadar.U001.MatlabCanCsvDbc"
ADAPTER_VERSION = "1.1.0"
HOST_API_VERSION = "U001_INPUT_ADAPTER_HOST_API_V0_1"
REQUEST_SCHEMA = "U001_INPUT_ADAPTER_REQUEST_V0_1"
OUTPUT_BOUNDARY = "U001_CANONICAL_SOURCE_UPDATES_V0_1"

UPDATE_FILE = "u001_adapter_source_updates.csv"
CATALOG_FILE = "u001_adapter_signal_catalog.csv"
QUALITY_FILE = "u001_adapter_quality.json"
MANIFEST_FILE = "u001_adapter_run_manifest.json"
CAPSULE_FILE = "u001_adapter_completion_capsule.txt"
PREFLIGHT_FILE = "u001_adapter_preflight.json"
INVENTORY_CATALOG_FILE = "u001_source_capability_catalog.csv"
INVENTORY_SUMMARY_FILE = "u001_source_inventory.json"
INVENTORY_CAPSULE_FILE = "u001_source_inventory_capsule.txt"

UPDATE_COLUMNS = [
    "SourceRowIndex",
    "SourceId",
    "SourceType",
    "SourceAdapterId",
    "SourceAdapterVersion",
    "ClockDomain",
    "NativeTimestamp",
    "NativeSequence",
    "SyncKeyCandidate",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "RawCode",
    "PhysicalValue",
    "ValueLabel",
    "OriginalUnit",
    "ValueKindHint",
    "DecodeValid",
    "DecodeIssue",
]

CATALOG_COLUMNS = [
    "SourceAdapterId",
    "SourceAdapterVersion",
    "SourceType",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "OriginalUnit",
    "ValueKindHint",
    "DecodeDefinition",
    "MessageDLC",
    "StartBit",
    "BitLength",
    "ByteOrder",
    "Signed",
    "Scale",
    "Offset",
    "DBCMinimum",
    "DBCMaximum",
    "EnumerationMap",
    "SourceGroupComplete",
    "SourceByteColumns",
    "Required",
    "SelectionOrder",
]

INVENTORY_COLUMNS = [
    "CatalogItemId",
    "SourceAdapterId",
    "SourceAdapterVersion",
    "SourceType",
    "ObservationFamily",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "OriginalUnit",
    "ValueKindHint",
    "MessageDLC",
    "StartBit",
    "BitLength",
    "ByteOrder",
    "Signed",
    "Scale",
    "Offset",
    "DBCMinimum",
    "DBCMaximum",
    "SourceGroupComplete",
    "TechnicallyDecodable",
    "SourceByteColumns",
    "SearchText",
]


class AdapterError(RuntimeError):
    """Fail-closed production adapter error."""


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _prepare_empty_directory(path: Path, label: str) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise AdapterError(f"{label}_NOT_EMPTY")


def _read_request(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AdapterError(f"REQUEST_JSON:{exc}") from exc
    if not isinstance(value, dict):
        raise AdapterError("REQUEST_NOT_OBJECT")
    required = ("RequestSchemaVersion", "RequestId", "DatasetId", "RunId", "SegmentId", "SourceId")
    for key in required:
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise AdapterError(f"REQUEST_FIELD:{key}")
    if value["RequestSchemaVersion"] != REQUEST_SCHEMA:
        raise AdapterError("REQUEST_SCHEMA")
    if not isinstance(value.get("Inputs", []), list):
        raise AdapterError("REQUEST_INPUTS")
    if not isinstance(value.get("Configuration", {}), dict):
        raise AdapterError("REQUEST_CONFIGURATION")
    return value


def _input_kind(item: dict[str, Any]) -> str:
    value = item.get("Kind", item.get("InputKind", item.get("Type", "")))
    return str(value).strip().upper()


def _input_path(item: dict[str, Any]) -> Path:
    value = item.get("Path", item.get("FilePath"))
    if not isinstance(value, str) or not value.strip():
        raise AdapterError("INPUT_PATH")
    return Path(value)


def _production_inputs(request: dict[str, Any]) -> tuple[Path, dict[int, Path]]:
    csv_paths: list[Path] = []
    dbc_paths: dict[int, Path] = {}
    for index, item in enumerate(request.get("Inputs", [])):
        if not isinstance(item, dict):
            raise AdapterError(f"INPUT_ITEM:{index}")
        kind = _input_kind(item)
        path = _input_path(item)
        if not path.is_file():
            raise AdapterError(f"INPUT_FILE:{index}")
        if kind in {"MATLAB_CAN_CSV", "CAN_CSV"}:
            csv_paths.append(path)
        elif kind in {"DBC_CHANNEL", "DBC"}:
            try:
                channel = int(item["Channel"])
            except (KeyError, TypeError, ValueError) as exc:
                raise AdapterError(f"DBC_CHANNEL:{index}") from exc
            if channel in dbc_paths:
                raise AdapterError(f"DBC_CHANNEL_DUPLICATE:{channel}")
            dbc_paths[channel] = path
        else:
            raise AdapterError(f"INPUT_KIND:{kind or index}")
    if len(csv_paths) != 1:
        raise AdapterError(f"MATLAB_CAN_CSV_COUNT:{len(csv_paths)}")
    if not dbc_paths:
        raise AdapterError("DBC_INPUT_EMPTY")
    return csv_paths[0], dbc_paths


def _synthetic_inputs(root: Path) -> tuple[Path, dict[int, Path]]:
    source = root / "CANDump.csv"
    dbc1 = root / "DBC1.dbc"
    dbc2 = root / "DBC2.dbc"
    dbc1.write_text(
        'VERSION ""\n'
        'BO_ 896 RadarObject: 8 Vector\n'
        ' SG_ DistanceToObject : 0|16@1+ (0.01,0) [0|655.35] "m" Vector\n'
        ' SG_ PrecedingVehicleDetectionFlag : 16|1@1+ (1,0) [0|1] "" Vector\n',
        encoding="utf-8",
    )
    dbc2.write_text(
        'VERSION ""\n'
        'BO_ 1568 FrameMessage: 8 Vector\n'
        ' SG_ FrameCount : 0|16@1+ (1,0) [0|65535] "count" Vector\n'
        'BO_ 545 CameraTarget: 8 Vector\n'
        ' SG_ Distance : 0|16@1+ (0.01,0) [0|655.35] "m" Vector\n'
        ' SG_ LateralPosition : 16|16@1- (0.01,0) [-327.68|327.67] "m" Vector\n'
        ' SG_ ObjectType : 32|4@1+ (1,0) [0|15] "" Vector\n'
        'VAL_ 545 ObjectType 0 "Unknown" 1 "Vehicle" ;\n',
        encoding="utf-8",
    )
    header = [
        "DateTime",
        "Time[us]",
        *[f"ID620_2_8_{index}" for index in range(8)],
        *[f"ID221_2_8_{index}" for index in range(8)],
        *[f"ID380_1_8_{index}" for index in range(8)],
    ]
    rows = [
        ["2026-01-01 00:00:00.000", 0, 100, 0, 0, 0, 0, 0, 0, 0,
         210, 4, 25, 0, 1, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["2026-01-01 00:00:00.001", 1000, "", "", "", "", "", "", "", "",
         "", "", "", "", "", "", "", "", 15, 4, 1, 0, 0, 0, 0, 0],
        ["2026-01-01 00:00:00.002", 2000, 101, 0, 0, 0, 0, 0, 0, 0,
         220, 4, 20, 0, 0, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["2026-01-01 00:00:00.003", 3000, "", "", "", "", "", "", "", "",
         230, 4, "", "", 1, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["2026-01-01 00:00:00.004", 4000, "", "", "", "", "", "", "", "",
         "", "", "", "", "", "", "", "", 999, 0, 0, 0, 0, 0, 0, 0],
    ]
    with source.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)
    return source, {1: dbc1, 2: dbc2}


def _configuration(request: dict[str, Any], test_mode: bool) -> dict[str, Any]:
    raw = dict(request.get("Configuration", {}))
    selection_mode = str(raw.get("SelectionMode", "ALL_TECHNICALLY_ELIGIBLE")).strip().upper()
    if selection_mode not in {"ALL_TECHNICALLY_ELIGIBLE", "CONTROLLED_PROFILE"}:
        raise AdapterError(f"SELECTION_MODE:{selection_mode}")
    selected_signals = raw.get("SelectedSignals", [])
    if not isinstance(selected_signals, list):
        raise AdapterError("SELECTED_SIGNALS")
    frame_key = raw.get("FrameKey")
    if frame_key is None and test_mode:
        frame_key = {"Channel": 2, "CAN_ID": "0x620", "SignalName": "FrameCount"}
    if frame_key is not None and not isinstance(frame_key, dict):
        raise AdapterError("FRAME_KEY")
    max_rows_raw = raw.get("MaxSourceRows")
    if max_rows_raw in (None, "", 0, "0"):
        max_rows = None
    else:
        try:
            max_rows = int(max_rows_raw)
        except (TypeError, ValueError) as exc:
            raise AdapterError("MAX_SOURCE_ROWS") from exc
        if max_rows <= 0:
            raise AdapterError("MAX_SOURCE_ROWS")
    try:
        chunk_rows = int(raw.get("ChunkRows", 10000))
    except (TypeError, ValueError) as exc:
        raise AdapterError("CHUNK_ROWS") from exc
    if chunk_rows < 1:
        raise AdapterError("CHUNK_ROWS")
    try:
        worker_count = int(raw.get("WorkerCount", 1))
        max_in_flight = int(raw.get("MaxInFlightChunks", 2))
        max_memory_mb = int(raw.get("MaxResidentMemoryMB", 512))
        output_shard_rows = int(raw.get("OutputShardRows", 250000))
    except (TypeError, ValueError) as exc:
        raise AdapterError("RESOURCE_POLICY") from exc
    if worker_count != 1:
        raise AdapterError("WORKER_COUNT_NOT_QUALIFIED")
    if not 1 <= max_in_flight <= 32:
        raise AdapterError("MAX_IN_FLIGHT_CHUNKS")
    if not 128 <= max_memory_mb <= 4096:
        raise AdapterError("MAX_RESIDENT_MEMORY_MB")
    if not 1000 <= output_shard_rows <= 5_000_000:
        raise AdapterError("OUTPUT_SHARD_ROWS")
    write_order = str(raw.get("WriteOrderPolicy", "SOURCE_ORDER")).strip().upper()
    if write_order != "SOURCE_ORDER":
        raise AdapterError("WRITE_ORDER_POLICY")
    return {
        "SelectionMode": selection_mode,
        "SelectedSignals": selected_signals,
        "FrameKey": frame_key,
        "MaxSourceRows": max_rows,
        "ChunkRows": chunk_rows,
        "WorkerCount": worker_count,
        "MaxInFlightChunks": max_in_flight,
        "MaxResidentMemoryMB": max_memory_mb,
        "OutputShardRows": output_shard_rows,
        "WriteOrderPolicy": write_order,
    }


def _parse_can_id(value: Any) -> int:
    if isinstance(value, bool):
        raise AdapterError("CAN_ID")
    if isinstance(value, int):
        return value
    text = str(value).strip()
    try:
        return int(text, 16)
    except ValueError as exc:
        raise AdapterError(f"CAN_ID:{text}") from exc


def _frame_identity(frame_key: dict[str, Any] | None) -> tuple[int, int, str] | None:
    if frame_key is None:
        return None
    try:
        return (
            int(frame_key["Channel"]),
            _parse_can_id(frame_key["CAN_ID"]),
            str(frame_key["SignalName"]),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise AdapterError("FRAME_KEY_FIELDS") from exc


def _load_source_definition(
    source: Path,
    dbc_paths: dict[int, Path],
    configuration: dict[str, Any],
) -> tuple[Any, list[Any], list[DbcParseResult], list[SelectedSignal]]:
    text_format = detect_text_format(source)
    groups = discover_source_message_groups(text_format.columns)
    dbc_results = [parse_dbc(path, channel) for channel, path in sorted(dbc_paths.items())]
    selected = resolve_selection(
        groups,
        dbc_results,
        configuration["SelectionMode"],
        configuration["SelectedSignals"],
    )
    frame_identity = _frame_identity(configuration["FrameKey"])
    if frame_identity is not None:
        selected_identities = {(item.channel, item.can_id, item.signal_name) for item in selected}
        if frame_identity not in selected_identities:
            if configuration["SelectionMode"] == "CONTROLLED_PROFILE":
                requested = list(configuration["SelectedSignals"])
                requested.append({
                    "Channel": frame_identity[0],
                    "CAN_ID": f"0x{frame_identity[1]:X}",
                    "SignalName": frame_identity[2],
                    "Required": True,
                })
                selected = resolve_selection(groups, dbc_results, "CONTROLLED_PROFILE", requested)
            else:
                raise AdapterError("FRAME_KEY_NOT_SELECTED")
    return text_format, groups, dbc_results, selected


def describe() -> dict[str, Any]:
    return {
        "AdapterId": ADAPTER_ID,
        "AdapterVersion": ADAPTER_VERSION,
        "HostApiVersion": HOST_API_VERSION,
        "OutputBoundary": OUTPUT_BOUNDARY,
        "SupportedActions": ["DESCRIBE", "SELF_TEST", "INVENTORY", "PREFLIGHT", "RUN"],
    }


def _catalog_item_id(selected: SelectedSignal) -> str:
    return f"CAN.CH{selected.channel}.ID{selected.can_id:X}.{selected.signal_name}"


def _inventory_row(selected: SelectedSignal) -> dict[str, Any]:
    signal = selected.dbc_signal
    group = selected.source_group
    item_id = _catalog_item_id(selected)
    search_text = " ".join(
        (
            item_id,
            f"CH{selected.channel}",
            selected.can_id_hex,
            selected.message_name,
            selected.signal_name,
            selected.canonical_name,
            signal.unit,
            value_kind_hint(signal),
        )
    ).lower()
    return {
        "CatalogItemId": item_id,
        "SourceAdapterId": ADAPTER_ID,
        "SourceAdapterVersion": ADAPTER_VERSION,
        "SourceType": "CAN",
        "ObservationFamily": "TABULAR_SIGNAL_UPDATE",
        "SourceChannel": selected.channel,
        "SourceMessageId": selected.can_id_hex,
        "SourceMessageName": selected.message_name,
        "SourceSignalName": selected.signal_name,
        "CanonicalNameCandidate": selected.canonical_name,
        "OriginalUnit": signal.unit,
        "ValueKindHint": value_kind_hint(signal),
        "MessageDLC": group.dlc,
        "StartBit": signal.start_bit,
        "BitLength": signal.bit_length,
        "ByteOrder": signal.byte_order,
        "Signed": int(signal.is_signed),
        "Scale": signal.factor,
        "Offset": signal.offset,
        "DBCMinimum": "" if signal.minimum is None else signal.minimum,
        "DBCMaximum": "" if signal.maximum is None else signal.maximum,
        "SourceGroupComplete": int(group.complete),
        "TechnicallyDecodable": 1,
        "SourceByteColumns": "|".join(group.byte_columns_by_index.values()),
        "SearchText": search_text,
    }


def inventory(request_path: Path, output_dir: Path) -> dict[str, Any]:
    """Discover decodable variables without scanning or decoding payload rows."""
    request = _read_request(request_path)
    test_mode = request.get("TestMode") is True
    _prepare_empty_directory(output_dir, "INVENTORY_OUTPUT")

    synthetic_context = tempfile.TemporaryDirectory(prefix="u001_h2_inventory_") if test_mode else None
    try:
        if test_mode:
            assert synthetic_context is not None
            source, dbc_paths = _synthetic_inputs(Path(synthetic_context.name))
        else:
            source, dbc_paths = _production_inputs(request)

        base_configuration = _configuration(request, test_mode)
        inventory_configuration = dict(base_configuration)
        inventory_configuration["SelectionMode"] = "ALL_TECHNICALLY_ELIGIBLE"
        inventory_configuration["SelectedSignals"] = []
        text_format, groups, dbc_results, available = _load_source_definition(
            source, dbc_paths, inventory_configuration
        )

        catalog_path = output_dir / INVENTORY_CATALOG_FILE
        with catalog_path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=INVENTORY_COLUMNS, extrasaction="raise")
            writer.writeheader()
            for selected in available:
                writer.writerow(_inventory_row(selected))

        complete_group_count = sum(group.complete for group in groups)
        dbc_signal_count = sum(
            len(message.signals)
            for dbc_result in dbc_results
            for message in dbc_result.messages
        )
        summary = {
            "InventorySchema": "U001_SOURCE_CAPABILITY_INVENTORY_V0_1",
            "AdapterId": ADAPTER_ID,
            "AdapterVersion": ADAPTER_VERSION,
            "RequestId": request["RequestId"],
            "Status": "COMPLETE",
            "CompletionCode": 0,
            "PayloadRowsDecoded": 0,
            "HeaderColumnCount": len(text_format.columns),
            "DetectedMessageGroupCount": len(groups),
            "CompleteMessageGroupCount": complete_group_count,
            "DBCSignalDefinitionCount": dbc_signal_count,
            "TechnicallyDecodableVariableCount": len(available),
            "CatalogSHA256": _sha256(catalog_path),
            "InputFingerprints": [
                {"FileName": source.name, "SHA256": sha256_file(source)},
                *[
                    {"FileName": path.name, "Channel": channel, "SHA256": sha256_file(path)}
                    for channel, path in sorted(dbc_paths.items())
                ],
            ],
            "Warnings": [
                *text_format.warnings,
                *[warning for group in groups for warning in group.warnings],
            ],
            "Errors": [],
        }
        _write_json(output_dir / INVENTORY_SUMMARY_FILE, summary)
        capsule = (
            f"U1INV-H{summary['HeaderColumnCount']}-"
            f"G{summary['DetectedMessageGroupCount']}-"
            f"V{summary['TechnicallyDecodableVariableCount']}-X0-C0"
        )
        (output_dir / INVENTORY_CAPSULE_FILE).write_text(capsule + "\n", encoding="utf-8")
        return summary
    finally:
        if synthetic_context is not None:
            synthetic_context.cleanup()


def preflight(request_path: Path, output_dir: Path) -> dict[str, Any]:
    request = _read_request(request_path)
    test_mode = request.get("TestMode") is True
    _prepare_empty_directory(output_dir, "PREFLIGHT_OUTPUT")
    with tempfile.TemporaryDirectory(prefix="u001_h2_preflight_") as temporary:
        if test_mode:
            source, dbc_paths = _synthetic_inputs(Path(temporary))
        else:
            source, dbc_paths = _production_inputs(request)
        configuration = _configuration(request, test_mode)
        text_format, groups, dbc_results, selected = _load_source_definition(
            source, dbc_paths, configuration
        )
        warnings = list(text_format.warnings)
        warnings.extend(
            warning
            for group in groups
            for warning in group.warnings
        )
        result = {
            "PreflightSchema": "U001_INPUT_ADAPTER_PREFLIGHT_V0_1",
            "AdapterId": ADAPTER_ID,
            "AdapterVersion": ADAPTER_VERSION,
            "RequestId": request["RequestId"],
            "Status": "READY",
            "CompletionCode": 0,
            "TestMode": test_mode,
            "SourceFileName": source.name,
            "DBCFileNames": [path.name for _, path in sorted(dbc_paths.items())],
            "DetectedEncoding": text_format.encoding,
            "DetectedDelimiter": text_format.delimiter,
            "HeaderRowIndex": text_format.header_row_index,
            "DetectedMessageGroupCount": len(groups),
            "CompleteMessageGroupCount": sum(group.complete for group in groups),
            "DBCMessageCount": sum(len(result.messages) for result in dbc_results),
            "SelectedSignalCount": len(selected),
            "SelectionMode": configuration["SelectionMode"],
            "FrameKeyConfigured": configuration["FrameKey"] is not None,
            "Warnings": warnings,
            "Errors": [],
        }
    _write_json(output_dir / PREFLIGHT_FILE, result)
    return result


def _write_catalog(path: Path, selected: Iterable[SelectedSignal]) -> int:
    rows = [signal_to_catalog_row(item) for item in selected]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=CATALOG_COLUMNS, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def _bounded_append(values: list[Any], value: Any, limit: int = 20) -> None:
    if len(values) < limit:
        values.append(value)


def _native_timestamp(row: dict[str, str], datetime_column: str | None, time_column: str | None) -> str:
    if datetime_column is not None:
        value = str(row.get(datetime_column, "")).strip()
        if value:
            return value
    if time_column is not None:
        return str(row.get(time_column, "")).strip()
    return ""


def _update_row(
    source_row_index: int,
    source_id: str,
    native_timestamp: str,
    selected: SelectedSignal,
    frame_identity: tuple[int, int, str] | None,
    raw_code: int | str,
    physical_value: float | str,
    decode_valid: int,
    decode_issue: str,
) -> dict[str, Any]:
    identity = (selected.channel, selected.can_id, selected.signal_name)
    sync_candidate: Any = ""
    if decode_valid and identity == frame_identity:
        sync_candidate = physical_value
    value_label = ""
    if decode_valid and isinstance(raw_code, int):
        value_label = selected.dbc_signal.value_map.get(raw_code, "")
    return {
        "SourceRowIndex": source_row_index,
        "SourceId": source_id,
        "SourceType": "CAN",
        "SourceAdapterId": ADAPTER_ID,
        "SourceAdapterVersion": ADAPTER_VERSION,
        "ClockDomain": "MATLAB_CAN_SOURCE_ORDER",
        "NativeTimestamp": native_timestamp,
        "NativeSequence": source_row_index,
        "SyncKeyCandidate": sync_candidate,
        "SourceChannel": selected.channel,
        "SourceMessageId": selected.can_id_hex,
        "SourceMessageName": selected.message_name,
        "SourceSignalName": selected.signal_name,
        "CanonicalNameCandidate": selected.canonical_name,
        "RawCode": raw_code,
        "PhysicalValue": physical_value,
        "ValueLabel": value_label,
        "OriginalUnit": selected.dbc_signal.unit,
        "ValueKindHint": value_kind_hint(selected.dbc_signal),
        "DecodeValid": decode_valid,
        "DecodeIssue": decode_issue,
    }


def _artifact_record(path: Path) -> dict[str, Any]:
    return {
        "FileName": path.name,
        "SizeBytes": path.stat().st_size,
        "SHA256": _sha256(path),
    }


def run(request_path: Path, output_dir: Path) -> dict[str, Any]:
    request = _read_request(request_path)
    test_mode = request.get("TestMode") is True
    _prepare_empty_directory(output_dir, "OUTPUT")

    synthetic_context = tempfile.TemporaryDirectory(prefix="u001_h2_run_") if test_mode else None
    try:
        if test_mode:
            assert synthetic_context is not None
            source, dbc_paths = _synthetic_inputs(Path(synthetic_context.name))
        else:
            source, dbc_paths = _production_inputs(request)
        configuration = _configuration(request, test_mode)
        text_format, groups, dbc_results, selected = _load_source_definition(
            source, dbc_paths, configuration
        )
        frame_identity = _frame_identity(configuration["FrameKey"])
        datetime_column, time_column = resolve_provenance_columns(text_format.columns)

        selected_by_group: dict[tuple[int, int], list[SelectedSignal]] = defaultdict(list)
        for item in selected:
            selected_by_group[(item.channel, item.can_id)].append(item)
        for values in selected_by_group.values():
            values.sort(key=lambda item: item.selection_order)
        selected_groups = [
            group
            for group in sorted(groups, key=lambda item: item.first_column_position)
            if (group.channel, group.can_id) in selected_by_group
        ]

        counters: Counter[str] = Counter()
        incomplete_examples: list[int] = []
        invalid_byte_examples: list[int] = []
        decode_failure_examples: list[dict[str, Any]] = []
        last_emitted_row = -1
        updates_path = output_dir / UPDATE_FILE
        with updates_path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=UPDATE_COLUMNS, extrasaction="raise")
            writer.writeheader()
            for source_row_index, source_row in iter_source_rows(source, text_format):
                if (
                    configuration["MaxSourceRows"] is not None
                    and source_row_index >= configuration["MaxSourceRows"]
                ):
                    break
                counters["SourceRowCount"] += 1
                row_had_update = False
                timestamp = _native_timestamp(source_row, datetime_column, time_column)
                for group in selected_groups:
                    status, payload = classify_message_cells(source_row, group)
                    if status == "NO_UPDATE":
                        counters["NoUpdateMessageObservationCount"] += 1
                        continue
                    if status == "INCOMPLETE_MESSAGE":
                        counters["IncompleteMessageCount"] += 1
                        _bounded_append(incomplete_examples, source_row_index)
                        continue
                    if status == "INVALID_BYTE":
                        counters["InvalidByteMessageCount"] += 1
                        _bounded_append(invalid_byte_examples, source_row_index)
                        continue
                    assert payload is not None
                    row_had_update = True
                    counters["DecodedMessageUpdateCount"] += 1
                    for item in selected_by_group[(group.channel, group.can_id)]:
                        try:
                            raw_code, physical_value = decode_physical_value(payload, item.dbc_signal)
                            if not math.isfinite(physical_value):
                                raise CanAdapterError("PHYSICAL_NONFINITE")
                            output_row = _update_row(
                                source_row_index,
                                request["SourceId"],
                                timestamp,
                                item,
                                frame_identity,
                                raw_code,
                                physical_value,
                                1,
                                "",
                            )
                            counters["DecodedSignalUpdateCount"] += 1
                            if (item.channel, item.can_id, item.signal_name) == frame_identity:
                                counters["FrameKeyUpdateCount"] += 1
                        except CanAdapterError as exc:
                            output_row = _update_row(
                                source_row_index,
                                request["SourceId"],
                                timestamp,
                                item,
                                frame_identity,
                                "",
                                "",
                                0,
                                str(exc),
                            )
                            counters["SignalDecodeFailureCount"] += 1
                            _bounded_append(
                                decode_failure_examples,
                                {
                                    "SourceRowIndex": source_row_index,
                                    "CanonicalNameCandidate": item.canonical_name,
                                    "Issue": str(exc),
                                },
                            )
                        if source_row_index < last_emitted_row:
                            raise AdapterError("SOURCE_ORDER_REGRESSION")
                        writer.writerow(output_row)
                        last_emitted_row = source_row_index
                if row_had_update:
                    counters["RowsWithAnySelectedUpdate"] += 1

        catalog_path = output_dir / CATALOG_FILE
        catalog_count = _write_catalog(catalog_path, selected)
        warnings = list(text_format.warnings)
        warnings.extend(
            warning
            for group in groups
            for warning in group.warnings
        )
        quality = {
            "QualitySchema": "U001_INPUT_ADAPTER_QUALITY_V0_1",
            "AdapterId": ADAPTER_ID,
            "AdapterVersion": ADAPTER_VERSION,
            "SelectionMode": configuration["SelectionMode"],
            "SourceRowCount": counters["SourceRowCount"],
            "DetectedMessageGroupCount": len(groups),
            "SelectedMessageGroupCount": len(selected_groups),
            "SelectedSignalCount": catalog_count,
            "RowsWithAnySelectedUpdate": counters["RowsWithAnySelectedUpdate"],
            "DecodedMessageUpdateCount": counters["DecodedMessageUpdateCount"],
            "DecodedUpdateCount": counters["DecodedSignalUpdateCount"],
            "DecodeFailureCount": counters["SignalDecodeFailureCount"],
            "IncompleteMessageCount": counters["IncompleteMessageCount"],
            "InvalidByteMessageCount": counters["InvalidByteMessageCount"],
            "NoUpdateMessageObservationCount": counters["NoUpdateMessageObservationCount"],
            "FrameKeyUpdateCount": counters["FrameKeyUpdateCount"],
            "IncompleteMessageExamples": incomplete_examples,
            "InvalidByteMessageExamples": invalid_byte_examples,
            "DecodeFailureExamples": decode_failure_examples,
            "AbsolutePathLeakCount": 0,
            "Warnings": warnings,
            "Errors": [],
        }
        quality_path = output_dir / QUALITY_FILE
        _write_json(quality_path, quality)

        artifacts = [_artifact_record(path) for path in (updates_path, catalog_path, quality_path)]
        manifest = {
            "ManifestSchema": "U001_INPUT_ADAPTER_RUN_MANIFEST_V0_1",
            "OutputBoundary": OUTPUT_BOUNDARY,
            "AdapterId": ADAPTER_ID,
            "AdapterVersion": ADAPTER_VERSION,
            "RequestId": request["RequestId"],
            "DatasetId": request["DatasetId"],
            "RunId": request["RunId"],
            "SegmentId": request["SegmentId"],
            "SourceId": request["SourceId"],
            "InputBasenames": [source.name] + [path.name for _, path in sorted(dbc_paths.items())],
            "InputFingerprints": [
                {"FileName": source.name, "SHA256": sha256_file(source)},
                *[
                    {"FileName": path.name, "Channel": channel, "SHA256": sha256_file(path)}
                    for channel, path in sorted(dbc_paths.items())
                ],
            ],
            "Configuration": {
                "SelectionMode": configuration["SelectionMode"],
                "SelectedSignalCount": len(selected),
                "FrameKey": configuration["FrameKey"],
                "MaxSourceRows": configuration["MaxSourceRows"],
                "ChunkRows": configuration["ChunkRows"],
                "WorkerCountRequested": configuration["WorkerCount"],
                "WorkerCountEffective": 1,
                "MaxInFlightChunks": configuration["MaxInFlightChunks"],
                "MaxResidentMemoryMBTarget": configuration["MaxResidentMemoryMB"],
                "OutputShardRowsReservation": configuration["OutputShardRows"],
                "WriteOrderPolicy": configuration["WriteOrderPolicy"],
                "StreamingImplementation": "ROW_STREAM_SINGLE_READER_SINGLE_WRITER",
            },
            "Artifacts": artifacts,
            "Status": "COMPLETE",
            "CompletionCode": 0,
            "Warnings": warnings,
            "Errors": [],
        }
        manifest_path = output_dir / MANIFEST_FILE
        _write_json(manifest_path, manifest)
        capsule = (
            f"U1H2A-N{len(selected)}-R{counters['SourceRowCount']}-"
            f"U{counters['DecodedSignalUpdateCount']}-F{counters['SignalDecodeFailureCount']}-"
            "X0-C0"
        )
        (output_dir / CAPSULE_FILE).write_text(capsule + "\n", encoding="utf-8")
        return manifest
    finally:
        if synthetic_context is not None:
            synthetic_context.cleanup()


def _read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    check(describe()["AdapterId"] == ADAPTER_ID, "T01")
    check(describe()["AdapterVersion"] == ADAPTER_VERSION, "T02")
    check(describe()["OutputBoundary"] == OUTPUT_BOUNDARY, "T03")
    with tempfile.TemporaryDirectory(prefix="u001_h2_adapter_selftest_") as temporary:
        root = Path(temporary)
        request_path = root / "request.json"
        request = {
            "RequestSchemaVersion": REQUEST_SCHEMA,
            "RequestId": "U001_H2_SELFTEST_REQUEST",
            "DatasetId": "SYNTHETIC_DATASET",
            "RunId": "SYNTHETIC_RUN",
            "SegmentId": "SEGMENT_001",
            "SourceId": "SYNTHETIC_SOURCE",
            "TestMode": True,
            "Inputs": [],
            "Configuration": {},
        }
        _write_json(request_path, request)
        inventory_result = inventory(request_path, root / "inventory")
        check(inventory_result["PayloadRowsDecoded"] == 0, "T04")
        check(inventory_result["TechnicallyDecodableVariableCount"] == 6, "T05")
        inventory_rows = _read_csv_rows(root / "inventory" / INVENTORY_CATALOG_FILE)
        check(len(inventory_rows) == 6, "T06")
        check(len({row["CatalogItemId"] for row in inventory_rows}) == 6, "T07")
        check((root / "inventory" / INVENTORY_CAPSULE_FILE).read_text().strip().endswith("C0"), "T08")
        preflight_result = preflight(request_path, root / "preflight")
        check(preflight_result["Status"] == "READY", "T09")
        check(preflight_result["CompletionCode"] == 0, "T10")
        check(preflight_result["DetectedMessageGroupCount"] == 3, "T11")
        check(preflight_result["SelectedSignalCount"] == 6, "T12")
        manifest = run(request_path, root / "run")
        check(manifest["Status"] == "COMPLETE", "T13")
        check(manifest["CompletionCode"] == 0, "T14")
        check(len(manifest["Artifacts"]) == 3, "T15")
        output_files = {path.name for path in (root / "run").iterdir() if path.is_file()}
        check(output_files == {UPDATE_FILE, CATALOG_FILE, QUALITY_FILE, MANIFEST_FILE, CAPSULE_FILE}, "T16")
        rows = _read_csv_rows(root / "run" / UPDATE_FILE)
        check(len(rows) == 10, "T17")
        check(list(rows[0]) == UPDATE_COLUMNS, "T18")
        source_indices = [int(row["SourceRowIndex"]) for row in rows]
        check(source_indices == sorted(source_indices), "T19")
        check({row["SourceAdapterId"] for row in rows} == {ADAPTER_ID}, "T20")
        check({row["SourceAdapterVersion"] for row in rows} == {ADAPTER_VERSION}, "T21")
        check({row["SourceId"] for row in rows} == {"SYNTHETIC_SOURCE"}, "T22")
        check(sum(bool(row["SyncKeyCandidate"]) for row in rows) == 2, "T23")
        check(sum(row["DecodeValid"] == "0" for row in rows) == 0, "T24")
        camera_distance = next(
            row for row in rows
            if row["SourceRowIndex"] == "0" and row["SourceSignalName"] == "Distance"
        )
        check(camera_distance["PhysicalValue"] == "12.34", "T25")
        object_type = next(
            row for row in rows
            if row["SourceRowIndex"] == "0" and row["SourceSignalName"] == "ObjectType"
        )
        check(object_type["ValueLabel"] == "Vehicle", "T26")
        quality = json.loads((root / "run" / QUALITY_FILE).read_text(encoding="utf-8"))
        check(quality["IncompleteMessageCount"] == 1, "T27")
        check(quality["InvalidByteMessageCount"] == 1, "T28")
        check(quality["DecodeFailureCount"] == 0, "T29")
        check(quality["AbsolutePathLeakCount"] == 0, "T30")
        check(not quality["Errors"], "T31")
        check(all(len(item["SHA256"]) == 64 for item in manifest["Artifacts"]), "T32")
        check(not any(str(root) in json.dumps(manifest) for _ in [0]), "T33")
        check((root / "run" / CAPSULE_FILE).read_text().strip().endswith("C0"), "T34")
        catalog = _read_csv_rows(root / "run" / CATALOG_FILE)
        check(len(catalog) == 6 and list(catalog[0]) == CATALOG_COLUMNS, "T35")
        check(len({row["CanonicalNameCandidate"] for row in catalog}) == 6, "T36")

    if checks != 36:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H2-MATLAB-CAN-DBC-ADAPTER-SELFTEST-PASS-36")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 MATLAB CAN CSV + DBC Input Adapter")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--describe", action="store_true")
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--inventory", action="store_true")
    action.add_argument("--preflight", action="store_true")
    action.add_argument("--run", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--out", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.describe:
            print(json.dumps(describe(), ensure_ascii=False))
            return 0
        if args.self_test:
            self_test()
            return 0
        if args.request is None or args.out is None:
            raise AdapterError("ACTION_ARGUMENTS")
        if args.inventory:
            result = inventory(args.request, args.out)
            print(
                f"U1INV-H{result['HeaderColumnCount']}-"
                f"G{result['DetectedMessageGroupCount']}-"
                f"V{result['TechnicallyDecodableVariableCount']}-X0-C0"
            )
            return 0
        if args.preflight:
            result = preflight(args.request, args.out)
            print(
                f"U1H2P-N{result['SelectedSignalCount']}-"
                f"G{result['DetectedMessageGroupCount']}-X0-C0"
            )
            return 0
        if args.run:
            result = run(args.request, args.out)
            quality = json.loads((args.out / QUALITY_FILE).read_text(encoding="utf-8"))
            print(
                f"U1H2A-N{quality['SelectedSignalCount']}-R{quality['SourceRowCount']}-"
                f"U{quality['DecodedUpdateCount']}-F{quality['DecodeFailureCount']}-X0-C0"
            )
            return 0
        raise AdapterError("ACTION")
    except (AdapterError, CanAdapterError, AssertionError, OSError, csv.Error) as exc:
        print(f"U1H2E-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
