#!/usr/bin/env python3
"""Independent black-box acceptance for U001 H2B Catalog/Selection."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_h2b_catalog_selection_acceptance"
PROGRAM_VERSION = "1.0.0"


class AcceptanceError(RuntimeError):
    """Fail-closed independent acceptance error."""


def _run(command: list[str], timeout: int = 90) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise AcceptanceError("CHILD_TIMEOUT") from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip().replace("\n", " | ")[:800]
        raise AcceptanceError(f"CHILD_EXIT:{result.returncode}:{detail}")
    return result


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AcceptanceError(f"JSON:{path.name}:{exc}") from exc
    if not isinstance(value, dict):
        raise AcceptanceError(f"JSON_OBJECT:{path.name}")
    return value


def _read_csv(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))
    except (OSError, UnicodeError, csv.Error) as exc:
        raise AcceptanceError(f"CSV:{path.name}:{exc}") from exc


def accept(adapter_path: Path, compiler_path: Path, output_root: Path) -> dict[str, Any]:
    output_root.mkdir(parents=True, exist_ok=True)
    if any(output_root.iterdir()):
        raise AcceptanceError("OUTPUT_NOT_EMPTY")

    request_path = output_root / "base_request.json"
    request = {
        "RequestSchemaVersion": "U001_INPUT_ADAPTER_REQUEST_V0_1",
        "RequestId": "U1H2B_ACCEPTANCE_REQUEST",
        "DatasetId": "U1H2B_SYNTHETIC_DATASET",
        "RunId": "U1H2B_ACCEPTANCE_RUN",
        "SegmentId": "FULL_SOURCE",
        "SourceId": "SYNTHETIC_SOURCE",
        "TestMode": True,
        "Inputs": [],
        "Configuration": {
            "SelectionMode": "ALL_TECHNICALLY_ELIGIBLE",
            "SelectedSignals": [],
            "FrameKey": {
                "Channel": 2,
                "CAN_ID": "0x620",
                "SignalName": "FrameCount"
            },
            "MaxSourceRows": None,
            "ChunkRows": 5000
        }
    }
    request_path.write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")

    inventory_dir = output_root / "inventory"
    inventory_result = _run(
        [
            sys.executable,
            str(adapter_path),
            "--inventory",
            "--request",
            str(request_path),
            "--out",
            str(inventory_dir),
        ]
    )
    inventory_summary = _load_json(inventory_dir / "u001_source_inventory.json")
    inventory_rows = _read_csv(inventory_dir / "u001_source_capability_catalog.csv")

    selection_path = output_root / "selection_request.json"
    selection = {
        "SelectionRequestSchema": "U001_SELECTION_PROFILE_REQUEST_V0_1",
        "ProfileId": "CAMERA_RADAR_DISTANCE_ONLY",
        "ProfileVersion": "1.0.0",
        "ProfileStatus": "APPROVED",
        "SelectedCatalogItemIds": [
            "CAN.CH2.ID221.Distance",
            "CAN.CH1.ID380.DistanceToObject"
        ],
        "FrameKeyCatalogItemId": "CAN.CH2.ID620.FrameCount",
        "ResourcePolicy": {
            "ChunkRows": 5000,
            "WorkerCount": 1,
            "MaxInFlightChunks": 2,
            "MaxResidentMemoryMB": 512,
            "OutputShardRows": 250000
        }
    }
    selection_path.write_text(json.dumps(selection, indent=2) + "\n", encoding="utf-8")

    compile_dir = output_root / "compiled"
    compile_result = _run(
        [
            sys.executable,
            str(compiler_path),
            "--compile",
            "--catalog",
            str(inventory_dir / "u001_source_capability_catalog.csv"),
            "--base-request",
            str(request_path),
            "--selection-request",
            str(selection_path),
            "--out",
            str(compile_dir),
        ]
    )
    profile = _load_json(compile_dir / "u001_compiled_selection_profile.json")

    run_dir = output_root / "run"
    run_result = _run(
        [
            sys.executable,
            str(adapter_path),
            "--run",
            "--request",
            str(compile_dir / "u001_h2_controlled_request.json"),
            "--out",
            str(run_dir),
        ]
    )
    quality = _load_json(run_dir / "u001_adapter_quality.json")
    manifest = _load_json(run_dir / "u001_adapter_run_manifest.json")
    update_rows = _read_csv(run_dir / "u001_adapter_source_updates.csv")
    catalog_rows = _read_csv(run_dir / "u001_adapter_signal_catalog.csv")

    checks: list[tuple[bool, str]] = [
        (inventory_summary.get("PayloadRowsDecoded") == 0, "INVENTORY_NO_PAYLOAD_DECODE"),
        (
            inventory_summary.get("TechnicallyDecodableVariableCount") == len(inventory_rows),
            "INVENTORY_COUNT_MATCHES_CATALOG",
        ),
        (len(inventory_rows) == 6, "SYNTHETIC_FIXTURE_CATALOG_ROWS"),
        (profile.get("UserSelectedCount") == 2, "USER_SELECTION_COUNT"),
        (profile.get("MandatoryDependencyCount") == 1, "DEPENDENCY_COUNT"),
        (profile.get("EffectiveSelectedCount") == 3, "EFFECTIVE_SELECTION_COUNT"),
        (quality.get("SelectedSignalCount") == 3, "RUN_SELECTED_COUNT"),
        (len(catalog_rows) == 3, "RUN_CATALOG_COUNT"),
        (
            {row["SourceSignalName"] for row in catalog_rows}
            == {"Distance", "DistanceToObject", "FrameCount"},
            "RUN_EXACT_SIGNAL_SET",
        ),
        (
            {row["SourceSignalName"] for row in update_rows}
            <= {"Distance", "DistanceToObject", "FrameCount"},
            "NO_UNSELECTED_UPDATE",
        ),
        (manifest.get("AdapterVersion") == "1.1.0", "ADAPTER_VERSION"),
        (manifest.get("Status") == "COMPLETE", "RUN_COMPLETE"),
        ("C0" in inventory_result.stdout.replace("-", ""), "INVENTORY_CAPSULE"),
        ("C0" in compile_result.stdout.replace("-", ""), "COMPILE_CAPSULE"),
        ("C0" in run_result.stdout.replace("-", ""), "RUN_CAPSULE"),
    ]
    failed = [label for condition, label in checks if not condition]
    if failed:
        raise AcceptanceError("CHECKS:" + ".".join(failed))

    receipt = {
        "AcceptanceSchema": "U001_H2B_CATALOG_SELECTION_ACCEPTANCE_V0_1",
        "Program": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "InventoryVariableCount": len(inventory_rows),
        "UserSelectedCount": profile["UserSelectedCount"],
        "MandatoryDependencyCount": profile["MandatoryDependencyCount"],
        "EffectiveSelectedCount": profile["EffectiveSelectedCount"],
        "DecodedUpdateCount": quality["DecodedUpdateCount"],
        "UnselectedSignalLeakCount": 0,
        "PayloadRowsDecodedDuringInventory": 0,
        "WholeFileMemoryLoadRequired": False,
        "CheckCount": len(checks),
        "Status": "ACCEPTED",
        "CompletionCode": 0,
    }
    (output_root / "u001_h2b_acceptance_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8"
    )
    capsule = (
        f"U1H2B-V{receipt['InventoryVariableCount']}-"
        f"U{receipt['UserSelectedCount']}-D{receipt['MandatoryDependencyCount']}-"
        f"E{receipt['EffectiveSelectedCount']}-L0-X0-C0"
    )
    (output_root / "u001_h2b_acceptance_capsule.txt").write_text(capsule + "\n", encoding="utf-8")
    return receipt


def self_test() -> None:
    root = Path(__file__).resolve().parents[2]
    adapter = (
        root
        / "01_PROGRAMS"
        / "adapters"
        / "CameraRadar.U001.MatlabCanCsvDbc"
        / "1.1.0"
        / "adapter.py"
    )
    compiler = root / "01_PROGRAMS" / "core" / "u001_selection_profile_compiler_v1_0.py"
    if not adapter.is_file() or not compiler.is_file():
        raise AcceptanceError("PROGRAM_FILESET")
    with tempfile.TemporaryDirectory(prefix="u001_h2b_acceptance_") as temporary:
        receipt = accept(adapter, compiler, Path(temporary) / "acceptance")
        if receipt["Status"] != "ACCEPTED" or receipt["CheckCount"] != 15:
            raise AssertionError("ACCEPTANCE_RECEIPT")
    print("U001-H2B-CATALOG-SELECTION-ACCEPTANCE-SELFTEST-PASS-15")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 H2B Catalog/Selection Acceptance")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--accept", action="store_true")
    parser.add_argument("--adapter", type=Path)
    parser.add_argument("--compiler", type=Path)
    parser.add_argument("--out", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.adapter is None or args.compiler is None or args.out is None:
            raise AcceptanceError("ACCEPT_ARGUMENTS")
        receipt = accept(args.adapter, args.compiler, args.out)
        print(
            f"U1H2B-V{receipt['InventoryVariableCount']}-"
            f"U{receipt['UserSelectedCount']}-D{receipt['MandatoryDependencyCount']}-"
            f"E{receipt['EffectiveSelectedCount']}-L0-X0-C0"
        )
        return 0
    except (AcceptanceError, AssertionError, OSError, csv.Error) as exc:
        print(f"U1H2BE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
