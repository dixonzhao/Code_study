#!/usr/bin/env python3
"""U001 high-code Workbench GUI shell.

The GUI follows the accepted U002 pipeline interaction model.  It visualizes
the fixed I0-I5 U001 stages, delegates Catalog/Mapping to the existing focused
sub-tool and keeps all data algorithms outside the presentation layer.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Any, Dict, List, Mapping, Optional

from u001_workbench_model_v0_1 import (
    MODEL_VERSION,
    STAGE_ORDER,
    STAGE_TITLES,
    WorkbenchError,
    catalog_gui_command,
    default_profile_path,
    default_state,
    grouped_adapters,
    load_profile,
    save_profile,
    scan_adapters,
    selected_adapter,
    self_test as model_self_test,
    stage_states,
    validate_state,
    workflow_command,
)


GUI_ID = "CameraRadar.U001.HighCodeWorkbenchGUI"
GUI_VERSION = "0.1.0"

STAGE_TITLES_JA = {
    "I0": "入力Adapter",
    "I1": "Catalog・Mapping",
    "I2": "Decode・正規化Mapping",
    "I3": "Frame再構成",
    "I4": "周期・有界保持",
    "I5": "承認Package・品質Gate",
}

I18N = {
    "EN": {
        "title": "U001 Data Foundation Workbench",
        "subtitle": "External source → governed signal catalog → frame-domain accepted package",
        "startup_title": "Select startup language",
        "startup_help": "The language is fixed for this Workbench session.",
        "adapter": "Input Adapter (modular)",
        "adapter_family": "Adapter family",
        "version": "Version",
        "refresh": "Refresh Adapters",
        "view_card": "View Adapter Card",
        "source_files": "Current Adapter Sources",
        "can_dump": "CAN dump CSV",
        "dbc1": "DBC 1",
        "dbc2": "DBC 2",
        "browse": "Browse",
        "mapping": "Catalog / Mapping Profile",
        "catalog": "Capability Catalog",
        "selection": "Selection Profile",
        "open_mapping": "Open Catalog / Mapping",
        "open_profile": "Open Profile",
        "save_profile": "Save Profile",
        "run_config": "Run Configuration",
        "run_id": "Run ID",
        "frame_range": "Frame start / end",
        "output": "Output root",
        "u002": "U002 link",
        "offline": "OFFLINE",
        "online": "ONLINE",
        "reset": "Reset",
        "pipeline": "Controlled I0-I5 Pipeline",
        "workflow": "Run Workflow",
        "save_setup": "1. Save setup",
        "check": "2. Check readiness",
        "run": "3. Run I0-I5",
        "open_output": "4. Open output",
        "execution_log": "Execution Log",
        "controller_pending": "U1G2 execution controller is not installed yet. The U1G1 GUI and mapping workflow are ready; formal I0-I5 execution remains fail-closed.",
        "stage_help": "Select a stage to see its fixed responsibility. Algorithms remain in versioned core or Adapter modules.",
        "close": "Close",
    },
    "JA": {
        "title": "U001 データ基盤ワークベンチ",
        "subtitle": "外部データ → 信号Catalog → Frame基準の承認済みPackage",
        "startup_title": "起動言語を選択",
        "startup_help": "このセッション中は選択した言語で固定されます。",
        "adapter": "入力Adapter（モジュール式）",
        "adapter_family": "Adapter種別",
        "version": "Version",
        "refresh": "Adapter更新",
        "view_card": "Adapter Card表示",
        "source_files": "入力データ",
        "can_dump": "CAN dump CSV",
        "dbc1": "DBC 1",
        "dbc2": "DBC 2",
        "browse": "参照",
        "mapping": "Catalog / Mapping Profile",
        "catalog": "Capability Catalog",
        "selection": "Selection Profile",
        "open_mapping": "Catalog / Mappingを開く",
        "open_profile": "Profileを開く",
        "save_profile": "Profileを保存",
        "run_config": "実行設定",
        "run_id": "Run ID",
        "frame_range": "開始 / 終了Frame",
        "output": "出力先",
        "u002": "U002接続",
        "offline": "OFFLINE",
        "online": "ONLINE",
        "reset": "解除",
        "pipeline": "管理対象 I0-I5 Pipeline",
        "workflow": "実行ワークフロー",
        "save_setup": "1. 設定を保存",
        "check": "2. 実行準備を確認",
        "run": "3. I0-I5を実行",
        "open_output": "4. 出力を開く",
        "execution_log": "実行ログ",
        "controller_pending": "U1G2実行Controllerは未導入です。U1G1 GUIとMapping操作は使用できますが、正式I0-I5実行はFail-closeです。",
        "stage_help": "Stageを選択すると責務を確認できます。AlgorithmはGUIではなくVersion管理されたCore / Adapterに保持されます。",
        "close": "閉じる",
    },
}

STAGE_DESCRIPTIONS = {
    "I0": "Select one versioned source Adapter. CAN+DBC is the current implementation; GNSS, LiDAR and other sources enter through the same contract boundary.",
    "I1": "Inspect the lightweight capability catalog, search signals, select the FrameCount authority and save a reusable Selection Profile.",
    "I2": "Decode only selected variables and map source identities into canonical U001 signal identities without loading the whole source into memory.",
    "I3": "Construct one ordered frame-domain row set while preserving update provenance, validity and source lineage.",
    "I4": "Measure signal cadence and apply explicit bounded-hold policies. Age and Updated fields remain visible; unlimited forward fill is prohibited.",
    "I5": "Assemble and validate the accepted six-file U001 package for downstream U002 analysis.",
}

STAGE_DESCRIPTIONS_JA = {
    "I0": "Version管理された入力Adapterを選択します。現在はCAN+DBCを実装し、将来のGNSS・LiDAR等も同一契約から入力します。",
    "I1": "軽量Catalogで信号検索、FrameCount基準選択、再利用可能なSelection Profile保存を行います。",
    "I2": "選択信号のみをDecodeし、Source信号をU001標準名へMappingします。全データの一括Memory読込は行いません。",
    "I3": "更新元・Validity・系譜を保持したまま、Frame基準の時系列表を構築します。",
    "I4": "信号周期を評価し、明示的な有界保持を適用します。AgeとUpdatedを保持し、無制限Forward Fillは禁止します。",
    "I5": "U002へ渡すU001標準6ファイルPackageを構成し、品質Gateで検証します。",
}

STATUS_COLORS = {
    "EMPTY": ("#e6ebef", "#52616b"),
    "SELECTED": ("#f6e2a3", "#4b3b00"),
    "PLANNED": ("#d9eaf5", "#17496b"),
    "READY": ("#2f855a", "white"),
    "RUNNING": ("#f4b942", "#1f1f1f"),
    "SUCCEEDED": ("#2f855a", "white"),
    "FAILED": ("#c53030", "white"),
}


def choose_startup_language() -> Optional[str]:
    chooser = tk.Tk()
    chooser.withdraw()
    dialog = tk.Toplevel(chooser)
    dialog.title("U001 / 言語選択")
    dialog.resizable(False, False)
    value: Dict[str, Optional[str]] = {"language": None}
    frame = ttk.Frame(dialog, padding=18)
    frame.grid()
    ttk.Label(frame, text="Select startup language / 起動言語を選択", font=("Segoe UI", 13, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 8))
    ttk.Label(frame, text="The selected language is fixed for this session.\n選択後、このセッション中は言語を固定します。", justify="center").grid(row=1, column=0, columnspan=2, pady=(0, 14))

    def select(language: str) -> None:
        value["language"] = language
        dialog.destroy()

    ttk.Button(frame, text="English", width=18, command=lambda: select("EN")).grid(row=2, column=0, padx=5)
    ttk.Button(frame, text="日本語", width=18, command=lambda: select("JA")).grid(row=2, column=1, padx=5)
    dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)
    dialog.transient(chooser)
    dialog.grab_set()
    dialog.wait_window()
    chooser.destroy()
    return value["language"]


class U001Workbench:
    """Thin GUI state owner; algorithms remain outside this class."""

    def __init__(self, workspace_root: Path, language: str) -> None:
        self.workspace_root = workspace_root.resolve()
        self.language = language
        self.text = I18N[language]
        self.root = tk.Tk()
        self.root.title(self.text["title"] + " v0.1")
        self.root.geometry("1480x900")
        self.root.minsize(1120, 720)
        self.state = default_state(self.workspace_root)
        self.state["Language"] = language
        self.adapter_entries: List[Dict[str, Any]] = []
        self.adapter_groups: List[Dict[str, Any]] = []
        self.stage_widgets: Dict[str, tk.Label] = {}
        self.active_profile_path: Optional[Path] = None
        self.active_process: Optional[subprocess.Popen[str]] = None
        self._variables()
        self._styles()
        self._build()
        self.refresh_adapters()
        self.refresh_ui()

    def _variables(self) -> None:
        self.adapter_id_var = tk.StringVar()
        self.adapter_version_var = tk.StringVar()
        self.can_var = tk.StringVar()
        self.dbc1_var = tk.StringVar()
        self.dbc2_var = tk.StringVar()
        self.catalog_var = tk.StringVar()
        self.selection_var = tk.StringVar()
        self.run_id_var = tk.StringVar(value=self.state["RunId"])
        self.frame_start_var = tk.StringVar()
        self.frame_end_var = tk.StringVar()
        self.output_var = tk.StringVar(value=self.state["OutputRoot"])
        self.u002_var = tk.StringVar()
        self.connection_var = tk.StringVar(value=self.text["offline"])
        self.profile_status_var = tk.StringVar(value="Editable Working Profile")
        self.stage_detail_var = tk.StringVar(value=self.text["stage_help"])
        self.status_var = tk.StringVar(value="U1G1 GUI ready")

    def _styles(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Header.TFrame", background="#173f5f")
        style.configure("HeaderTitle.TLabel", background="#173f5f", foreground="white", font=("Segoe UI", 24, "bold"))
        style.configure("HeaderSub.TLabel", background="#173f5f", foreground="#dcecf7", font=("Segoe UI", 11))
        style.configure("Action.TButton", font=("Segoe UI", 10, "bold"), padding=8)

    def _build(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(2, weight=1)

        header = ttk.Frame(self.root, style="Header.TFrame", padding=(18, 12))
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text=self.text["title"], style="HeaderTitle.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text=self.text["subtitle"], style="HeaderSub.TLabel").grid(row=1, column=0, sticky="w")
        link = ttk.Frame(header, style="Header.TFrame")
        link.grid(row=0, column=1, rowspan=2, sticky="e")
        ttk.Label(link, text=self.text["u002"], style="HeaderSub.TLabel").grid(row=0, column=0, padx=4)
        self.u002_button = tk.Button(link, textvariable=self.connection_var, relief="flat", command=self.select_u002, width=12)
        self.u002_button.grid(row=0, column=1, padx=4)
        ttk.Button(link, text=self.text["reset"], command=self.reset_u002).grid(row=0, column=2, padx=4)

        pipeline = ttk.LabelFrame(self.root, text=self.text["pipeline"], padding=10)
        pipeline.grid(row=1, column=0, sticky="ew", padx=12, pady=(10, 4))
        for index, stage in enumerate(STAGE_ORDER):
            pipeline.columnconfigure(index, weight=1)
            title = STAGE_TITLES_JA[stage] if self.language == "JA" else STAGE_TITLES[stage]
            widget = tk.Label(pipeline, text=f"{stage}\n{title}", bd=1, relief="solid", padx=8, pady=10, cursor="hand2", wraplength=185)
            widget.grid(row=0, column=index, sticky="nsew", padx=3)
            widget.bind("<Button-1>", lambda event, selected=stage: self.show_stage(selected))
            self.stage_widgets[stage] = widget
        ttk.Label(pipeline, textvariable=self.stage_detail_var, wraplength=1320).grid(row=1, column=0, columnspan=6, sticky="w", pady=(8, 0))

        body = ttk.Panedwindow(self.root, orient="horizontal")
        body.grid(row=2, column=0, sticky="nsew", padx=12, pady=4)
        left = ttk.Frame(body)
        right = ttk.Frame(body)
        body.add(left, weight=3)
        body.add(right, weight=2)
        left.columnconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)

        adapter = ttk.LabelFrame(left, text=self.text["adapter"], padding=10)
        adapter.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        adapter.columnconfigure(1, weight=1)
        ttk.Label(adapter, text=self.text["adapter_family"]).grid(row=0, column=0, sticky="w", pady=3)
        self.adapter_combo = ttk.Combobox(adapter, textvariable=self.adapter_id_var, state="readonly")
        self.adapter_combo.grid(row=0, column=1, sticky="ew", padx=6, pady=3)
        self.adapter_combo.bind("<<ComboboxSelected>>", lambda event: self.adapter_family_changed())
        ttk.Label(adapter, text=self.text["version"]).grid(row=1, column=0, sticky="w", pady=3)
        self.version_combo = ttk.Combobox(adapter, textvariable=self.adapter_version_var, state="readonly", width=18)
        self.version_combo.grid(row=1, column=1, sticky="w", padx=6, pady=3)
        self.version_combo.bind("<<ComboboxSelected>>", lambda event: self.refresh_ui())
        buttons = ttk.Frame(adapter)
        buttons.grid(row=0, column=2, rowspan=2, padx=(8, 0))
        ttk.Button(buttons, text=self.text["refresh"], command=self.refresh_adapters).grid(row=0, column=0, sticky="ew", pady=2)
        ttk.Button(buttons, text=self.text["view_card"], command=self.view_adapter_card).grid(row=1, column=0, sticky="ew", pady=2)

        sources = ttk.LabelFrame(left, text=self.text["source_files"], padding=10)
        sources.grid(row=1, column=0, sticky="ew", pady=6)
        sources.columnconfigure(1, weight=1)
        self._path_row(sources, 0, self.text["can_dump"], self.can_var, "csv")
        self._path_row(sources, 1, self.text["dbc1"], self.dbc1_var, "dbc")
        self._path_row(sources, 2, self.text["dbc2"], self.dbc2_var, "dbc")

        mapping = ttk.LabelFrame(left, text=self.text["mapping"], padding=10)
        mapping.grid(row=2, column=0, sticky="ew", pady=6)
        mapping.columnconfigure(1, weight=1)
        self._path_row(mapping, 0, self.text["catalog"], self.catalog_var, "csv")
        self._path_row(mapping, 1, self.text["selection"], self.selection_var, "json")
        mapping_buttons = ttk.Frame(mapping)
        mapping_buttons.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        mapping_buttons.columnconfigure(0, weight=2)
        mapping_buttons.columnconfigure(1, weight=1)
        mapping_buttons.columnconfigure(2, weight=1)
        ttk.Button(mapping_buttons, text=self.text["open_mapping"], style="Action.TButton", command=self.open_mapping).grid(row=0, column=0, sticky="ew", padx=2)
        ttk.Button(mapping_buttons, text=self.text["open_profile"], command=self.open_profile).grid(row=0, column=1, sticky="ew", padx=2)
        ttk.Button(mapping_buttons, text=self.text["save_profile"], command=self.save_profile_dialog).grid(row=0, column=2, sticky="ew", padx=2)

        run = ttk.LabelFrame(left, text=self.text["run_config"], padding=10)
        run.grid(row=3, column=0, sticky="ew", pady=6)
        run.columnconfigure(1, weight=1)
        ttk.Label(run, text=self.text["run_id"]).grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(run, textvariable=self.run_id_var).grid(row=0, column=1, columnspan=2, sticky="ew", padx=6, pady=3)
        ttk.Label(run, text=self.text["frame_range"]).grid(row=1, column=0, sticky="w", pady=3)
        frame_box = ttk.Frame(run)
        frame_box.grid(row=1, column=1, columnspan=2, sticky="ew", padx=6)
        frame_box.columnconfigure(0, weight=1)
        frame_box.columnconfigure(2, weight=1)
        ttk.Entry(frame_box, textvariable=self.frame_start_var).grid(row=0, column=0, sticky="ew")
        ttk.Label(frame_box, text="→").grid(row=0, column=1, padx=8)
        ttk.Entry(frame_box, textvariable=self.frame_end_var).grid(row=0, column=2, sticky="ew")
        ttk.Label(run, text=self.text["output"]).grid(row=2, column=0, sticky="w", pady=3)
        ttk.Entry(run, textvariable=self.output_var).grid(row=2, column=1, sticky="ew", padx=6, pady=3)
        ttk.Button(run, text=self.text["browse"], command=lambda: self.browse_directory(self.output_var)).grid(row=2, column=2, pady=3)

        actions = ttk.LabelFrame(right, text=self.text["workflow"], padding=10)
        actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)
        ttk.Button(actions, text=self.text["save_setup"], style="Action.TButton", command=self.save_setup).grid(row=0, column=0, sticky="ew", padx=3, pady=3)
        ttk.Button(actions, text=self.text["check"], style="Action.TButton", command=self.check_readiness).grid(row=0, column=1, sticky="ew", padx=3, pady=3)
        ttk.Button(actions, text=self.text["run"], style="Action.TButton", command=self.run_workflow).grid(row=1, column=0, sticky="ew", padx=3, pady=3)
        ttk.Button(actions, text=self.text["open_output"], style="Action.TButton", command=self.open_output).grid(row=1, column=1, sticky="ew", padx=3, pady=3)

        ttk.Label(right, textvariable=self.profile_status_var, wraplength=520).grid(row=1, column=0, sticky="ew", pady=4)
        log_frame = ttk.LabelFrame(right, text=self.text["execution_log"], padding=6)
        log_frame.grid(row=2, column=0, sticky="nsew", pady=6)
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log = ScrolledText(log_frame, height=20, wrap="word", state="disabled", font=("Consolas", 9))
        self.log.grid(row=0, column=0, sticky="nsew")

        ttk.Label(self.root, textvariable=self.status_var, relief="sunken", anchor="w").grid(row=3, column=0, sticky="ew", padx=12, pady=(2, 10))

    def _path_row(self, parent: ttk.Frame, row: int, label: str, variable: tk.StringVar, kind: str) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=6, pady=3)
        ttk.Button(parent, text=self.text["browse"], command=lambda: self.browse_file(variable, kind)).grid(row=row, column=2, pady=3)

    def append_log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text.rstrip() + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def browse_file(self, variable: tk.StringVar, kind: str) -> None:
        types = {
            "csv": [("CSV files", "*.csv"), ("All files", "*.*")],
            "dbc": [("DBC files", "*.dbc"), ("All files", "*.*")],
            "json": [("JSON files", "*.json"), ("All files", "*.*")],
        }[kind]
        selected = filedialog.askopenfilename(filetypes=types)
        if selected:
            variable.set(selected)
            self.refresh_ui()

    def browse_directory(self, variable: tk.StringVar) -> None:
        selected = filedialog.askdirectory()
        if selected:
            variable.set(selected)
            self.refresh_ui()

    def refresh_adapters(self) -> None:
        try:
            previous_id = self.adapter_id_var.get() or self.state.get("AdapterId", "")
            previous_version = self.adapter_version_var.get() or self.state.get("AdapterVersion", "")
            self.adapter_entries = scan_adapters(self.workspace_root)
            self.adapter_groups = grouped_adapters(self.adapter_entries)
            ids = [str(item["AdapterId"]) for item in self.adapter_groups]
            self.adapter_combo.configure(values=ids)
            selected_id = previous_id if previous_id in ids else ids[0]
            self.adapter_id_var.set(selected_id)
            self.adapter_family_changed(preferred_version=previous_version)
            self.append_log(f"Adapter scan: {len(self.adapter_groups)} families / {len(self.adapter_entries)} versions")
        except Exception as error:
            self.show_error(error)

    def adapter_family_changed(self, preferred_version: str = "") -> None:
        selected_id = self.adapter_id_var.get()
        group = next(item for item in self.adapter_groups if item["AdapterId"] == selected_id)
        versions = [str(item["AdapterVersion"]) for item in group["Versions"]]
        self.version_combo.configure(values=versions)
        self.adapter_version_var.set(preferred_version if preferred_version in versions else versions[0])
        self.refresh_ui()

    def collect_state(self) -> Dict[str, Any]:
        value = dict(self.state)
        value.update(
            {
                "Language": self.language,
                "AdapterId": self.adapter_id_var.get(),
                "AdapterVersion": self.adapter_version_var.get(),
                "SourceFiles": {
                    "CANDump": self.can_var.get().strip(),
                    "DBC1": self.dbc1_var.get().strip(),
                    "DBC2": self.dbc2_var.get().strip(),
                },
                "CapabilityCatalogPath": self.catalog_var.get().strip(),
                "SelectionProfilePath": self.selection_var.get().strip(),
                "RunId": self.run_id_var.get().strip(),
                "FrameStart": self.frame_start_var.get().strip() or None,
                "FrameEnd": self.frame_end_var.get().strip() or None,
                "OutputRoot": self.output_var.get().strip(),
                "U002Workspace": self.u002_var.get().strip(),
            }
        )
        return value

    def apply_state(self, value: Mapping[str, object]) -> None:
        self.state = dict(value)
        self.adapter_id_var.set(str(value.get("AdapterId", "")))
        self.adapter_family_changed(str(value.get("AdapterVersion", "")))
        sources = value.get("SourceFiles", {})
        if isinstance(sources, dict):
            self.can_var.set(str(sources.get("CANDump", "")))
            self.dbc1_var.set(str(sources.get("DBC1", "")))
            self.dbc2_var.set(str(sources.get("DBC2", "")))
        self.catalog_var.set(str(value.get("CapabilityCatalogPath", "")))
        self.selection_var.set(str(value.get("SelectionProfilePath", "")))
        self.run_id_var.set(str(value.get("RunId", "U001_RUN_NEW")))
        self.frame_start_var.set("" if value.get("FrameStart") is None else str(value.get("FrameStart")))
        self.frame_end_var.set("" if value.get("FrameEnd") is None else str(value.get("FrameEnd")))
        self.output_var.set(str(value.get("OutputRoot", "")))
        self.u002_var.set(str(value.get("U002Workspace", "")))
        self.refresh_ui()

    def refresh_ui(self) -> None:
        value = self.collect_state()
        for stage, status in stage_states(self.workspace_root, value).items():
            background, foreground = STATUS_COLORS[status]
            self.stage_widgets[stage].configure(bg=background, fg=foreground)
        online = Path(self.u002_var.get()).is_dir() if self.u002_var.get() else False
        self.connection_var.set(self.text["online"] if online else self.text["offline"])
        self.u002_button.configure(bg="#2f855a" if online else "#c53030", fg="white", activebackground="#276749" if online else "#9b2c2c")

    def show_stage(self, stage: str) -> None:
        descriptions = STAGE_DESCRIPTIONS_JA if self.language == "JA" else STAGE_DESCRIPTIONS
        self.stage_detail_var.set(f"{stage} — {descriptions[stage]}")

    def view_adapter_card(self) -> None:
        try:
            entry = selected_adapter(self.adapter_entries, self.adapter_id_var.get(), self.adapter_version_var.get())
            card = entry["Card"]
            window = tk.Toplevel(self.root)
            window.title(self.text["view_card"])
            window.geometry("760x560")
            frame = ttk.Frame(window, padding=12)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text=f"{entry['AdapterId']} @ {entry['AdapterVersion']}", font=("Segoe UI", 14, "bold"), wraplength=710).pack(anchor="w")
            ttk.Label(frame, text=str(entry["Purpose"]), wraplength=710).pack(anchor="w", pady=(6, 12))
            tree = ttk.Treeview(frame, columns=("value",), show="tree headings")
            tree.heading("#0", text="Field")
            tree.heading("value", text="Value")
            tree.column("#0", width=220)
            tree.column("value", width=470)
            for key, value in sorted(card.items()):
                rendered = json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)
                tree.insert("", "end", text=key, values=(rendered,))
            tree.pack(fill="both", expand=True)
            ttk.Button(frame, text=self.text["close"], command=window.destroy).pack(anchor="e", pady=(8, 0))
        except Exception as error:
            self.show_error(error)

    def open_mapping(self) -> None:
        try:
            command = catalog_gui_command(self.workspace_root, self.catalog_var.get())
            subprocess.Popen(command, cwd=str(self.workspace_root / "01_PROGRAMS/core"))
            self.append_log("Catalog / Mapping child window started")
        except Exception as error:
            self.show_error(error)

    def save_profile_dialog(self) -> None:
        try:
            value = self.collect_state()
            default = default_profile_path(self.workspace_root, value.get("ProfileName", "U001_Working_Profile"))
            selected = filedialog.asksaveasfilename(initialdir=str(default.parent), initialfile=default.name, defaultextension=".json", filetypes=[("JSON files", "*.json")])
            if not selected:
                return
            self.active_profile_path = save_profile(self.workspace_root, value, Path(selected))
            self.profile_status_var.set(f"Profile: {self.active_profile_path}")
            self.append_log(f"Saved profile: {self.active_profile_path}")
        except Exception as error:
            self.show_error(error)

    def open_profile(self) -> None:
        selected = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if not selected:
            return
        try:
            self.active_profile_path = Path(selected).resolve()
            self.apply_state(load_profile(self.active_profile_path))
            self.profile_status_var.set(f"Profile: {self.active_profile_path}")
            self.append_log(f"Opened profile: {self.active_profile_path}")
        except Exception as error:
            self.show_error(error)

    def save_setup(self) -> None:
        try:
            value = self.collect_state()
            target = self.active_profile_path or default_profile_path(self.workspace_root, value.get("ProfileName", "U001_Working_Profile"))
            self.active_profile_path = save_profile(self.workspace_root, value, target)
            self.profile_status_var.set(f"Profile: {self.active_profile_path}")
            self.status_var.set("Setup saved")
            self.append_log(f"PASS | Workbench setup saved | {self.active_profile_path}")
        except Exception as error:
            self.show_error(error)

    def check_readiness(self) -> None:
        try:
            report = validate_state(self.workspace_root, self.collect_state())
            self.refresh_ui()
            self.append_log(f"PASS | Adapter selected | {report['Adapter']['AdapterId']} @ {report['Adapter']['AdapterVersion']}")
            self.append_log(f"{'PASS' if report['SourceReady'] else 'WAIT'} | Source files | missing={report['MissingSourceKeys']}")
            self.append_log(f"{'PASS' if report['CatalogReady'] else 'WAIT'} | Capability Catalog")
            self.append_log(f"{'PASS' if report['SelectionReady'] else 'WAIT'} | Selection Profile")
            self.append_log(f"{'PASS' if report['ControllerReady'] else 'WAIT'} | U1G2 execution controller")
            self.status_var.set("Readiness check completed")
        except Exception as error:
            self.show_error(error)

    def run_workflow(self) -> None:
        try:
            if self.active_profile_path is None:
                self.save_setup()
            if self.active_profile_path is None:
                return
            command = workflow_command(self.workspace_root, self.active_profile_path)
        except WorkbenchError as error:
            if error.reason == "U1G2_CONTROLLER_NOT_INSTALLED":
                messagebox.showinfo("U1G1", self.text["controller_pending"])
                self.append_log("WAIT | U1G2 controller not installed; formal execution remains fail-closed")
                return
            self.show_error(error)
            return
        except Exception as error:
            self.show_error(error)
            return

        def worker() -> None:
            try:
                self.root.after(0, lambda: self.status_var.set("I0-I5 workflow running"))
                process = subprocess.run(command, cwd=str(self.workspace_root), capture_output=True, text=True, check=False)
                output = (process.stdout or "") + (process.stderr or "")
                self.root.after(0, lambda: self.append_log(output or "No controller output"))
                self.root.after(0, lambda: self.status_var.set("Workflow completed" if process.returncode == 0 else "Workflow failed"))
            except Exception as error:
                self.root.after(0, lambda: self.show_error(error))

        threading.Thread(target=worker, daemon=True).start()

    def open_output(self) -> None:
        path = Path(self.output_var.get()).expanduser()
        try:
            path.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as error:
            self.show_error(error)

    def select_u002(self) -> None:
        selected = filedialog.askdirectory(title="Select U-UDP002 workspace")
        if selected:
            path = Path(selected)
            if path.name != "U-UDP002":
                messagebox.showerror("U002", "Selected folder must be U-UDP002")
                return
            self.u002_var.set(str(path.resolve()))
            self.refresh_ui()

    def reset_u002(self) -> None:
        self.u002_var.set("")
        self.refresh_ui()

    def show_error(self, error: BaseException) -> None:
        if isinstance(error, WorkbenchError):
            message = f"{error.reason}\n{error.detail}"
        else:
            message = f"{type(error).__name__}: {error}"
        self.append_log("ERROR | " + message.replace("\n", " | "))
        self.status_var.set("Operation failed")
        messagebox.showerror("U001 Workbench", message)

    def run(self) -> None:
        self.root.mainloop()


def gui_self_test() -> str:
    model_self_test()
    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check_{checks + 1}")
        checks += 1

    check(GUI_VERSION == "0.1.0")
    check(len(STAGE_ORDER) == 6)
    check(set(STAGE_ORDER) == set(STAGE_TITLES_JA))
    check(set(I18N) == {"EN", "JA"})
    check("Adapter" in STAGE_DESCRIPTIONS["I0"])
    check("有界保持" in STAGE_DESCRIPTIONS_JA["I4"])
    check("run" in I18N["EN"])
    check("run" in I18N["JA"])
    capsule = f"U1G1-GUI-SELFTEST-PASS-{checks}"
    print(capsule)
    return capsule


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--gui", action="store_true")
    parser.add_argument("--workspace-root", default=None)
    parser.add_argument("--language", choices=["EN", "JA"])
    return parser.parse_args()


def main() -> int:
    arguments = parse_arguments()
    if arguments.self_test:
        gui_self_test()
        return 0
    workspace = (
        Path(arguments.workspace_root).resolve()
        if arguments.workspace_root
        else Path(__file__).resolve().parents[2]
    )
    language = arguments.language or choose_startup_language()
    if language is None:
        return 0
    U001Workbench(workspace, language).run()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U1G1-GUI-ERROR-{type(error).__name__.upper()}-{error}-C7", file=sys.stderr)
        raise
