#!/usr/bin/env python3
"""Governed S7 export from U002 candidates to a U003 review package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


MODULE_ID = "CameraRadar.S7.U003ReviewPackageExport"
MODULE_VERSION = "0.1.0"
STAGE = "S7"
ARTIFACT_TYPE = "U003_REVIEW_PACKAGE"
CONTRACT_VERSION = "U22.0.1"
PROTOCOL = "U002_U22_MODULE_RUNTIME"
PROTOCOL_VERSION = "0.1"

REQUIRED_ARTIFACTS = [
    "ANOMALY_CANDIDATES",
    "CAMERA_TARGET_RECONSTRUCTION",
    "RADAR_VALIDITY",
    "ROBUST_RESIDUAL_EVIDENCE",
]

S6_MODULE_ID = "CameraRadar.S6.RobustScoreCandidateSynthesis"
S6_MODULE_VERSION = "0.1.0"

QUEUE_COLUMNS = [
    "EventID",
    "StartFrameCount",
    "PeakFrameCount",
    "EndFrameCount",
    "ReviewResult",
    "ReviewMemo",
    "CandidateId",
    "EvidenceStartFrame",
    "EvidenceEndFrame",
    "CandidateType",
    "CandidateScore",
    "CandidateRank",
    "PriorityClass",
    "PriorityReason",
    "CandidatePolicyProfileId",
    "SuggestedReviewMemo",
    "SuggestedReviewTags",
    "SuggestedEvidenceIds",
    "SuggestedConfidence",
    "PrimarySignal",
    "RelatedSignals",
    "ModuleId",
    "ModuleVersion",
    "AlgorithmStatus",
    "ReviewDataArtifactId",
    "SourceArtifactId",
    "CandidateStatus",
    "RootCauseClaim",
]

CORE_REVIEW_COLUMNS = [
    "FrameCount",
    "CandidateIds",
    "Camera1Distance",
    "Camera3Distance",
    "CanonicalCameraDistance",
    "RadarDistance",
    "CameraRadarDiscrepancy",
    "CameraRadarResidual",
    "RobustAnomalyScore",
    "RadarMeasurementValid",
]

DETAIL_REVIEW_COLUMNS = [
    "FrameCount",
    "CandidateIds",
    "SelectedCameraRole",
    "CameraSelectionStatus",
    "CameraSelectionReason",
    "RadarDetectionFlag",
    "RadarValidityReason",
    "ComparisonEligibility",
    "EligibilityReason",
    "BaselineEstimate",
    "EvidenceScaleMeters",
    "SignedRobustScore",
    "EvidenceValid",
    "EvidenceReason",
]

CANDIDATE_REQUIRED_COLUMNS = [
    "CandidateId",
    "PriorityRank",
    "EvidenceStartFrame",
    "PeakFrameCount",
    "EvidenceEndFrame",
    "ReviewStartFrame",
    "ReviewEndFrame",
    "PeakRobustScore",
    "PeakSignedRobustScore",
    "PeakResidualMeters",
    "HitCount",
    "BurstCount",
    "Severity",
    "CandidateReason",
    "EvidenceThreshold",
    "HitBurstGapFrames",
    "MinimumBurstHits",
    "CandidateMergeGapFrames",
    "ReviewPaddingFrames",
    "SourceArtifactId",
    "CandidateStatus",
    "RootCauseClaim",
]

CAMERA_REQUIRED_COLUMNS = [
    "FrameCount",
    "Camera1Distance",
    "Camera3Distance",
    "CanonicalCameraDistance",
    "SelectedCameraRole",
    "SelectionStatus",
    "SelectionReason",
]

RADAR_REQUIRED_COLUMNS = [
    "FrameCount",
    "RadarDistance",
    "RadarDetectionFlag",
    "RadarMeasurementValid",
    "RadarValidityReason",
]

EVIDENCE_REQUIRED_COLUMNS = [
    "FrameCount",
    "CameraRadarDiscrepancy",
    "ComparisonEligibility",
    "EligibilityReason",
    "BaselineEstimate",
    "CameraRadarResidual",
    "EvidenceScaleMeters",
    "SignedRobustScore",
    "RobustAnomalyScore",
    "EvidenceValid",
    "EvidenceReason",
]

POLICY_FIELDS = [
    "EvidenceThreshold",
    "HitBurstGapFrames",
    "MinimumBurstHits",
    "CandidateMergeGapFrames",
    "ReviewPaddingFrames",
]


class ModuleError(RuntimeError):
    """Represent one deterministic, fail-closed Module failure."""


def stable(value: object) -> str:
    """Convert an exception into a compact machine-readable token."""

    text = re.sub(r"[^A-Z0-9_]+", "_", str(value).upper())
    return text.strip("_")[:96] or "INTERNAL"


def canonical_bytes(value: object) -> bytes:
    """Serialize governed JSON deterministically."""

    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    return (text + "\n").encode("utf-8")


def write_json(path: Path, value: object) -> None:
    """Write JSON atomically."""

    temporary = path.with_name(path.name + ".writing")
    temporary.write_bytes(canonical_bytes(value))
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    """Hash one file without loading it entirely into memory."""

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink()


def inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def load_json(path: Path, reason: str) -> Dict[str, object]:
    if not regular_file(path):
        raise ModuleError(reason + "_MISSING")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise ModuleError(reason + "_JSON") from exc
    if not isinstance(value, dict):
        raise ModuleError(reason + "_TYPE")
    return value


def safe_relative(value: object, field: str) -> PurePosixPath:
    text = str(value)
    if "\\" in text:
        raise ModuleError(field + "_SEPARATOR")
    path = PurePosixPath(text)
    if path.is_absolute() or not path.parts:
        raise ModuleError(field + "_PATH")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ModuleError(field + "_PATH")
    return path


def parse_integer(value: object, field: str) -> int:
    try:
        number = float(str(value).strip())
    except ValueError as exc:
        raise ModuleError("INTEGER_" + field) from exc
    if not math.isfinite(number) or not number.is_integer():
        raise ModuleError("INTEGER_" + field)
    return int(number)


def parse_finite(value: object, field: str) -> float:
    try:
        number = float(str(value).strip())
    except ValueError as exc:
        raise ModuleError("NUMBER_" + field) from exc
    if not math.isfinite(number):
        raise ModuleError("NUMBER_" + field)
    return number


def parse_boolean(value: object, field: str) -> bool:
    text = str(value if value is not None else "").strip().lower()
    if text in {"true", "false"}:
        return text == "true"
    try:
        number = float(text)
    except ValueError as exc:
        raise ModuleError("BOOLEAN_" + field) from exc
    if not math.isfinite(number) or number not in {0.0, 1.0}:
        raise ModuleError("BOOLEAN_" + field)
    return number == 1.0


def csv_value(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, float):
        return format(value, ".12g")
    return value


def validate_configuration(value: object) -> Dict[str, str]:
    if not isinstance(value, dict):
        raise ModuleError("CONFIGURATION_TYPE")
    expected = {
        "PackageFormatVersion": "0.1",
        "PriorityPolicy": "PRESERVE_S6_RANK_AND_SEVERITY",
        "ReviewDataProfile": "CAMERA_RADAR_CORE_V0_1",
        "ReviewDataWindowPolicy": "UNION_OF_REVIEW_WINDOWS",
        "ReviewQueueFormat": "U003_EVENT_QUEUE_V0_1",
        "SuggestedReviewMemoPolicy": "NON_CAUSAL_EVIDENCE_SUMMARY_V0_1",
    }
    if value != expected:
        raise ModuleError("CONFIGURATION_SHAPE_OR_VALUE")
    return dict(expected)


def validate_request(request: Mapping[str, object]) -> None:
    expected = {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Stage": STAGE,
    }
    for field, expected_value in expected.items():
        if request.get(field) != expected_value:
            raise ModuleError("REQUEST_" + field.upper())
    if request.get("ExpectedOutputTypes") != [ARTIFACT_TYPE]:
        raise ModuleError("REQUEST_OUTPUT_TYPE")
    artifacts = request.get("InputArtifacts")
    if not isinstance(artifacts, list):
        raise ModuleError("REQUEST_INPUT_ARTIFACTS")
    observed = [str(item.get("ArtifactType")) for item in artifacts]
    if observed != REQUIRED_ARTIFACTS:
        raise ModuleError("REQUEST_INPUT_ARTIFACT_TYPES")
    validate_configuration(request.get("Configuration"))


def artifact_record(
    request: Mapping[str, object],
    artifact_type: str,
) -> Mapping[str, object]:
    matches = [
        item
        for item in request["InputArtifacts"]
        if item.get("ArtifactType") == artifact_type
    ]
    if len(matches) != 1:
        raise ModuleError("ARTIFACT_COUNT_" + artifact_type)
    return matches[0]


def primary_csv(
    request: Mapping[str, object],
    artifact_type: str,
) -> Tuple[Path, Dict[str, object], Mapping[str, object]]:
    """Resolve and hash-check one governed primary CSV Artifact."""

    record = artifact_record(request, artifact_type)
    run_root = Path(str(request["RunRoot"])).resolve()
    relative = safe_relative(record.get("ManifestRelativePath"), "MANIFEST")
    manifest_path = run_root.joinpath(*relative.parts).resolve()
    if not regular_file(manifest_path) or not inside(manifest_path, run_root):
        raise ModuleError("MANIFEST_MISSING_" + artifact_type)
    if sha256_file(manifest_path) != record.get("ManifestSha256"):
        raise ModuleError("MANIFEST_HASH_" + artifact_type)

    manifest = load_json(manifest_path, "MANIFEST")
    if manifest.get("ArtifactId") != record.get("ArtifactId"):
        raise ModuleError("ARTIFACT_ID_" + artifact_type)
    if manifest.get("ArtifactType") != artifact_type:
        raise ModuleError("ARTIFACT_TYPE_" + artifact_type)
    candidates = [
        item
        for item in manifest.get("Payloads", [])
        if item.get("PayloadKind") == "PRIMARY"
        and item.get("MediaType") == "text/csv"
    ]
    if len(candidates) != 1:
        raise ModuleError("PRIMARY_CSV_COUNT_" + artifact_type)

    relative_payload = safe_relative(candidates[0].get("RelativePath"), "PAYLOAD")
    package_root = manifest_path.parent
    path = package_root.joinpath(*relative_payload.parts).resolve()
    if not regular_file(path) or not inside(path, package_root):
        raise ModuleError("PRIMARY_CSV_MISSING_" + artifact_type)
    if sha256_file(path) != candidates[0].get("Sha256"):
        raise ModuleError("PRIMARY_CSV_HASH_" + artifact_type)
    return path, manifest, record


def read_all_rows(
    path: Path,
    required_columns: Sequence[str],
) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        header = reader.fieldnames or []
        missing = [name for name in required_columns if name not in header]
        if missing:
            raise ModuleError("CSV_COLUMN_" + missing[0])
        return [dict(row) for row in reader]


def read_candidates(
    path: Path,
    source_artifact_id: str,
) -> List[Dict[str, object]]:
    rows = read_all_rows(path, CANDIDATE_REQUIRED_COLUMNS)
    if len(rows) > 40:
        raise ModuleError("CANDIDATE_CAPACITY")

    candidates: List[Dict[str, object]] = []
    identities: set[str] = set()
    ranks: set[int] = set()
    policy_reference: Optional[Tuple[object, ...]] = None
    for row in rows:
        candidate_id = row["CandidateId"].strip()
        if not candidate_id or candidate_id in identities:
            raise ModuleError("CANDIDATE_ID")
        identities.add(candidate_id)
        rank = parse_integer(row["PriorityRank"], "PRIORITY_RANK")
        if rank < 1 or rank in ranks:
            raise ModuleError("CANDIDATE_RANK")
        ranks.add(rank)

        evidence_start = parse_integer(row["EvidenceStartFrame"], "EVIDENCE_START")
        peak = parse_integer(row["PeakFrameCount"], "PEAK_FRAME")
        evidence_end = parse_integer(row["EvidenceEndFrame"], "EVIDENCE_END")
        review_start = parse_integer(row["ReviewStartFrame"], "REVIEW_START")
        review_end = parse_integer(row["ReviewEndFrame"], "REVIEW_END")
        if not review_start <= evidence_start <= peak <= evidence_end <= review_end:
            raise ModuleError("CANDIDATE_WINDOW_ORDER")

        score = parse_finite(row["PeakRobustScore"], "PEAK_SCORE")
        if score < 0.0:
            raise ModuleError("CANDIDATE_SCORE")
        if row["Severity"] not in {"REVIEW", "HIGH", "CRITICAL"}:
            raise ModuleError("CANDIDATE_SEVERITY")
        if row["CandidateStatus"] != "INVESTIGATION_CANDIDATE":
            raise ModuleError("CANDIDATE_STATUS")
        if parse_boolean(row["RootCauseClaim"], "ROOT_CAUSE_CLAIM"):
            raise ModuleError("ROOT_CAUSE_CLAIM")
        if row["SourceArtifactId"] != source_artifact_id:
            raise ModuleError("CANDIDATE_SOURCE_ARTIFACT")

        policy = tuple(row[field] for field in POLICY_FIELDS)
        if policy_reference is None:
            policy_reference = policy
        elif policy != policy_reference:
            raise ModuleError("CANDIDATE_POLICY_INCONSISTENT")

        candidate: Dict[str, object] = dict(row)
        candidate.update({
            "PriorityRank": rank,
            "EvidenceStartFrame": evidence_start,
            "PeakFrameCount": peak,
            "EvidenceEndFrame": evidence_end,
            "ReviewStartFrame": review_start,
            "ReviewEndFrame": review_end,
            "PeakRobustScore": score,
            "HitCount": parse_integer(row["HitCount"], "HIT_COUNT"),
            "BurstCount": parse_integer(row["BurstCount"], "BURST_COUNT"),
        })
        candidates.append(candidate)

    if ranks and ranks != set(range(1, len(rows) + 1)):
        raise ModuleError("CANDIDATE_RANK_SEQUENCE")
    candidates.sort(key=lambda item: int(item["PriorityRank"]))
    return candidates


def review_intervals(
    candidates: Sequence[Mapping[str, object]],
) -> List[Tuple[int, int]]:
    """Merge overlapping review windows to bound source rows retained in memory."""

    intervals = sorted(
        (
            int(candidate["ReviewStartFrame"]),
            int(candidate["ReviewEndFrame"]),
        )
        for candidate in candidates
    )
    merged: List[Tuple[int, int]] = []
    for start, end in intervals:
        if not merged or start > merged[-1][1] + 1:
            merged.append((start, end))
        else:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
    return merged


def frame_in_intervals(frame: int, intervals: Sequence[Tuple[int, int]]) -> bool:
    for start, end in intervals:
        if frame < start:
            return False
        if frame <= end:
            return True
    return False


def read_window_rows(
    path: Path,
    required_columns: Sequence[str],
    intervals: Sequence[Tuple[int, int]],
) -> Tuple[Dict[int, Dict[str, str]], int]:
    """Stream one source table and retain only rows needed for human review."""

    selected: Dict[int, Dict[str, str]] = {}
    total = 0
    previous: Optional[int] = None
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        header = reader.fieldnames or []
        missing = [name for name in required_columns if name not in header]
        if missing:
            raise ModuleError("CSV_COLUMN_" + missing[0])
        for row in reader:
            frame = parse_integer(row["FrameCount"], "FRAMECOUNT")
            if previous is not None and frame <= previous:
                raise ModuleError("FRAME_ORDER")
            previous = frame
            total += 1
            if frame_in_intervals(frame, intervals):
                selected[frame] = dict(row)
    return selected, total


def candidate_ids_at_frame(
    frame: int,
    candidates: Sequence[Mapping[str, object]],
) -> str:
    identities = [
        str(candidate["CandidateId"])
        for candidate in candidates
        if int(candidate["ReviewStartFrame"]) <= frame <= int(candidate["ReviewEndFrame"])
    ]
    return ";".join(identities)


def policy_profile_id(candidates: Sequence[Mapping[str, object]]) -> str:
    if not candidates:
        return "S6P-EMPTY"
    policy = {field: candidates[0][field] for field in POLICY_FIELDS}
    digest = hashlib.sha256(canonical_bytes(policy)).hexdigest()[:16]
    return "S6P-" + digest


def review_artifact_id(request: Mapping[str, object]) -> str:
    return str(request["RunId"]) + "." + MODULE_ID + "." + str(request["Sequence"])


def build_queue_rows(
    request: Mapping[str, object],
    candidates: Sequence[Mapping[str, object]],
    s6_manifest: Mapping[str, object],
    s5_artifact_id: str,
) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    profile_id = policy_profile_id(candidates)
    artifact_id = review_artifact_id(request)
    for candidate in candidates:
        score = float(candidate["PeakRobustScore"])
        hit_count = int(candidate["HitCount"])
        peak = int(candidate["PeakFrameCount"])
        reason = (
            "PeakRobustScore=" + format(score, ".12g")
            + ";HitCount=" + str(hit_count)
            + ";Rank=" + str(candidate["PriorityRank"])
        )
        memo = (
            "Robust Camera-Radar residual evidence produced "
            + str(hit_count)
            + " threshold hits; inspect target identity, measurement validity, "
            + "timing and scene context around FrameCount "
            + str(peak)
            + "."
        )
        rows.append({
            "EventID": candidate["CandidateId"],
            "StartFrameCount": candidate["ReviewStartFrame"],
            "PeakFrameCount": peak,
            "EndFrameCount": candidate["ReviewEndFrame"],
            "ReviewResult": "",
            "ReviewMemo": "",
            "CandidateId": candidate["CandidateId"],
            "EvidenceStartFrame": candidate["EvidenceStartFrame"],
            "EvidenceEndFrame": candidate["EvidenceEndFrame"],
            "CandidateType": candidate["CandidateReason"],
            "CandidateScore": score,
            "CandidateRank": candidate["PriorityRank"],
            "PriorityClass": candidate["Severity"],
            "PriorityReason": reason,
            "CandidatePolicyProfileId": profile_id,
            "SuggestedReviewMemo": memo,
            "SuggestedReviewTags": (
                "CAMERA_RADAR_DISCREPANCY;ROBUST_RESIDUAL;VIDEO_CONFIRMATION_REQUIRED"
            ),
            "SuggestedEvidenceIds": (
                str(s6_manifest["ArtifactId"]) + ";" + s5_artifact_id
            ),
            "SuggestedConfidence": "PROVISIONAL_MACHINE_EVIDENCE",
            "PrimarySignal": "CameraRadarResidual",
            "RelatedSignals": (
                "Camera1Distance;Camera3Distance;CanonicalCameraDistance;"
                "RadarDistance;CameraRadarDiscrepancy;RobustAnomalyScore"
            ),
            "ModuleId": s6_manifest["ProducerModuleId"],
            "ModuleVersion": s6_manifest["ProducerModuleVersion"],
            "AlgorithmStatus": "PROVISIONAL",
            "ReviewDataArtifactId": artifact_id,
            "SourceArtifactId": candidate["SourceArtifactId"],
            "CandidateStatus": candidate["CandidateStatus"],
            "RootCauseClaim": 0,
        })
    return rows


def build_review_rows(
    candidates: Sequence[Mapping[str, object]],
    camera_rows: Mapping[int, Mapping[str, str]],
    radar_rows: Mapping[int, Mapping[str, str]],
    evidence_rows: Mapping[int, Mapping[str, str]],
) -> Tuple[List[Dict[str, object]], List[Dict[str, object]]]:
    frames = sorted(evidence_rows)
    if set(camera_rows) != set(frames):
        raise ModuleError("CAMERA_REVIEW_FRAME_COVERAGE")
    if set(radar_rows) != set(frames):
        raise ModuleError("RADAR_REVIEW_FRAME_COVERAGE")

    core_rows: List[Dict[str, object]] = []
    detail_rows: List[Dict[str, object]] = []
    for frame in frames:
        camera = camera_rows[frame]
        radar = radar_rows[frame]
        evidence = evidence_rows[frame]
        candidate_ids = candidate_ids_at_frame(frame, candidates)
        core_rows.append({
            "FrameCount": frame,
            "CandidateIds": candidate_ids,
            "Camera1Distance": camera["Camera1Distance"],
            "Camera3Distance": camera["Camera3Distance"],
            "CanonicalCameraDistance": camera["CanonicalCameraDistance"],
            "RadarDistance": radar["RadarDistance"],
            "CameraRadarDiscrepancy": evidence["CameraRadarDiscrepancy"],
            "CameraRadarResidual": evidence["CameraRadarResidual"],
            "RobustAnomalyScore": evidence["RobustAnomalyScore"],
            "RadarMeasurementValid": radar["RadarMeasurementValid"],
        })
        detail_rows.append({
            "FrameCount": frame,
            "CandidateIds": candidate_ids,
            "SelectedCameraRole": camera["SelectedCameraRole"],
            "CameraSelectionStatus": camera["SelectionStatus"],
            "CameraSelectionReason": camera["SelectionReason"],
            "RadarDetectionFlag": radar["RadarDetectionFlag"],
            "RadarValidityReason": radar["RadarValidityReason"],
            "ComparisonEligibility": evidence["ComparisonEligibility"],
            "EligibilityReason": evidence["EligibilityReason"],
            "BaselineEstimate": evidence["BaselineEstimate"],
            "EvidenceScaleMeters": evidence["EvidenceScaleMeters"],
            "SignedRobustScore": evidence["SignedRobustScore"],
            "EvidenceValid": evidence["EvidenceValid"],
            "EvidenceReason": evidence["EvidenceReason"],
        })
    return core_rows, detail_rows


def write_csv(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> int:
    count = 0
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({name: csv_value(row.get(name)) for name in fieldnames})
            count += 1
    return count


def file_record(
    path: Path,
    media_type: str,
    row_count: Optional[int],
    payload_kind: str,
) -> Dict[str, object]:
    return {
        "RelativePath": path.name,
        "MediaType": media_type,
        "RowCount": row_count,
        "Sha256": sha256_file(path),
        "ByteSize": path.stat().st_size,
        "PayloadKind": payload_kind,
    }


def execute(request: Mapping[str, object]) -> Dict[str, object]:
    configuration = validate_configuration(request.get("Configuration"))
    source: Dict[str, Tuple[Path, Dict[str, object], Mapping[str, object]]] = {}
    for artifact_type in REQUIRED_ARTIFACTS:
        source[artifact_type] = primary_csv(request, artifact_type)

    candidate_path, s6_manifest, _ = source["ANOMALY_CANDIDATES"]
    if s6_manifest.get("ProducerModuleId") != S6_MODULE_ID:
        raise ModuleError("S6_PRODUCER_ID")
    if s6_manifest.get("ProducerModuleVersion") != S6_MODULE_VERSION:
        raise ModuleError("S6_PRODUCER_VERSION")

    s5_manifest = source["ROBUST_RESIDUAL_EVIDENCE"][1]
    if s6_manifest.get("ParentArtifactIds") != [s5_manifest.get("ArtifactId")]:
        raise ModuleError("S6_S5_LINEAGE")
    candidates = read_candidates(candidate_path, str(s5_manifest["ArtifactId"]))
    intervals = review_intervals(candidates)

    camera_rows, camera_total = read_window_rows(
        source["CAMERA_TARGET_RECONSTRUCTION"][0],
        CAMERA_REQUIRED_COLUMNS,
        intervals,
    )
    radar_rows, radar_total = read_window_rows(
        source["RADAR_VALIDITY"][0],
        RADAR_REQUIRED_COLUMNS,
        intervals,
    )
    evidence_rows, evidence_total = read_window_rows(
        source["ROBUST_RESIDUAL_EVIDENCE"][0],
        EVIDENCE_REQUIRED_COLUMNS,
        intervals,
    )

    for candidate in candidates:
        if int(candidate["PeakFrameCount"]) not in evidence_rows:
            raise ModuleError("CANDIDATE_PEAK_EVIDENCE_MISSING")

    queue_rows = build_queue_rows(
        request,
        candidates,
        s6_manifest,
        str(s5_manifest["ArtifactId"]),
    )
    core_rows, detail_rows = build_review_rows(
        candidates,
        camera_rows,
        radar_rows,
        evidence_rows,
    )

    output_root = Path(str(request["OutputRoot"])).resolve()
    package_root = output_root / "artifact_01"
    package_root.mkdir(parents=True)

    queue_path = package_root / "review_queue.csv"
    data_path = package_root / "review_data.csv"
    detail_path = package_root / "review_evidence_detail.csv"
    validation_path = package_root / "review_package_validation.json"
    review_manifest_path = package_root / "review_manifest.json"

    queue_count = write_csv(queue_path, QUEUE_COLUMNS, queue_rows)
    data_count = write_csv(data_path, CORE_REVIEW_COLUMNS, core_rows)
    detail_count = write_csv(detail_path, DETAIL_REVIEW_COLUMNS, detail_rows)

    peak_coverage = all(
        int(candidate["PeakFrameCount"]) in evidence_rows
        for candidate in candidates
    )
    validation = {
        "Contract": "U002_U003_REVIEW_PACKAGE_VALIDATION_V0_1",
        "Status": "PASS",
        "RunId": request["RunId"],
        "CandidateCount": queue_count,
        "ReviewDataRowCount": data_count,
        "DetailDataRowCount": detail_count,
        "MergedReviewWindowCount": len(intervals),
        "PeakCoveragePassed": peak_coverage,
        "QueueCapacityPassed": queue_count <= 40,
        "QueueHeaderPassed": QUEUE_COLUMNS[:5] == [
            "EventID",
            "StartFrameCount",
            "PeakFrameCount",
            "EndFrameCount",
            "ReviewResult",
        ],
        "ReviewDataHeaderPassed": CORE_REVIEW_COLUMNS[0] == "FrameCount",
        "HumanReviewColumnCount": len(CORE_REVIEW_COLUMNS),
        "RootCauseClaim": False,
        "CandidateIsConfirmedEvent": False,
        "SourceRowCounts": {
            "Camera": camera_total,
            "Radar": radar_total,
            "Evidence": evidence_total,
        },
        "FileHashes": {
            queue_path.name: sha256_file(queue_path),
            data_path.name: sha256_file(data_path),
            detail_path.name: sha256_file(detail_path),
        },
    }
    write_json(validation_path, validation)

    source_artifacts = [
        {
            "ArtifactType": artifact_type,
            "ArtifactId": source[artifact_type][1]["ArtifactId"],
            "ManifestSha256": source[artifact_type][2]["ManifestSha256"],
        }
        for artifact_type in REQUIRED_ARTIFACTS
    ]
    review_manifest = {
        "Contract": "U002_U003_REVIEW_PACKAGE",
        "PackageFormatVersion": configuration["PackageFormatVersion"],
        "RunId": request["RunId"],
        "ReviewArtifactId": review_artifact_id(request),
        "CandidatePolicyProfileId": policy_profile_id(candidates),
        "CandidatePolicySourceArtifactId": s6_manifest["ArtifactId"],
        "CandidateCount": queue_count,
        "ReviewDataRowCount": data_count,
        "ReviewDataProfile": configuration["ReviewDataProfile"],
        "CoreReviewColumns": CORE_REVIEW_COLUMNS,
        "DetailReviewColumns": DETAIL_REVIEW_COLUMNS,
        "SourceArtifacts": source_artifacts,
        "Files": {
            "ReviewQueue": file_record(queue_path, "text/csv", queue_count, "PRIMARY"),
            "ReviewData": file_record(data_path, "text/csv", data_count, "AUXILIARY"),
            "DetailedEvidence": file_record(detail_path, "text/csv", detail_count, "AUXILIARY"),
            "Validation": file_record(validation_path, "application/json", None, "AUXILIARY"),
        },
        "U003Loading": {
            "EventQueue": queue_path.name,
            "ReviewData": data_path.name,
            "DetailedEvidenceOptional": detail_path.name,
            "VideoSelection": "MANUAL",
            "FrameCountAnchor": "USER_CONFIRMED",
        },
        "SemanticBoundaries": {
            "CandidateIsConfirmedEvent": False,
            "RootCauseClaim": False,
            "RadarIsGroundTruth": False,
            "ReviewResultOwner": "HUMAN_ENGINEER",
        },
    }
    write_json(review_manifest_path, review_manifest)

    artifact_manifest = {
        "ContractVersion": CONTRACT_VERSION,
        "ArtifactId": review_artifact_id(request),
        "ArtifactType": ARTIFACT_TYPE,
        "SchemaId": "U002_U003_REVIEW_PACKAGE",
        "SchemaVersion": "0.1",
        "RunId": request["RunId"],
        "Stage": STAGE,
        "ProducerModuleId": MODULE_ID,
        "ProducerModuleVersion": MODULE_VERSION,
        "ParentArtifactIds": [
            source[artifact_type][1]["ArtifactId"]
            for artifact_type in REQUIRED_ARTIFACTS
        ],
        "Payloads": [
            file_record(queue_path, "text/csv", queue_count, "PRIMARY"),
            file_record(data_path, "text/csv", data_count, "AUXILIARY"),
            file_record(detail_path, "text/csv", detail_count, "AUXILIARY"),
            file_record(validation_path, "application/json", None, "AUXILIARY"),
            file_record(review_manifest_path, "application/json", None, "AUXILIARY"),
        ],
        "Metadata": {
            "CandidateCount": queue_count,
            "ReviewDataRowCount": data_count,
            "MergedReviewWindowCount": len(intervals),
            "HumanReviewColumnCount": len(CORE_REVIEW_COLUMNS),
            "DetailedEvidenceColumnCount": len(DETAIL_REVIEW_COLUMNS),
            "CandidatePolicyProfileId": policy_profile_id(candidates),
            "U003CompatibleManualLoad": True,
            "CandidateIsConfirmedEvent": False,
            "RootCauseClaim": False,
        },
    }
    write_json(package_root / "artifact_manifest.json", artifact_manifest)

    return {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "RunId": request["RunId"],
        "Sequence": request["Sequence"],
        "Stage": STAGE,
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Status": "SUCCEEDED",
        "ProducedPackages": ["artifact_01"],
        "Capsule": (
            "B5S7 N-C" + str(queue_count)
            + "-R" + str(data_count)
            + "-D" + str(detail_count)
            + "-W" + str(len(intervals))
            + "-K" + str(len(CORE_REVIEW_COLUMNS))
            + "-X0 C-0"
        ),
        "Diagnostics": [],
    }


def test_configuration() -> Dict[str, str]:
    return validate_configuration({
        "PackageFormatVersion": "0.1",
        "PriorityPolicy": "PRESERVE_S6_RANK_AND_SEVERITY",
        "ReviewDataProfile": "CAMERA_RADAR_CORE_V0_1",
        "ReviewDataWindowPolicy": "UNION_OF_REVIEW_WINDOWS",
        "ReviewQueueFormat": "U003_EVENT_QUEUE_V0_1",
        "SuggestedReviewMemoPolicy": "NON_CAUSAL_EVIDENCE_SUMMARY_V0_1",
    })


def write_fixture_artifact(
    run_root: Path,
    artifact_type: str,
    producer_id: str,
    producer_version: str,
    stage: str,
    sequence: int,
    file_name: str,
    fieldnames: Sequence[str],
    rows: Sequence[Mapping[str, object]],
    parent_ids: Sequence[str],
) -> Dict[str, object]:
    artifact_id = "SELFTEST." + producer_id + "." + str(sequence)
    package = run_root / "03_ARTIFACTS" / stage / artifact_id
    package.mkdir(parents=True)
    payload = package / file_name
    write_csv(payload, fieldnames, rows)
    manifest = {
        "ContractVersion": CONTRACT_VERSION,
        "ArtifactId": artifact_id,
        "ArtifactType": artifact_type,
        "SchemaId": "SELFTEST",
        "SchemaVersion": "0.1",
        "RunId": "SELFTEST",
        "Stage": stage,
        "ProducerModuleId": producer_id,
        "ProducerModuleVersion": producer_version,
        "ParentArtifactIds": list(parent_ids),
        "Payloads": [file_record(payload, "text/csv", len(rows), "PRIMARY")],
        "Metadata": {},
    }
    manifest_path = package / "artifact_manifest.json"
    write_json(manifest_path, manifest)
    return {
        "ArtifactId": artifact_id,
        "ArtifactType": artifact_type,
        "ManifestRelativePath": manifest_path.relative_to(run_root).as_posix(),
        "ManifestSha256": sha256_file(manifest_path),
        "ParentArtifactIds": list(parent_ids),
        "Payloads": manifest["Payloads"],
        "ProducerModuleId": producer_id,
        "ProducerModuleVersion": producer_version,
        "Stage": stage,
    }


def semantic_selftest() -> int:
    checks: List[bool] = []

    def check(value: bool) -> None:
        if not value:
            raise AssertionError("SEMANTIC_SELFTEST")
        checks.append(True)

    configuration = test_configuration()
    check(configuration["ReviewDataProfile"] == "CAMERA_RADAR_CORE_V0_1")
    check(len(CORE_REVIEW_COLUMNS) == 10)
    check(CORE_REVIEW_COLUMNS[0] == "FrameCount")
    check(QUEUE_COLUMNS[0] == "EventID")
    check("ReviewMemo" in QUEUE_COLUMNS)
    check("SuggestedReviewMemo" in QUEUE_COLUMNS)
    check(review_intervals([]) == [])
    check(review_intervals([
        {"ReviewStartFrame": 10, "ReviewEndFrame": 20},
        {"ReviewStartFrame": 20, "ReviewEndFrame": 30},
    ]) == [(10, 30)])
    check(frame_in_intervals(15, [(10, 20)]))
    check(not frame_in_intervals(21, [(10, 20)]))

    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_root = root / "RUN"
        run_root.mkdir()
        frames = [100, 101, 102]
        s5_id = "SELFTEST.CameraRadar.S5.RobustResidualEvidence.4"

        candidate_rows = [{
            "CandidateId": "C0001",
            "PriorityRank": 1,
            "EvidenceStartFrame": 100,
            "PeakFrameCount": 101,
            "EvidenceEndFrame": 101,
            "ReviewStartFrame": 100,
            "ReviewEndFrame": 102,
            "PeakRobustScore": 3.5,
            "PeakSignedRobustScore": 3.5,
            "PeakResidualMeters": 0.7,
            "HitCount": 2,
            "BurstCount": 1,
            "Severity": "HIGH",
            "CandidateReason": "ROBUST_RESIDUAL_SCORE_BURST",
            "EvidenceThreshold": 2.0,
            "HitBurstGapFrames": 20,
            "MinimumBurstHits": 2,
            "CandidateMergeGapFrames": 100,
            "ReviewPaddingFrames": 400,
            "SourceArtifactId": s5_id,
            "CandidateStatus": "INVESTIGATION_CANDIDATE",
            "RootCauseClaim": 0,
        }]
        camera_rows = [
            {
                "FrameCount": frame,
                "Camera1Distance": 10 + index,
                "Camera3Distance": "",
                "CanonicalCameraDistance": 10 + index,
                "SelectedCameraRole": "CAMERA_1_DISTANCE",
                "SelectionStatus": "CONFIDENT",
                "SelectionReason": "CURRENT_SOURCE_PLAUSIBLE",
            }
            for index, frame in enumerate(frames)
        ]
        radar_rows = [
            {
                "FrameCount": frame,
                "RadarDistance": 12 + index,
                "RadarDetectionFlag": 1,
                "RadarMeasurementValid": 1,
                "RadarValidityReason": "VALID_MEASUREMENT",
            }
            for index, frame in enumerate(frames)
        ]
        evidence_rows = [
            {
                "FrameCount": frame,
                "CameraRadarDiscrepancy": 2.0,
                "ComparisonEligibility": "FORMAL_ELIGIBLE",
                "EligibilityReason": "BOTH_MEASUREMENTS_VALID",
                "BaselineEstimate": 1.3,
                "CameraRadarResidual": 0.7,
                "EvidenceScaleMeters": 0.2,
                "SignedRobustScore": 3.5,
                "RobustAnomalyScore": 3.5,
                "EvidenceValid": 1,
                "EvidenceReason": "VALID_EVIDENCE",
            }
            for frame in frames
        ]

        candidate_record = write_fixture_artifact(
            run_root,
            "ANOMALY_CANDIDATES",
            S6_MODULE_ID,
            S6_MODULE_VERSION,
            "S6",
            1,
            "anomaly_candidates.csv",
            CANDIDATE_REQUIRED_COLUMNS,
            candidate_rows,
            [s5_id],
        )
        camera_record = write_fixture_artifact(
            run_root,
            "CAMERA_TARGET_RECONSTRUCTION",
            "CameraRadar.S1.CameraTargetContinuityArbitration",
            "0.2.0",
            "S1",
            2,
            "camera_target_reconstruction.csv",
            CAMERA_REQUIRED_COLUMNS,
            camera_rows,
            [],
        )
        radar_record = write_fixture_artifact(
            run_root,
            "RADAR_VALIDITY",
            "CameraRadar.S1.RadarMeasurementValidity",
            "0.1.0",
            "S1",
            3,
            "radar_validity.csv",
            RADAR_REQUIRED_COLUMNS,
            radar_rows,
            [],
        )
        evidence_record = write_fixture_artifact(
            run_root,
            "ROBUST_RESIDUAL_EVIDENCE",
            "CameraRadar.S5.RobustResidualEvidence",
            "0.1.0",
            "S5",
            4,
            "robust_residual_evidence.csv",
            EVIDENCE_REQUIRED_COLUMNS,
            evidence_rows,
            [],
        )
        check(evidence_record["ArtifactId"] == s5_id)

        request: Dict[str, object] = {
            "Protocol": PROTOCOL,
            "ProtocolVersion": PROTOCOL_VERSION,
            "ContractVersion": CONTRACT_VERSION,
            "RunId": "SELFTEST",
            "Sequence": 5,
            "Stage": STAGE,
            "ModuleId": MODULE_ID,
            "ModuleVersion": MODULE_VERSION,
            "ModuleRoot": str(Path(__file__).resolve().parent),
            "RunRoot": str(run_root),
            "InputPackage": str(root / "INPUT"),
            "RequiredInputs": [],
            "OptionalInputs": [],
            "InputArtifacts": [
                candidate_record,
                camera_record,
                radar_record,
                evidence_record,
            ],
            "Configuration": configuration,
            "ExpectedOutputTypes": [ARTIFACT_TYPE],
            "OutputRoot": str(root / "OUTPUT"),
        }
        validate_request(request)
        check(True)
        result = execute(request)
        check(result["Status"] == "SUCCEEDED")
        check(result["ProducedPackages"] == ["artifact_01"])
        check(result["Capsule"].endswith("C-0"))

        package = root / "OUTPUT" / "artifact_01"
        manifest = load_json(package / "artifact_manifest.json", "TEST_MANIFEST")
        review_manifest = load_json(package / "review_manifest.json", "TEST_REVIEW_MANIFEST")
        validation = load_json(package / "review_package_validation.json", "TEST_VALIDATION")
        check(manifest["ArtifactType"] == ARTIFACT_TYPE)
        check(len(manifest["Payloads"]) == 5)
        check(review_manifest["CandidateCount"] == 1)
        check(review_manifest["ReviewDataRowCount"] == 3)
        check(review_manifest["SemanticBoundaries"]["RootCauseClaim"] is False)
        check(validation["Status"] == "PASS")
        check(validation["HumanReviewColumnCount"] == 10)

        queue = read_all_rows(package / "review_queue.csv", QUEUE_COLUMNS)
        data = read_all_rows(package / "review_data.csv", CORE_REVIEW_COLUMNS)
        detail = read_all_rows(package / "review_evidence_detail.csv", DETAIL_REVIEW_COLUMNS)
        check(len(queue) == 1)
        check(queue[0]["EventID"] == "C0001")
        check(queue[0]["ReviewResult"] == "")
        check(queue[0]["ReviewMemo"] == "")
        check(queue[0]["PriorityClass"] == "HIGH")
        check(queue[0]["RootCauseClaim"] == "0")
        check("target identity" in queue[0]["SuggestedReviewMemo"])
        check(len(data) == 3)
        check(data[1]["FrameCount"] == "101")
        check(data[1]["CandidateIds"] == "C0001")
        check(len(detail) == 3)
        check(detail[1]["CameraSelectionStatus"] == "CONFIDENT")
        check(queue[0]["CandidatePolicyProfileId"].startswith("S6P-"))

        evidence_path = run_root / evidence_record["ManifestRelativePath"]
        evidence_payload = evidence_path.parent / "robust_residual_evidence.csv"
        evidence_payload.write_text(
            evidence_payload.read_text(encoding="utf-8") + "\n",
            encoding="utf-8",
        )
        tamper_blocked = False
        try:
            request["OutputRoot"] = str(root / "TAMPER_OUTPUT")
            execute(request)
        except ModuleError as exc:
            tamper_blocked = "PRIMARY_CSV_HASH" in str(exc)
        check(tamper_blocked)

    if len(checks) != 36:
        raise AssertionError("SELFTEST_COUNT")
    return len(checks)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request-json", required=True)
    parser.add_argument("--result-json", required=True)
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        request = load_json(Path(args.request_json), "REQUEST")
        validate_request(request)
        result = execute(request)
        write_json(Path(args.result_json), result)
        print(result["Capsule"])
        return 0
    except Exception as exc:
        print("B5S7 K-" + stable(exc) + "-X1 C-7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
