#!/usr/bin/env python3
"""Installed-source gate for the U3M8H1 synchronized Signal CSV repair."""

from __future__ import annotations

import argparse
import importlib
import subprocess
import sys
from pathlib import Path


class GateError(RuntimeError):
    """Raised when the installed hotfix is incomplete or not executable."""


def run_child(path: Path, expected: str) -> None:
    completed = subprocess.run(
        [sys.executable, str(path), "--self-test"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=90,
        check=False,
    )
    if completed.returncode != 0 or expected not in completed.stdout:
        raise GateError(
            f"Child self-test failed: {path.name}; rc={completed.returncode}; "
            f"stdout={completed.stdout[-500:]}; stderr={completed.stderr[-500:]}"
        )


def run_gate(root: Path) -> int:
    root = root.resolve()
    program_root = root / "01_PROGRAMS"
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise GateError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    required = (
        program_root / "u003_gui_shell_v0_8.py",
        program_root / "u003_evidence_review_workbench_v0_21.py",
        program_root / "u003_u3m8h1_signal_csv_acceptance_gate_v0_1.py",
        program_root / "u003_domain_core_v0_2.py",
        program_root / "u003_live_review_context_v0_1.py",
        program_root / "u003_module_action_gui_v0_2.py",
    )
    for path in required:
        check(path.is_file(), f"required file {path.name}", "installed topology is complete")

    sys.path.insert(0, str(program_root))
    shell = importlib.import_module("u003_gui_shell_v0_8")
    workbench = importlib.import_module("u003_evidence_review_workbench_v0_21")
    check(shell.GUI_SHELL_VERSION == "0.8", "GUI shell version", "the repaired shell is active")
    check(workbench.VERSION == "0.21", "workbench version", "the repaired composition launches")
    check(hasattr(shell, "bisect"), "bisect import", "Signal CSV lookup dependency is present")
    check(
        shell.signal_frame_window([100, 110, 120, 130], 105, 125) == (1, 3),
        "bounded Signal CSV lookup",
        "inclusive FrameCount selection returns the expected slice",
    )
    check(
        shell.signal_frame_window([100, 110, 120, 130], 100, 130) == (0, 4),
        "full Signal CSV lookup",
        "both range boundaries are included",
    )
    try:
        shell.signal_frame_window([100], 101, 100)
    except ValueError:
        invalid_range_closed = True
    else:
        invalid_range_closed = False
    check(invalid_range_closed, "invalid range fail-close", "reversed FrameCount ranges are rejected")

    shell_source = (program_root / "u003_gui_shell_v0_8.py").read_text(encoding="utf-8")
    workbench_source = (program_root / "u003_evidence_review_workbench_v0_21.py").read_text(encoding="utf-8")
    check("import bisect" in shell_source, "explicit dependency", "the repair cannot depend on an incidental import")
    check(shell_source.count("signal_frame_window(") >= 3, "shared lookup helper", "display and export use one tested boundary rule")
    check("u003_gui_shell_v0_8" in workbench_source, "composition identity", "the launcher cannot silently reopen v0.7")
    check("Signal CSV error" in shell_source, "user-facing error boundary", "load failures remain visible")
    check("load_signal_path" in shell_source, "governed path loader", "manual and U002 handoff paths share one implementation")

    class DummyVariable:
        def __init__(self) -> None:
            self.value = ""

        def set(self, value: object) -> None:
            self.value = str(value)

    class DummyTree:
        def get_children(self) -> tuple[()]:
            return ()

        def delete(self, *items: object) -> None:
            del items

        def configure(self, **options: object) -> None:
            del options

        def heading(self, column: str, **options: object) -> None:
            del column, options

        def column(self, column: str, **options: object) -> None:
            del column, options

    fixture_csv = root / "04_TEMP" / "U3M8H1_GATE_REVIEW_DATA.csv"
    fixture_csv.parent.mkdir(parents=True, exist_ok=True)
    fixture_csv.write_text(
        "FrameCount,SignalA\n100,1.0\n110,2.0\n110,3.0\n",
        encoding="utf-8",
    )
    reviewer = shell.FrameCountVideoReviewer.__new__(shell.FrameCountVideoReviewer)
    reviewer.signal_tree = DummyTree()
    reviewer.signal_info_var = DummyVariable()
    reviewer.status_var = DummyVariable()
    reviewer.refresh_signal_table = lambda: None
    reviewer.load_signal_path(fixture_csv)
    check(reviewer.signal_framecounts == [100, 110], "Signal CSV parse", "numeric FrameCount rows load and sort")
    check(len(reviewer.signal_records) == 2, "duplicate FrameCount collapse", "the final row remains authoritative")
    check(reviewer.signal_records[-1][1]["SignalA"] == "3.0", "duplicate value policy", "the same rule used by U003 is exercised")
    try:
        fixture_csv.unlink()
    except OSError:
        pass

    run_child(
        program_root / "u003_evidence_review_workbench_v0_21.py",
        "U003-V021-SELFTEST-PASS-25",
    )
    check(True, "workbench self-test", "the complete v0.21 composition imports")

    print(f"U3H1G N-S1-W1-B1-L1-T{checks}-X0 C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    return run_gate(arguments.root)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3H1GE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
