#!/usr/bin/env python3
"""U003 GUI shell with non-blocking, live-context Module Actions.

The shell owns widgets, video decoding, synchronized table presentation and
engineer interaction. Review-domain and U002-handoff behavior belong to the
separate versioned cores imported below.
"""

from __future__ import annotations

import bisect
import csv
import math
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from u003_domain_core_v0_2 import (
    REVIEW_CODES,
    ReviewEvent,
    build_review_return_capsule,
    compact_text,
    find_column,
    framecount_to_video_index as map_framecount_to_video_index,
    highlight_target_framecount,
    nearest_sorted_index,
    normalized_name,
    parse_number,
    parse_review_events,
    read_delimited_file,
    video_index_to_framecount as map_video_index_to_framecount,
)
from u003_handoff_core_v0_2 import GovernedHandoffBatch
from u003_localization_v0_2 import (
    LocalizedTtk,
    Localizer,
    localized_string_var,
    normalize_language,
)
from u003_live_review_context_v0_1 import LiveReviewContextPublisher
from u003_module_action_gui_v0_2 import ModuleActionWindow
from u003_module_execution_coordinator_v0_3 import ModuleExecutionCoordinator
from u003_module_manager_gui_v0_4 import ModuleManagerWindow


GUI_SHELL_VERSION = "0.8"
WORKBENCH_VERSION = "0.21"
VERSION = WORKBENCH_VERSION


def signal_frame_window(
    framecounts: list[int],
    start_framecount: int,
    end_framecount: int,
) -> tuple[int, int]:
    """Return the inclusive FrameCount window as Python slice boundaries.

    This pure helper keeps synchronized-table lookup testable without opening
    tkinter.  The returned right boundary is exclusive, matching ``range``.
    """

    if start_framecount > end_framecount:
        raise ValueError("start_framecount must not exceed end_framecount")
    left = bisect.bisect_left(framecounts, start_framecount)
    right = bisect.bisect_right(framecounts, end_framecount)
    return left, right


def application_root() -> Path:
    """Return the persistent U003 root in source and one-file deployments."""

    configured = os.environ.get("U003_APPLICATION_ROOT", "").strip()
    if configured:
        return Path(configured).resolve()
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


class FrameCountVideoReviewer:
    def __init__(self, language: str = "EN") -> None:
        self.language = normalize_language(language)
        self.localizer = Localizer(self.language)
        local_vendor = Path(__file__).resolve().parent / "fvr_vendor"
        if local_vendor.is_dir():
            sys.path.insert(0, str(local_vendor))
        try:
            import cv2
        except ImportError as exc:
            raise RuntimeError(
                "OpenCV is not available. If company policy permits, install "
                "'opencv-python' into the isolated fvr_vendor folder beside this script."
            ) from exc

        import tkinter as tk
        from tkinter import ttk

        self.cv2 = cv2
        self.tk = tk
        self.ttk = LocalizedTtk(ttk, self.localizer)
        self.root = tk.Tk()
        self.root.title(
            f"{self.localizer.text('U003 Evidence Review Workbench')} v{VERSION}"
        )
        self.root.geometry("1480x920")
        self.root.minsize(1050, 700)

        self.capture = None
        self.video_path: Path | None = None
        self.video_fps = 20.0
        self.total_frames = 0
        self.current_video_index = -1
        self.current_bgr_frame = None
        self.tk_image = None
        self.playing = False
        self.after_id = None
        self.seek_dragging = False

        self.all_events: list[ReviewEvent] = []
        self.events: list[ReviewEvent] = []
        self.current_event_index = -1
        self.event_file_path: Path | None = None
        self.pending_event_start: int | None = None

        # Only explicitly selected, contract-valid PROCESS Modules are active.
        self.module_manager_window: ModuleManagerWindow | None = None
        self.module_action_window: ModuleActionWindow | None = None
        self.module_plan: Any = None
        self.module_coordinator: ModuleExecutionCoordinator | None = None
        self.module_root = application_root() / "02_MODULES"
        workspace_value = os.environ.get("U003_WORKSPACE", "").strip()
        workspace_root = Path(workspace_value).resolve() if workspace_value else Path.cwd()
        self.module_run_root = workspace_root / "U003_MODULE_RUNS"
        self.module_run_id = "U003_LOCAL_SESSION"
        self.live_context_publisher: LiveReviewContextPublisher | None = None

        self.signal_file_path: Path | None = None
        self.signal_frame_column: str | None = None
        self.signal_display_columns: list[str] = []
        self.signal_records: list[tuple[int, dict[str, str]]] = []
        self.signal_framecounts: list[int] = []
        self.signal_exact_can_pin: int | None = None

        self.anchor_video_var = tk.StringVar(value="0")
        self.anchor_framecount_var = tk.StringVar(value="0")
        self.framecount_rate_var = tk.StringVar(value="20")
        self.mapping_mode_var = tk.StringVar(value=self.localizer.text("Rate-based"))
        self.seek_scale_var = tk.DoubleVar(value=0.0)
        self.jump_framecount_var = tk.StringVar(value="")
        self.speed_var = tk.StringVar(value="0.25")
        self.loop_event_var = tk.BooleanVar(value=False)
        self.review_code_var = tk.StringVar(value="")
        self.event_filter_var = tk.StringVar(value="")
        self.signal_range_var = tk.StringVar(value="15")
        self.signal_lag_var = tk.StringVar(value="0")
        self.signal_export_before_var = tk.StringVar(value="100")
        self.signal_export_after_var = tk.StringVar(value="100")
        self.module_button_text_var = localized_string_var(
            tk, self.localizer, self.root, "Modules (0)"
        )
        self.module_action_button_text_var = tk.StringVar(value="Module Actions (0)")

        self.video_info_var = localized_string_var(
            tk, self.localizer, self.root, "No video loaded"
        )
        self.position_var = localized_string_var(
            tk,
            self.localizer,
            self.root,
            "Video frame: — | FrameCount: — | Time: —",
        )
        self.mapping_info_var = localized_string_var(
            tk, self.localizer, self.root, "Mapping not configured"
        )
        self.event_info_var = localized_string_var(
            tk, self.localizer, self.root, "No event file loaded"
        )
        self.current_event_range_var = localized_string_var(
            tk, self.localizer, self.root, "Start — | Peak — | End —"
        )
        self.pending_event_info_var = localized_string_var(
            tk, self.localizer, self.root, "No pending Event start"
        )
        self.signal_info_var = localized_string_var(
            tk,
            self.localizer,
            self.root,
            "No signal CSV loaded. Recommended: c13v002_subgraph_v0_1.csv",
        )
        self.status_var = localized_string_var(
            tk, self.localizer, self.root, "Ready"
        )

        self._build_ui()
        self._build_signal_window()
        self._bind_keys()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _ensure_module_coordinator(self) -> ModuleExecutionCoordinator:
        """Create the execution boundary lazily so no-Module use stays independent."""

        if self.module_coordinator is None:
            self.module_coordinator = ModuleExecutionCoordinator(
                module_root=self.module_root,
                run_root=self.module_run_root,
                language=self.language,
            )
        else:
            self.module_coordinator.run_root = self.module_run_root.resolve()
        return self.module_coordinator

    def _module_plan_changed(self, plan: Any) -> None:
        """Activate the exact plan; no selected Module preserves legacy behavior."""

        self.module_plan = plan
        self.module_button_text_var.set(f"Modules ({plan.selected_count()})")
        if plan.selected_count() == 0:
            if self.module_coordinator is not None:
                self.module_coordinator.activate_plan(plan)
            self.module_action_button_text_var.set("Module Actions (0)")
            if self.module_action_window is not None:
                self.module_action_window.refresh()
            self.status_var.set("Module Plan cleared; no-Module behavior is active")
            return
        selected_root = Path(plan.module_root).resolve()
        if selected_root != self.module_root.resolve():
            self.module_root = selected_root
            self.module_coordinator = None
        coordinator = self._ensure_module_coordinator()
        coordinator.activate_plan(plan)
        action_count = len(coordinator.available_actions())
        self.module_action_button_text_var.set(f"Module Actions ({action_count})")
        if self.module_action_window is not None:
            self.module_action_window.refresh()
        self.status_var.set(
            f"Module Plan updated: {plan.selected_count()} selected; "
            "eligible PROCESS Modules are active"
        )
        if 0 <= self.current_event_index < len(self.events):
            self._run_module_assistance(self.events[self.current_event_index])

    def _run_module_assistance(self, event: ReviewEvent) -> None:
        """Execute selected review-assist modules and append editable suggestions."""

        if self.module_plan is None or self.module_plan.selected_count() == 0:
            return
        try:
            coordinator = self._ensure_module_coordinator()
            report = coordinator.execute_event(event, self.module_run_id)
            changed = coordinator.apply_report_to_event(event, report)
            if changed and 0 <= self.current_event_index < len(self.events):
                if self.events[self.current_event_index] is event:
                    self._set_memo_text(event.memo)
            self.status_var.set(
                f"Module assistance: {event.event_id} | executed {report.executed_count} | "
                f"cached {report.cached_count} | suggestions {report.suggestion_count}"
            )
        except Exception as error:
            self._show_error("Module execution error", error)

    def open_module_manager(self) -> None:
        """Open one reusable Module Plan and execution-control window."""

        try:
            if self.module_manager_window is None:
                self.module_manager_window = ModuleManagerWindow(
                    parent=self.root,
                    module_root=self.module_root,
                    language=self.language,
                    on_plan_changed=self._module_plan_changed,
                )
            self.module_manager_window.show()
        except Exception as error:
            self._show_error("Module Manager error", error)

    def _module_action_context(self, action: Any) -> dict[str, Any]:
        """Build serializable evidence context from the current review session."""

        event = (
            self.events[self.current_event_index]
            if 0 <= self.current_event_index < len(self.events)
            else None
        )
        event_id = str(event.event_id) if event is not None else "NO_EVENT"
        context = dict(event.original) if event is not None else {}
        current_framecount: int | None = None
        if self.current_video_index >= 0:
            current_framecount = self.video_index_to_framecount(self.current_video_index)
        elif self.signal_exact_can_pin is not None:
            current_framecount = int(self.signal_exact_can_pin)

        output_directory = self.module_run_root.parent / "U003_ACTION_OUTPUTS"
        profile_directory = application_root() / "02_CONTROLS" / "profiles"
        output_directory.mkdir(parents=True, exist_ok=True)
        profile_directory.mkdir(parents=True, exist_ok=True)

        frame_image_path: str | None = None
        if "CurrentFrameImagePath" in action.required_context_fields:
            if self.current_bgr_frame is None or current_framecount is None:
                raise RuntimeError(
                    "This action requires a current video frame. Open the video and navigate first."
                )
            input_directory = self.module_run_root.parent / "U003_ACTION_INPUTS"
            input_directory.mkdir(parents=True, exist_ok=True)
            frame_path = self._unique_path(
                input_directory
                / f"action_input_FC{current_framecount}_VF{self.current_video_index}.png"
            )
            if not self.cv2.imwrite(str(frame_path), self.current_bgr_frame):
                raise RuntimeError("OpenCV failed to prepare the Module Action frame.")
            frame_image_path = str(frame_path)

        live_context_path: str | None = None
        if "LiveReviewContextPath" in action.required_context_fields:
            publisher = self._ensure_live_context_publisher()
            publisher.start()
            published = self._publish_live_review_context(force=True)
            if published is None:
                raise RuntimeError("The live U003 review context could not be published.")
            live_context_path = str(published)

        context.update(
            {
                "EventID": event_id,
                "ReviewStartFrame": int(event.start_framecount) if event is not None else None,
                "PeakFrameCount": (
                    int(event.peak_framecount)
                    if event is not None and event.peak_framecount is not None
                    else None
                ),
                "ReviewEndFrame": int(event.end_framecount) if event is not None else None,
                "ReviewCode": str(event.review_result or "") if event is not None else "",
                "ReviewMemo": str(event.memo or "") if event is not None else "",
                "CurrentFrameImagePath": frame_image_path,
                "LiveReviewContextPath": live_context_path,
                "CurrentVideoFrame": (
                    int(self.current_video_index) if self.current_video_index >= 0 else None
                ),
                "CurrentCANFrameCount": current_framecount,
                "VideoPath": str(self.video_path) if self.video_path is not None else None,
                "SignalDataPath": (
                    str(self.signal_file_path) if self.signal_file_path is not None else None
                ),
                "EventDataPath": (
                    str(self.event_file_path) if self.event_file_path is not None else None
                ),
                "OutputDirectory": str(output_directory),
                "ProfileDirectory": str(profile_directory),
                "Language": self.language,
                "_RunId": self.module_run_id,
                "_EventId": event_id,
            }
        )
        return context

    def _module_action_completed(self, report: Any) -> None:
        summary = report.outputs.get("ActionSummary", "")
        self.status_var.set(
            f"Module Action completed: {report.action_id}"
            + (f" | {summary}" if summary else "")
        )

    def _module_action_finished(self) -> None:
        """Stop frame publication after the interactive child action exits."""

        if self.live_context_publisher is not None:
            self.live_context_publisher.stop()

    def _ensure_live_context_publisher(self) -> LiveReviewContextPublisher:
        """Bind the publisher to the current governed run identity."""

        expected_root = self.module_run_root.parent / "U003_LIVE_CONTEXT"
        if (
            self.live_context_publisher is None
            or self.live_context_publisher.root.resolve() != expected_root.resolve()
            or self.live_context_publisher.run_id != self.module_run_id
        ):
            if self.live_context_publisher is not None:
                self.live_context_publisher.stop()
            self.live_context_publisher = LiveReviewContextPublisher(
                root=expected_root,
                cv2=self.cv2,
                run_id=self.module_run_id,
                language=self.language,
            )
        return self.live_context_publisher

    def _publish_live_review_context(self, force: bool) -> Path | None:
        """Publish current video/Event state for a subscribed child Module."""

        publisher = self.live_context_publisher
        if publisher is None or not publisher.active or self.current_bgr_frame is None:
            return None
        if self.current_video_index < 0:
            return None
        framecount = self.video_index_to_framecount(self.current_video_index)
        event = (
            self.events[self.current_event_index]
            if 0 <= self.current_event_index < len(self.events)
            else None
        )
        return publisher.publish(
            frame=self.current_bgr_frame,
            current_framecount=framecount,
            current_video_frame=self.current_video_index,
            event_id=str(event.event_id) if event is not None else "NO_EVENT",
            event_start=int(event.start_framecount) if event is not None else None,
            event_peak=(
                int(event.peak_framecount)
                if event is not None and event.peak_framecount is not None
                else None
            ),
            event_end=int(event.end_framecount) if event is not None else None,
            force=force,
        )

    def open_module_actions(self) -> None:
        """Open the action launcher bound to the current exact Module Plan."""

        try:
            coordinator = self._ensure_module_coordinator()
            actions = coordinator.available_actions()
            if not actions:
                self._show_info(
                    "Module Actions",
                    "No UserAction is available. Select a qualified action Module first.",
                )
                return
            if self.module_action_window is None:
                self.module_action_window = ModuleActionWindow(
                    parent=self.root,
                    language=self.language,
                    coordinator_provider=self._ensure_module_coordinator,
                    context_provider=self._module_action_context,
                    on_completed=self._module_action_completed,
                    on_finished=self._module_action_finished,
                )
            self.module_action_window.show()
        except Exception as error:
            self._show_error("Module Action error", error)

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        tk = self.tk
        ttk = self.ttk

        main = ttk.Frame(self.root, padding=8)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(main)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(toolbar, text="Open Video", command=self.open_video).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Load Event CSV", command=self.load_event_csv).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Load Signal CSV", command=self.load_signal_csv).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Show CAN Window", command=self.show_signal_window).pack(
            side="left", padx=2
        )
        ttk.Button(toolbar, text="Export Reviews", command=self.export_reviews).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Save Screenshot", command=self.save_screenshot).pack(side="left", padx=2)
        ttk.Button(
            toolbar,
            textvariable=self.module_button_text_var,
            command=self.open_module_manager,
        ).pack(side="left", padx=2)
        ttk.Button(
            toolbar,
            textvariable=self.module_action_button_text_var,
            command=self.open_module_actions,
        ).pack(side="left", padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Label(toolbar, textvariable=self.video_info_var).pack(side="left", padx=4)

        self.main_paned = ttk.Panedwindow(main, orient="horizontal")
        self.main_paned.grid(row=1, column=0, sticky="nsew")

        video_panel = ttk.Frame(self.main_paned, relief="sunken")
        video_panel.rowconfigure(0, weight=1)
        video_panel.columnconfigure(0, weight=1)
        self.video_canvas = tk.Canvas(video_panel, background="black", highlightthickness=0)
        self.video_canvas.grid(row=0, column=0, sticky="nsew")
        self.video_canvas.bind("<Configure>", lambda event: self._render_current_frame())

        position_bar = ttk.Frame(video_panel, padding=(6, 4))
        position_bar.grid(row=1, column=0, sticky="ew")
        ttk.Label(position_bar, textvariable=self.position_var, font=("TkDefaultFont", 12, "bold")).pack(
            side="left"
        )

        seek_bar = ttk.Frame(video_panel, padding=(6, 0, 6, 2))
        seek_bar.grid(row=2, column=0, sticky="ew")
        seek_bar.columnconfigure(0, weight=1)
        self.seek_scale = ttk.Scale(
            seek_bar,
            from_=0,
            to=1,
            orient="horizontal",
            variable=self.seek_scale_var,
            command=self._on_seek_preview,
        )
        self.seek_scale.grid(row=0, column=0, sticky="ew")
        self.seek_scale.bind("<ButtonPress-1>", self._on_seek_press)
        self.seek_scale.bind("<ButtonRelease-1>", self._on_seek_release)

        controls = ttk.Frame(video_panel, padding=(6, 2, 6, 6))
        controls.grid(row=3, column=0, sticky="ew")
        controls.columnconfigure(0, weight=1)
        navigation_controls = ttk.Frame(controls)
        navigation_controls.grid(row=0, column=0, sticky="ew")
        for column in range(6):
            navigation_controls.columnconfigure(column, weight=1, uniform="navigation")

        ttk.Button(navigation_controls, text="⏮ Event Start", command=self.go_event_start).grid(
            row=0, column=0, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="-100", command=lambda: self.step_framecount(-100)).grid(
            row=0, column=1, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="-20", command=lambda: self.step_framecount(-20)).grid(
            row=0, column=2, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="-10", command=lambda: self.step_framecount(-10)).grid(
            row=0, column=3, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="◀ -1", command=lambda: self.step_video_frames(-1)).grid(
            row=0, column=4, sticky="ew", padx=2, pady=2
        )
        self.play_button = ttk.Button(navigation_controls, text="▶ Play", command=self.toggle_play)
        self.play_button.grid(row=0, column=5, sticky="ew", padx=2, pady=2)

        ttk.Button(navigation_controls, text="+1 ▶", command=lambda: self.step_video_frames(1)).grid(
            row=1, column=0, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="+10", command=lambda: self.step_framecount(10)).grid(
            row=1, column=1, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="+20", command=lambda: self.step_framecount(20)).grid(
            row=1, column=2, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="+100", command=lambda: self.step_framecount(100)).grid(
            row=1, column=3, sticky="ew", padx=2, pady=2
        )
        ttk.Button(navigation_controls, text="Event End ⏭", command=self.go_event_end).grid(
            row=1, column=4, columnspan=2, sticky="ew", padx=2, pady=2
        )

        playback_controls = ttk.Frame(controls)
        playback_controls.grid(row=1, column=0, sticky="w", pady=(5, 0))
        ttk.Label(playback_controls, text="Playback speed").pack(side="left", padx=(2, 4))
        ttk.Combobox(
            playback_controls,
            textvariable=self.speed_var,
            values=["0.10", "0.25", "0.50", "1.00", "2.00"],
            state="readonly",
            width=6,
        ).pack(side="left")
        ttk.Checkbutton(
            playback_controls,
            text="Loop current event",
            variable=self.loop_event_var,
        ).pack(side="left", padx=10)

        side = ttk.Frame(self.main_paned)
        side.columnconfigure(0, weight=1)
        side.rowconfigure(3, weight=1)
        self.main_paned.add(video_panel, weight=5)
        self.main_paned.add(side, weight=1)

        mapping = ttk.LabelFrame(side, text="FrameCount Mapping", padding=8)
        mapping.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        mapping.columnconfigure(1, weight=1)
        self._entry_row(mapping, 0, "Video anchor index", self.anchor_video_var)
        self._entry_row(mapping, 1, "CAN anchor FC", self.anchor_framecount_var)
        self._entry_row(mapping, 2, "CAN rate (Hz)", self.framecount_rate_var)
        ttk.Label(mapping, text="Mode").grid(row=3, column=0, sticky="w", pady=2)
        ttk.Combobox(
            mapping,
            textvariable=self.mapping_mode_var,
            values=["1:1", self.localizer.text("Rate-based")],
            state="readonly",
            width=14,
        ).grid(row=3, column=1, sticky="ew", pady=2)
        ttk.Button(mapping, text="Apply Mapping", command=self.apply_mapping).grid(
            row=4, column=0, columnspan=2, sticky="ew", pady=(6, 2)
        )
        ttk.Label(mapping, textvariable=self.mapping_info_var, wraplength=280).grid(
            row=5, column=0, columnspan=2, sticky="w", pady=2
        )

        event_header = ttk.LabelFrame(side, text="Event Navigation", padding=8)
        event_header.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        event_header.columnconfigure(1, weight=1)
        ttk.Label(event_header, text="Jump FC").grid(row=0, column=0, sticky="w", padx=2)
        self.jump_entry = ttk.Entry(event_header, textvariable=self.jump_framecount_var)
        self.jump_entry.grid(row=0, column=1, sticky="ew", padx=2)
        self.jump_entry.bind("<Return>", lambda event: self.go_to_framecount())
        ttk.Button(event_header, text="Go", command=self.go_to_framecount).grid(
            row=0, column=2, padx=2
        )
        ttk.Label(event_header, text="Filter IDs").grid(row=1, column=0, sticky="w", padx=2)
        filter_entry = ttk.Entry(event_header, textvariable=self.event_filter_var)
        filter_entry.grid(row=1, column=1, sticky="ew", padx=2)
        filter_entry.bind("<Return>", lambda event: self.apply_event_filter())
        ttk.Button(event_header, text="Apply", command=self.apply_event_filter).grid(
            row=1, column=2, padx=2
        )
        ttk.Button(event_header, text="Previous", command=self.previous_event).grid(
            row=2, column=0, padx=2
        )
        ttk.Button(event_header, text="Next", command=self.next_event).grid(
            row=2, column=2, padx=2
        )

        side_peak_cursor = ttk.LabelFrame(event_header, text="Peak Cursor", padding=4)
        side_peak_cursor.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        side_peak_cursor.columnconfigure(0, weight=1)
        side_peak_cursor.columnconfigure(1, weight=1)
        self.global_peak_button = ttk.Button(
            side_peak_cursor,
            text="Jump / Pin Peak",
            command=self.go_event_peak,
        )
        self.global_peak_button.grid(row=0, column=0, sticky="ew", padx=(0, 2))
        ttk.Button(
            side_peak_cursor,
            text="Release Pin",
            command=self.release_exact_can_pin,
        ).grid(row=0, column=1, sticky="ew", padx=(2, 0))

        ttk.Label(
            event_header,
            textvariable=self.current_event_range_var,
            font=("TkDefaultFont", 9, "bold"),
            wraplength=280,
        ).grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Label(event_header, textvariable=self.event_info_var, wraplength=280).grid(
            row=5, column=0, columnspan=3, sticky="w", pady=(2, 0)
        )
        self._set_peak_navigation_enabled(False)

        quick_event = ttk.LabelFrame(side, text="Quick Event Capture", padding=8)
        quick_event.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        quick_event.columnconfigure(0, weight=1)
        quick_event.columnconfigure(1, weight=1)
        quick_event.columnconfigure(2, weight=1)
        ttk.Label(quick_event, textvariable=self.pending_event_info_var, wraplength=280).grid(
            row=0, column=0, columnspan=3, sticky="ew", pady=(0, 4)
        )
        ttk.Button(quick_event, text="1. Mark Start", command=self.mark_new_event_start).grid(
            row=1, column=0, sticky="ew", padx=(0, 2)
        )
        ttk.Button(quick_event, text="2. Finish / Add", command=self.finish_add_event).grid(
            row=1, column=1, sticky="ew", padx=2
        )
        ttk.Button(quick_event, text="Cancel", command=self.cancel_pending_event).grid(
            row=1, column=2, sticky="ew", padx=(2, 0)
        )
        ttk.Button(
            quick_event,
            text="Delete Selected Event",
            command=self.delete_current_event,
        ).grid(row=2, column=0, columnspan=3, sticky="ew", pady=(5, 0))

        event_list_frame = ttk.Frame(side)
        event_list_frame.grid(row=3, column=0, sticky="nsew", pady=(0, 6))
        event_list_frame.rowconfigure(0, weight=1)
        event_list_frame.columnconfigure(0, weight=1)
        self.event_listbox = tk.Listbox(event_list_frame, exportselection=False, height=12)
        event_scroll = ttk.Scrollbar(event_list_frame, orient="vertical", command=self.event_listbox.yview)
        self.event_listbox.configure(yscrollcommand=event_scroll.set)
        self.event_listbox.grid(row=0, column=0, sticky="nsew")
        event_scroll.grid(row=0, column=1, sticky="ns")
        self.event_listbox.bind("<<ListboxSelect>>", self._on_event_selected)

        review = ttk.LabelFrame(side, text="Current Event Review", padding=8)
        review.grid(row=4, column=0, sticky="ew")
        review.columnconfigure(1, weight=1)
        ttk.Label(review, text="Result code").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Combobox(
            review,
            textvariable=self.review_code_var,
            values=list(REVIEW_CODES.keys()),
            state="readonly",
            width=5,
        ).grid(row=0, column=1, sticky="w", pady=2)
        ttk.Label(review, text="1 correct, 2 wrong, 3 scene, 4 unclear, 5 unavailable", wraplength=300).grid(
            row=1, column=0, columnspan=2, sticky="w", pady=2
        )
        ttk.Label(review, text="Short memo").grid(row=2, column=0, sticky="w", pady=2)
        memo_frame = ttk.Frame(review)
        memo_frame.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=2)
        memo_frame.columnconfigure(0, weight=1)
        memo_frame.rowconfigure(0, weight=1)
        self.memo_text = tk.Text(memo_frame, height=4, wrap="word", undo=True)
        memo_scroll = ttk.Scrollbar(memo_frame, orient="vertical", command=self.memo_text.yview)
        self.memo_text.configure(yscrollcommand=memo_scroll.set)
        self.memo_text.grid(row=0, column=0, sticky="nsew")
        memo_scroll.grid(row=0, column=1, sticky="ns")
        ttk.Button(review, text="Save Event Review", command=self.save_current_event_review).grid(
            row=4, column=0, columnspan=2, sticky="ew", pady=(6, 2)
        )

        status = ttk.Label(main, textvariable=self.status_var, relief="sunken", anchor="w")
        status.grid(row=2, column=0, sticky="ew", pady=(6, 0))

    def _set_initial_main_sash(self) -> None:
        """Give the video most of the width while keeping the divider draggable."""
        try:
            self.root.update_idletasks()
            available_width = self.main_paned.winfo_width()
            if available_width > 700:
                control_width = min(330, max(280, int(available_width * 0.24)))
                self.main_paned.sashpos(0, available_width - control_width)
        except Exception:
            # Window-manager timing differs across Windows systems. The panes
            # remain usable even when the initial sash position is not applied.
            pass

    def _set_peak_navigation_enabled(self, enabled: bool) -> None:
        """Keep both Peak navigation controls consistent."""
        state = "normal" if enabled else "disabled"
        for button_name in ("global_peak_button",):
            button = getattr(self, button_name, None)
            if button is not None:
                button.configure(state=state)

    def _build_signal_window(self) -> None:
        ttk = self.ttk

        self.signal_window = self.tk.Toplevel(self.root)
        self.signal_window.title(
            f"{self.localizer.text('U003 Synchronized CAN Review Table')} v{VERSION}"
        )
        self.signal_window.minsize(520, 500)
        self.signal_window.protocol("WM_DELETE_WINDOW", self.signal_window.withdraw)

        screen_width = max(self.root.winfo_screenwidth(), 1000)
        screen_height = max(self.root.winfo_screenheight(), 700)
        usable_height = max(650, min(920, screen_height - 80))
        if screen_width >= 1700:
            main_width = max(1100, int(screen_width * 0.70))
            signal_width = max(500, screen_width - main_width - 40)
            self.root.geometry(f"{main_width}x{usable_height}+10+30")
            self.signal_window.geometry(
                f"{signal_width}x{usable_height}+{main_width + 20}+30"
            )
        else:
            main_width = max(1050, screen_width - 40)
            signal_width = max(520, int(screen_width * 0.70))
            self.root.geometry(f"{main_width}x{usable_height}+10+20")
            self.signal_window.geometry(f"{signal_width}x{usable_height}+40+60")
        self.root.after_idle(self._set_initial_main_sash)

        signal_panel = ttk.Frame(self.signal_window, padding=8)
        signal_panel.pack(fill="both", expand=True)
        signal_panel.columnconfigure(0, weight=1)
        signal_panel.rowconfigure(4, weight=1)

        top_bar = ttk.Frame(signal_panel)
        top_bar.grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 6))
        ttk.Button(top_bar, text="Load Review Data CSV", command=self.load_signal_csv).pack(
            side="left", padx=(0, 6)
        )
        ttk.Label(top_bar, textvariable=self.signal_info_var, wraplength=620).pack(
            side="left", fill="x", expand=True
        )

        ttk.Label(signal_panel, text="Display range ±FrameCount (15 = 31 rows)").grid(
            row=1, column=0, sticky="w", padx=(0, 4)
        )
        ttk.Entry(signal_panel, textvariable=self.signal_range_var, width=8).grid(
            row=1, column=1, sticky="w", padx=(0, 4)
        )
        ttk.Button(signal_panel, text="Refresh", command=self.refresh_signal_table).grid(
            row=1, column=2, sticky="e"
        )

        ttk.Label(
            signal_panel,
            text="CAN highlight lag offset (CAN highlight = Video FC + offset)",
        ).grid(row=2, column=0, sticky="w", padx=(0, 4), pady=(4, 0))
        lag_entry = ttk.Combobox(
            signal_panel,
            textvariable=self.signal_lag_var,
            values=["-10", "-5", "-3", "-2", "-1", "0", "1", "2", "3", "5", "10"],
            state="normal",
            width=8,
        )
        lag_entry.grid(row=2, column=1, sticky="w", padx=(0, 4), pady=(4, 0))
        lag_entry.bind("<Return>", lambda _event: self.refresh_signal_table())
        ttk.Button(signal_panel, text="Apply lag", command=self.refresh_signal_table).grid(
            row=2, column=2, sticky="e", pady=(4, 0)
        )

        export_bar = ttk.LabelFrame(
            signal_panel,
            text="Export plot data around yellow row",
            padding=6,
        )
        export_bar.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(6, 0))
        export_bar.columnconfigure(5, weight=1)
        ttk.Label(export_bar, text="Before FC").grid(row=0, column=0, sticky="w")
        ttk.Entry(
            export_bar,
            textvariable=self.signal_export_before_var,
            width=8,
        ).grid(row=0, column=1, sticky="w", padx=(4, 10))
        ttk.Label(export_bar, text="After FC").grid(row=0, column=2, sticky="w")
        ttk.Entry(
            export_bar,
            textvariable=self.signal_export_after_var,
            width=8,
        ).grid(row=0, column=3, sticky="w", padx=(4, 10))
        ttk.Button(
            export_bar,
            text="Export Plot CSV",
            command=self.export_signal_plot_window,
        ).grid(row=0, column=4, sticky="w")
        ttk.Label(
            export_bar,
            text="Center = yellow CAN row; all loaded columns are exported.",
        ).grid(row=0, column=5, sticky="e", padx=(10, 0))

        signal_table_frame = ttk.Frame(signal_panel)
        signal_table_frame.grid(row=4, column=0, columnspan=3, sticky="nsew", pady=(6, 0))
        signal_table_frame.columnconfigure(0, weight=1)
        signal_table_frame.rowconfigure(0, weight=1)
        self.signal_tree = ttk.Treeview(
            signal_table_frame,
            show="headings",
            selectmode="browse",
            height=30,
        )
        signal_y_scroll = ttk.Scrollbar(
            signal_table_frame, orient="vertical", command=self.signal_tree.yview
        )
        signal_x_scroll = ttk.Scrollbar(
            signal_table_frame, orient="horizontal", command=self.signal_tree.xview
        )
        self.signal_tree.configure(
            yscrollcommand=signal_y_scroll.set,
            xscrollcommand=signal_x_scroll.set,
        )
        self.signal_tree.grid(row=0, column=0, sticky="nsew")
        signal_y_scroll.grid(row=0, column=1, sticky="ns")
        signal_x_scroll.grid(row=1, column=0, sticky="ew")
        self.signal_tree.tag_configure("current", background="#fff2a8", foreground="#000000")
        self.signal_tree.bind("<Double-1>", self._on_signal_row_double_click)

        ttk.Label(
            signal_panel,
            text=(
                "Yellow = exact Event Peak CAN row while Peak Pin is active; "
                "otherwise exact/nearest CAN row for the displayed video frame. "
                "Double-click a row to jump the video. All columns supplied by the "
                "Review Data CSV are retained. Plot export uses independent Before/After "
                "FrameCount ranges so causes may be captured asymmetrically."
            ),
            wraplength=720,
        ).grid(row=5, column=0, columnspan=3, sticky="ew", pady=(6, 0))

    def show_signal_window(self) -> None:
        self.signal_window.deiconify()
        self.signal_window.lift()
        self.signal_window.focus_force()

    def pin_exact_can_frame(self, framecount: int) -> None:
        """Pin the table cursor to an exact governed CAN evidence FrameCount."""

        self.signal_exact_can_pin = int(framecount)

    def release_exact_can_pin(self) -> None:
        """Return the table cursor to normal video-following behavior."""

        previous = self.signal_exact_can_pin
        self.signal_exact_can_pin = None
        self.refresh_signal_table()
        if previous is not None:
            self.status_var.set(
                f"Released exact CAN Peak pin FC {previous}; table follows video again"
            )

    def _entry_row(self, parent, row: int, label: str, variable) -> None:
        self.ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2)
        self.ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=2)

    def _bind_keys(self) -> None:
        self.root.bind("<space>", lambda event: self._run_shortcut(event, self.toggle_play))
        self.root.bind(
            "<Left>", lambda event: self._run_shortcut(event, lambda: self.step_video_frames(-1))
        )
        self.root.bind(
            "<Right>", lambda event: self._run_shortcut(event, lambda: self.step_video_frames(1))
        )
        self.root.bind(
            "<Shift-Left>", lambda event: self._run_shortcut(event, lambda: self.step_framecount(-10))
        )
        self.root.bind(
            "<Shift-Right>", lambda event: self._run_shortcut(event, lambda: self.step_framecount(10))
        )
        self.root.bind(
            "<Control-Left>", lambda event: self._run_shortcut(event, lambda: self.step_framecount(-100))
        )
        self.root.bind(
            "<Control-Right>", lambda event: self._run_shortcut(event, lambda: self.step_framecount(100))
        )
        self.root.bind("<Up>", lambda event: self._run_shortcut(event, self.previous_event))
        self.root.bind("<Down>", lambda event: self._run_shortcut(event, self.next_event))
        self.root.bind("g", lambda event: self._focus_jump_entry(event))

    def _run_shortcut(self, event, action):
        if event.widget.winfo_class() in {"Entry", "TEntry", "TCombobox", "Text"}:
            return None
        action()
        return "break"

    def _focus_jump_entry(self, event):
        if event.widget.winfo_class() in {"Entry", "TEntry", "TCombobox", "Text"}:
            return None
        self.jump_entry.focus_set()
        return "break"

    # -------------------------------------------------------- synchronized CAN
    def _signal_display_columns(self, fieldnames: list[str], frame_column: str) -> list[str]:
        # The review-data CSV owns the human-visible schema. The Viewer keeps
        # every supplied column and only moves FrameCount to the first position.
        return [frame_column] + [column for column in fieldnames if column != frame_column]

    def _signal_heading(self, column: str) -> str:
        compact = normalized_name(column)
        if "framecount" in compact or compact == "frame":
            return "FrameCount"
        if "canonical" in compact and "distance" in compact:
            return "Canonical"
        if ("221" in compact or "cam1" in compact or "camera1" in compact) and "distance" in compact:
            return "CAM1"
        if ("251" in compact or "cam3" in compact or "camera3" in compact) and "distance" in compact:
            return "CAM3"
        return compact_text(column, 18)

    def _format_signal_value(self, value: object) -> str:
        text = "" if value is None else str(value).strip()
        if not text:
            return ""
        try:
            number = float(text)
            if math.isfinite(number):
                if number.is_integer() and abs(number) < 1e12:
                    return str(int(number))
                return f"{number:.6g}"
        except Exception:
            pass
        return compact_text(text, 20)

    def load_signal_csv(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askopenfilename(
            title=self.localizer.text("Load synchronized narrow CAN CSV"),
            filetypes=[
                (self.localizer.text("CSV or TSV"), "*.csv *.tsv *.txt"),
                (self.localizer.text("All files"), "*.*"),
            ],
        )
        if not selected:
            return
        try:
            self.load_signal_path(Path(selected))
        except Exception as exc:
            self._show_error("Signal CSV error", exc)

    def load_signal_path(self, path: Path) -> None:
        """Load Review Data from an explicit governed path without a file dialog."""

        path = path.resolve()
        fieldnames, rows = read_delimited_file(path)
        frame_column = find_column(
            fieldnames,
            ("FrameCount", "CANFrameCount", "ID_620_FrameCount", "Frame"),
        )
        if frame_column is None:
            raise RuntimeError(
                "FrameCount column was not found in the signal CSV.\n\n"
                f"Headers: {', '.join(fieldnames)}"
            )
        display_columns = self._signal_display_columns(fieldnames, frame_column)
        if len(display_columns) < 2:
            raise RuntimeError("The review-data CSV does not contain a displayable signal column.")

        # One row per FrameCount. When duplicates exist, keep the final row,
        # matching the C13V001 collapse contract.
        by_framecount: dict[int, dict[str, str]] = {}
        for row in rows:
            frame_value = parse_number(row.get(frame_column, ""))
            if frame_value is None:
                continue
            by_framecount[int(round(frame_value))] = row
        if not by_framecount:
            raise RuntimeError("No numeric FrameCount rows were found in the signal CSV.")

        self.signal_file_path = path
        self.signal_frame_column = frame_column
        self.signal_display_columns = display_columns
        self.signal_records = sorted(by_framecount.items(), key=lambda item: item[0])
        self.signal_framecounts = [item[0] for item in self.signal_records]

        self.signal_tree.delete(*self.signal_tree.get_children())
        tree_columns = [f"c{index}" for index in range(len(display_columns))]
        self.signal_tree.configure(columns=tree_columns)
        for tree_column, source_column in zip(tree_columns, display_columns):
            heading = self._signal_heading(source_column)
            self.signal_tree.heading(tree_column, text=heading)
            width = 92 if source_column == frame_column else 116
            self.signal_tree.column(
                tree_column,
                width=width,
                minwidth=75,
                anchor="e",
                stretch=True,
            )

        self.signal_info_var.set(
            f"{path.name}: {len(self.signal_records):,} unique FrameCounts | "
            f"{len(display_columns)} displayed columns"
        )
        self.refresh_signal_table()
        self.status_var.set(f"Loaded synchronized CAN table: {path.name}")

    def _signal_highlight_context(self) -> tuple[int, int, int, int]:
        if not self.signal_records:
            raise RuntimeError("Load a synchronized CAN Review Data CSV first.")
        if self.current_video_index < 0:
            raise RuntimeError("Open a video and navigate to the desired center frame first.")
        video_fc = self.video_index_to_framecount(self.current_video_index)
        lag_offset = int(float(self.signal_lag_var.get()))
        highlight_fc = highlight_target_framecount(
            video_fc,
            lag_offset,
            self.signal_exact_can_pin,
        )
        nearest_index = nearest_sorted_index(self.signal_framecounts, highlight_fc)
        return video_fc, lag_offset, highlight_fc, nearest_index

    def refresh_signal_table(self) -> None:
        if not self.signal_records or self.current_video_index < 0:
            return
        try:
            half_range = max(1, int(float(self.signal_range_var.get())))
            video_fc, lag_offset, highlight_fc, nearest_index = (
                self._signal_highlight_context()
            )
        except Exception as exc:
            self._show_error("Signal table refresh error", exc)
            return

        left, right = signal_frame_window(
            self.signal_framecounts,
            highlight_fc - half_range,
            highlight_fc + half_range,
        )
        if right <= left:
            left = nearest_index
            right = nearest_index + 1

        self.signal_tree.delete(*self.signal_tree.get_children())
        current_item = ""
        for record_index in range(left, right):
            frame_value, row = self.signal_records[record_index]
            values: list[str] = []
            for column in self.signal_display_columns:
                if column == self.signal_frame_column:
                    values.append(str(frame_value))
                else:
                    values.append(self._format_signal_value(row.get(column, "")))
            item_id = f"signal_{record_index}"
            tags = ("current",) if record_index == nearest_index else ()
            self.signal_tree.insert("", "end", iid=item_id, values=values, tags=tags)
            if record_index == nearest_index:
                current_item = item_id

        if current_item:
            self.signal_tree.selection_set(current_item)
            self.signal_tree.focus(current_item)
            self.signal_tree.see(current_item)
        nearest_fc = self.signal_framecounts[nearest_index]
        delta = nearest_fc - highlight_fc
        relation = "exact" if delta == 0 else f"nearest Δ{delta:+d}"
        file_name = self.signal_file_path.name if self.signal_file_path else "signal CSV"
        natural_target = video_fc + lag_offset
        if self.signal_exact_can_pin is not None:
            cursor_text = (
                f"Peak Pin CAN FC {highlight_fc} → row {nearest_fc} ({relation}); "
                f"nearest video maps to CAN target {natural_target} "
                f"(video delta {natural_target - highlight_fc:+d})"
            )
        else:
            cursor_text = (
                f"video FC {video_fc} + lag {lag_offset:+d} "
                f"→ target {highlight_fc} → CAN FC {nearest_fc} ({relation})"
            )
        self.signal_info_var.set(
            f"{file_name} | {cursor_text} | "
            f"showing {max(0, right - left)} rows"
        )

    def export_signal_plot_window(self) -> None:
        try:
            before = int(float(self.signal_export_before_var.get()))
            after = int(float(self.signal_export_after_var.get()))
            if before < 0 or after < 0:
                raise RuntimeError("Before FC and After FC must be zero or positive.")
            _video_fc, _lag_offset, _highlight_fc, nearest_index = (
                self._signal_highlight_context()
            )
            center_fc = self.signal_framecounts[nearest_index]
            start_fc = center_fc - before
            end_fc = center_fc + after
            left, right = signal_frame_window(
                self.signal_framecounts,
                start_fc,
                end_fc,
            )
            if right <= left:
                raise RuntimeError(
                    f"No CAN rows exist inside FC {start_fc}–{end_fc}."
                )

            export_rows: list[dict[str, str]] = []
            for record_index in range(left, right):
                frame_value, source_row = self.signal_records[record_index]
                export_row = {
                    column: source_row.get(column, "")
                    for column in self.signal_display_columns
                }
                if self.signal_frame_column:
                    export_row[self.signal_frame_column] = str(frame_value)
                export_rows.append(export_row)

            output_dir = (
                self.signal_file_path.parent if self.signal_file_path else Path.cwd()
            )
            source_stem = (
                self.signal_file_path.stem if self.signal_file_path else "review_data"
            )
            export_stem = f"{source_stem}_plot_FC{center_fc}_M{before}_P{after}"
            csv_path = self._unique_path(output_dir / f"{export_stem}.csv")

            with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=self.signal_display_columns,
                    extrasaction="ignore",
                )
                writer.writeheader()
                writer.writerows(export_rows)

            self.status_var.set(
                f"Plot data exported: FC {start_fc}–{end_fc}, "
                f"{len(export_rows):,} rows, {len(self.signal_display_columns)} columns"
            )
            self._show_info(
                "Plot data exported",
                f"Yellow center CAN FC: {center_fc}\n"
                f"Requested range: -{before} / +{after} FrameCounts\n"
                f"Actual rows: {len(export_rows):,}\n"
                f"Columns: {len(self.signal_display_columns)}\n\n"
                f"CSV:\n{csv_path}",
            )
        except Exception as exc:
            self._show_error("Plot data export error", exc)

    def _on_signal_row_double_click(self, _event=None) -> None:
        selection = self.signal_tree.selection()
        if not selection:
            return
        values = self.signal_tree.item(selection[0], "values")
        if not values:
            return
        try:
            self.signal_exact_can_pin = None
            can_framecount = int(float(values[0]))
            lag_offset = int(float(self.signal_lag_var.get()))
            video_framecount = can_framecount - lag_offset
            self.show_video_frame(self.framecount_to_video_index(video_framecount))
        except Exception as exc:
            self._show_error("Signal-row navigation error", exc)

    # ----------------------------------------------------------- video mapping
    def _mapping_values(self) -> tuple[int, int, float, str]:
        anchor_video = int(float(self.anchor_video_var.get()))
        anchor_framecount = int(float(self.anchor_framecount_var.get()))
        rate = float(self.framecount_rate_var.get())
        displayed_mode = self.mapping_mode_var.get()
        mode = (
            "Rate-based"
            if displayed_mode == self.localizer.text("Rate-based")
            else displayed_mode
        )
        if rate <= 0:
            raise ValueError("FrameCount rate must be greater than zero.")
        if mode not in {"1:1", "Rate-based"}:
            raise ValueError("Unknown mapping mode.")
        return anchor_video, anchor_framecount, rate, mode

    def video_index_to_framecount(self, video_index: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        return map_video_index_to_framecount(
            video_index,
            anchor_video,
            anchor_fc,
            rate,
            self.video_fps,
            mode,
        )

    def framecount_to_video_index(self, framecount: int) -> int:
        anchor_video, anchor_fc, rate, mode = self._mapping_values()
        return map_framecount_to_video_index(
            framecount,
            anchor_video,
            anchor_fc,
            rate,
            self.video_fps,
            mode,
        )

    def apply_mapping(self) -> None:
        try:
            anchor_video, anchor_fc, rate, mode = self._mapping_values()
            if mode == "1:1":
                relationship = "1 video frame = 1 CAN count; Hz value is ignored"
            else:
                fc_per_video = rate / self.video_fps
                video_per_fc = self.video_fps / rate
                relationship = (
                    f"1 video frame = {fc_per_video:.6g} CAN counts; "
                    f"1 CAN count = {video_per_fc:.6g} video frames"
                )
            self.mapping_info_var.set(
                f"Video frame {anchor_video} ↔ CAN FC {anchor_fc}; mode={mode}; "
                f"video={self.video_fps:.6g} fps, FC={rate:.6g} Hz; {relationship}"
            )
            self._update_position_text()
            self.status_var.set("FrameCount mapping applied")
        except Exception as exc:
            self._show_error("Mapping error", exc)

    # --------------------------------------------------------------- video I/O
    def open_video(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askopenfilename(
            title=self.localizer.text("Open test video"),
            filetypes=[
                (
                    self.localizer.text("Video files"),
                    "*.avi *.mp4 *.mov *.mkv *.wmv *.mpg *.mpeg",
                ),
                (self.localizer.text("All files"), "*.*"),
            ],
        )
        if not selected:
            return
        self.stop_playback()
        if self.capture is not None:
            self.capture.release()
        capture = self.cv2.VideoCapture(selected)
        if not capture.isOpened():
            raise_error = RuntimeError(
                "The video could not be opened by OpenCV. The codec may not be supported "
                "in this Python environment."
            )
            self._show_error("Video open error", raise_error)
            return
        self.capture = capture
        self.video_path = Path(selected)
        detected_fps = float(capture.get(self.cv2.CAP_PROP_FPS))
        self.video_fps = detected_fps if math.isfinite(detected_fps) and detected_fps > 0 else 20.0
        self.total_frames = int(capture.get(self.cv2.CAP_PROP_FRAME_COUNT))
        self.seek_scale.configure(to=max(self.total_frames - 1, 1))
        self.seek_scale_var.set(0.0)
        try:
            backend = capture.getBackendName()
        except Exception:
            backend = "unknown"
        self.video_info_var.set(
            f"{self.video_path.name} | {self.total_frames:,} frames | "
            f"{self.video_fps:.6g} fps | backend {backend}"
        )
        self.anchor_video_var.set("0")
        if not self.anchor_framecount_var.get().strip():
            self.anchor_framecount_var.set("0")
        self.apply_mapping()
        self.show_video_frame(0)

    def show_video_frame(self, target_index: int) -> None:
        if self.capture is None:
            return
        self.stop_playback()
        target_index = max(0, min(int(target_index), max(self.total_frames - 1, 0)))
        self.capture.set(self.cv2.CAP_PROP_POS_FRAMES, target_index)
        ok, frame = self.capture.read()
        if not ok:
            self.status_var.set(f"Failed to decode video frame {target_index}")
            return
        reported_next = int(round(self.capture.get(self.cv2.CAP_PROP_POS_FRAMES)))
        actual_index = max(0, reported_next - 1)
        self.current_video_index = actual_index
        if not self.seek_dragging:
            self.seek_scale_var.set(float(actual_index))
        self.current_bgr_frame = frame
        self._render_current_frame()
        self._update_position_text()
        self._publish_live_review_context(force=True)
        if actual_index != target_index:
            self.status_var.set(
                f"Requested video frame {target_index}; decoder reported frame {actual_index}. "
                "Check the visible FrameCount overlay."
            )
        else:
            self.status_var.set(f"Video frame {actual_index} loaded")

    def _read_next_frame(self) -> bool:
        if self.capture is None:
            return False
        ok, frame = self.capture.read()
        if not ok:
            self.stop_playback()
            return False
        reported_next = int(round(self.capture.get(self.cv2.CAP_PROP_POS_FRAMES)))
        self.current_video_index = max(0, reported_next - 1)
        if not self.seek_dragging:
            self.seek_scale_var.set(float(self.current_video_index))
        self.current_bgr_frame = frame
        self._render_current_frame()
        self._update_position_text()
        self._publish_live_review_context(force=False)
        return True

    def _render_current_frame(self) -> None:
        if self.current_bgr_frame is None:
            return
        width = max(self.video_canvas.winfo_width(), 320)
        height = max(self.video_canvas.winfo_height(), 240)
        frame_height, frame_width = self.current_bgr_frame.shape[:2]
        scale = min(width / frame_width, height / frame_height)
        display_width = max(1, int(frame_width * scale))
        display_height = max(1, int(frame_height * scale))
        if display_width != frame_width or display_height != frame_height:
            display = self.cv2.resize(
                self.current_bgr_frame,
                (display_width, display_height),
                interpolation=self.cv2.INTER_AREA if scale < 1 else self.cv2.INTER_LINEAR,
            )
        else:
            display = self.current_bgr_frame
        rgb = self.cv2.cvtColor(display, self.cv2.COLOR_BGR2RGB)
        ppm = f"P6 {display_width} {display_height} 255\n".encode("ascii") + rgb.tobytes()
        self.tk_image = self.tk.PhotoImage(data=ppm, format="PPM")
        self.video_canvas.delete("all")
        self.video_canvas.create_image(width // 2, height // 2, image=self.tk_image, anchor="center")

    def _update_position_text(self) -> None:
        if self.current_video_index < 0:
            return
        seconds = self.current_video_index / self.video_fps
        try:
            framecount = self.video_index_to_framecount(self.current_video_index)
            framecount_text = str(framecount)
        except Exception:
            framecount_text = "mapping error"
        self.position_var.set(
            f"Video frame: {self.current_video_index:,}/{max(self.total_frames - 1, 0):,} | "
            f"CAN FrameCount: {framecount_text} | Time: {seconds:.3f} s"
        )
        if framecount_text != "mapping error":
            self.refresh_signal_table()

    # ------------------------------------------------------------- navigation
    def _on_seek_press(self, _event=None) -> None:
        self.seek_dragging = True
        self.stop_playback()

    def _on_seek_preview(self, value: str) -> None:
        if self.capture is None or not self.seek_dragging:
            return
        target_index = max(0, min(int(round(float(value))), max(self.total_frames - 1, 0)))
        seconds = target_index / self.video_fps
        try:
            framecount = self.video_index_to_framecount(target_index)
            framecount_text = str(framecount)
        except Exception:
            framecount_text = "mapping error"
        self.status_var.set(
            f"Seek preview: video frame {target_index:,}; CAN FC {framecount_text}; "
            f"time {seconds:.3f} s (release to load)"
        )

    def _on_seek_release(self, _event=None) -> None:
        if self.capture is None:
            self.seek_dragging = False
            return
        target_index = int(round(self.seek_scale_var.get()))
        self.seek_dragging = False
        self.signal_exact_can_pin = None
        self.show_video_frame(target_index)

    def go_to_framecount(self) -> None:
        try:
            self.signal_exact_can_pin = None
            target_fc = int(float(self.jump_framecount_var.get()))
            target_video = self.framecount_to_video_index(target_fc)
            self.show_video_frame(target_video)
        except Exception as exc:
            self._show_error("FrameCount jump error", exc)

    def step_video_frames(self, delta: int) -> None:
        if self.current_video_index < 0:
            return
        self.signal_exact_can_pin = None
        self.show_video_frame(self.current_video_index + int(delta))

    def step_framecount(self, delta: int) -> None:
        if self.current_video_index < 0:
            return
        try:
            self.signal_exact_can_pin = None
            current_fc = self.video_index_to_framecount(self.current_video_index)
            target_video = self.framecount_to_video_index(current_fc + int(delta))
            self.show_video_frame(target_video)
        except Exception as exc:
            self._show_error("FrameCount step error", exc)

    def toggle_play(self) -> None:
        if self.capture is None:
            return
        if self.playing:
            self.stop_playback()
        else:
            self.signal_exact_can_pin = None
            self.playing = True
            self.play_button.configure(text=self.localizer.text("⏸ Pause"))
            self._schedule_next_frame()

    def stop_playback(self) -> None:
        self.playing = False
        if hasattr(self, "play_button"):
            self.play_button.configure(text=self.localizer.text("▶ Play"))
        if self.after_id is not None:
            try:
                self.root.after_cancel(self.after_id)
            except Exception:
                pass
            self.after_id = None

    def _schedule_next_frame(self) -> None:
        if not self.playing:
            return
        if self.loop_event_var.get() and 0 <= self.current_event_index < len(self.events):
            event = self.events[self.current_event_index]
            current_fc = self.video_index_to_framecount(self.current_video_index)
            if current_fc >= event.end_framecount:
                self.show_video_frame(self.framecount_to_video_index(event.start_framecount))
                self.playing = True
                self.play_button.configure(text=self.localizer.text("⏸ Pause"))
        if not self._read_next_frame():
            return
        try:
            speed = max(float(self.speed_var.get()), 0.01)
        except Exception:
            speed = 0.25
        delay_ms = max(1, int(round(1000.0 / (self.video_fps * speed))))
        self.after_id = self.root.after(delay_ms, self._schedule_next_frame)

    # ----------------------------------------------------------- quick events
    def _set_memo_text(self, text: str) -> None:
        self.memo_text.delete("1.0", "end")
        if text:
            self.memo_text.insert("1.0", text)

    def _get_memo_text(self) -> str:
        return self.memo_text.get("1.0", "end-1c").strip()

    def _current_mapped_framecount(self) -> int:
        if self.current_video_index < 0:
            raise RuntimeError("Open a video before marking an Event.")
        return self.video_index_to_framecount(self.current_video_index)

    def _next_user_event_id(self) -> str:
        used = {event.event_id.upper() for event in self.all_events}
        for number in range(1, 10000):
            candidate = f"U{number:03d}"
            if candidate not in used:
                return candidate
        raise RuntimeError("No free user Event ID remains from U001 to U9999.")

    def mark_new_event_start(self) -> None:
        try:
            self.pending_event_start = self._current_mapped_framecount()
            self.pending_event_info_var.set(
                f"Pending Event start: FC {self.pending_event_start}. "
                "Navigate to the end and press Finish / Add."
            )
            self.status_var.set(f"Marked new Event start at FC {self.pending_event_start}")
        except Exception as exc:
            self._show_error("Mark Event start error", exc)

    def cancel_pending_event(self) -> None:
        self.pending_event_start = None
        self.pending_event_info_var.set("No pending Event start")
        self.status_var.set("Pending Event capture cancelled")

    def delete_current_event(self) -> None:
        """Delete the selected in-memory Event after explicit confirmation.

        The source Event Queue file is read-only. Deletion affects only the
        current session and the next exported review result.
        """
        if not (0 <= self.current_event_index < len(self.events)):
            self.status_var.set("No Event is selected for deletion")
            return

        from tkinter import messagebox

        event = self.events[self.current_event_index]
        confirmed = messagebox.askyesno(
            self.localizer.text("Delete selected Event"),
            self.localizer.text(
                f"Delete {event.event_id} from this review session?\n\n"
                "The original Event Queue CSV will not be modified."
            ),
            parent=self.root,
        )
        if not confirmed:
            self.status_var.set(f"Deletion cancelled: {event.event_id}")
            return

        old_index = self.current_event_index
        self.all_events = [item for item in self.all_events if item is not event]
        self.events = [item for item in self.events if item is not event]
        self.current_event_index = -1
        self._refresh_event_list()

        if self.events:
            self.select_event(min(old_index, len(self.events) - 1))
        else:
            self.review_code_var.set("")
            self._set_memo_text("")
            self.current_event_range_var.set("Start — | Peak — | End —")
            self._set_peak_navigation_enabled(False)
            self.event_info_var.set("No Events remain in the current review session")
        self.status_var.set(
            f"Deleted {event.event_id} from current session; source CSV unchanged"
        )

    def finish_add_event(self) -> None:
        try:
            if self.pending_event_start is None:
                raise RuntimeError("Press Mark Start before finishing a new Event.")
            current_framecount = self._current_mapped_framecount()
            start_framecount = min(self.pending_event_start, current_framecount)
            end_framecount = max(self.pending_event_start, current_framecount)
            event = ReviewEvent(
                event_id=self._next_user_event_id(),
                start_framecount=start_framecount,
                end_framecount=end_framecount,
                original={"EventSource": "IN_GUI_CAPTURE"},
            )
            self.all_events.append(event)
            self.event_filter_var.set("")
            self.events = list(self.all_events)
            self.current_event_index = -1
            self._refresh_event_list()
            self.pending_event_start = None
            self.pending_event_info_var.set("No pending Event start")
            file_name = self.event_file_path.name if self.event_file_path else "in-memory Event list"
            self.event_info_var.set(
                f"{file_name}: showing {len(self.events)} of {len(self.all_events)} events"
            )
            self.select_event(len(self.events) - 1)
            self.status_var.set(
                f"Added {event.event_id}: FC {event.start_framecount}–{event.end_framecount}. "
                "Add Review code / memo, then export all Events."
            )
        except Exception as exc:
            self._show_error("Add Event error", exc)

    # -------------------------------------------------------------- event CSV
    def load_event_csv(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askopenfilename(
            title=self.localizer.text("Load event/review CSV"),
            filetypes=[
                (self.localizer.text("CSV or TSV"), "*.csv *.tsv *.txt"),
                (self.localizer.text("All files"), "*.*"),
            ],
        )
        if not selected:
            return
        try:
            self.load_event_path(Path(selected))
        except Exception as exc:
            self._show_error("Event CSV error", exc)

    def load_event_path(self, path: Path) -> None:
        """Load an Event Queue from an explicit governed path without a dialog."""

        path = path.resolve()
        fieldnames, rows = read_delimited_file(path)
        events, start_column, peak_column, end_column = parse_review_events(fieldnames, rows)
        self.all_events = events
        self.events = list(events)
        self.event_file_path = path
        self.module_run_root = path.parent / "U003_MODULE_RUNS"
        self.module_run_id = f"LOCAL_{path.stem}"
        if self.module_coordinator is not None:
            self.module_coordinator.run_root = self.module_run_root.resolve()
        self.current_event_index = -1
        self._refresh_event_list()
        peak_text = peak_column or "legacy queue: no Peak"
        self.event_info_var.set(
            f"{path.name}: {len(events)} events | columns "
            f"{start_column} / {peak_text} / {end_column}"
        )
        self.select_event(0, navigate=self.video_path is not None)
        self.status_var.set(f"Loaded {len(events)} review events")

    def _refresh_event_list(self) -> None:
        self.event_listbox.delete(0, self.tk.END)
        for event in self.events:
            self.event_listbox.insert(self.tk.END, event.display_text())

    def apply_event_filter(self) -> None:
        if not self.all_events:
            return
        requested = [
            item.strip()
            for item in re.split(r"[,;\s]+", self.event_filter_var.get().strip())
            if item.strip()
        ]
        if not requested:
            self.events = list(self.all_events)
        else:
            requested_normalized = {normalized_name(item) for item in requested}
            self.events = [
                event
                for event in self.all_events
                if normalized_name(event.event_id) in requested_normalized
            ]
        self.current_event_index = -1
        self._refresh_event_list()
        file_name = self.event_file_path.name if self.event_file_path else "event file"
        self.event_info_var.set(
            f"{file_name}: showing {len(self.events)} of {len(self.all_events)} events"
        )
        if self.events:
            self.select_event(0)
        else:
            self.review_code_var.set("")
            self._set_memo_text("")
            self.current_event_range_var.set("Start — | Peak — | End —")
            self._set_peak_navigation_enabled(False)
            self.status_var.set("No event IDs matched the filter")

    def _on_event_selected(self, _event=None) -> None:
        selection = self.event_listbox.curselection()
        if selection:
            self.select_event(int(selection[0]))

    def select_event(self, index: int, navigate: bool = True) -> None:
        if not self.events:
            return
        index = max(0, min(index, len(self.events) - 1))
        self.current_event_index = index
        self.event_listbox.selection_clear(0, self.tk.END)
        self.event_listbox.selection_set(index)
        self.event_listbox.see(index)
        event = self.events[index]
        self.review_code_var.set(event.review_result)
        self._set_memo_text(event.memo)
        self._run_module_assistance(event)
        peak_text = str(event.peak_framecount) if event.peak_framecount is not None else "—"
        self.current_event_range_var.set(
            f"Start {event.start_framecount} | Peak {peak_text} | End {event.end_framecount}"
        )
        self._set_peak_navigation_enabled(event.peak_framecount is not None)
        if not navigate:
            if event.peak_framecount is not None:
                self.pin_exact_can_frame(event.peak_framecount)
            else:
                self.signal_exact_can_pin = None
            self._publish_live_review_context(force=True)
            return
        try:
            target_framecount = (
                event.peak_framecount
                if event.peak_framecount is not None
                else event.start_framecount
            )
            target_name = "Peak" if event.peak_framecount is not None else "Start"
            if event.peak_framecount is not None:
                self.pin_exact_can_frame(event.peak_framecount)
            else:
                self.signal_exact_can_pin = None
            self.show_video_frame(self.framecount_to_video_index(target_framecount))
            self.status_var.set(
                f"{event.event_id}: auto-jumped {target_name} FC {target_framecount}; "
                f"window {event.start_framecount}–{event.end_framecount}"
            )
        except Exception as exc:
            self._show_error("Event navigation error", exc)

    def previous_event(self) -> None:
        if self.events:
            self.select_event(max(0, self.current_event_index - 1))

    def next_event(self) -> None:
        if self.events:
            self.select_event(min(len(self.events) - 1, self.current_event_index + 1))

    def go_event_start(self) -> None:
        if 0 <= self.current_event_index < len(self.events):
            self.signal_exact_can_pin = None
            self.show_video_frame(
                self.framecount_to_video_index(self.events[self.current_event_index].start_framecount)
            )

    def go_event_peak(self) -> None:
        if 0 <= self.current_event_index < len(self.events):
            event = self.events[self.current_event_index]
            if event.peak_framecount is None:
                self.status_var.set(
                    f"{event.event_id}: this legacy Event row has no PeakFrameCount"
                )
                return
            self.pin_exact_can_frame(event.peak_framecount)
            self.show_video_frame(self.framecount_to_video_index(event.peak_framecount))
            self.status_var.set(
                f"{event.event_id}: exact CAN Peak pin FC {event.peak_framecount}; "
                "video shows nearest representable frame"
            )

    def go_event_end(self) -> None:
        if 0 <= self.current_event_index < len(self.events):
            self.signal_exact_can_pin = None
            self.show_video_frame(
                self.framecount_to_video_index(self.events[self.current_event_index].end_framecount)
            )

    def save_current_event_review(self) -> None:
        if not (0 <= self.current_event_index < len(self.events)):
            return
        code = self.review_code_var.get().strip()
        if code not in REVIEW_CODES:
            self._show_error("Review code error", RuntimeError("Review code must be 1–5 or blank."))
            return
        event = self.events[self.current_event_index]
        event.review_result = code
        event.memo = self._get_memo_text()
        self._refresh_event_list()
        self.event_listbox.selection_set(self.current_event_index)
        self.event_listbox.see(self.current_event_index)
        self.status_var.set(
            f"Saved {event.event_id}: R{code or '-'} {compact_text(event.memo)}"
        )

    def export_reviews(self) -> None:
        if not self.all_events:
            self._show_error("Export error", RuntimeError("No Events are available to export."))
            return
        if 0 <= self.current_event_index < len(self.events):
            self.save_current_event_review()
        output_dir = (
            self.event_file_path.parent
            if self.event_file_path
            else self.video_path.parent
            if self.video_path
            else Path.cwd()
        )
        export_stamp = datetime.now().strftime("%y%m%dT%H%M%S")
        csv_path = self._unique_path(output_dir / f"u003_review_results_{export_stamp}.csv")
        code_path = self._unique_path(output_dir / f"u003_return_{export_stamp}.txt")
        fieldnames = [
            "EventID",
            "StartFrameCount",
            "PeakFrameCount",
            "EndFrameCount",
            "ReviewResult",
            "ReviewMemo",
        ]
        with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for event in self.all_events:
                writer.writerow(
                    {
                        "EventID": event.event_id,
                        "StartFrameCount": event.start_framecount,
                        "PeakFrameCount": (
                            event.peak_framecount if event.peak_framecount is not None else ""
                        ),
                        "EndFrameCount": event.end_framecount,
                        "ReviewResult": event.review_result,
                        "ReviewMemo": event.memo,
                    }
                )

        reviewed = [event for event in self.all_events if event.review_result]
        lines = [build_review_return_capsule(self.all_events, export_stamp)]
        for event in reviewed:
            source_memo_column = find_column(list(event.original), ("ReviewMemo", "Memo", "Comment"))
            source_memo = event.original.get(source_memo_column, "") if source_memo_column else ""
            if event.memo and event.memo.strip() != source_memo.strip():
                short_id = compact_event_number(event.event_id)
                memo_id = str(short_id) if short_id is not None else event.event_id
                lines.append(f"M{memo_id}-{compact_text(event.memo, 80)}")
        code_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.status_var.set(f"Review output saved: {csv_path.name} / {code_path.name}")
        self._show_info(
            "Reviews exported",
            f"Full local output:\n{csv_path}\n\nCompact return code:\n{code_path}",
        )

    # ----------------------------------------------------------- screenshots
    def save_screenshot(self) -> None:
        if self.current_bgr_frame is None or self.video_path is None:
            return
        try:
            framecount = self.video_index_to_framecount(self.current_video_index)
            path = self._unique_path(
                self.video_path.parent
                / f"review_FC{framecount}_VF{self.current_video_index}.png"
            )
            if not self.cv2.imwrite(str(path), self.current_bgr_frame):
                raise RuntimeError("OpenCV failed to write the screenshot.")
            self.status_var.set(f"Screenshot saved locally: {path.name}")
        except Exception as exc:
            self._show_error("Screenshot error", exc)

    # --------------------------------------------------------------- helpers
    def _unique_path(self, path: Path) -> Path:
        if not path.exists():
            return path
        for number in range(1, 1000):
            candidate = path.with_name(f"{path.stem}_{number:03d}{path.suffix}")
            if not candidate.exists():
                return candidate
        raise RuntimeError("No free output suffix is available from _001 to _999.")

    def _show_error(self, title: str, error: Exception) -> None:
        from tkinter import messagebox

        self.status_var.set(f"ERROR: {error}")
        messagebox.showerror(
            self.localizer.text(title),
            self.localizer.text(str(error)),
            parent=self.root,
        )

    def _show_info(self, title: str, message: str) -> None:
        from tkinter import messagebox

        messagebox.showinfo(
            self.localizer.text(title),
            self.localizer.text(message),
            parent=self.root,
        )

    def load_handoff(self, handoff: GovernedHandoffBatch) -> None:
        """Preload both governed U002 payloads and expose the CAN table."""

        self.load_event_path(handoff.event_queue_path)
        self.module_run_id = handoff.run_id
        self.module_run_root = handoff.descriptor_path.parent / "U003_MODULE_RUNS"
        if self.module_coordinator is not None:
            self.module_coordinator.run_root = self.module_run_root.resolve()
        self.load_signal_path(handoff.review_data_path)
        self.show_signal_window()
        self.status_var.set(
            f"Governed handoff loaded: {handoff.run_id} / {handoff.batch_id} | "
            f"{handoff.candidate_count} events | "
            f"{handoff.review_data_row_count:,} Review Data rows"
        )

    def run(self) -> None:
        self.root.mainloop()

    def close(self) -> None:
        self.stop_playback()
        if self.live_context_publisher is not None:
            self.live_context_publisher.stop()
        if self.capture is not None:
            self.capture.release()
        self.root.destroy()
