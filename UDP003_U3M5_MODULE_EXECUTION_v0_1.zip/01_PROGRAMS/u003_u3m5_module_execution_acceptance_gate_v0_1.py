#!/usr/bin/env python3
"""Fail-close acceptance for U3M5 governed Module execution in U003."""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


GATE_VERSION = "0.1"
PROGRAM_ROOT = Path(__file__).resolve().parent
U003_ROOT = PROGRAM_ROOT.parent
CONTRACT_PATH = (
    U003_ROOT
    / "02_CONTROLS"
    / "contracts"
    / "u003_module_assistance_runtime_contract_v0_1.json"
)
PREDECESSORS = {
    "u003_evidence_review_workbench_v0_16.py": "087232edfdeb76976528d74324c586a6bfe023837c555b9a3f6e0571405b3e57",
    "u003_gui_shell_v0_3.py": "08ebc3d6fd0a39b6ad52f1f0a44d2cab4899ae14d3b2c9a70869652cc71b3f43",
    "u003_localization_v0_1.py": "1b96547440e68a5720ac77e44d62ddfb15412d87c6a13d89337e114612153f14",
    "u003_module_manager_gui_v0_2.py": "12395c3228422209893d2cd982b29c0bda398a8dbda4543b84d731059eaa95cc",
    "u003_module_executor_v0_1.py": "c374b0cdc0ca56228e0f67bd98ba8bfcfce90ae0fd98629adc45566125efaf27",
    "u003_module_runtime_v0_1.py": "617b0a756acfbf1ce7db9f40f1e080ac0a2d22d5a35db8228518254f187bd370",
    "u003_module_plan_core_v0_1.py": "8faa92354eb5f9de3e83bbe082b6d360971da40a9ebcc8a3a89b34e0f0c2ebe4",
    "u003_domain_core_v0_2.py": "6c25c2ef9b6e51be286291532cfddb44bfd0fdd20b827c230d3199e910f06bd7",
    "u003_handoff_core_v0_2.py": "cbd4c02b86e8df8ce10fdf4e15fdd31be49dd328a3f4c03d07754ec4bef5fd66",
}
NEW_FILES = (
    "u003_module_execution_coordinator_v0_1.py",
    "u003_localization_v0_2.py",
    "u003_module_manager_gui_v0_3.py",
    "u003_gui_shell_v0_4.py",
    "u003_evidence_review_workbench_v0_17.py",
)
GUI_ALLOWED_CHANGED = {
    "__init__",
    "_module_plan_changed",
    "open_module_manager",
    "load_event_path",
    "select_event",
    "load_handoff",
}
GUI_EXPECTED_ADDED = {
    "_ensure_module_coordinator",
    "_run_module_assistance",
}
MANAGER_ALLOWED_CHANGED = {
    "__init__",
    "_build_ui",
    "add_selected",
    "load_recommended",
}


class AcceptanceError(RuntimeError):
    """Raised when U3M5 violates predecessor, execution, or review authority."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def class_methods(path: Path, class_name: str) -> dict[str, str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return {
                child.name: ast.dump(child, include_attributes=False)
                for child in node.body
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
    raise AcceptanceError(f"Class not found: {class_name} in {path.name}")


def fresh_process(program_name: str, *arguments: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-B", str(PROGRAM_ROOT / program_name), *arguments],
        cwd=U003_ROOT.parent,
        capture_output=True,
        text=True,
        timeout=40,
        check=False,
    )


def fresh_capability(program_name: str) -> dict[str, Any]:
    result = fresh_process(program_name, "--print-launch-capability")
    if result.returncode != 0:
        raise AcceptanceError(f"Capability failed: {program_name}: {result.stderr}")
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if not lines:
        raise AcceptanceError(f"Capability output missing: {program_name}")
    return json.loads(lines[-1])


def run_acceptance(verbose: bool) -> tuple[int, dict[str, int]]:
    if str(PROGRAM_ROOT) not in sys.path:
        sys.path.insert(0, str(PROGRAM_ROOT))

    coordinator_module = importlib.import_module(
        "u003_module_execution_coordinator_v0_1"
    )
    domain = importlib.import_module("u003_domain_core_v0_2")
    entry = importlib.import_module("u003_evidence_review_workbench_v0_17")
    localization = importlib.import_module("u003_localization_v0_2")
    manager = importlib.import_module("u003_module_manager_gui_v0_3")
    plan_core = importlib.import_module("u003_module_plan_core_v0_1")
    shell = importlib.import_module("u003_gui_shell_v0_4")

    checks = 0
    groups = {"identity": 0, "regression": 0, "execution": 0, "authority": 0}

    def check(condition: bool, group: str, label: str, meaning: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(f"{group}:{label}")
        checks += 1
        groups[group] += 1
        if verbose:
            print(f"[CHECK {checks:03d}] {label} - {meaning}")

    for name, expected_hash in PREDECESSORS.items():
        path = PROGRAM_ROOT / name
        check(path.is_file(), "identity", f"predecessor {name}", "accepted source exists")
        check(
            sha256_file(path) == expected_hash,
            "identity",
            f"hash {name}",
            "accepted source remains byte-identical",
        )
    for name in NEW_FILES:
        check((PROGRAM_ROOT / name).is_file(), "identity", f"new {name}", "U3M5 component is installed")
    check(CONTRACT_PATH.is_file(), "identity", "runtime contract", "execution policy is explicit")
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8-sig"))
    check(
        contract.get("ContractId") == "U003_MODULE_ASSISTANCE_RUNTIME",
        "identity",
        "contract identity",
        "the coordinator follows one versioned policy",
    )
    check(entry.VERSION == "0.17", "identity", "entry version", "U3M5 is identifiable")
    check(shell.GUI_SHELL_VERSION == "0.4", "identity", "GUI version", "runtime integration is identifiable")
    check(manager.MANAGER_VERSION == "0.3", "identity", "manager version", "active plan UI is identifiable")
    check(localization.LOCALIZATION_VERSION == "0.2", "identity", "localization version", "new runtime text is localized")
    check(coordinator_module.COORDINATOR_VERSION == "0.1", "identity", "coordinator version", "execution ownership is explicit")

    old_gui = class_methods(PROGRAM_ROOT / "u003_gui_shell_v0_3.py", "FrameCountVideoReviewer")
    new_gui = class_methods(PROGRAM_ROOT / "u003_gui_shell_v0_4.py", "FrameCountVideoReviewer")
    check(
        set(new_gui) - set(old_gui) == GUI_EXPECTED_ADDED,
        "regression",
        "GUI additions",
        "only the coordinator boundary and event assistance are new",
    )
    check(not (set(old_gui) - set(new_gui)), "regression", "GUI removals", "no accepted GUI operation was removed")
    changed_gui = {name for name in old_gui if old_gui[name] != new_gui[name]}
    check(changed_gui == GUI_ALLOWED_CHANGED, "regression", "GUI change boundary", "only Module integration call sites changed")
    for name in sorted(set(old_gui) - GUI_ALLOWED_CHANGED):
        check(old_gui[name] == new_gui[name], "regression", f"GUI {name}", "unrelated review behavior is AST-identical")

    old_manager = class_methods(PROGRAM_ROOT / "u003_module_manager_gui_v0_2.py", "ModuleManagerWindow")
    new_manager = class_methods(PROGRAM_ROOT / "u003_module_manager_gui_v0_3.py", "ModuleManagerWindow")
    check(old_manager.keys() == new_manager.keys(), "regression", "manager inventory", "selection functions are preserved")
    changed_manager = {name for name in old_manager if old_manager[name] != new_manager[name]}
    check(changed_manager == MANAGER_ALLOWED_CHANGED, "regression", "manager change boundary", "only runtime wording changed")
    for name in sorted(set(old_manager) - MANAGER_ALLOWED_CHANGED):
        check(old_manager[name] == new_manager[name], "regression", f"manager {name}", "selection logic is AST-identical")

    old_capability = fresh_capability("u003_evidence_review_workbench_v0_16.py")
    new_capability = fresh_capability("u003_evidence_review_workbench_v0_17.py")
    for key in (
        "InterfaceId",
        "InterfaceVersion",
        "ProgramId",
        "SupportedArguments",
        "AcceptedHandoffContractId",
        "AcceptedHandoffContractVersion",
    ):
        check(old_capability[key] == new_capability[key], "regression", f"capability {key}", "U002 launch compatibility is unchanged")

    coordinator_test = fresh_process("u003_module_execution_coordinator_v0_1.py")
    check(coordinator_test.returncode == 0, "execution", "coordinator self-test exit", "pure composition helpers pass")
    check(
        coordinator_test.stdout.strip() == "U003-U3M5-COORDINATOR-SELFTEST-PASS-12 C-0",
        "execution",
        "coordinator self-test capsule",
        "context and memo rules are exact",
    )
    entry_test = fresh_process("u003_evidence_review_workbench_v0_17.py", "--self-test")
    check(entry_test.returncode == 0, "execution", "entry self-test exit", "fresh-process imports pass")
    check(entry_test.stdout.strip() == "U003-V017-SELFTEST-PASS-22", "execution", "entry self-test capsule", "component versions are composed")

    module_root = U003_ROOT / "02_MODULES"
    catalog = plan_core.discover_catalog(module_root)
    descriptor = plan_core.find_descriptor(
        catalog,
        "CameraRadar.U003.SampleMemoDraft",
        "0.1.0",
    )
    check(descriptor.execution_kind == "PROCESS", "execution", "sample PROCESS module", "the isolated bridge is exercised")
    check("ON_EVENT_SELECTED" in descriptor.lifecycle_hooks, "execution", "event hook", "execution occurs at the review boundary")

    original = {
        "CandidateReasonCode": "RADAR_LOSS",
        "CandidateScore": "2.48487",
        "ReviewMemo": "U002 source memo",
    }
    event = domain.ReviewEvent(
        event_id="C0010",
        start_framecount=41480,
        peak_framecount=41520,
        end_framecount=41600,
        original=dict(original),
        memo="U002 source memo",
    )
    with tempfile.TemporaryDirectory(prefix="u003_u3m5_gate_") as temporary:
        run_root = Path(temporary) / "U003_MODULE_RUNS"
        coordinator = coordinator_module.ModuleExecutionCoordinator(
            module_root,
            run_root,
            "EN",
        )
        empty_report = coordinator.execute_event(event, "U3M5_EMPTY")
        check(empty_report.selected_count == 0, "execution", "empty plan", "no Module is selected by default")
        check(empty_report.executed_count == 0, "execution", "empty execution", "legacy no-Module path performs no child work")

        plan = plan_core.add_or_replace_selection(
            plan_core.empty_plan(module_root, "EN"),
            descriptor,
        )
        coordinator.activate_plan(plan)
        first = coordinator.execute_event(event, "U3M5_GOLDEN")
        changed = coordinator.apply_report_to_event(event, first)
        second = coordinator.execute_event(event, "U3M5_GOLDEN")
        changed_again = coordinator.apply_report_to_event(event, second)
        check(first.executed_count == 1, "execution", "first execution", "one selected eligible Module runs")
        check(first.suggestion_count == 1, "execution", "memo output", "one editable suggestion is produced")
        check(changed, "execution", "memo composed", "suggestion is appended to the source memo")
        check(second.executed_count == 0 and second.cached_count == 1, "execution", "cache reuse", "the same event/context/package does not rerun")
        check(not changed_again, "execution", "duplicate suppressed", "revisiting an Event does not duplicate text")
        check("C0010" in event.memo and "41520" in event.memo, "execution", "human context", "Event and Peak remain visible")
        trace_paths = list(run_root.rglob("module_trace.json"))
        check(len(trace_paths) == 1, "execution", "single trace", "only one child execution occurred")
        result_path = trace_paths[0].with_name("module_result.json")
        result_payload = json.loads(result_path.read_text(encoding="utf-8-sig"))
        check(result_payload.get("RootCauseClaim") is False, "authority", "no root cause", "Module remains review assistance")
        check(event.event_id == "C0010", "authority", "Event identity", "Module cannot rewrite EventID")
        check(event.peak_framecount == 41520, "authority", "Peak identity", "Module cannot rewrite PeakFrameCount")
        check(event.review_result == "", "authority", "review authority", "Module cannot choose engineer disposition")
        check(event.original == original, "authority", "source immutability", "U002 evidence is not mutated")

        japanese_event = domain.ReviewEvent(
            event_id="C0011",
            start_framecount=41620,
            peak_framecount=41662,
            end_framecount=41700,
            original={"CandidateReasonCode": "RADAR_LOSS"},
        )
        japanese = coordinator_module.ModuleExecutionCoordinator(
            module_root,
            run_root,
            "JA",
        )
        japanese.activate_plan(plan_core.set_language(plan, "JA"))
        japanese_report = japanese.execute_event(japanese_event, "U3M5_GOLDEN_JA")
        japanese.apply_report_to_event(japanese_event, japanese_report)
        check("確認してください" in japanese_event.memo, "execution", "Japanese memo", "session language reaches the Module")

    return checks, groups


def capsule(checks: int, groups: dict[str, int]) -> str:
    return (
        "U3M5 "
        f"N-I{groups['identity']}-R{groups['regression']}-"
        f"E{groups['execution']}-A{groups['authority']}-T{checks}-X0 C-0"
    )


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--accept", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if not arguments.self_test and not arguments.accept:
            raise AcceptanceError("Use --self-test or --accept")
        checks, groups = run_acceptance(verbose=arguments.accept)
        print(capsule(checks, groups))
        return 0
    except Exception as error:
        print(
            f"U3M5E K-{type(error).__name__.upper()} D-{error} X1 C-7",
            file=sys.stderr,
        )
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
