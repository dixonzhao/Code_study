#!/usr/bin/env python3
"""Session-locked English/Japanese localization for U003 user interfaces."""

from __future__ import annotations

from typing import Any


LOCALIZATION_VERSION = "0.2"
SUPPORTED_LANGUAGES = ("EN", "JA")


JA_TEXT = {
    "U003 Evidence Review Workbench": "U003 エビデンス確認ワークベンチ",
    "U003 Synchronized CAN Review Table": "U003 同期CAN確認テーブル",
    "U003 Module Manager": "U003 モジュールマネージャー",
    "U003 Evidence Review Workbench error": "U003 エビデンス確認ワークベンチ エラー",
    "Open Video": "映像を開く",
    "Load Event CSV": "イベントCSVを読込",
    "Load Signal CSV": "信号CSVを読込",
    "Show CAN Window": "CAN画面を表示",
    "Export Reviews": "確認結果を出力",
    "Save Screenshot": "スクリーンショット保存",
    "Modules": "モジュール",
    "Modules (0)": "モジュール (0)",
    "No video loaded": "映像未読込",
    "Video frame: — | FrameCount: — | Time: —": "映像フレーム: — | FrameCount: — | 時刻: —",
    "Mapping not configured": "FrameCount対応未設定",
    "No event file loaded": "イベントファイル未読込",
    "Start — | Peak — | End —": "開始 — | ピーク — | 終了 —",
    "No pending Event start": "追加中イベントなし",
    "No signal CSV loaded. Recommended: c13v002_subgraph_v0_1.csv": "信号CSV未読込（推奨: c13v002_subgraph_v0_1.csv）",
    "Ready": "準備完了",
    "Module Manager error": "モジュールマネージャーエラー",
    "Module execution error": "モジュール実行エラー",
    "⏮ Event Start": "⏮ イベント開始",
    "▶ Play": "▶ 再生",
    "⏸ Pause": "⏸ 一時停止",
    "Event End ⏭": "イベント終了 ⏭",
    "Playback speed": "再生速度",
    "Loop current event": "現在イベントを繰返し再生",
    "FrameCount Mapping": "FrameCount対応設定",
    "Video anchor index": "映像基準フレーム",
    "CAN anchor FC": "CAN基準FrameCount",
    "CAN rate (Hz)": "CAN周期 (Hz)",
    "Mode": "方式",
    "Rate-based": "レート換算",
    "Apply Mapping": "対応設定を適用",
    "Event Navigation": "イベント移動",
    "Jump FC": "FrameCountへ移動",
    "Go": "移動",
    "Filter IDs": "ID絞込み",
    "Apply": "適用",
    "Previous": "前へ",
    "Next": "次へ",
    "Peak Cursor": "ピークカーソル",
    "Jump / Pin Peak": "ピークへ移動・固定",
    "Release Pin": "固定解除",
    "Quick Event Capture": "イベント簡易追加",
    "1. Mark Start": "1. 開始を記録",
    "2. Finish / Add": "2. 終了・追加",
    "Cancel": "キャンセル",
    "Delete Selected Event": "選択イベントを削除",
    "Current Event Review": "現在イベントの確認",
    "Result code": "判定コード",
    "1 correct, 2 wrong, 3 scene, 4 unclear, 5 unavailable": "1 正常、2 誤り、3 評価対象外、4 不明、5 映像使用不可",
    "Short memo": "確認メモ",
    "Save Event Review": "イベント確認結果を保存",
    "Load Review Data CSV": "確認用データCSVを読込",
    "Display range ±FrameCount (15 = 31 rows)": "表示範囲 ±FrameCount（15 = 31行）",
    "Refresh": "更新",
    "CAN highlight lag offset (CAN highlight = Video FC + offset)": "CAN強調表示のLag補正（CAN表示 = 映像FC + 補正値）",
    "Apply lag": "Lagを適用",
    "Export plot data around yellow row": "黄色行周辺の作図データを出力",
    "Before FC": "前方FC",
    "After FC": "後方FC",
    "Export Plot CSV": "作図CSVを出力",
    "Center = yellow CAN row; all loaded columns are exported.": "中心は黄色のCAN行。読込済みの全列を出力します。",
    "Yellow = exact Event Peak CAN row while Peak Pin is active; otherwise exact/nearest CAN row for the displayed video frame. Double-click a row to jump the video. All columns supplied by the Review Data CSV are retained. Plot export uses independent Before/After FrameCount ranges so causes may be captured asymmetrically.": "黄色は、ピーク固定中はイベントの正確なCANピーク行、それ以外は表示映像フレームに対応する正確または最近傍のCAN行です。行をダブルクリックすると映像へ移動します。確認用CSVの全列を保持し、作図出力では原因側と結果側で異なるFrameCount範囲を指定できます。",
    "Open test video": "テスト映像を開く",
    "Load synchronized narrow CAN CSV": "同期済みCAN確認CSVを読込",
    "Load event/review CSV": "イベント・確認CSVを読込",
    "CSV or TSV": "CSVまたはTSV",
    "Video files": "映像ファイル",
    "All files": "すべてのファイル",
    "Delete selected Event": "選択イベントを削除",
    "Reviews exported": "確認結果を出力しました",
    "Plot data exported": "作図データを出力しました",
    "FrameCount mapping applied": "FrameCount対応設定を適用しました",
    "Signal CSV error": "信号CSVエラー",
    "Plot data export error": "作図データ出力エラー",
    "Signal-row navigation error": "信号行移動エラー",
    "Mapping error": "対応設定エラー",
    "Video open error": "映像読込エラー",
    "FrameCount jump error": "FrameCount移動エラー",
    "FrameCount step error": "FrameCountステップエラー",
    "Mark Event start error": "イベント開始記録エラー",
    "Add Event error": "イベント追加エラー",
    "Event CSV error": "イベントCSVエラー",
    "Event navigation error": "イベント移動エラー",
    "Review code error": "判定コードエラー",
    "Export error": "出力エラー",
    "Screenshot error": "スクリーンショットエラー",
    "Module Root": "モジュール格納先",
    "Choose…": "選択…",
    "Governed behavior": "管理ルール",
    "Available Module families": "利用可能なモジュール",
    "Slot": "スロット",
    "Module": "モジュール",
    "Version": "バージョン",
    "Kind": "種類",
    "Recommended": "推奨",
    "Yes": "はい",
    "No": "いいえ",
    "Add / Replace": "追加・置換",
    "View Algorithm Card": "Algorithm Cardを表示",
    "Active Module Plan": "有効なモジュールPlan",
    "Fixed Slot": "固定スロット",
    "Selected Module": "選択済みモジュール",
    "Remove": "削除",
    "Move Up": "上へ",
    "Move Down": "下へ",
    "Clear": "全解除",
    "Load Recommended": "推奨構成を読込",
    "Open Plan…": "Planを開く…",
    "Save Plan…": "Planを保存…",
    "Select U003 02_MODULES directory": "U003の02_MODULESフォルダーを選択",
    "Select one available Module family.": "利用可能なモジュールを1つ選択してください。",
    "Select one active Module.": "有効なモジュールを1つ選択してください。",
    "None": "なし",
    "Module discovery error": "モジュール検出エラー",
    "Version selection error": "バージョン選択エラー",
    "Add Module error": "モジュール追加エラー",
    "Remove Module error": "モジュール削除エラー",
    "Move Module error": "モジュール移動エラー",
    "Algorithm Card error": "Algorithm Cardエラー",
    "Save U003 Module Plan": "U003モジュールPlanを保存",
    "Open U003 Module Plan": "U003モジュールPlanを開く",
    "Save Module Plan error": "モジュールPlan保存エラー",
    "Open Module Plan error": "モジュールPlan読込エラー",
    "Overview": "概要",
    "Method / Rules": "手法・ルール",
    "Interface": "入出力",
    "Validation": "検証",
    "Limits": "制約",
    "Raw JSON": "Raw JSON（上級者向け）",
    "Close": "閉じる",
    "Purpose": "目的",
    "Reality Meaning": "現実の意味",
    "Inputs": "入力",
    "Outputs": "出力",
    "Rules": "ルール",
    "Assumptions": "前提条件",
    "Limitations": "制約事項",
    "Not declared": "未定義",
    "No Module is selected by default. One version per ModuleId. Reordering is allowed only inside the same fixed slot. Selected PROCESS Modules run once per Event/context and may only append editable review assistance.": "初期状態ではモジュールを選択しません。ModuleIdごとに1バージョンのみ選択できます。順序変更は同じ固定スロット内だけ可能です。選択したPROCESSモジュールはイベント／入力条件ごとに1回だけ実行され、編集可能な確認支援のみを追記できます。",
    "Ready - valid selected PROCESS Modules execute on Event selection": "準備完了：選択済みの有効なPROCESSモジュールはイベント選択時に実行されます",
    "Active Module Plan cleared; no-Module behavior is active": "モジュールPlanを解除しました。モジュールなしの動作が有効です",
    "ERROR": "エラー",
}


JA_PHRASES = (
    ("Module Plan updated:", "モジュールPlan更新:"),
    ("Module Plan cleared; no-Module behavior is active", "モジュールPlanを解除しました。モジュールなしの動作が有効です"),
    ("Modules (", "モジュール ("),
    ("selected; eligible PROCESS Modules are active", "件選択済み。有効なPROCESSモジュールを実行します"),
    ("Validated", "検証済み:"),
    ("versions in", "バージョン /"),
    ("Module families", "モジュール"),
    ("Selected", "選択:"),
    ("eligible PROCESS Module is active", "有効なPROCESSモジュールを実行します"),
    ("Loaded", "読込:"),
    ("recommended Modules; eligible PROCESS Modules are active", "件の推奨モジュール。有効なPROCESSモジュールを実行します"),
    ("Module assistance:", "モジュール支援:"),
    ("executed", "実行"),
    ("cached", "キャッシュ"),
    ("suggestions", "提案"),
    ("Module Plan saved:", "モジュールPlan保存:"),
    ("Module Plan opened and validated:", "モジュールPlan読込・検証完了:"),
    ("No pending Event start", "追加中イベントなし"),
    ("Pending Event capture cancelled", "イベント追加をキャンセルしました"),
    ("No Events remain in the current review session", "現在の確認Sessionにイベントはありません"),
    ("No event IDs matched the filter", "絞込み条件に一致するイベントIDはありません"),
    ("Review output saved:", "確認結果保存:"),
    ("Screenshot saved locally:", "スクリーンショット保存:"),
    ("Loaded synchronized CAN table:", "同期CANテーブル読込:"),
    ("unique FrameCounts", "個のFrameCount"),
    ("displayed columns", "表示列"),
    ("Video frame:", "映像フレーム:"),
    ("CAN FrameCount:", "CAN FrameCount:"),
    ("Time:", "時刻:"),
    ("Start", "開始"),
    ("Peak", "ピーク"),
    ("End", "終了"),
    ("Delete ", "削除: "),
    (" from this review session?", " を現在の確認Sessionから削除しますか？"),
    ("The original Event Queue CSV will not be modified.", "元のイベントQueue CSVは変更されません。"),
)


def normalize_language(value: str | None) -> str:
    language = str(value or "EN").strip().upper()
    if language not in SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported U003 interface language: {value}")
    return language


class Localizer:
    """Translate presentation text while leaving schemas and stored data unchanged."""

    def __init__(self, language: str) -> None:
        self.language = normalize_language(language)

    def text(self, value: Any) -> Any:
        if not isinstance(value, str) or self.language == "EN":
            return value
        if value in JA_TEXT:
            return JA_TEXT[value]
        translated = value
        for source, target in JA_PHRASES:
            translated = translated.replace(source, target)
        return translated

    def format(self, english_template: str, **values: Any) -> str:
        return str(self.text(english_template.format(**values)))


class LocalizedTtk:
    """Translate static ttk widget labels at construction time only."""

    TRANSLATED_WIDGETS = {"Button", "Checkbutton", "Label", "LabelFrame"}

    def __init__(self, ttk_module: Any, localizer: Localizer) -> None:
        self._ttk = ttk_module
        self._localizer = localizer

    def __getattr__(self, name: str) -> Any:
        target = getattr(self._ttk, name)
        if name not in self.TRANSLATED_WIDGETS:
            return target

        def constructor(*args: Any, **kwargs: Any) -> Any:
            if "text" in kwargs:
                kwargs["text"] = self._localizer.text(kwargs["text"])
            return target(*args, **kwargs)

        return constructor


def localized_string_var(tk_module: Any, localizer: Localizer, master: Any, value: str) -> Any:
    """Create a presentation-only StringVar whose later status text is localized."""

    variable = tk_module.StringVar(master=master, value=localizer.text(value))
    original_set = variable.set

    def translated_set(next_value: Any) -> None:
        original_set(localizer.text(next_value))

    variable.set = translated_set
    return variable


def choose_session_language() -> str | None:
    """Ask once at startup; returning None means the user cancelled launch."""

    import tkinter as tk
    from tkinter import ttk

    result: dict[str, str | None] = {"language": None}
    root = tk.Tk()
    root.title("U003 Language / 言語選択")
    root.geometry("430x190")
    root.resizable(False, False)

    frame = ttk.Frame(root, padding=20)
    frame.pack(fill="both", expand=True)
    ttk.Label(
        frame,
        text="Select the interface language for this session.\nこのSessionで使用する表示言語を選択してください。",
        justify="center",
    ).pack(fill="x", pady=(5, 20))

    buttons = ttk.Frame(frame)
    buttons.pack()

    def finish(language: str | None) -> None:
        result["language"] = language
        root.destroy()

    ttk.Button(buttons, text="English", width=15, command=lambda: finish("EN")).pack(
        side="left", padx=8
    )
    ttk.Button(buttons, text="日本語", width=15, command=lambda: finish("JA")).pack(
        side="left", padx=8
    )
    ttk.Button(frame, text="Cancel / キャンセル", command=lambda: finish(None)).pack(
        pady=(18, 0)
    )
    root.protocol("WM_DELETE_WINDOW", lambda: finish(None))
    root.mainloop()
    return result["language"]
