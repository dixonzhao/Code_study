#!/usr/bin/env python3
"""Pure, GUI-independent domain logic extracted from accepted U003 v0.13.

Version 0.2 preserves the accepted delimiter and encoding behavior exactly so
the GUI shell can delegate all review-domain ownership without compatibility
fallbacks.
"""

from __future__ import annotations

import bisect
import csv
import math
import re
from dataclasses import dataclass, field
from pathlib import Path


DOMAIN_VERSION = "0.2"
REVIEW_CODES = {
    "": "Not reviewed",
    "1": "Correct / expected",
    "2": "Incorrect / mismatch",
    "3": "Real target or scene change",
    "4": "Unclear",
    "5": "Video unavailable",
}
EVENT_START_ALIASES = (
    "ReviewStartFrame",
    "StartFrame",
    "StartFrameCount",
    "WindowStart",
    "FrameStart",
)
EVENT_PEAK_ALIASES = (
    "PeakFrameCount",
    "PeakFrame",
    "ReviewPeakFrame",
    "WindowPeak",
    "PeakFC",
    "Peak",
)
EVENT_END_ALIASES = (
    "ReviewEndFrame",
    "EndFrame",
    "EndFrameCount",
    "WindowEnd",
    "FrameEnd",
)


@dataclass
class ReviewEvent:
    """One immutable candidate window plus mutable engineer review state."""

    event_id: str
    start_framecount: int
    end_framecount: int
    original: dict[str, str] = field(default_factory=dict)
    review_result: str = ""
    memo: str = ""
    peak_framecount: int | None = None

    def display_text(self) -> str:
        result = self.review_result or "-"
        peak = str(self.peak_framecount) if self.peak_framecount is not None else "—"
        return (
            f"{self.event_id} | S {self.start_framecount} | P {peak} | "
            f"E {self.end_framecount} | R{result}"
        )


def highlight_target_framecount(
    video_framecount: int,
    lag_offset: int,
    exact_can_pin: int | None,
) -> int:
    """Return the CAN row selected by free navigation or exact Peak pin."""

    if exact_can_pin is not None:
        return int(exact_can_pin)
    return int(video_framecount) + int(lag_offset)


def nearest_sorted_index(framecounts: list[int], target: int) -> int:
    """Locate an exact row when present, otherwise the nearest governed row."""

    if not framecounts:
        raise RuntimeError("No CAN FrameCount rows are available.")
    insertion = bisect.bisect_left(framecounts, target)
    candidates = [
        index
        for index in (insertion - 1, insertion)
        if 0 <= index < len(framecounts)
    ]
    return min(candidates, key=lambda index: (abs(framecounts[index] - target), index))


def normalized_name(value: object) -> str:
    text = "" if value is None else str(value)
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    return re.sub(r"[^a-z0-9]+", "", text.lower())


def compact_text(value: object, limit: int = 40) -> str:
    text = " ".join(str(value).replace("\r", " ").replace("\n", " ").split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def compact_event_number(event_id: str) -> int | None:
    match = re.fullmatch(r"[^0-9]*([0-9]+)", str(event_id).strip())
    return int(match.group(1)) if match else None


def integer_range_tokens(values: list[int]) -> list[str]:
    if not values:
        return []
    ordered = sorted(set(values))
    tokens: list[str] = []
    start = previous = ordered[0]
    for value in ordered[1:]:
        if value == previous + 1:
            previous = value
            continue
        tokens.append(str(start) if start == previous else f"{start}-{previous}")
        start = previous = value
    tokens.append(str(start) if start == previous else f"{start}-{previous}")
    return tokens


def compress_integer_ranges(values: list[int]) -> str:
    return "_".join(integer_range_tokens(values))


def build_review_return_capsule(events: list[ReviewEvent], export_stamp: str) -> str:
    reviewed = [event for event in events if event.review_result]
    numeric_ids = [compact_event_number(event.event_id) for event in reviewed]
    numeric_mode = (
        all(value is not None for value in numeric_ids)
        and len(set(numeric_ids)) == len(numeric_ids)
    )
    fields = [f"RV{export_stamp}", f"N{len(events)}-R{len(reviewed)}"]
    for review_code in sorted({event.review_result for event in reviewed}):
        group = [event for event in reviewed if event.review_result == review_code]
        if numeric_mode:
            numbers = [compact_event_number(event.event_id) for event in group]
            for payload in integer_range_tokens(
                [number for number in numbers if number is not None]
            ):
                fields.append(f"C{review_code}-{payload}")
        else:
            for event in group:
                fields.append(f"C{review_code}-{event.event_id}")
    return "_".join(fields)


def read_delimited_file(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    """Read a CSV/TSV-like file using the accepted v0.13 delimiter strategy."""

    encodings = ["utf-8-sig", "utf-8", "cp932", "shift_jis", "latin-1"]
    last_error: Exception | None = None
    for encoding in encodings:
        try:
            sample = path.read_text(encoding=encoding, errors="strict")[:8192]
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
            except csv.Error:
                dialect = csv.excel
            with path.open("r", encoding=encoding, newline="") as handle:
                reader = csv.DictReader(handle, dialect=dialect)
                fieldnames = [str(name) for name in (reader.fieldnames or [])]
                rows = [
                    {
                        str(key): "" if value is None else str(value)
                        for key, value in row.items()
                    }
                    for row in reader
                ]
            if not fieldnames:
                raise RuntimeError("The event file has no header row.")
            return fieldnames, rows
        except Exception as error:
            last_error = error
    raise RuntimeError(f"Event file could not be read: {last_error}")


def find_column(fieldnames: list[str], candidates: tuple[str, ...]) -> str | None:
    normalized = {normalized_name(name): name for name in fieldnames}
    for candidate in candidates:
        key = normalized_name(candidate)
        if key in normalized:
            return normalized[key]
    for candidate in candidates:
        key = normalized_name(candidate)
        for normalized_field, original in normalized.items():
            if key and key in normalized_field:
                return original
    return None


def parse_number(value: object) -> float | None:
    try:
        number = float(str(value).strip())
        return number if math.isfinite(number) else None
    except Exception:
        return None


def parse_review_events(
    fieldnames: list[str],
    rows: list[dict[str, str]],
) -> tuple[list[ReviewEvent], str, str | None, str]:
    start_column = find_column(fieldnames, EVENT_START_ALIASES)
    peak_column = find_column(fieldnames, EVENT_PEAK_ALIASES)
    end_column = find_column(fieldnames, EVENT_END_ALIASES)
    id_column = find_column(fieldnames, ("EventID", "WindowID", "QueueID", "ID"))
    result_column = find_column(fieldnames, ("ReviewResult", "VideoReviewResult"))
    memo_column = find_column(fieldnames, ("ReviewMemo", "Memo", "Comment"))
    if start_column is None or end_column is None:
        raise RuntimeError(
            "Start/end FrameCount columns were not found. Supported examples: "
            "ReviewStartFrame/ReviewEndFrame or StartFrame/EndFrame.\n\n"
            f"Headers: {', '.join(fieldnames)}"
        )

    events: list[ReviewEvent] = []
    for row_number, row in enumerate(rows, start=1):
        start_value = parse_number(row.get(start_column, ""))
        end_value = parse_number(row.get(end_column, ""))
        if start_value is None or end_value is None:
            continue
        start_framecount = int(round(start_value))
        end_framecount = int(round(end_value))
        if start_framecount > end_framecount:
            raise RuntimeError(
                f"Event row {row_number} has StartFrameCount greater than EndFrameCount."
            )

        peak_framecount: int | None = None
        if peak_column is not None:
            raw_peak = row.get(peak_column, "").strip()
            if raw_peak:
                peak_value = parse_number(raw_peak)
                if peak_value is None:
                    raise RuntimeError(
                        f"Event row {row_number} has a nonnumeric PeakFrameCount."
                    )
                peak_framecount = int(round(peak_value))
                if not start_framecount <= peak_framecount <= end_framecount:
                    raise RuntimeError(
                        f"Event row {row_number} PeakFrameCount is outside Start/End."
                    )

        event_id = row.get(id_column, "") if id_column else ""
        event_id = event_id.strip() or f"E{row_number:03d}"
        result = row.get(result_column, "").strip() if result_column else ""
        memo = row.get(memo_column, "").strip() if memo_column else ""
        events.append(
            ReviewEvent(
                event_id=event_id,
                start_framecount=start_framecount,
                end_framecount=end_framecount,
                peak_framecount=peak_framecount,
                original=row,
                review_result=result if result in REVIEW_CODES else "",
                memo=memo,
            )
        )
    if not events:
        raise RuntimeError("No valid event rows were found.")
    return events, start_column, peak_column, end_column


def video_index_to_framecount(
    video_index: int,
    anchor_video: int,
    anchor_framecount: int,
    framecount_rate: float,
    video_fps: float,
    mapping_mode: str,
) -> int:
    """Pure form of the accepted U003 mapping method."""

    if framecount_rate <= 0 or video_fps <= 0:
        raise ValueError("FrameCount rate and video FPS must be greater than zero.")
    delta = video_index - anchor_video
    if mapping_mode == "1:1":
        return anchor_framecount + delta
    if mapping_mode == "Rate-based":
        return anchor_framecount + int(round(delta * framecount_rate / video_fps))
    raise ValueError("Unknown mapping mode.")


def framecount_to_video_index(
    framecount: int,
    anchor_video: int,
    anchor_framecount: int,
    framecount_rate: float,
    video_fps: float,
    mapping_mode: str,
) -> int:
    """Inverse mapping used for Event navigation."""

    if framecount_rate <= 0 or video_fps <= 0:
        raise ValueError("FrameCount rate and video FPS must be greater than zero.")
    delta = framecount - anchor_framecount
    if mapping_mode == "1:1":
        return anchor_video + delta
    if mapping_mode == "Rate-based":
        return anchor_video + int(round(delta * video_fps / framecount_rate))
    raise ValueError("Unknown mapping mode.")
