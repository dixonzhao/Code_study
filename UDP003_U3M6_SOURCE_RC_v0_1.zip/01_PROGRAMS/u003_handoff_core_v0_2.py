#!/usr/bin/env python3
"""Hash-verified U002-to-U003 handoff validation for the high-code GUI shell."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

from u003_domain_core_v0_2 import (
    find_column,
    parse_number,
    parse_review_events,
    read_delimited_file,
)


HANDOFF_CORE_VERSION = "0.2"
HANDOFF_CONTRACT_ID = "U002_U003_LOCAL_HANDOFF_DESCRIPTOR"
HANDOFF_CONTRACT_VERSION = "0.1"


@dataclass(frozen=True)
class GovernedHandoffBatch:
    descriptor_path: Path
    run_id: str
    batch_id: str
    event_queue_path: Path
    review_data_path: Path
    candidate_count: int
    review_data_row_count: int
    frame_start: int
    frame_end: int


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _required_nonnegative_integer(value: object, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise RuntimeError(f"Handoff field {field_name} must be a nonnegative integer.")
    return value


def _descriptor_payload_path(descriptor_path: Path, value: object, field_name: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise RuntimeError(f"Handoff field {field_name} is missing.")
    supplied = Path(value.strip())
    path = supplied if supplied.is_absolute() else descriptor_path.parent / supplied
    path = path.resolve()
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"Handoff payload {field_name} is missing: {path}")
    return path


def load_governed_handoff(descriptor_path: Path) -> GovernedHandoffBatch:
    descriptor_path = descriptor_path.resolve()
    if not descriptor_path.is_file() or descriptor_path.is_symlink():
        raise RuntimeError(f"Handoff descriptor is missing: {descriptor_path}")
    try:
        descriptor = json.loads(descriptor_path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise RuntimeError(f"Handoff descriptor is not valid JSON: {error}") from error
    if not isinstance(descriptor, dict):
        raise RuntimeError("Handoff descriptor must be a JSON object.")
    if descriptor.get("ContractId") != HANDOFF_CONTRACT_ID:
        raise RuntimeError("Handoff ContractId is not accepted by U003.")
    if descriptor.get("ContractVersion") != HANDOFF_CONTRACT_VERSION:
        raise RuntimeError("Handoff ContractVersion is not accepted by U003.")
    if descriptor.get("LocalOnlyNotRunEvidence") is not True:
        raise RuntimeError("Handoff descriptor must remain local-only non-Run evidence.")

    candidate_count = _required_nonnegative_integer(
        descriptor.get("CandidateCount"), "CandidateCount"
    )
    batch_count = _required_nonnegative_integer(
        descriptor.get("ReviewBatchCount"), "ReviewBatchCount"
    )
    total_review_rows = _required_nonnegative_integer(
        descriptor.get("ReviewDataRowCount"), "ReviewDataRowCount"
    )
    batches = descriptor.get("Batches")
    if not isinstance(batches, list) or len(batches) != batch_count:
        raise RuntimeError("Handoff Batches do not match ReviewBatchCount.")
    if batch_count != 1:
        raise RuntimeError(
            "U003 v0.12 requires exactly one Review Batch; no batch may be omitted silently."
        )
    batch = batches[0]
    if not isinstance(batch, dict):
        raise RuntimeError("Handoff Batch must be a JSON object.")

    batch_candidate_count = _required_nonnegative_integer(
        batch.get("CandidateCount"), "Batches[0].CandidateCount"
    )
    batch_review_rows = _required_nonnegative_integer(
        batch.get("ReviewDataRowCount"), "Batches[0].ReviewDataRowCount"
    )
    frame_start = _required_nonnegative_integer(
        batch.get("FrameStart"), "Batches[0].FrameStart"
    )
    frame_end = _required_nonnegative_integer(
        batch.get("FrameEnd"), "Batches[0].FrameEnd"
    )
    if frame_end < frame_start:
        raise RuntimeError("Handoff FrameEnd is earlier than FrameStart.")
    if batch_candidate_count != candidate_count or batch_review_rows != total_review_rows:
        raise RuntimeError("Handoff top-level and Batch counts are inconsistent.")

    event_path = _descriptor_payload_path(
        descriptor_path, batch.get("EventQueuePath"), "EventQueuePath"
    )
    review_path = _descriptor_payload_path(
        descriptor_path, batch.get("ReviewDataPath"), "ReviewDataPath"
    )
    for path, hash_field in (
        (event_path, "EventQueueSha256"),
        (review_path, "ReviewDataSha256"),
    ):
        expected_hash = batch.get(hash_field)
        if not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected_hash):
            raise RuntimeError(f"Handoff field {hash_field} is not a SHA-256 value.")
        if sha256_file(path).lower() != expected_hash.lower():
            raise RuntimeError(f"Handoff payload hash mismatch: {path.name}")

    event_fields, event_rows = read_delimited_file(event_path)
    events, start_column, peak_column, end_column = parse_review_events(event_fields, event_rows)
    if peak_column is None or len(events) != candidate_count:
        raise RuntimeError("Event Queue does not preserve the declared Candidate inventory.")
    if len({event.event_id for event in events}) != len(events):
        raise RuntimeError("Event Queue contains duplicate EventID values.")
    for field_name, actual in {
        "U003StartColumn": start_column,
        "U003PeakColumn": peak_column,
        "U003EndColumn": end_column,
    }.items():
        if batch.get(field_name) != actual:
            raise RuntimeError(f"Handoff {field_name} does not match the Event Queue.")

    review_fields, review_rows = read_delimited_file(review_path)
    frame_column = find_column(
        review_fields,
        ("FrameCount", "CANFrameCount", "ID_620_FrameCount", "Frame"),
    )
    if frame_column is None or len(review_rows) != batch_review_rows:
        raise RuntimeError("Review Data does not preserve its declared rows or FrameCount.")
    frame_values: list[int] = []
    for row in review_rows:
        value = parse_number(row.get(frame_column, ""))
        if value is None:
            raise RuntimeError("Review Data contains a nonnumeric FrameCount.")
        frame_values.append(int(round(value)))
    if not frame_values or min(frame_values) != frame_start or max(frame_values) != frame_end:
        raise RuntimeError("Review Data FrameCount coverage differs from the descriptor.")
    for event in events:
        if not frame_start <= event.start_framecount <= event.end_framecount <= frame_end:
            raise RuntimeError(f"Review Data does not cover Event {event.event_id}.")
        if event.peak_framecount is None or not frame_start <= event.peak_framecount <= frame_end:
            raise RuntimeError(f"Review Data does not cover Event Peak {event.event_id}.")

    run_id = descriptor.get("RunId")
    batch_id = batch.get("ReviewBatchId")
    if not isinstance(run_id, str) or not run_id.strip():
        raise RuntimeError("Handoff RunId is missing.")
    if not isinstance(batch_id, str) or not batch_id.strip():
        raise RuntimeError("Handoff ReviewBatchId is missing.")
    return GovernedHandoffBatch(
        descriptor_path=descriptor_path,
        run_id=run_id,
        batch_id=batch_id,
        event_queue_path=event_path,
        review_data_path=review_path,
        candidate_count=candidate_count,
        review_data_row_count=batch_review_rows,
        frame_start=frame_start,
        frame_end=frame_end,
    )
