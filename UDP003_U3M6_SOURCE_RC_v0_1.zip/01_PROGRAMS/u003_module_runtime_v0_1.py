#!/usr/bin/env python3
"""Governed discovery and validation runtime for U003 modules.

U3M1 intentionally does not execute modules or modify the U003 GUI.  It makes
the module boundary concrete before runtime integration begins.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


RUNTIME_VERSION = "0.1"
CONTRACT_ID = "U003_MODULE_MANIFEST"
CONTRACT_VERSION = "0.1"
MODULE_SLOTS = (
    "IMPORT_ADAPTER",
    "EVIDENCE_VIEW",
    "REVIEW_ASSIST",
    "EXPORT",
)
EXECUTION_KINDS = ("DECLARATIVE", "PROCESS")
LIFECYCLE_HOOKS = (
    "ON_HANDOFF_LOADED",
    "ON_EVENT_SELECTED",
    "ON_REVIEW_SAVED",
    "ON_EXPORT",
)
PROCESS_TRANSPORTS = ("PYTHON_SOURCE", "NATIVE_EXECUTABLE")
PROTECTED_FIELDS = (
    "EventID",
    "CandidateId",
    "ReviewStartFrame",
    "PeakFrameCount",
    "ReviewEndFrame",
    "CandidateRank",
    "PriorityClass",
    "AnomalyScore",
    "ReviewData",
    "ReviewResult",
    "EngineerReviewMemo",
)
MODULE_ID_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9]*(\.[A-Za-z0-9_]+)+$")
SEMVER_PATTERN = re.compile(r"^([0-9]+)\.([0-9]+)\.([0-9]+)$")
ALGORITHM_CARD_PATTERN = re.compile(r"^[^/\\]+\.json$")


class ModuleContractError(RuntimeError):
    """Raised when a discovered module violates the governed contract."""


@dataclass(frozen=True)
class ModuleDescriptor:
    module_id: str
    module_version: str
    module_slot: str
    execution_kind: str
    display_name_en: str
    display_name_ja: str
    description_en: str
    description_ja: str
    lifecycle_hooks: tuple[str, ...]
    required_context_fields: tuple[str, ...]
    produced_fields: tuple[str, ...]
    enabled_by_default: bool
    manifest_path: str
    algorithm_card_path: str
    process_transport: str | None
    process_entry_path: str | None
    timeout_seconds: int | None
    package_sha256: str

    @property
    def semantic_version(self) -> tuple[int, int, int]:
        match = SEMVER_PATTERN.fullmatch(self.module_version)
        if match is None:
            raise ModuleContractError(f"Invalid semantic version: {self.module_version}")
        return tuple(int(value) for value in match.groups())

    def localized_name(self, language: str) -> str:
        """Return Japanese text when requested and available, otherwise English."""

        if language.upper() == "JA" and self.display_name_ja.strip():
            return self.display_name_ja
        return self.display_name_en

    def localized_description(self, language: str) -> str:
        """Use visible English fallback instead of returning an empty label."""

        if language.upper() == "JA" and self.description_ja.strip():
            return self.description_ja
        return self.description_en


@dataclass(frozen=True)
class ModuleCatalog:
    module_root: str
    descriptors: tuple[ModuleDescriptor, ...]
    selected_versions: dict[str, str]

    def to_json_payload(self) -> dict[str, Any]:
        return {
            "CatalogId": "U003_MODULE_CATALOG",
            "CatalogVersion": RUNTIME_VERSION,
            "ModuleRoot": self.module_root,
            "ModuleVersionCount": len(self.descriptors),
            "ModuleIdCount": len(self.selected_versions),
            "SelectedVersions": dict(sorted(self.selected_versions.items())),
            "Modules": [asdict(item) for item in self.descriptors],
        }


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise ModuleContractError(f"{label} is missing or is not a regular file: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise ModuleContractError(f"{label} is not valid JSON: {path}: {error}") from error
    if not isinstance(value, dict):
        raise ModuleContractError(f"{label} must contain one JSON object: {path}")
    return value


def _required_string(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ModuleContractError(f"Manifest field {key} must be a non-empty string.")
    return value.strip()


def _required_boolean(mapping: dict[str, Any], key: str) -> bool:
    value = mapping.get(key)
    if not isinstance(value, bool):
        raise ModuleContractError(f"Manifest field {key} must be boolean.")
    return value


def _unique_string_list(mapping: dict[str, Any], key: str) -> tuple[str, ...]:
    value = mapping.get(key)
    if not isinstance(value, list):
        raise ModuleContractError(f"Manifest field {key} must be an array.")
    normalized: list[str] = []
    for item in value:
        if not isinstance(item, str) or not item.strip():
            raise ModuleContractError(f"Manifest field {key} contains an invalid item.")
        normalized.append(item.strip())
    if len(set(normalized)) != len(normalized):
        raise ModuleContractError(f"Manifest field {key} contains duplicate items.")
    return tuple(normalized)


def _localized_text(mapping: dict[str, Any], key: str) -> tuple[str, str]:
    value = mapping.get(key)
    if not isinstance(value, dict):
        raise ModuleContractError(f"Manifest field {key} must be a localized object.")
    extra = set(value) - {"EN", "JA"}
    if extra:
        raise ModuleContractError(f"Manifest field {key} has unsupported keys: {sorted(extra)}")
    english = value.get("EN")
    japanese = value.get("JA", "")
    if not isinstance(english, str) or not english.strip():
        raise ModuleContractError(f"Manifest field {key}.EN must be non-empty.")
    if not isinstance(japanese, str):
        raise ModuleContractError(f"Manifest field {key}.JA must be a string.")
    return english.strip(), japanese.strip()


def _hash_files(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.name.lower()):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        digest.update(b"\0")
    return digest.hexdigest()


def validate_module_manifest(manifest_path: Path, module_root: Path) -> ModuleDescriptor:
    """Validate one module package without importing or executing its code."""

    manifest_path = manifest_path.resolve()
    module_root = module_root.resolve()
    try:
        manifest_path.relative_to(module_root)
    except ValueError as error:
        raise ModuleContractError("Module manifest escapes the governed module root.") from error

    manifest = _read_json_object(manifest_path, "Module manifest")
    if manifest.get("ContractId") != CONTRACT_ID:
        raise ModuleContractError("Module manifest ContractId is not accepted.")
    if manifest.get("ContractVersion") != CONTRACT_VERSION:
        raise ModuleContractError("Module manifest ContractVersion is not accepted.")

    module_id = _required_string(manifest, "ModuleId")
    module_version = _required_string(manifest, "ModuleVersion")
    module_slot = _required_string(manifest, "ModuleSlot")
    execution_kind = _required_string(manifest, "ExecutionKind")
    if MODULE_ID_PATTERN.fullmatch(module_id) is None:
        raise ModuleContractError(f"ModuleId is invalid: {module_id}")
    if SEMVER_PATTERN.fullmatch(module_version) is None:
        raise ModuleContractError(f"ModuleVersion is not MAJOR.MINOR.PATCH: {module_version}")
    if module_slot not in MODULE_SLOTS:
        raise ModuleContractError(f"ModuleSlot is not accepted: {module_slot}")
    if execution_kind not in EXECUTION_KINDS:
        raise ModuleContractError(f"ExecutionKind is not accepted: {execution_kind}")

    expected_directory = module_root / module_slot / module_id / module_version
    if manifest_path.parent != expected_directory.resolve():
        raise ModuleContractError(
            "Module directory must be <root>/<slot>/<ModuleId>/<ModuleVersion>."
        )

    name_en, name_ja = _localized_text(manifest, "DisplayName")
    description_en, description_ja = _localized_text(manifest, "Description")
    hooks = _unique_string_list(manifest, "LifecycleHooks")
    invalid_hooks = sorted(set(hooks) - set(LIFECYCLE_HOOKS))
    if invalid_hooks:
        raise ModuleContractError(f"Unsupported LifecycleHooks: {invalid_hooks}")
    required_fields = _unique_string_list(manifest, "RequiredContextFields")
    produced_fields = _unique_string_list(manifest, "ProducedFields")
    protected_mutation = _unique_string_list(manifest, "ProtectedFieldMutation")
    if protected_mutation:
        raise ModuleContractError(
            "ProtectedFieldMutation must remain empty; modules enrich but do not rewrite core evidence."
        )
    protected_outputs = sorted(set(produced_fields) & set(PROTECTED_FIELDS))
    if protected_outputs:
        raise ModuleContractError(f"ProducedFields contains protected fields: {protected_outputs}")

    algorithm_card_name = _required_string(manifest, "AlgorithmCard")
    if ALGORITHM_CARD_PATTERN.fullmatch(algorithm_card_name) is None:
        raise ModuleContractError("AlgorithmCard must be a local JSON filename.")
    algorithm_card_path = manifest_path.parent / algorithm_card_name
    algorithm_card = _read_json_object(algorithm_card_path, "Algorithm Card")
    for required_card_field in (
        "AlgorithmCardId",
        "Purpose",
        "RealityMeaning",
        "Inputs",
        "Outputs",
        "Assumptions",
        "Limitations",
        "Validation",
    ):
        if required_card_field not in algorithm_card:
            raise ModuleContractError(
                f"Algorithm Card field {required_card_field} is missing: {algorithm_card_path}"
            )

    process_transport: str | None = None
    process_entry_path: str | None = None
    timeout_seconds: int | None = None
    package_files = [manifest_path, algorithm_card_path]
    process = manifest.get("Process")
    if execution_kind == "PROCESS":
        if not isinstance(process, dict):
            raise ModuleContractError("PROCESS module requires a Process object.")
        process_transport = _required_string(process, "Transport")
        if process_transport not in PROCESS_TRANSPORTS:
            raise ModuleContractError(f"Process Transport is not accepted: {process_transport}")
        entry_name = _required_string(process, "EntryPoint")
        entry_path = (manifest_path.parent / entry_name).resolve()
        if entry_path.parent != manifest_path.parent or not entry_path.is_file():
            raise ModuleContractError("Process EntryPoint must be a local regular file.")
        timeout_value = process.get("TimeoutSeconds")
        if isinstance(timeout_value, bool) or not isinstance(timeout_value, int):
            raise ModuleContractError("Process TimeoutSeconds must be an integer.")
        if not 1 <= timeout_value <= 300:
            raise ModuleContractError("Process TimeoutSeconds must be between 1 and 300.")
        process_entry_path = str(entry_path)
        timeout_seconds = timeout_value
        package_files.append(entry_path)
    elif process is not None:
        raise ModuleContractError("DECLARATIVE module must not declare Process.")

    return ModuleDescriptor(
        module_id=module_id,
        module_version=module_version,
        module_slot=module_slot,
        execution_kind=execution_kind,
        display_name_en=name_en,
        display_name_ja=name_ja,
        description_en=description_en,
        description_ja=description_ja,
        lifecycle_hooks=hooks,
        required_context_fields=required_fields,
        produced_fields=produced_fields,
        enabled_by_default=_required_boolean(manifest, "EnabledByDefault"),
        manifest_path=str(manifest_path),
        algorithm_card_path=str(algorithm_card_path.resolve()),
        process_transport=process_transport,
        process_entry_path=process_entry_path,
        timeout_seconds=timeout_seconds,
        package_sha256=_hash_files(package_files),
    )


def discover_modules(module_root: Path) -> ModuleCatalog:
    """Discover every version, validate all packages, and select the newest version."""

    module_root = module_root.resolve()
    if not module_root.is_dir() or module_root.is_symlink():
        raise ModuleContractError(f"Module root is missing or invalid: {module_root}")
    manifest_paths = sorted(module_root.glob("*/*/*/module_manifest.json"))
    if not manifest_paths:
        raise ModuleContractError(f"No module manifests were found under: {module_root}")

    descriptors = tuple(
        validate_module_manifest(path, module_root)
        for path in manifest_paths
    )
    identities = [(item.module_id, item.module_version) for item in descriptors]
    if len(set(identities)) != len(identities):
        raise ModuleContractError("Duplicate ModuleId and ModuleVersion identity detected.")

    selected: dict[str, ModuleDescriptor] = {}
    for descriptor in descriptors:
        current = selected.get(descriptor.module_id)
        if current is None or descriptor.semantic_version > current.semantic_version:
            selected[descriptor.module_id] = descriptor
    selected_versions = {
        module_id: descriptor.module_version
        for module_id, descriptor in selected.items()
    }
    return ModuleCatalog(
        module_root=str(module_root),
        descriptors=tuple(
            sorted(
                descriptors,
                key=lambda item: (item.module_slot, item.module_id, item.semantic_version),
            )
        ),
        selected_versions=selected_versions,
    )


def write_catalog(catalog: ModuleCatalog, output_path: Path) -> None:
    output_path = output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    writing_path = output_path.with_name(output_path.name + ".writing")
    writing_path.write_text(
        json.dumps(catalog.to_json_payload(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    writing_path.replace(output_path)


def _write_fixture_module(
    module_root: Path,
    version: str,
    japanese_description: str,
) -> Path:
    module_directory = (
        module_root
        / "REVIEW_ASSIST"
        / "CameraRadar.U003.SelfTestLabels"
        / version
    )
    module_directory.mkdir(parents=True)
    manifest = {
        "ContractId": CONTRACT_ID,
        "ContractVersion": CONTRACT_VERSION,
        "ModuleId": "CameraRadar.U003.SelfTestLabels",
        "ModuleVersion": version,
        "ModuleSlot": "REVIEW_ASSIST",
        "ExecutionKind": "DECLARATIVE",
        "DisplayName": {"EN": "Self-test labels", "JA": ""},
        "Description": {"EN": "Self-test description", "JA": japanese_description},
        "LifecycleHooks": ["ON_EVENT_SELECTED"],
        "RequiredContextFields": ["ReviewCode"],
        "ProducedFields": ["ReviewCodeLabelEN"],
        "ProtectedFieldMutation": [],
        "AlgorithmCard": "algorithm_card.json",
        "EnabledByDefault": True,
    }
    card = {
        "AlgorithmCardId": f"CameraRadar.U003.SelfTestLabels.{version}",
        "Purpose": "Validate module discovery.",
        "RealityMeaning": "Confirms the governed module boundary.",
        "Inputs": {"ReviewCode": "Synthetic code."},
        "Outputs": {"ReviewCodeLabelEN": "Synthetic label."},
        "Assumptions": [],
        "Limitations": [],
        "Validation": ["Discovered without importing code."],
    }
    manifest_path = module_directory / "module_manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    (module_directory / "algorithm_card.json").write_text(
        json.dumps(card), encoding="utf-8"
    )
    return manifest_path


def run_self_test() -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    with tempfile.TemporaryDirectory(prefix="u003_u3m1_") as temporary:
        root = Path(temporary)
        module_root = root / "02_MODULES"
        first_path = _write_fixture_module(module_root, "0.1.0", "")
        second_path = _write_fixture_module(module_root, "0.2.0", "日本語説明")

        first = validate_module_manifest(first_path, module_root)
        check(first.module_slot == "REVIEW_ASSIST", "slot preserved", "prevents cross-slot loading")
        check(first.execution_kind == "DECLARATIVE", "declarative kind", "does not execute code")
        check(first.localized_name("JA") == "Self-test labels", "name fallback", "blank JA uses EN")
        check(first.localized_description("JA") == "Self-test description", "description fallback", "blank JA uses EN")
        check(len(first.package_sha256) == 64, "package hash", "binds manifest and Algorithm Card")
        check(not first.process_entry_path, "no process entry", "declarative modules have no executable")

        second = validate_module_manifest(second_path, module_root)
        check(second.localized_description("JA") == "日本語説明", "Japanese selection", "uses JA when available")
        check(second.semantic_version == (0, 2, 0), "semantic version", "supports deterministic version ordering")

        catalog = discover_modules(module_root)
        check(len(catalog.descriptors) == 2, "all versions retained", "older versions remain selectable")
        check(len(catalog.selected_versions) == 1, "one module family", "groups versions by ModuleId")
        check(catalog.selected_versions[first.module_id] == "0.2.0", "latest selected", "newest semantic version is default")
        check(catalog.descriptors[0].module_id == first.module_id, "stable ordering", "catalog output is deterministic")

        catalog_path = root / "catalog.json"
        write_catalog(catalog, catalog_path)
        catalog_payload = _read_json_object(catalog_path, "Catalog")
        check(catalog_payload["ModuleVersionCount"] == 2, "catalog count", "records every discovered version")
        check(catalog_payload["ModuleIdCount"] == 1, "catalog family count", "records grouped module identities")
        check(catalog_payload["SelectedVersions"][first.module_id] == "0.2.0", "catalog selection", "persists default version")

        invalid_manifest = json.loads(first_path.read_text(encoding="utf-8"))
        invalid_manifest["ProducedFields"] = ["PeakFrameCount"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("protected fields" in str(error), "protected output rejected", "modules cannot rewrite evidence identity")
        else:
            raise AssertionError("protected output was accepted")

        invalid_manifest["ProducedFields"] = ["ReviewCodeLabelEN"]
        invalid_manifest["ProtectedFieldMutation"] = ["ReviewResult"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("must remain empty" in str(error), "mutation rejected", "engineer decision remains core-owned")
        else:
            raise AssertionError("protected mutation was accepted")

        invalid_manifest["ProtectedFieldMutation"] = []
        invalid_manifest["LifecycleHooks"] = ["UNKNOWN_HOOK"]
        first_path.write_text(json.dumps(invalid_manifest), encoding="utf-8")
        try:
            validate_module_manifest(first_path, module_root)
        except ModuleContractError as error:
            check("Unsupported LifecycleHooks" in str(error), "unknown hook rejected", "lifecycle remains fixed")
        else:
            raise AssertionError("unknown hook was accepted")

        check(CONTRACT_ID == "U003_MODULE_MANIFEST", "contract identity", "prevents unrelated manifests")
        check(CONTRACT_VERSION == "0.1", "contract version", "supports explicit future migration")
        check(len(MODULE_SLOTS) == 4, "four slots", "keeps U003 extension responsibilities bounded")
        check("ReviewResult" in PROTECTED_FIELDS, "review protected", "module suggestions cannot become final decisions")
        check("PeakFrameCount" in PROTECTED_FIELDS, "peak protected", "U002 candidate evidence is immutable")
        check("ON_EXPORT" in LIFECYCLE_HOOKS, "export hook governed", "optional reports have a fixed entry point")
        check(len(PROCESS_TRANSPORTS) == 2, "two transports", "supports development source and portable executable")

    if checks != 25:
        raise AssertionError(f"self-test count {checks} != 25")
    print("U003-U3M1-SELFTEST-PASS-25 C-0")
    return 0


def print_catalog_summary(catalog: ModuleCatalog) -> None:
    process_count = sum(
        descriptor.execution_kind == "PROCESS"
        for descriptor in catalog.descriptors
    )
    enabled_count = sum(
        descriptor.enabled_by_default
        for descriptor in catalog.descriptors
    )
    japanese_count = sum(
        bool(descriptor.description_ja.strip())
        for descriptor in catalog.descriptors
    )
    print("Validated module catalog:")
    for descriptor in catalog.descriptors:
        print(
            f"  [{descriptor.module_slot}] {descriptor.module_id} "
            f"v{descriptor.module_version} | {descriptor.execution_kind} | "
            f"SHA256 {descriptor.package_sha256[:12]}"
        )
    print(
        f"U3M1R N-M{len(catalog.descriptors)}-G{len(catalog.selected_versions)}-"
        f"D{enabled_count}-P{process_count}-J{japanese_count}-X0 C-0"
    )


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--scan-root", type=Path)
    parser.add_argument("--catalog-output", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if arguments.self_test:
            return run_self_test()
        if arguments.scan_root is None:
            raise ModuleContractError("Use --self-test or provide --scan-root.")
        catalog = discover_modules(arguments.scan_root)
        if arguments.catalog_output is not None:
            write_catalog(catalog, arguments.catalog_output)
        print_catalog_summary(catalog)
        return 0
    except Exception as error:
        print(f"U3M1E K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
