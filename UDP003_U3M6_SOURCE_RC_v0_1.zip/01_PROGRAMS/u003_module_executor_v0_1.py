#!/usr/bin/env python3
"""Isolated PROCESS-module execution bridge for U003.

The bridge writes immutable JSON requests, invokes one validated module in a
child process, validates the result, and records a ModuleTrace.  It never
imports module implementation code into the GUI process and never mutates the
U002 handoff or engineer review state.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EXECUTOR_VERSION = "0.1"
REQUEST_CONTRACT_ID = "U003_MODULE_REQUEST"
REQUEST_CONTRACT_VERSION = "0.1"
RESULT_CONTRACT_ID = "U003_MODULE_RESULT"
RESULT_CONTRACT_VERSION = "0.1"
TRACE_CONTRACT_ID = "U003_MODULE_TRACE"
TRACE_CONTRACT_VERSION = "0.1"
RESULT_STATUSES = ("SUCCESS", "NO_RESULT")
LANGUAGES = ("EN", "JA")


class ModuleExecutionError(RuntimeError):
    """Raised when a module request, child process, or result is invalid."""


@dataclass(frozen=True)
class ExecutionOutcome:
    result: dict[str, Any]
    trace: dict[str, Any]
    run_directory: Path


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    if writing.exists():
        writing.unlink()
    writing.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def read_json_object(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise ModuleExecutionError(f"{label} is missing or invalid: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise ModuleExecutionError(f"{label} is not valid JSON: {error}") from error
    if not isinstance(payload, dict):
        raise ModuleExecutionError(f"{label} must contain one JSON object.")
    return payload


def load_module_foundation(program_directory: Path):
    """Load only the governed U3M1 foundation, never a plugin implementation."""

    foundation_path = program_directory / "u003_module_runtime_v0_1.py"
    if not foundation_path.is_file():
        raise ModuleExecutionError(f"U3M1 foundation is missing: {foundation_path}")
    specification = importlib.util.spec_from_file_location(
        "u003_module_runtime_v0_1",
        foundation_path,
    )
    if specification is None or specification.loader is None:
        raise ModuleExecutionError("U3M1 foundation could not be loaded.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def require_string(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ModuleExecutionError(f"{key} must be a non-empty string.")
    return value.strip()


def validate_request(
    request: dict[str, Any],
    descriptor: Any,
) -> None:
    if request.get("ContractId") != REQUEST_CONTRACT_ID:
        raise ModuleExecutionError("Request ContractId is not accepted.")
    if request.get("ContractVersion") != REQUEST_CONTRACT_VERSION:
        raise ModuleExecutionError("Request ContractVersion is not accepted.")
    for key in ("RequestId", "RunId", "EventId", "Hook", "Language"):
        require_string(request, key)
    if request.get("ModuleId") != descriptor.module_id:
        raise ModuleExecutionError("Request ModuleId differs from selected module.")
    if request.get("ModuleVersion") != descriptor.module_version:
        raise ModuleExecutionError("Request ModuleVersion differs from selected module.")
    if request["Hook"] not in descriptor.lifecycle_hooks:
        raise ModuleExecutionError(
            f"Module does not support lifecycle hook: {request['Hook']}"
        )
    if request["Language"] not in LANGUAGES:
        raise ModuleExecutionError("Language must be EN or JA.")
    context = request.get("Context")
    if not isinstance(context, dict):
        raise ModuleExecutionError("Request Context must be one JSON object.")
    missing = [
        field_name
        for field_name in descriptor.required_context_fields
        if field_name not in context or context[field_name] is None
    ]
    if missing:
        raise ModuleExecutionError(f"Required Context fields are missing: {missing}")


def validate_result(
    result: dict[str, Any],
    request: dict[str, Any],
    descriptor: Any,
    protected_fields: tuple[str, ...],
) -> None:
    if result.get("ContractId") != RESULT_CONTRACT_ID:
        raise ModuleExecutionError("Result ContractId is not accepted.")
    if result.get("ContractVersion") != RESULT_CONTRACT_VERSION:
        raise ModuleExecutionError("Result ContractVersion is not accepted.")
    for identity in ("RequestId", "RunId", "EventId", "Hook", "ModuleId", "ModuleVersion"):
        if result.get(identity) != request.get(identity):
            raise ModuleExecutionError(f"Result identity mismatch: {identity}")
    if result.get("Status") not in RESULT_STATUSES:
        raise ModuleExecutionError("Result Status is not accepted.")
    if result.get("RootCauseClaim") is not False:
        raise ModuleExecutionError("Result RootCauseClaim must remain false.")
    outputs = result.get("Outputs")
    if not isinstance(outputs, dict):
        raise ModuleExecutionError("Result Outputs must be one JSON object.")
    unapproved_outputs = sorted(set(outputs) - set(descriptor.produced_fields))
    if unapproved_outputs:
        raise ModuleExecutionError(f"Result contains unapproved outputs: {unapproved_outputs}")
    protected_outputs = sorted(set(outputs) & set(protected_fields))
    if protected_outputs:
        raise ModuleExecutionError(f"Result contains protected outputs: {protected_outputs}")
    warnings = result.get("Warnings")
    if not isinstance(warnings, list) or any(not isinstance(item, str) for item in warnings):
        raise ModuleExecutionError("Result Warnings must be an array of strings.")
    if result["Status"] == "NO_RESULT" and outputs:
        raise ModuleExecutionError("NO_RESULT must not contain Outputs.")


def build_request(
    descriptor: Any,
    run_id: str,
    event_id: str,
    hook: str,
    language: str,
    context: dict[str, Any],
) -> dict[str, Any]:
    request = {
        "ContractId": REQUEST_CONTRACT_ID,
        "ContractVersion": REQUEST_CONTRACT_VERSION,
        "RequestId": uuid.uuid4().hex,
        "RunId": run_id,
        "EventId": event_id,
        "Hook": hook,
        "Language": language.upper(),
        "ModuleId": descriptor.module_id,
        "ModuleVersion": descriptor.module_version,
        "Context": context,
    }
    return request


def find_descriptor(
    foundation: Any,
    module_root: Path,
    module_id: str,
    module_version: str | None,
) -> Any:
    catalog = foundation.discover_modules(module_root)
    selected_version = module_version or catalog.selected_versions.get(module_id)
    matches = [
        descriptor
        for descriptor in catalog.descriptors
        if descriptor.module_id == module_id
        and descriptor.module_version == selected_version
    ]
    if len(matches) != 1:
        raise ModuleExecutionError(
            f"Selected module identity is not unique: {module_id} {selected_version}"
        )
    descriptor = matches[0]
    if descriptor.execution_kind != "PROCESS":
        raise ModuleExecutionError("Execution bridge accepts PROCESS modules only.")
    return descriptor


def child_command(descriptor: Any, request_path: Path, result_path: Path) -> list[str]:
    entry_path = Path(descriptor.process_entry_path)
    if descriptor.process_transport == "PYTHON_SOURCE":
        prefix = [sys.executable, str(entry_path)]
    elif descriptor.process_transport == "NATIVE_EXECUTABLE":
        prefix = [str(entry_path)]
    else:
        raise ModuleExecutionError(
            f"Unsupported process transport: {descriptor.process_transport}"
        )
    return prefix + [
        "--execute",
        "--request",
        str(request_path),
        "--result",
        str(result_path),
    ]


def write_trace(
    trace_path: Path,
    trace: dict[str, Any],
) -> None:
    write_json_atomic(trace_path, trace)


def execute_process_module(
    descriptor: Any,
    request: dict[str, Any],
    run_root: Path,
    protected_fields: tuple[str, ...],
) -> ExecutionOutcome:
    """Execute one validated module and preserve complete child evidence."""

    validate_request(request, descriptor)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    safe_module_id = descriptor.module_id.replace(".", "_")
    run_directory = (
        run_root.resolve()
        / require_string(request, "RunId")
        / require_string(request, "EventId")
        / safe_module_id
        / descriptor.module_version
        / stamp
    )
    run_directory.mkdir(parents=True, exist_ok=False)
    request_path = run_directory / "module_request.json"
    result_path = run_directory / "module_result.json"
    stdout_path = run_directory / "stdout.txt"
    stderr_path = run_directory / "stderr.txt"
    trace_path = run_directory / "module_trace.json"
    write_json_atomic(request_path, request)

    started_utc = utc_now()
    started_clock = time.monotonic()
    command = child_command(descriptor, request_path, result_path)
    exit_code: int | None = None
    trace_status = "FAILED"
    result_hash = ""
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=descriptor.timeout_seconds,
            check=False,
        )
        exit_code = completed.returncode
        stdout_path.write_text(completed.stdout, encoding="utf-8")
        stderr_path.write_text(completed.stderr, encoding="utf-8")
        if exit_code != 0:
            raise ModuleExecutionError(
                f"Module child exited with code {exit_code}; see {stderr_path}"
            )
        result = read_json_object(result_path, "Module result")
        validate_result(result, request, descriptor, protected_fields)
        result_hash = sha256_file(result_path)
        trace_status = "SUCCESS"
        return_result = result
    except subprocess.TimeoutExpired as error:
        stdout_path.write_text(error.stdout or "", encoding="utf-8")
        stderr_path.write_text(error.stderr or "", encoding="utf-8")
        raise ModuleExecutionError(
            f"Module exceeded timeout {descriptor.timeout_seconds} seconds."
        ) from error
    finally:
        finished_utc = utc_now()
        duration_ms = int(round((time.monotonic() - started_clock) * 1000))
        trace = {
            "ContractId": TRACE_CONTRACT_ID,
            "ContractVersion": TRACE_CONTRACT_VERSION,
            "TraceId": uuid.uuid4().hex,
            "RequestId": request.get("RequestId"),
            "RunId": request.get("RunId"),
            "EventId": request.get("EventId"),
            "ModuleId": descriptor.module_id,
            "ModuleVersion": descriptor.module_version,
            "Hook": request.get("Hook"),
            "StartedUtc": started_utc,
            "FinishedUtc": finished_utc,
            "DurationMilliseconds": duration_ms,
            "Status": trace_status,
            "RequestSha256": sha256_file(request_path),
            "ResultSha256": result_hash,
            "ExitCode": exit_code,
            "StdoutPath": str(stdout_path),
            "StderrPath": str(stderr_path),
        }
        write_trace(trace_path, trace)

    return ExecutionOutcome(
        result=return_result,
        trace=trace,
        run_directory=run_directory,
    )


def execute_selected_module(
    module_root: Path,
    run_root: Path,
    module_id: str,
    module_version: str | None,
    run_id: str,
    event_id: str,
    hook: str,
    language: str,
    context: dict[str, Any],
) -> ExecutionOutcome:
    program_directory = Path(__file__).resolve().parent
    foundation = load_module_foundation(program_directory)
    descriptor = find_descriptor(
        foundation,
        module_root,
        module_id,
        module_version,
    )
    request = build_request(
        descriptor,
        run_id,
        event_id,
        hook,
        language,
        context,
    )
    return execute_process_module(
        descriptor,
        request,
        run_root,
        tuple(foundation.PROTECTED_FIELDS),
    )


def run_self_test() -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    program_directory = Path(__file__).resolve().parent
    root = program_directory.parent
    module_root = root / "02_MODULES"
    foundation = load_module_foundation(program_directory)
    descriptor = find_descriptor(
        foundation,
        module_root,
        "CameraRadar.U003.SampleMemoDraft",
        "0.1.0",
    )
    check(descriptor.execution_kind == "PROCESS", "process module selected", "exercises child isolation")
    check(descriptor.process_transport == "PYTHON_SOURCE", "development transport", "runs on the company Python host")
    check(descriptor.timeout_seconds == 10, "bounded timeout", "prevents a plugin from freezing U003")
    check("SuggestedReviewMemo" in descriptor.produced_fields, "approved output", "module output is explicit")
    check("ReviewResult" not in descriptor.produced_fields, "decision protected", "engineer keeps final authority")

    with tempfile.TemporaryDirectory(prefix="u003_u3m2_") as temporary:
        run_root = Path(temporary) / "runs"
        outcome = execute_selected_module(
            module_root=module_root,
            run_root=run_root,
            module_id=descriptor.module_id,
            module_version=descriptor.module_version,
            run_id="SELFTEST_RUN",
            event_id="C0001",
            hook="ON_EVENT_SELECTED",
            language="EN",
            context={
                "CandidateReasonCode": "RADAR_LOSS",
                "PeakFrameCount": 41662,
            },
        )
        memo = outcome.result["Outputs"]["SuggestedReviewMemo"]
        check(outcome.result["Status"] == "SUCCESS", "result success", "child completed its contract")
        check("C0001" in memo, "event identity visible", "draft remains traceable to the reviewed event")
        check("41662" in memo, "peak visible", "reviewer is told where to inspect")
        check(outcome.result["RootCauseClaim"] is False, "no root-cause claim", "review assistance is not diagnosis")
        check(outcome.trace["Status"] == "SUCCESS", "trace success", "execution outcome is persistent")
        check(outcome.trace["ExitCode"] == 0, "exit code captured", "child process evidence is retained")
        check(len(outcome.trace["RequestSha256"]) == 64, "request hash", "module input is traceable")
        check(len(outcome.trace["ResultSha256"]) == 64, "result hash", "module output is traceable")
        check((outcome.run_directory / "stdout.txt").is_file(), "stdout retained", "supports diagnosis")
        check((outcome.run_directory / "stderr.txt").is_file(), "stderr retained", "supports diagnosis")
        check((outcome.run_directory / "module_trace.json").is_file(), "trace retained", "supports handoff and audit")

        ja_outcome = execute_selected_module(
            module_root=module_root,
            run_root=run_root,
            module_id=descriptor.module_id,
            module_version=None,
            run_id="SELFTEST_RUN",
            event_id="C0002",
            hook="ON_EVENT_SELECTED",
            language="JA",
            context={
                "CandidateReasonCode": "RADAR_LOSS",
                "PeakFrameCount": 41520,
            },
        )
        ja_memo = ja_outcome.result["Outputs"]["SuggestedReviewMemo"]
        check("確認してください" in ja_memo, "Japanese output", "requested language reaches the module")
        check(ja_outcome.trace["Status"] == "SUCCESS", "second trace", "each execution has independent evidence")

        incomplete_request = build_request(
            descriptor,
            "SELFTEST_RUN",
            "C0003",
            "ON_EVENT_SELECTED",
            "EN",
            {"PeakFrameCount": 10},
        )
        try:
            validate_request(incomplete_request, descriptor)
        except ModuleExecutionError as error:
            check("Required Context fields" in str(error), "missing context rejected", "module cannot guess required evidence")
        else:
            raise AssertionError("missing context was accepted")

        valid_request = build_request(
            descriptor,
            "SELFTEST_RUN",
            "C0004",
            "ON_EVENT_SELECTED",
            "EN",
            {"CandidateReasonCode": "TEST", "PeakFrameCount": 10},
        )
        base_result = {
            "ContractId": RESULT_CONTRACT_ID,
            "ContractVersion": RESULT_CONTRACT_VERSION,
            "RequestId": valid_request["RequestId"],
            "RunId": valid_request["RunId"],
            "EventId": valid_request["EventId"],
            "Hook": valid_request["Hook"],
            "ModuleId": valid_request["ModuleId"],
            "ModuleVersion": valid_request["ModuleVersion"],
            "Status": "SUCCESS",
            "Outputs": {"SuggestedReviewMemo": "draft"},
            "Warnings": [],
            "RootCauseClaim": False,
        }
        validate_result(base_result, valid_request, descriptor, tuple(foundation.PROTECTED_FIELDS))
        check(True, "valid synthetic result", "validator accepts only the declared output")

        protected_result = json.loads(json.dumps(base_result))
        protected_result["Outputs"] = {"ReviewResult": "1"}
        try:
            validate_result(protected_result, valid_request, descriptor, tuple(foundation.PROTECTED_FIELDS))
        except ModuleExecutionError as error:
            check("unapproved outputs" in str(error) or "protected outputs" in str(error), "protected result rejected", "module cannot decide review code")
        else:
            raise AssertionError("protected result was accepted")

        claim_result = json.loads(json.dumps(base_result))
        claim_result["RootCauseClaim"] = True
        try:
            validate_result(claim_result, valid_request, descriptor, tuple(foundation.PROTECTED_FIELDS))
        except ModuleExecutionError as error:
            check("RootCauseClaim" in str(error), "root-cause claim rejected", "human review remains epistemically explicit")
        else:
            raise AssertionError("root-cause claim was accepted")

        mismatch_result = json.loads(json.dumps(base_result))
        mismatch_result["EventId"] = "C9999"
        try:
            validate_result(mismatch_result, valid_request, descriptor, tuple(foundation.PROTECTED_FIELDS))
        except ModuleExecutionError as error:
            check("identity mismatch" in str(error), "identity mismatch rejected", "results cannot move between events")
        else:
            raise AssertionError("identity mismatch was accepted")

        no_result = json.loads(json.dumps(base_result))
        no_result["Status"] = "NO_RESULT"
        no_result["Outputs"] = {}
        validate_result(no_result, valid_request, descriptor, tuple(foundation.PROTECTED_FIELDS))
        check(True, "no-result accepted", "optional module may produce no suggestion")

    if checks != 24:
        raise AssertionError(f"self-test count {checks} != 24")
    print("U003-U3M2-SELFTEST-PASS-24 C-0")
    return 0


def run_demo(module_root: Path, run_root: Path) -> int:
    outcomes = []
    for event_id, peak, language in (
        ("C0001", 41662, "EN"),
        ("C0002", 41520, "JA"),
    ):
        outcomes.append(
            execute_selected_module(
                module_root=module_root,
                run_root=run_root,
                module_id="CameraRadar.U003.SampleMemoDraft",
                module_version=None,
                run_id="U3M2_DEMO",
                event_id=event_id,
                hook="ON_EVENT_SELECTED",
                language=language,
                context={
                    "CandidateReasonCode": "RADAR_LOSS",
                    "PeakFrameCount": peak,
                },
            )
        )
    for outcome in outcomes:
        print(outcome.result["Outputs"]["SuggestedReviewMemo"])
        print(f"  Trace: {outcome.run_directory / 'module_trace.json'}")
    japanese_count = sum("確認してください" in item.result["Outputs"]["SuggestedReviewMemo"] for item in outcomes)
    print(
        f"U3M2R N-M1-E{len(outcomes)}-T{len(outcomes)}-O{len(outcomes)}-"
        f"J{japanese_count}-X0 C-0"
    )
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--module-root", type=Path)
    parser.add_argument("--run-root", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if arguments.self_test:
            return run_self_test()
        if arguments.demo:
            if arguments.module_root is None or arguments.run_root is None:
                raise ModuleExecutionError("--demo requires --module-root and --run-root.")
            return run_demo(arguments.module_root, arguments.run_root)
        raise ModuleExecutionError("Use --self-test or --demo.")
    except Exception as error:
        print(f"U3M2E K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
