#!/usr/bin/env python3
"""Fail-close acceptance for the complete U003 U3M6 source release candidate."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import importlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


GATE_VERSION = "0.1"
PROGRAM_ROOT = Path(__file__).resolve().parent
U003_ROOT = PROGRAM_ROOT.parent
MODULE_ROOT = U003_ROOT / "02_MODULES"
CONTRACT_ROOT = U003_ROOT / "02_CONTROLS" / "contracts"
RELEASE_CONTRACT = CONTRACT_ROOT / "u003_source_release_candidate_contract_v0_1.json"

ACTIVE_PROGRAMS = {
    "u003_domain_core_v0_2.py",
    "u003_evidence_review_workbench_v0_17.py",
    "u003_gui_shell_v0_4.py",
    "u003_handoff_core_v0_2.py",
    "u003_localization_v0_2.py",
    "u003_module_execution_coordinator_v0_1.py",
    "u003_module_executor_v0_1.py",
    "u003_module_manager_gui_v0_3.py",
    "u003_module_plan_core_v0_1.py",
    "u003_module_runtime_v0_1.py",
    "u003_u3m6_source_release_acceptance_gate_v0_1.py",
}
ACTIVE_CONTRACTS = {
    "u003_high_code_composition_contract_v0_1.json",
    "u003_module_assistance_runtime_contract_v0_1.json",
    "u003_module_contract_v0_1.json",
    "u003_module_execution_contract_bundle_v0_1.json",
    "u003_module_plan_contract_v0_1.json",
    "u003_session_localization_contract_v0_1.json",
    "u003_source_release_candidate_contract_v0_1.json",
}
EXPECTED_MODULES = {
    ("CameraRadar.U003.ReviewDispositionLabels", "0.1.0"),
    ("CameraRadar.U003.SampleMemoDraft", "0.1.0"),
}


class AcceptanceError(RuntimeError):
    """Raised when the release candidate violates an owned invariant."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_child(program: str, *arguments: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-B", str(PROGRAM_ROOT / program), *arguments],
        cwd=U003_ROOT.parent,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )


def write_handoff_fixture(root: Path, handoff: Any) -> Path:
    event_path = root / "event_queue.csv"
    review_path = root / "review_data.csv"
    with event_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=(
                "EventID",
                "ReviewStartFrame",
                "PeakFrameCount",
                "ReviewEndFrame",
                "ReviewResult",
                "ReviewMemo",
                "CandidateReasonCode",
                "CandidateScore",
            ),
        )
        writer.writeheader()
        writer.writerow(
            {
                "EventID": "C0001",
                "ReviewStartFrame": 100,
                "PeakFrameCount": 103,
                "ReviewEndFrame": 106,
                "ReviewResult": "",
                "ReviewMemo": "U002 source memo",
                "CandidateReasonCode": "RADAR_LOSS",
                "CandidateScore": "2.48487",
            }
        )
    with review_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=("FrameCount", "RadarDistance", "SelectedCameraDistance"),
        )
        writer.writeheader()
        for framecount in range(100, 107):
            writer.writerow(
                {
                    "FrameCount": framecount,
                    "RadarDistance": "0" if framecount >= 103 else "16.5",
                    "SelectedCameraDistance": "16.5",
                }
            )
    descriptor = {
        "ContractId": handoff.HANDOFF_CONTRACT_ID,
        "ContractVersion": handoff.HANDOFF_CONTRACT_VERSION,
        "LocalOnlyNotRunEvidence": True,
        "RunId": "U3M6_ACCEPTANCE",
        "CandidateCount": 1,
        "ReviewBatchCount": 1,
        "ReviewDataRowCount": 7,
        "Batches": [
            {
                "ReviewBatchId": "RB001",
                "CandidateCount": 1,
                "ReviewDataRowCount": 7,
                "FrameStart": 100,
                "FrameEnd": 106,
                "EventQueuePath": str(event_path),
                "EventQueueSha256": sha256_file(event_path),
                "ReviewDataPath": str(review_path),
                "ReviewDataSha256": sha256_file(review_path),
                "U003StartColumn": "ReviewStartFrame",
                "U003PeakColumn": "PeakFrameCount",
                "U003EndColumn": "ReviewEndFrame"
            }
        ],
    }
    descriptor_path = root / "handoff_descriptor.json"
    descriptor_path.write_text(json.dumps(descriptor), encoding="utf-8")
    return descriptor_path


def run_acceptance(verbose: bool, quick: bool) -> tuple[int, dict[str, int]]:
    if str(PROGRAM_ROOT) not in sys.path:
        sys.path.insert(0, str(PROGRAM_ROOT))

    groups = {
        "inventory": 0,
        "compile": 0,
        "interface": 0,
        "handoff": 0,
        "module": 0,
        "authority": 0,
    }
    checks = 0

    def check(condition: bool, group: str, label: str, meaning: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(f"{group}:{label}")
        checks += 1
        groups[group] += 1
        if verbose:
            print(f"[CHECK {checks:03d}] {label} - {meaning}")

    check(RELEASE_CONTRACT.is_file(), "inventory", "release contract", "freeze boundary is explicit")
    contract = json.loads(RELEASE_CONTRACT.read_text(encoding="utf-8-sig"))
    check(contract.get("ContractId") == "U003_SOURCE_RELEASE_CANDIDATE", "inventory", "contract id", "the release is identifiable")
    check(contract.get("ProgramVersion") == "0.17", "inventory", "contract version", "the active entry is pinned")

    actual_programs = {path.name for path in PROGRAM_ROOT.glob("*.py") if path.is_file()}
    check(ACTIVE_PROGRAMS.issubset(actual_programs), "inventory", "program inventory", "all active source files exist")
    actual_contracts = {path.name for path in CONTRACT_ROOT.glob("*.json") if path.is_file()}
    check(ACTIVE_CONTRACTS.issubset(actual_contracts), "inventory", "contract inventory", "all active policies exist")

    for name in sorted(ACTIVE_PROGRAMS):
        source = (PROGRAM_ROOT / name).read_text(encoding="utf-8-sig")
        ast.parse(source, filename=name)
        check(bool(source.strip()), "compile", name, "source parses and is nonempty")
    for name in sorted(ACTIVE_CONTRACTS):
        payload = json.loads((CONTRACT_ROOT / name).read_text(encoding="utf-8-sig"))
        check(isinstance(payload, dict) and bool(payload), "compile", name, "contract is valid JSON")

    domain = importlib.import_module("u003_domain_core_v0_2")
    entry = importlib.import_module("u003_evidence_review_workbench_v0_17")
    gui = importlib.import_module("u003_gui_shell_v0_4")
    handoff = importlib.import_module("u003_handoff_core_v0_2")
    localization = importlib.import_module("u003_localization_v0_2")
    manager = importlib.import_module("u003_module_manager_gui_v0_3")
    coordinator_module = importlib.import_module("u003_module_execution_coordinator_v0_1")
    executor = importlib.import_module("u003_module_executor_v0_1")
    plan_core = importlib.import_module("u003_module_plan_core_v0_1")
    runtime = importlib.import_module("u003_module_runtime_v0_1")

    expected_versions = {
        domain.DOMAIN_VERSION: "0.2",
        handoff.HANDOFF_CORE_VERSION: "0.2",
        gui.GUI_SHELL_VERSION: "0.4",
        localization.LOCALIZATION_VERSION: "0.2",
        manager.MANAGER_VERSION: "0.3",
        coordinator_module.COORDINATOR_VERSION: "0.1",
        executor.EXECUTOR_VERSION: "0.1",
        plan_core.PLAN_CORE_VERSION: "0.1",
        runtime.RUNTIME_VERSION: "0.1",
        entry.VERSION: "0.17",
    }
    check(all(actual == expected for actual, expected in expected_versions.items()), "interface", "component versions", "composition identity is exact")
    capability = entry.launch_capability()
    check(capability["InterfaceId"] == "CameraRadar.U003.HandoffLauncher", "interface", "launcher id", "U002 discovery remains stable")
    check(capability["AcceptedHandoffContractId"] == handoff.HANDOFF_CONTRACT_ID, "interface", "handoff id", "producer and consumer agree")
    check("--handoff-descriptor" in capability["SupportedArguments"], "interface", "handoff argument", "automatic U002 launch is supported")
    check("--language" in capability["SupportedArguments"], "interface", "language argument", "session language can be governed")

    child_expectations = (
        ("u003_module_runtime_v0_1.py", ("--self-test",), "U3M1-SELFTEST-PASS"),
        ("u003_module_executor_v0_1.py", ("--self-test",), "U3M2-SELFTEST-PASS"),
        ("u003_module_execution_coordinator_v0_1.py", (), "COORDINATOR-SELFTEST-PASS"),
        ("u003_evidence_review_workbench_v0_17.py", ("--self-test",), "U003-V017-SELFTEST-PASS"),
    )
    for program, arguments, token in child_expectations:
        result = run_child(program, *arguments)
        check(result.returncode == 0, "interface", f"{program} exit", "fresh-process self-test passes")
        check(token in result.stdout, "interface", f"{program} capsule", "expected evidence is emitted")

    catalog = plan_core.discover_catalog(MODULE_ROOT)
    module_keys = {(item.module_id, item.module_version) for item in catalog.descriptors}
    check(module_keys == EXPECTED_MODULES, "module", "module catalog", "the RC contains the two approved sample families")
    check(len(catalog.selected_versions) == 2, "module", "selected versions", "one current version exists per family")
    process_modules = [item for item in catalog.descriptors if item.execution_kind == "PROCESS"]
    check(len(process_modules) == 1, "module", "PROCESS inventory", "only the memo draft executes")
    empty_plan = plan_core.empty_plan(MODULE_ROOT, "EN")
    check(empty_plan.selected_count() == 0, "authority", "default plan", "no Module executes by default")

    if not quick:
        with tempfile.TemporaryDirectory(prefix="u003_u3m6_") as temporary:
            temporary_root = Path(temporary)
            descriptor_path = write_handoff_fixture(temporary_root, handoff)
            loaded = handoff.load_governed_handoff(descriptor_path)
            check(loaded.candidate_count == 1, "handoff", "candidate count", "the descriptor is consumed")
            check(loaded.review_data_row_count == 7, "handoff", "review rows", "the narrow evidence table is consumed")
            events, *_columns = domain.parse_review_events(
                *domain.read_delimited_file(loaded.event_queue_path)
            )
            check(len(events) == 1 and events[0].event_id == "C0001", "handoff", "event parse", "the review candidate is intact")
            descriptor = process_modules[0]
            active_plan = plan_core.add_or_replace_selection(empty_plan, descriptor)
            coordinator = coordinator_module.ModuleExecutionCoordinator(
                MODULE_ROOT,
                temporary_root / "U003_MODULE_RUNS",
                "EN",
            )
            coordinator.activate_plan(active_plan)
            first = coordinator.execute_event(events[0], loaded.run_id)
            changed = coordinator.apply_report_to_event(events[0], first)
            second = coordinator.execute_event(events[0], loaded.run_id)
            changed_again = coordinator.apply_report_to_event(events[0], second)
            check(first.executed_count == 1 and first.suggestion_count == 1, "module", "first run", "one eligible Module executes once")
            check(changed and "C0001" in events[0].memo, "module", "memo composition", "editable assistance reaches Review Memo")
            check(second.executed_count == 0 and second.cached_count == 1, "module", "cache", "revisit does not rerun the Module")
            check(not changed_again, "module", "deduplication", "revisit does not duplicate text")
            trace_files = list((temporary_root / "U003_MODULE_RUNS").rglob("module_trace.json"))
            check(len(trace_files) == 1, "module", "trace", "one execution has one trace")
            result_payload = json.loads(trace_files[0].with_name("module_result.json").read_text(encoding="utf-8-sig"))
            check(result_payload.get("RootCauseClaim") is False, "authority", "root cause", "the Module cannot claim root cause")
            check(events[0].review_result == "", "authority", "review result", "the engineer disposition remains untouched")
            check(events[0].peak_framecount == 103, "authority", "peak", "source evidence remains untouched")

    return checks, groups


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--accept", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if arguments.self_test == arguments.accept:
            raise AcceptanceError("select exactly one of --self-test or --accept")
        checks, groups = run_acceptance(arguments.verbose, quick=arguments.self_test)
        if arguments.self_test:
            print(f"U3M6-SELFTEST-PASS-{checks} C-0")
        else:
            print(
                "U3M6 N-P{}-C{}-M{}-H{}-A{}-T{}-X0 C-0".format(
                    groups["inventory"],
                    groups["compile"],
                    groups["module"],
                    groups["handoff"],
                    groups["authority"],
                    checks,
                )
            )
        return 0
    except Exception as error:
        print(
            f"U3M6E K-{type(error).__name__.upper()} D-{error} X1 C-7",
            file=sys.stderr,
        )
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
