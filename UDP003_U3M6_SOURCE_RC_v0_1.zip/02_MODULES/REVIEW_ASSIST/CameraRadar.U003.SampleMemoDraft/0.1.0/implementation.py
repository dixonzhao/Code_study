#!/usr/bin/env python3
"""Reference U003 PROCESS module used to verify the U3M2 execution bridge."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


MODULE_ID = "CameraRadar.U003.SampleMemoDraft"
MODULE_VERSION = "0.1.0"


def read_request(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise RuntimeError("Request must be one JSON object.")
    return value


def create_result(request: dict[str, object]) -> dict[str, object]:
    context = request.get("Context")
    if not isinstance(context, dict):
        raise RuntimeError("Context must be one JSON object.")
    reason = str(context.get("CandidateReasonCode", "")).strip()
    peak = context.get("PeakFrameCount")
    if not reason or isinstance(peak, bool) or not isinstance(peak, int):
        raise RuntimeError("CandidateReasonCode and integer PeakFrameCount are required.")

    event_id = str(request.get("EventId", "")).strip()
    language = str(request.get("Language", "EN")).upper()
    if language == "JA":
        memo = (
            f"[{MODULE_ID} v{MODULE_VERSION}] {event_id}: FC {peak}付近で"
            f"{reason}を検出。映像とCANで確認してください。"
        )
    else:
        memo = (
            f"[{MODULE_ID} v{MODULE_VERSION}] {event_id}: {reason} near FC {peak}; "
            "confirm against video and CAN."
        )

    return {
        "ContractId": "U003_MODULE_RESULT",
        "ContractVersion": "0.1",
        "RequestId": request.get("RequestId"),
        "RunId": request.get("RunId"),
        "EventId": request.get("EventId"),
        "Hook": request.get("Hook"),
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Status": "SUCCESS",
        "Outputs": {
            "SuggestedReviewMemo": memo
        },
        "Warnings": [],
        "RootCauseClaim": False
    }


def write_result(path: Path, result: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def run_self_test() -> int:
    request = {
        "RequestId": "SELFTEST",
        "RunId": "SELFTEST",
        "EventId": "C0001",
        "Hook": "ON_EVENT_SELECTED",
        "Language": "EN",
        "Context": {
            "CandidateReasonCode": "RADAR_LOSS",
            "PeakFrameCount": 41662,
        },
    }
    result = create_result(request)
    memo = result["Outputs"]["SuggestedReviewMemo"]
    assert "C0001" in memo
    assert "41662" in memo
    assert result["RootCauseClaim"] is False
    print("U003-U3M2-SAMPLE-MODULE-SELFTEST-PASS-3 C-0")
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--result", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if arguments.self_test:
            return run_self_test()
        if not arguments.execute or arguments.request is None or arguments.result is None:
            raise RuntimeError("Use --self-test or --execute --request PATH --result PATH.")
        request = read_request(arguments.request)
        write_result(arguments.result, create_result(request))
        print("U003-U3M2-SAMPLE-MODULE-EXECUTION C-0")
        return 0
    except Exception as error:
        print(f"U3M2ME K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
