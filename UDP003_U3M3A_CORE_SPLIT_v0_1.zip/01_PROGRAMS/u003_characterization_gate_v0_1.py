#!/usr/bin/env python3
"""Compare extracted U003 cores with the accepted v0.13 behavior baseline."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

import u003_domain_core_v0_1 as domain
import u003_handoff_core_v0_1 as handoff


GATE_VERSION = "0.1"
LEGACY_SHA256 = "a9b4f4a14d43fd51dce0bc577c74a9482606a3d918c4c2fec935b56d99c56758"


class CharacterizationError(RuntimeError):
    """Raised when the baseline or extracted behavior differs."""


class StaticVar:
    """Minimal tkinter-variable substitute for pure mapping characterization."""

    def __init__(self, value: object) -> None:
        self.value = value

    def get(self) -> object:
        return self.value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_legacy(path: Path):
    path = path.resolve()
    if not path.is_file() or path.is_symlink():
        raise CharacterizationError(f"Legacy baseline is missing: {path}")
    actual_hash = sha256_file(path)
    if actual_hash != LEGACY_SHA256:
        raise CharacterizationError(
            f"Legacy SHA-256 mismatch: expected {LEGACY_SHA256}, got {actual_hash}"
        )
    specification = importlib.util.spec_from_file_location("u003_legacy_v013", path)
    if specification is None or specification.loader is None:
        raise CharacterizationError("Legacy baseline could not be loaded.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def event_signature(events: list[Any]) -> list[tuple[Any, ...]]:
    return [
        (
            item.event_id,
            item.start_framecount,
            item.peak_framecount,
            item.end_framecount,
            item.review_result,
            item.memo,
            dict(item.original),
            item.display_text(),
        )
        for item in events
    ]


def handoff_signature(value: Any) -> tuple[Any, ...]:
    return (
        value.run_id,
        value.batch_id,
        value.event_queue_path,
        value.review_data_path,
        value.candidate_count,
        value.review_data_row_count,
        value.frame_start,
        value.frame_end,
    )


def write_handoff_fixture(root: Path, legacy: Any) -> Path:
    event_path = root / "event_queue.csv"
    review_path = root / "review_data.csv"
    event_fields = (
        "EventID",
        "ReviewStartFrame",
        "PeakFrameCount",
        "ReviewEndFrame",
        "ReviewResult",
        "ReviewMemo",
    )
    with event_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=event_fields)
        writer.writeheader()
        writer.writerows(
            [
                {
                    "EventID": "C0001",
                    "ReviewStartFrame": 100,
                    "PeakFrameCount": 103,
                    "ReviewEndFrame": 106,
                    "ReviewResult": "1",
                    "ReviewMemo": "first",
                },
                {
                    "EventID": "C0002",
                    "ReviewStartFrame": 104,
                    "PeakFrameCount": 108,
                    "ReviewEndFrame": 110,
                    "ReviewResult": "",
                    "ReviewMemo": "second",
                },
            ]
        )
    with review_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("FrameCount", "RadarDistance"))
        writer.writeheader()
        for framecount in range(100, 111):
            writer.writerow({"FrameCount": framecount, "RadarDistance": framecount / 10})
    descriptor = {
        "ContractId": legacy.HANDOFF_CONTRACT_ID,
        "ContractVersion": legacy.HANDOFF_CONTRACT_VERSION,
        "LocalOnlyNotRunEvidence": True,
        "RunId": "U3M3A_CHARACTERIZATION",
        "CandidateCount": 2,
        "ReviewBatchCount": 1,
        "ReviewDataRowCount": 11,
        "Batches": [
            {
                "ReviewBatchId": "RB001",
                "CandidateCount": 2,
                "ReviewDataRowCount": 11,
                "FrameStart": 100,
                "FrameEnd": 110,
                "EventQueuePath": str(event_path),
                "EventQueueSha256": legacy.sha256_file(event_path),
                "ReviewDataPath": str(review_path),
                "ReviewDataSha256": legacy.sha256_file(review_path),
                "U003StartColumn": "ReviewStartFrame",
                "U003PeakColumn": "PeakFrameCount",
                "U003EndColumn": "ReviewEndFrame",
            }
        ],
    }
    descriptor_path = root / "handoff.json"
    descriptor_path.write_text(json.dumps(descriptor), encoding="utf-8")
    return descriptor_path


def run_characterization(legacy_path: Path, verbose: bool = True) -> int:
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise CharacterizationError(name)
        checks += 1
        if verbose:
            print(f"[CHECK {checks:02d}] {name} - {reason}")

    legacy = load_legacy(legacy_path)
    check(legacy.VERSION == "0.13", "legacy version", "characterizes the accepted GUI baseline")
    check(sha256_file(legacy_path) == LEGACY_SHA256, "legacy identity", "prevents comparison against a drifting source")
    check(domain.REVIEW_CODES == legacy.REVIEW_CODES, "review codes", "engineer disposition semantics remain fixed")
    check(domain.EVENT_START_ALIASES == legacy.EVENT_START_ALIASES, "start aliases", "legacy Event queues remain loadable")
    check(domain.EVENT_PEAK_ALIASES == legacy.EVENT_PEAK_ALIASES, "peak aliases", "exact Peak identity remains loadable")
    check(domain.EVENT_END_ALIASES == legacy.EVENT_END_ALIASES, "end aliases", "legacy Event queues remain loadable")

    for video_fc, lag, pin in (
        (100, 0, None),
        (100, 4, None),
        (100, -3, None),
        (100, 7, 108),
    ):
        check(
            domain.highlight_target_framecount(video_fc, lag, pin)
            == legacy.highlight_target_framecount(video_fc, lag, pin),
            f"highlight {video_fc}/{lag}/{pin}",
            "yellow-row selection is unchanged",
        )
    for framecounts, target in (
        ([10, 11, 12], 11),
        ([10, 12], 11),
        ([10, 20], 100),
        ([10, 20], -100),
    ):
        check(
            domain.nearest_sorted_index(framecounts, target)
            == legacy.nearest_sorted_index(framecounts, target),
            f"nearest row {target}",
            "exact/nearest CAN behavior is unchanged",
        )

    for text in (None, "FrameCount", "ID_620_FrameCount", "camelCaseValue", "ＡＢＣ"):
        check(
            domain.normalized_name(text) == legacy.normalized_name(text),
            f"normalized name {text}",
            "column matching remains compatible",
        )
    for text, limit in (("short", 40), ("a\n b\r c", 40), ("x" * 50, 40)):
        check(
            domain.compact_text(text, limit) == legacy.compact_text(text, limit),
            f"compact text {limit}",
            "return memo compression remains compatible",
        )

    standard_fields = [
        "EventID",
        "ReviewStartFrame",
        "PeakFrameCount",
        "ReviewEndFrame",
        "ReviewResult",
        "ReviewMemo",
    ]
    standard_rows = [
        {
            "EventID": "C0001",
            "ReviewStartFrame": "100",
            "PeakFrameCount": "103",
            "ReviewEndFrame": "106",
            "ReviewResult": "1",
            "ReviewMemo": "first",
        },
        {
            "EventID": "C0002",
            "ReviewStartFrame": "104",
            "PeakFrameCount": "108",
            "ReviewEndFrame": "110",
            "ReviewResult": "",
            "ReviewMemo": "second",
        },
    ]
    legacy_parsed = legacy.parse_review_events(standard_fields, standard_rows)
    domain_parsed = domain.parse_review_events(standard_fields, standard_rows)
    check(legacy_parsed[1:] == domain_parsed[1:], "resolved columns", "Start/Peak/End binding is unchanged")
    check(event_signature(legacy_parsed[0]) == event_signature(domain_parsed[0]), "standard events", "candidate and review state are unchanged")

    alias_fields = ["QueueID", "WindowStart", "PeakFC", "WindowEnd"]
    alias_rows = [{"QueueID": "A1", "WindowStart": "10", "PeakFC": "12", "WindowEnd": "15"}]
    check(
        event_signature(legacy.parse_review_events(alias_fields, alias_rows)[0])
        == event_signature(domain.parse_review_events(alias_fields, alias_rows)[0]),
        "alias events",
        "historical column aliases remain compatible",
    )
    legacy_fields = ["EventID", "StartFrameCount", "EndFrameCount"]
    legacy_rows = [{"EventID": "L1", "StartFrameCount": "1", "EndFrameCount": "2"}]
    check(
        event_signature(legacy.parse_review_events(legacy_fields, legacy_rows)[0])
        == event_signature(domain.parse_review_events(legacy_fields, legacy_rows)[0]),
        "no-peak legacy events",
        "manual Event queues without Peak remain readable",
    )

    invalid_cases = (
        ([{"EventID": "X", "ReviewStartFrame": "5", "PeakFrameCount": "4", "ReviewEndFrame": "6"}], "outside"),
        ([{"EventID": "X", "ReviewStartFrame": "5", "PeakFrameCount": "bad", "ReviewEndFrame": "6"}], "nonnumeric"),
        ([{"EventID": "X", "ReviewStartFrame": "7", "PeakFrameCount": "7", "ReviewEndFrame": "6"}], "greater"),
    )
    for rows, label in invalid_cases:
        messages = []
        for implementation in (legacy, domain):
            try:
                implementation.parse_review_events(standard_fields, rows)
            except RuntimeError as error:
                messages.append(str(error))
        check(len(messages) == 2 and messages[0] == messages[1], f"invalid {label}", "fail-close error behavior is unchanged")

    capsule_events_legacy = [
        legacy.ReviewEvent(f"C{number:04d}", number, number, review_result="1")
        for number in list(range(1, 10)) + list(range(11, 17))
    ]
    capsule_events_legacy.append(legacy.ReviewEvent("C0010", 10, 10, review_result="4"))
    capsule_events_domain = [
        domain.ReviewEvent(f"C{number:04d}", number, number, review_result="1")
        for number in list(range(1, 10)) + list(range(11, 17))
    ]
    capsule_events_domain.append(domain.ReviewEvent("C0010", 10, 10, review_result="4"))
    expected_capsule = "RV260825T145605_N16-R16_C1-1-9_C1-11-16_C4-10"
    check(legacy.build_review_return_capsule(capsule_events_legacy, "260825T145605") == expected_capsule, "legacy capsule", "locks the accepted low-bandwidth format")
    check(domain.build_review_return_capsule(capsule_events_domain, "260825T145605") == expected_capsule, "domain capsule", "new core preserves the accepted format")

    legacy_mapper = object.__new__(legacy.FrameCountVideoReviewer)
    legacy_mapper.anchor_video_var = StaticVar("3")
    legacy_mapper.anchor_framecount_var = StaticVar("100")
    legacy_mapper.framecount_rate_var = StaticVar("20")
    legacy_mapper.mapping_mode_var = StaticVar("1:1")
    legacy_mapper.video_fps = 20.0
    for video_index in (0, 3, 10, 100):
        check(
            legacy_mapper.video_index_to_framecount(video_index)
            == domain.video_index_to_framecount(video_index, 3, 100, 20, 20, "1:1"),
            f"1:1 video to FC {video_index}",
            "accepted mapping is unchanged",
        )
    for framecount in (97, 100, 107, 200):
        check(
            legacy_mapper.framecount_to_video_index(framecount)
            == domain.framecount_to_video_index(framecount, 3, 100, 20, 20, "1:1"),
            f"1:1 FC to video {framecount}",
            "accepted inverse mapping is unchanged",
        )
    legacy_mapper.mapping_mode_var = StaticVar("Rate-based")
    legacy_mapper.framecount_rate_var = StaticVar("40")
    legacy_mapper.video_fps = 20.0
    for video_index in (3, 4, 10):
        check(
            legacy_mapper.video_index_to_framecount(video_index)
            == domain.video_index_to_framecount(video_index, 3, 100, 40, 20, "Rate-based"),
            f"rate video to FC {video_index}",
            "non-1:1 mapping is unchanged",
        )
    for framecount in (100, 102, 114):
        check(
            legacy_mapper.framecount_to_video_index(framecount)
            == domain.framecount_to_video_index(framecount, 3, 100, 40, 20, "Rate-based"),
            f"rate FC to video {framecount}",
            "non-1:1 inverse mapping is unchanged",
        )

    with tempfile.TemporaryDirectory(prefix="u003_m3a_") as temporary:
        descriptor_path = write_handoff_fixture(Path(temporary), legacy)
        legacy_handoff = legacy.load_governed_handoff(descriptor_path)
        new_handoff = handoff.load_governed_handoff(descriptor_path)
        check(handoff_signature(legacy_handoff) == handoff_signature(new_handoff), "valid handoff", "U002-to-U003 intake remains byte-governed")

        broken = json.loads(descriptor_path.read_text(encoding="utf-8"))
        broken["Batches"][0]["EventQueueSha256"] = "0" * 64
        descriptor_path.write_text(json.dumps(broken), encoding="utf-8")
        messages = []
        for loader in (legacy.load_governed_handoff, handoff.load_governed_handoff):
            try:
                loader(descriptor_path)
            except RuntimeError as error:
                messages.append(str(error))
        check(len(messages) == 2 and messages[0] == messages[1], "hash mismatch", "tampered handoff is rejected identically")

    capability = legacy.launch_capability()
    check(capability["ProgramVersion"] == "0.13", "legacy capability", "automatic U002 launch baseline is identified")
    check(capability["AcceptedHandoffContractVersion"] == handoff.HANDOFF_CONTRACT_VERSION, "handoff contract version", "extracted core accepts the same descriptor version")
    check(domain.DOMAIN_VERSION == "0.1", "domain version", "new internal responsibility is versioned")
    check(handoff.HANDOFF_CORE_VERSION == "0.1", "handoff version", "new internal responsibility is versioned")

    print(f"U3M3A N-L1-D1-H1-T{checks}-X0 C-0")
    return 0


def parse_arguments(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--characterize", action="store_true")
    parser.add_argument("--legacy", type=Path)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        if not arguments.self_test and not arguments.characterize:
            raise CharacterizationError("Use --self-test or --characterize.")
        legacy_path = arguments.legacy or Path(__file__).with_name(
            "u003_evidence_review_workbench_v0_13.py"
        )
        return run_characterization(legacy_path, verbose=arguments.characterize)
    except Exception as error:
        print(f"U3M3AE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
