#!/usr/bin/env python3
"""Qualification tests for additive selected-Camera Width evidence v0.4.0."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


MODULE_ID = "CameraRadar.S1.CameraTargetContinuityArbitration"
MODULE_VERSION = "0.4.0"
D1 = "CAMERA_1_DISTANCE"
L1 = "CAMERA_1_LATERAL_POSITION"
D3 = "CAMERA_3_DISTANCE"
L3 = "CAMERA_3_LATERAL_POSITION"
W1 = "CAMERA_1_WIDTH"
W3 = "CAMERA_3_WIDTH"
ROLES = (D1, L1, W1, D3, L3, W3)
HISTORICAL_FAILURE_COVERAGE = ("FP030", "FP031", "FP032", "FP033", "FP034")
HISTORICAL_FAILURE_TEST_MAP = {
    "FP030": ("nullable_age", "invalid_age", "runtime_blank_age"),
    "FP031": ("four_role_binding", "runtime_four_role_contract"),
    "FP032": ("reviewed_recovery_window", "stable_turn_not_dropped"),
    "FP033": ("absolute_lateral_symmetry", "radar_not_in_api"),
    "FP034": ("same_frame_width", "width_does_not_select_target"),
}


def load_implementation(module_root: Path):
    """Load only the implementation selected by the qualification request."""

    spec = importlib.util.spec_from_file_location(
        "u22b11_camera_geometry_module",
        module_root / "implementation.py",
    )
    if spec is None or spec.loader is None:
        raise AssertionError("IMPLEMENTATION_SPEC")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source(value, eligible=True, age=0):
    """Create one normalized U001 source state."""

    return {
        "Value": value,
        "Age": age,
        "Valid": bool(eligible),
        "Eligible": bool(eligible),
        "Updated": bool(eligible),
        "CanonicalName": "",
    }


def record(
    frame,
    d1,
    l1,
    d3,
    l3,
    distance_1_valid=True,
    lateral_1_valid=True,
    distance_3_valid=True,
    lateral_3_valid=True,
    width_1=2.0,
    width_3=2.0,
    width_1_valid=True,
    width_3_valid=True,
):
    """Create one six-role reconstruction fixture."""

    result = {
        "FrameCount": frame,
        D1: source(d1, distance_1_valid),
        L1: source(l1, lateral_1_valid),
        W1: source(width_1, width_1_valid),
        D3: source(d3, distance_3_valid),
        L3: source(l3, lateral_3_valid),
        W3: source(width_3, width_3_valid),
    }
    for role in ROLES:
        result[role]["CanonicalName"] = role
    return result


def configuration(seed_frame=None, seed_role=None):
    """Return the B10-frozen controlled configuration."""

    return {
        "BindingProfilePath": "02_CONFIG/signal_profiles/test.json",
        "BindingProfileSha256": "0" * 64,
        "ContinuityScaleMeters": 0.38,
        "MaxContinuityCost": 3.0,
        "AcquireConfirmFrames": 3,
        "SwitchConfirmFrames": 3,
        "SwitchMargin": 1.0,
        "ResetAfterBothInvalidFrames": 3,
        "MaxReacquisitionAbsLateralMeters": 0.75,
        "MinimumCenterlineAdvantageMeters": 1.0,
        "GeometryConfirmFrames": 3,
        "SeedFrame": seed_frame,
        "SeedRole": seed_role,
        "ContextFrameStart": None,
    }


def canonical_bytes(value) -> bytes:
    """Serialize deterministic self-test documents."""

    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    ).encode("utf-8")


def write_json(path: Path, value) -> None:
    """Write one deterministic fixture document."""

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical_bytes(value))


def sha256(path: Path) -> str:
    """Hash one self-test fixture."""

    return hashlib.sha256(path.read_bytes()).hexdigest()


def group_header(role: str):
    """Return the seven U001 Frame View columns for one role."""

    return [
        role + suffix
        for suffix in (
            "__value",
            "__label",
            "__updated",
            "__update_count",
            "__age",
            "__valid",
            "__missing_reason",
        )
    ]


def group_values(value, valid=True):
    """Return one valid or never-updated U001 row group."""

    if valid:
        return [value, "", 1, 1, 0, 1, "VALID_UPDATE"]
    return ["", "", 0, 0, "", 0, "NO_UPDATE"]


def runtime_smoke(source_root: Path) -> int:
    """Execute one real request/result/artifact round trip."""

    checks = 0
    with tempfile.TemporaryDirectory(prefix="u22b11_module_") as temporary:
        root = Path(temporary) / "U-UDP002"
        module_root = root / "01_PROGRAMS/modules/S1" / MODULE_ID / MODULE_VERSION
        module_root.mkdir(parents=True)
        for name in (
            "algorithm_card.json",
            "configuration_schema.json",
            "implementation.py",
            "module_manifest.json",
            "selftest.py",
        ):
            shutil.copy2(source_root / name, module_root / name)

        input_root = root / "03_CASES/TC_SELFTEST/U001_OUTPUT"
        input_root.mkdir(parents=True)
        frame_view = input_root / "u001_frame_values.csv"
        header = ["FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount"]
        for role in ROLES:
            header.extend(group_header(role))
        with frame_view.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(header)
            for index, frame in enumerate(range(100, 105), start=1):
                row = [frame, index, index, 4]
                row.extend(group_values(40.0 + index))
                row.extend(group_values(-1.95))
                row.extend(group_values(2.0))
                row.extend(group_values(16.0 + index / 10))
                row.extend(group_values(0.15))
                row.extend(group_values(2.0))
                writer.writerow(row)
        input_hash = sha256(frame_view)

        run_id = "RUN_U22B11_SELFTEST"
        run_root = root / "07_OUTPUT" / run_id
        write_json(
            run_root / "00_CONFIG/resolved_run_plan.json",
            {
                "RunId": run_id,
                "RunScope": "FULL_CASE",
                "FrameStart": None,
                "FrameEnd": None,
            },
        )
        parent = run_root / "03_ARTIFACTS/S0/ART_S0_SELFTEST"
        parent.mkdir(parents=True)
        inventory = parent / "u001_signal_inventory.csv"
        inventory.write_text(
            "CanonicalName,CAN_ID,Channel,SignalName,Unit\n"
            + D1 + ",0x221,2,Distance,m\n"
            + L1 + ",0x221,2,LateralPosition,m\n"
            + W1 + ",0x221,2,Width,m\n"
            + D3 + ",0x251,2,Distance,m\n"
            + L3 + ",0x251,2,LateralPosition,m\n"
            + W3 + ",0x251,2,Width,m\n",
            encoding="utf-8",
        )
        summary = parent / "u001_intake_summary.json"
        write_json(summary, {"Status": "INTAKE_ACCEPTED"})
        manifest_path = parent / "artifact_manifest.json"
        write_json(
            manifest_path,
            {
                "ContractVersion": "U22.0.1",
                "ArtifactId": "ART_S0_SELFTEST",
                "ArtifactType": "U001_INTAKE_ACCEPTED",
                "SchemaId": "U002_U001_INTAKE_SUMMARY",
                "SchemaVersion": "0.1",
                "RunId": run_id,
                "Stage": "S0",
                "ProducerModuleId": "CameraRadar.S0.U001ControlledProfileIntake",
                "ProducerModuleVersion": "0.1.1",
                "ParentArtifactIds": [],
                "Payloads": [
                    {
                        "RelativePath": summary.name,
                        "MediaType": "application/json",
                        "RowCount": None,
                        "Sha256": sha256(summary),
                        "ByteSize": summary.stat().st_size,
                        "PayloadKind": "PRIMARY",
                    },
                    {
                        "RelativePath": inventory.name,
                        "MediaType": "text/csv",
                        "RowCount": 6,
                        "Sha256": sha256(inventory),
                        "ByteSize": inventory.stat().st_size,
                        "PayloadKind": "AUXILIARY",
                    },
                ],
                "Metadata": {},
            },
        )

        profile_path = root / "02_CONFIG/signal_profiles/test.json"
        profile = {
            "ContractVersion": "U002_SIGNAL_BINDING_PROFILE_V0_1",
            "BindingProfileId": "TC001.CameraRadar.Geometry.SELFTEST",
            "BindingProfileVersion": "0.3.0",
            "DuplicateRoleCount": 0,
            "BlockingIssues": [],
            "SourceInventorySha256": sha256(inventory),
            "Prohibitions": [
                "Radar is not used to select the Camera target",
                "Recognition_ID is not target truth",
            ],
            "Bindings": {},
        }
        for role in ROLES:
            profile["Bindings"][role] = [
                {
                    "CanonicalName": role,
                    "IncludeInFrameView": True,
                    "MaxAgeFrames": "1",
                }
            ]
        write_json(profile_path, profile)
        cfg = configuration()
        cfg["BindingProfileSha256"] = sha256(profile_path)

        staging = run_root / "00_STAGING/0002_S1/packages"
        staging.mkdir(parents=True)
        request_path = run_root / "00_STAGING/0002_S1/module_request.json"
        result_path = run_root / "00_STAGING/0002_S1/module_result.json"
        write_json(
            request_path,
            {
                "Protocol": "U002_U22_MODULE_RUNTIME",
                "ProtocolVersion": "0.1",
                "ContractVersion": "U22.0.1",
                "RunId": run_id,
                "Sequence": 2,
                "Stage": "S1",
                "ModuleId": MODULE_ID,
                "ModuleVersion": MODULE_VERSION,
                "ModuleRoot": str(module_root),
                "RunRoot": str(run_root),
                "InputPackage": str(input_root),
                "RequiredInputs": list(ROLES),
                "OptionalInputs": [],
                "InputArtifacts": [
                    {
                        "ArtifactId": "ART_S0_SELFTEST",
                        "ArtifactType": "U001_INTAKE_ACCEPTED",
                        "ManifestRelativePath": manifest_path.relative_to(run_root).as_posix(),
                        "ManifestSha256": sha256(manifest_path),
                    }
                ],
                "Configuration": cfg,
                "ExpectedOutputTypes": ["CAMERA_TARGET_RECONSTRUCTION"],
                "OutputRoot": str(staging),
            },
        )
        completed = subprocess.run(
            [
                sys.executable,
                str(module_root / "implementation.py"),
                "--request-json",
                str(request_path),
                "--result-json",
                str(result_path),
            ],
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        assert completed.returncode == 0 and "C-0" in completed.stdout, (
            completed.returncode,
            completed.stdout,
            completed.stderr,
        )
        checks += 1
        result = json.loads(result_path.read_text(encoding="utf-8"))
        assert result["Status"] == "SUCCEEDED"
        checks += 1
        table = staging / "artifact_01/camera_target_reconstruction.csv"
        with table.open("r", encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        assert len(rows) == 5
        assert rows[-1]["SelectedCameraRole"] == D3
        assert rows[-1]["SelectedCameraWidth"] == "2"
        assert rows[-1]["SelectedCameraWidthValid"] == "1"
        assert rows[-1]["SelectedCameraWidthReason"] == "VALID"
        assert rows[-1]["SelectedCameraWidthSourceCanonicalName"] == W3
        assert any(row["SelectionReason"] == "GEOMETRY_ACQUIRED" for row in rows)
        checks += 7
        quality = json.loads(
            (staging / "artifact_01/camera_target_reconstruction_quality.json")
            .read_text(encoding="utf-8")
        )
        assert quality["GeometryAuthorizedRows"] == 5
        assert quality["SelectedCameraWidthValidRows"] == 3
        assert quality["EngineeringClaim"].startswith("GEOMETRY_ASSISTED")
        checks += 3
        assert sha256(frame_view) == input_hash
        checks += 1
    return checks


def main() -> int:
    """Run semantic, historical and runtime qualification fixtures."""

    parser = argparse.ArgumentParser()
    parser.add_argument("--module-root", required=True)
    parser.add_argument("--workspace-root", required=True)
    args = parser.parse_args()
    module_root = Path(args.module_root).resolve()
    implementation = load_implementation(module_root)
    checks = 0

    assert set(HISTORICAL_FAILURE_COVERAGE) == set(HISTORICAL_FAILURE_TEST_MAP)
    assert all(HISTORICAL_FAILURE_TEST_MAP.values())
    checks += 2

    cfg = configuration()
    implementation.validate_configuration(cfg)
    checks += 1

    bindings = {
        role: {"CanonicalName": role, "MaxAgeFramesParsed": 1}
        for role in ROLES
    }
    raw = {}
    for role in ROLES:
        raw[role + "__value"] = ""
        raw[role + "__age"] = ""
        raw[role + "__valid"] = 0
        raw[role + "__updated"] = 0
    raw[D3 + "__value"] = "16.5"
    raw[D3 + "__age"] = "0"
    raw[D3 + "__valid"] = 1
    raw[D3 + "__updated"] = 1
    raw[L3 + "__value"] = "0.15"
    raw[L3 + "__age"] = "0"
    raw[L3 + "__valid"] = 1
    raw[L3 + "__updated"] = 1
    raw[W3 + "__value"] = "2.0"
    raw[W3 + "__age"] = "0"
    raw[W3 + "__valid"] = 1
    raw[W3 + "__updated"] = 1
    normalized = implementation.normalized_record(100, raw, bindings)
    assert normalized[D1]["Age"] is None and not normalized[D1]["Eligible"]
    assert normalized[D3]["Eligible"] and normalized[L3]["Eligible"]
    assert normalized[W3]["Eligible"]
    checks += 2

    bad = dict(raw)
    bad[D1 + "__value"] = "10"
    bad[D1 + "__age"] = "-1"
    try:
        implementation.normalized_record(100, bad, bindings)
    except implementation.ModuleError:
        checks += 1
    else:
        raise AssertionError("NEGATIVE_AGE_ACCEPTED")

    # Reviewed recovery: wrong stable Camera 1 is off-center; Camera 3 is centered.
    recovery = [
        record(200 + index, 10.5, -1.95, 16.5 + 0.02 * index, 0.15)
        for index in range(5)
    ]
    rows = implementation.reconstruct(recovery, cfg)
    assert rows[0]["SelectionStatus"] == "ACQUIRING"
    assert rows[1]["CanonicalCameraValid"] == 0
    assert rows[2]["SelectedCameraRole"] == D3
    assert rows[2]["SelectionReason"] == "GEOMETRY_ACQUIRED"
    assert all(row["SelectedCameraRole"] != D1 for row in rows)
    checks += 5

    # Absolute lateral is symmetric: +1.95 and -1.95 are equally unauthorized.
    plus = implementation.geometry_state(record(1, 10, 1.95, 20, 0.1), D1, 0.75)
    minus = implementation.geometry_state(record(1, 10, -1.95, 20, 0.1), D1, 0.75)
    assert plus["AbsLateral"] == minus["AbsLateral"] == 1.95
    assert not plus["Authorized"] and not minus["Authorized"]
    checks += 2

    # Both near centerline but without the explicit 1 m advantage remain ambiguous.
    ambiguous = implementation.reconstruct(
        [record(300 + index, 10.0, 0.10, 10.2, -0.20) for index in range(4)],
        cfg,
    )
    assert all(row["CanonicalCameraValid"] == 0 for row in ambiguous)
    assert all(row["SelectionReason"] == "CENTERLINE_ADVANTAGE_BELOW_MARGIN" for row in ambiguous)
    checks += 2

    # Once Camera 3 is seeded and distance-plausible, a turn alone cannot drop it.
    stable_cfg = configuration(400, D3)
    stable = implementation.reconstruct(
        [
            record(400, 50.0, 0.0, 12.0, 0.1),
            record(401, 50.2, 0.0, 12.1, 2.5),
            record(402, 50.4, 0.0, 12.2, -2.8),
        ],
        stable_cfg,
    )
    assert all(row["SelectedCameraRole"] == D3 for row in stable)
    assert all(row["CanonicalCameraValid"] == 1 for row in stable)
    checks += 2

    # A switch requires an eligible and geometry-authorized alternative.
    switch_cfg = configuration(500, D1)
    switched = implementation.reconstruct(
        [
            record(500, 10.0, 0.1, 50.0, 0.1),
            record(501, None, None, 10.1, 0.1, False, False, True, True),
            record(502, None, None, 10.2, 0.1, False, False, True, True),
            record(503, None, None, 10.3, 0.1, False, False, True, True),
        ],
        switch_cfg,
    )
    assert switched[-1]["SelectedCameraRole"] == D3
    assert switched[-1]["SelectionChanged"] == 1
    checks += 2

    fixture = [record(600 + index, 40, -1.5, 15 + index / 100, 0.1) for index in range(8)]
    before = repr(fixture)
    first = implementation.reconstruct(fixture, cfg)
    second = implementation.reconstruct(fixture, cfg)
    assert first == second and repr(fixture) == before
    checks += 2

    # Width is additive evidence only: changing Width cannot change selection.
    narrow = [record(700 + index, 40, -1.5, 15 + index / 100, 0.1, width_1=0.5, width_3=0.5) for index in range(8)]
    wide = [record(700 + index, 40, -1.5, 15 + index / 100, 0.1, width_1=4.0, width_3=4.0) for index in range(8)]
    narrow_rows = implementation.reconstruct(narrow, cfg)
    wide_rows = implementation.reconstruct(wide, cfg)
    preserved_fields = [name for name in implementation.OUTPUT_COLUMNS if not name.startswith("SelectedCameraWidth")]
    assert [tuple(row[name] for name in preserved_fields) for row in narrow_rows] == [
        tuple(row[name] for name in preserved_fields) for row in wide_rows
    ]
    assert narrow_rows[-1]["SelectedCameraWidth"] == "0.5"
    assert wide_rows[-1]["SelectedCameraWidth"] == "4"
    checks += 3

    # Same-frame contract: stale Width remains visible only as an invalid reason.
    stale_width = record(800, 10, 0.1, 12, 0.2)
    stale_width[W3] = source(2.0, True, age=1)
    stale_width[W3]["Updated"] = False
    stale_width[W3]["CanonicalName"] = W3
    stale_width[D1]["CanonicalName"] = D1
    stale_width[L1]["CanonicalName"] = L1
    stale_width[W1]["CanonicalName"] = W1
    stale_width[D3]["CanonicalName"] = D3
    stale_width[L3]["CanonicalName"] = L3
    state = implementation.selected_width_state(stale_width, D3)
    assert not state["Valid"] and state["Reason"] == "WIDTH_NOT_UPDATED_THIS_FRAME"
    checks += 1

    assert implementation.reconstruct.__code__.co_argcount == 2
    assert "RADAR" not in implementation.REQUIRED_ROLES
    checks += 2

    checks += runtime_smoke(module_root)
    assert checks == 40, checks
    print("U22B19-MODULE-SELFTEST-PASS-40-H5-X0 C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
