#!/usr/bin/env python3
"""Interactive U003 Module Action for editable XLSX chart export.

The action keeps U003 as the authority for the selected Event and current
FrameCount.  It presents a normal form-based editor for the governed chart
Profile and delegates all range selection and workbook generation to the
accepted U3M9B export core.

No raw JSON editor is exposed to the engineer.  JSON remains the traceable
storage contract behind the GUI.
"""

from __future__ import annotations

import argparse
import copy
import csv
import importlib.util
import inspect
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any


MODULE_ID = "CameraRadar.U003.EditableXlsxCharts"
MODULE_VERSION = "0.2.2"
ACTION_ID = "EXPORT_EDITABLE_XLSX_CHARTS"
CORE_FILENAME = "u003_editable_xlsx_export_core_v0_2_1.py"
MAX_CHARTS = 12
MAX_SERIES = 12
POLL_MILLISECONDS = 500


class ChartActionError(RuntimeError):
    """Raised when the action cannot form a governed export request."""


def require(condition: bool, message: str) -> None:
    """Fail closed with one actionable message."""

    if not condition:
        raise ChartActionError(message)


def read_json_object(path: Path, label: str) -> dict[str, Any]:
    """Read one UTF-8 JSON object."""

    require(path.is_file(), f"{label} does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ChartActionError(f"{label} is not valid UTF-8 JSON: {error}") from error
    require(isinstance(payload, dict), f"{label} root must be a JSON object.")
    return payload


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    """Replace one JSON file without exposing a partial write."""

    path.parent.mkdir(parents=True, exist_ok=True)
    writing = path.with_name(path.name + ".writing")
    writing.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    writing.replace(path)


def safe_segment(value: str, fallback: str) -> str:
    """Create one portable filename segment."""

    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip()).strip("._-")
    return cleaned[:80] or fallback


def unique_path(path: Path) -> Path:
    """Return a non-existing sibling path without deleting earlier evidence."""

    if not path.exists():
        return path
    counter = 2
    while True:
        candidate = path.with_name(f"{path.stem}_{counter:03d}{path.suffix}")
        if not candidate.exists():
            return candidate
        counter += 1


def find_export_core(start: Path) -> Path:
    """Find the accepted U3M9D core from an installed or prepared Module."""

    explicit = os.environ.get("U003_EDITABLE_XLSX_CORE_PATH", "").strip()
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    resolved = start.resolve()
    for parent in (resolved.parent, *resolved.parents):
        candidates.append(parent / "01_PROGRAMS" / CORE_FILENAME)
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise ChartActionError(
        f"Accepted export core {CORE_FILENAME} was not found under U-UDP003/01_PROGRAMS."
    )


def load_export_core(start: Path) -> Any:
    """Load the accepted core by exact file path, not by an ambient import."""

    core_path = find_export_core(start)
    module_name = "u003_editable_xlsx_export_core_v0_2_1"
    specification = importlib.util.spec_from_file_location(module_name, core_path)
    require(
        specification is not None and specification.loader is not None,
        f"Could not load export core: {core_path}",
    )
    module = importlib.util.module_from_spec(specification)
    sys.modules[module_name] = module
    specification.loader.exec_module(module)
    require(getattr(module, "ENGINE_VERSION", None) == "0.2.1", "Export core version differs.")
    return module


def detect_csv_header(path: Path) -> list[str]:
    """Read only the Review Data header; do not load the full CSV in the GUI."""

    require(path.is_file(), f"Review Data CSV does not exist: {path}")
    raw = path.read_bytes()[:65536]
    require(bool(raw), "Review Data CSV is empty.")
    decoded: str | None = None
    encoding = ""
    for candidate in ("utf-8-sig", "utf-8", "cp932"):
        try:
            decoded = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue
    require(decoded is not None, "Review Data CSV is not UTF-8 or CP932 text.")
    try:
        delimiter = csv.Sniffer().sniff(decoded, delimiters=",\t;").delimiter
    except csv.Error:
        delimiter = ","
    with path.open("r", encoding=encoding, newline="") as stream:
        row = next(csv.reader(stream, delimiter=delimiter), [])
    columns = [str(item).strip() for item in row]
    require(columns and all(columns), "Review Data CSV header is empty or contains blanks.")
    require(len(columns) == len(set(columns)), "Review Data CSV header contains duplicates.")
    require("FrameCount" in columns, "Review Data CSV requires exact FrameCount column.")
    return columns


def localized(value: Any, language: str) -> str:
    """Resolve one localized value with JA-to-EN fallback."""

    if not isinstance(value, dict):
        return ""
    english = str(value.get("EN", "")).strip()
    japanese = str(value.get("JA", "")).strip()
    return japanese if language == "JA" and japanese else english


def default_series(column: str, index: int = 0) -> dict[str, Any]:
    """Create one readable series definition for an available column."""

    colors = ("#2E75B6", "#ED7D31", "#70AD47", "#A5A5A5", "#7030A0", "#00B0F0")
    return {
        "Column": column,
        "DisplayName": {"EN": column, "JA": ""},
        "Color": colors[index % len(colors)],
    }


def is_default_plot_column(column: str) -> bool:
    """Keep machine-control metadata out of the first human-facing chart."""

    normalized = re.sub(r"[^a-z0-9]+", "", column.lower())
    excluded = {
        "activecandidateids",
        "iscandidatepeak",
    }
    return column != "FrameCount" and normalized not in excluded


def default_chart(columns: list[str], chart_number: int = 1) -> dict[str, Any]:
    """Create a data-driven chart draft without assuming company signal names."""

    candidates = [column for column in columns if is_default_plot_column(column)]
    require(bool(candidates), "Review Data requires at least one plotted column besides FrameCount.")
    selected = candidates[: min(2, len(candidates))]
    return {
        "ChartId": f"CHART_{chart_number:02d}",
        "Title": {"EN": f"Chart {chart_number}", "JA": f"グラフ {chart_number}"},
        "XAxisColumn": "FrameCount",
        "XAxisTitle": {"EN": "FrameCount", "JA": "FrameCount"},
        "YAxisTitle": {"EN": "Value", "JA": "値"},
        "Unit": "",
        "Series": [default_series(column, index) for index, column in enumerate(selected)],
        "PeakPolicy": {
            "Highlight": True,
            "DataLabel": False,
            "PrimarySeriesColumn": selected[0],
        },
    }


def default_profile(columns: list[str]) -> dict[str, Any]:
    """Create one valid, editable Profile from the actual Review Data header."""

    return {
        "ContractId": "U003_EDITABLE_XLSX_CHART_PROFILE",
        "ContractVersion": "0.1",
        "ProfileId": "CameraRadar.U003.CustomChartProfile",
        "ProfileVersion": "0.2.2",
        "DisplayName": {"EN": "Custom U003 Chart Export", "JA": "U003カスタムグラフ出力"},
        "RangePolicy": {
            "EventRangePriority": True,
            "FallbackMode": "CURRENT_ROW_WINDOW",
            "BeforeRows": 100,
            "AfterRows": 100,
            "AllowEngineerOverride": True,
        },
        "Charts": [default_chart(columns, 1)],
        "OutputPolicy": {
            "LanguageSource": "U003_SESSION",
            "JapaneseFallback": "EN",
            "IncludeSourceData": True,
            "NativeEditableCharts": True,
            "BlankMissingValues": True,
            "OpenOutputFolder": False,
            "TableStyle": "TableStyleMedium2",
        },
    }


def duplicate_chart(chart: dict[str, Any], existing_ids: set[str]) -> dict[str, Any]:
    """Copy a chart while preserving a unique governed ChartId."""

    duplicate = copy.deepcopy(chart)
    base = safe_segment(str(chart.get("ChartId", "CHART")), "CHART").upper()
    candidate = f"{base}_COPY"
    counter = 2
    while candidate in existing_ids:
        candidate = f"{base}_COPY_{counter}"
        counter += 1
    duplicate["ChartId"] = candidate[:40]
    duplicate["Title"]["EN"] = str(duplicate["Title"].get("EN", "Chart")) + " copy"
    if duplicate["Title"].get("JA"):
        duplicate["Title"]["JA"] = str(duplicate["Title"]["JA"]) + " コピー"
    return duplicate


def open_directory(path: Path) -> None:
    """Open a directory using the host platform without shell interpolation."""

    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except OSError as error:
        raise ChartActionError(f"Could not open output directory: {error}") from error


class EditableXlsxActionWindow:
    """Form-based Profile editor and live-context-aware export window."""

    def __init__(
        self,
        *,
        core: Any,
        language: str,
        review_data_path: Path,
        live_context_path: Path,
        profile_directory: Path,
        output_directory: Path,
    ) -> None:
        import tkinter as tk
        from tkinter import colorchooser, filedialog, messagebox, ttk

        self.tk = tk
        self.ttk = ttk
        self.colorchooser = colorchooser
        self.filedialog = filedialog
        self.messagebox = messagebox
        self.core = core
        self.language = language.upper()
        self.review_data_path = review_data_path.resolve()
        self.live_context_path = live_context_path.resolve()
        self.profile_directory = profile_directory.resolve()
        self.output_directory = output_directory.resolve()
        self.profile_directory.mkdir(parents=True, exist_ok=True)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        self.columns = detect_csv_header(self.review_data_path)
        self.profile = default_profile(self.columns)
        self.current_chart_index = 0
        self.current_series_index: int | None = None
        self.last_sequence: int | None = None
        self.latest_context: dict[str, Any] = {}
        self.export_records: list[dict[str, Any]] = []
        self.artifact_paths: list[str] = []
        self.active_profile_path: Path | None = None
        self.export_result: dict[str, Any] | None = None

        self.root = tk.Tk()
        self.root.title(self._text("U003 Editable XLSX Chart Export", "U003 編集可能XLSXグラフ出力"))
        self.root.geometry("1280x780")
        self.root.minsize(1040, 680)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self._build_variables()
        self._build_layout()
        self._load_profile_into_form()
        self._poll_context()

    def _text(self, english: str, japanese: str) -> str:
        return japanese if self.language == "JA" else english

    def _build_variables(self) -> None:
        tk = self.tk
        self.context_var = tk.StringVar(value=self._text("Waiting for U003 context", "U003コンテキスト待機中"))
        self.status_var = tk.StringVar(value=self._text("Ready", "準備完了"))
        self.search_var = tk.StringVar()
        self.profile_id_var = tk.StringVar()
        self.profile_version_var = tk.StringVar()
        self.profile_en_var = tk.StringVar()
        self.profile_ja_var = tk.StringVar()
        self.event_priority_var = tk.BooleanVar(value=True)
        self.before_rows_var = tk.StringVar(value="100")
        self.after_rows_var = tk.StringVar(value="100")
        self.explicit_range_var = tk.BooleanVar(value=False)
        self.start_frame_var = tk.StringVar()
        self.end_frame_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(self.output_directory))
        self.output_name_var = tk.StringVar()
        self.open_folder_var = tk.BooleanVar(value=False)
        self.table_style_var = tk.StringVar(value="TableStyleMedium2")
        self.chart_id_var = tk.StringVar()
        self.chart_title_en_var = tk.StringVar()
        self.chart_title_ja_var = tk.StringVar()
        self.x_column_var = tk.StringVar(value="FrameCount")
        self.x_title_en_var = tk.StringVar(value="FrameCount")
        self.x_title_ja_var = tk.StringVar(value="FrameCount")
        self.y_title_en_var = tk.StringVar(value="Value")
        self.y_title_ja_var = tk.StringVar(value="値")
        self.unit_var = tk.StringVar()
        self.peak_highlight_var = tk.BooleanVar(value=True)
        self.peak_label_var = tk.BooleanVar(value=False)
        self.primary_series_var = tk.StringVar()
        self.series_column_var = tk.StringVar()
        self.series_en_var = tk.StringVar()
        self.series_ja_var = tk.StringVar()
        self.series_color_var = tk.StringVar(value="#2E75B6")

    def _build_layout(self) -> None:
        ttk = self.ttk
        root = self.root
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)

        context = ttk.Frame(root, padding=(10, 8))
        context.grid(row=0, column=0, sticky="ew")
        context.columnconfigure(0, weight=1)
        ttk.Label(context, textvariable=self.context_var).grid(row=0, column=0, sticky="w")
        ttk.Button(
            context,
            text=self._text("Refresh Context", "コンテキスト更新"),
            command=lambda: self._refresh_context(show_error=True),
        ).grid(row=0, column=1, padx=(8, 0))

        body = ttk.Panedwindow(root, orient="horizontal")
        body.grid(row=1, column=0, sticky="nsew", padx=10)
        left = ttk.Frame(body, padding=(0, 0, 8, 0))
        middle = ttk.Frame(body, padding=(8, 0))
        right = ttk.Frame(body, padding=(8, 0, 0, 0))
        body.add(left, weight=3)
        body.add(middle, weight=3)
        body.add(right, weight=5)
        self._build_profile_panel(left)
        self._build_inventory_panel(middle)
        self._build_chart_editor(right)

        footer = ttk.Frame(root, padding=10)
        footer.grid(row=2, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status_var, relief="sunken", anchor="w").grid(
            row=0, column=0, sticky="ew", padx=(0, 8)
        )
        ttk.Button(
            footer,
            text=self._text("Export Editable XLSX", "編集可能XLSXを出力"),
            command=self._export,
        ).grid(row=0, column=1)
        ttk.Button(footer, text=self._text("Close", "閉じる"), command=self._close).grid(
            row=0, column=2, padx=(8, 0)
        )

    def _build_profile_panel(self, parent: Any) -> None:
        ttk = self.ttk
        parent.columnconfigure(0, weight=1)
        profile_box = ttk.LabelFrame(parent, text=self._text("Chart Profile", "グラフProfile"), padding=8)
        profile_box.grid(row=0, column=0, sticky="ew")
        profile_box.columnconfigure(1, weight=1)
        buttons = ttk.Frame(profile_box)
        buttons.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        buttons.columnconfigure(0, weight=2)
        buttons.columnconfigure(1, weight=1)
        buttons.columnconfigure(2, weight=1)
        ttk.Button(buttons, text=self._text("Open Profile", "Profileを開く"), command=self._open_profile).grid(row=0, column=0, sticky="ew")
        ttk.Button(buttons, text=self._text("Save", "保存"), command=self._save_profile).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(buttons, text=self._text("New", "新規"), command=self._new_profile).grid(row=0, column=2, sticky="ew")
        self._entry_row(profile_box, 1, "Profile ID", self.profile_id_var)
        self._entry_row(profile_box, 2, "Version", self.profile_version_var)
        self._entry_row(profile_box, 3, "Name EN", self.profile_en_var)
        self._entry_row(profile_box, 4, "Name JA", self.profile_ja_var)

        range_box = ttk.LabelFrame(parent, text=self._text("Range", "範囲"), padding=8)
        range_box.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        range_box.columnconfigure(1, weight=1)
        ttk.Checkbutton(
            range_box,
            text=self._text("Use selected Event range first", "選択Event範囲を優先"),
            variable=self.event_priority_var,
        ).grid(row=0, column=0, columnspan=2, sticky="w")
        self._entry_row(range_box, 1, self._text("Rows before", "前の行数"), self.before_rows_var)
        self._entry_row(range_box, 2, self._text("Rows after", "後の行数"), self.after_rows_var)
        ttk.Checkbutton(
            range_box,
            text=self._text("Engineer frame override", "技術者指定範囲"),
            variable=self.explicit_range_var,
        ).grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self._entry_row(range_box, 4, self._text("Start FrameCount", "開始FrameCount"), self.start_frame_var)
        self._entry_row(range_box, 5, self._text("End FrameCount", "終了FrameCount"), self.end_frame_var)

        output_box = ttk.LabelFrame(parent, text=self._text("Output", "出力"), padding=8)
        output_box.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        output_box.columnconfigure(0, weight=1)
        ttk.Entry(output_box, textvariable=self.output_var).grid(row=0, column=0, sticky="ew")
        ttk.Button(output_box, text=self._text("Browse", "参照"), command=self._browse_output).grid(row=0, column=1, padx=(4, 0))
        ttk.Label(output_box, text=self._text("Optional filename", "任意ファイル名")).grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Entry(output_box, textvariable=self.output_name_var).grid(row=2, column=0, columnspan=2, sticky="ew")
        ttk.Checkbutton(
            output_box,
            text=self._text("Open folder after export", "出力後にフォルダを開く"),
            variable=self.open_folder_var,
        ).grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(output_box, text=self._text("Excel table style", "Excelテーブルスタイル")).grid(
            row=4, column=0, sticky="w", pady=(6, 0)
        )
        self.table_style_combo = ttk.Combobox(
            output_box,
            textvariable=self.table_style_var,
            values=("TableStyleMedium2", "TableStyleMedium9", "TableStyleLight9"),
            state="readonly",
        )
        self.table_style_combo.grid(row=5, column=0, columnspan=2, sticky="ew")

    def _build_inventory_panel(self, parent: Any) -> None:
        ttk = self.ttk
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=2)
        parent.rowconfigure(4, weight=2)
        ttk.Label(parent, text=self._text("Available Review Data columns", "利用可能なReview Data列")).grid(row=0, column=0, sticky="w")
        search = ttk.Entry(parent, textvariable=self.search_var)
        search.grid(row=1, column=0, sticky="new", pady=(4, 0))
        search.bind("<KeyRelease>", lambda _event: self._refresh_available_columns())
        list_frame = ttk.Frame(parent)
        list_frame.grid(row=2, column=0, sticky="nsew", pady=(4, 8))
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        self.available_list = self.tk.Listbox(list_frame, exportselection=False, height=12)
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.available_list.yview)
        self.available_list.configure(yscrollcommand=scroll.set)
        self.available_list.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        ttk.Button(
            parent,
            text=self._text("Add selected column to chart →", "選択列をグラフへ追加 →"),
            command=self._add_available_series,
        ).grid(row=3, column=0, sticky="new", pady=(0, 8))

        chart_box = ttk.LabelFrame(parent, text=self._text("Charts (max 12)", "グラフ（最大12）"), padding=6)
        chart_box.grid(row=4, column=0, sticky="nsew")
        chart_box.columnconfigure(0, weight=1)
        chart_box.rowconfigure(0, weight=1)
        self.chart_list = self.tk.Listbox(chart_box, exportselection=False, height=10)
        self.chart_list.grid(row=0, column=0, columnspan=3, sticky="nsew")
        self.chart_list.bind("<<ListboxSelect>>", self._chart_selected)
        ttk.Button(chart_box, text=self._text("Add", "追加"), command=self._add_chart).grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Button(chart_box, text=self._text("Duplicate", "複製"), command=self._duplicate_chart).grid(row=1, column=1, sticky="ew", padx=4, pady=(4, 0))
        ttk.Button(chart_box, text=self._text("Delete", "削除"), command=self._delete_chart).grid(row=1, column=2, sticky="ew", pady=(4, 0))

    def _build_chart_editor(self, parent: Any) -> None:
        ttk = self.ttk
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(9, weight=1)
        self._entry_row(parent, 0, "Chart ID", self.chart_id_var)
        self._entry_row(parent, 1, "Title EN", self.chart_title_en_var)
        self._entry_row(parent, 2, "Title JA", self.chart_title_ja_var)
        ttk.Label(parent, text=self._text("X column", "X列")).grid(row=3, column=0, sticky="w", pady=2)
        self.x_column_combo = ttk.Combobox(parent, textvariable=self.x_column_var, values=self.columns, state="readonly")
        self.x_column_combo.grid(row=3, column=1, sticky="ew", pady=2)
        self._entry_row(parent, 4, "X title EN", self.x_title_en_var)
        self._entry_row(parent, 5, "X title JA", self.x_title_ja_var)
        self._entry_row(parent, 6, self._text("Y-axis label EN", "Y軸ラベル EN"), self.y_title_en_var)
        self._entry_row(parent, 7, self._text("Y-axis label JA", "Y軸ラベル JA"), self.y_title_ja_var)
        self._entry_row(parent, 8, self._text("Physical unit", "物理単位"), self.unit_var)

        series_box = ttk.LabelFrame(parent, text=self._text("Series (max 12)", "系列（最大12）"), padding=6)
        series_box.grid(row=9, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        series_box.columnconfigure(0, weight=1)
        series_box.rowconfigure(0, weight=1)
        self.series_tree = ttk.Treeview(series_box, columns=("column", "en", "ja", "color"), show="headings", height=7)
        for key, heading, width in (("column", "Column", 190), ("en", "EN", 120), ("ja", "JA", 120), ("color", "Color", 75)):
            self.series_tree.heading(key, text=heading)
            self.series_tree.column(key, width=width, anchor="w")
        self.series_tree.grid(row=0, column=0, columnspan=5, sticky="nsew")
        self.series_tree.bind("<<TreeviewSelect>>", self._series_selected)
        ttk.Button(series_box, text="↑", width=4, command=lambda: self._move_series(-1)).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Button(series_box, text="↓", width=4, command=lambda: self._move_series(1)).grid(row=1, column=1, sticky="w", pady=(4, 0))
        ttk.Button(series_box, text=self._text("Remove", "削除"), command=self._remove_series).grid(row=1, column=4, sticky="e", pady=(4, 0))

        editor = ttk.Frame(parent)
        editor.grid(row=10, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        editor.columnconfigure(1, weight=1)
        ttk.Label(editor, text="Column").grid(row=0, column=0, sticky="w")
        ttk.Entry(editor, textvariable=self.series_column_var, state="readonly").grid(row=0, column=1, sticky="ew")
        ttk.Label(editor, text="EN").grid(row=1, column=0, sticky="w")
        ttk.Entry(editor, textvariable=self.series_en_var).grid(row=1, column=1, sticky="ew")
        ttk.Label(editor, text="JA").grid(row=2, column=0, sticky="w")
        ttk.Entry(editor, textvariable=self.series_ja_var).grid(row=2, column=1, sticky="ew")
        ttk.Label(editor, text="Color").grid(row=3, column=0, sticky="w")
        ttk.Entry(editor, textvariable=self.series_color_var, width=12).grid(row=3, column=1, sticky="w")
        ttk.Button(editor, text=self._text("Choose", "選択"), command=self._choose_color).grid(row=3, column=1, sticky="e")
        ttk.Button(editor, text=self._text("Apply series", "系列へ反映"), command=self._commit_series_fields).grid(row=4, column=1, sticky="e", pady=(4, 0))

        peak = ttk.Frame(parent)
        peak.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        peak.columnconfigure(3, weight=1)
        ttk.Checkbutton(peak, text=self._text("Highlight Peak", "Peakを強調"), variable=self.peak_highlight_var).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(peak, text=self._text("Peak label", "Peakラベル"), variable=self.peak_label_var).grid(row=0, column=1, sticky="w", padx=(8, 0))
        ttk.Label(peak, text=self._text("Primary", "主系列")).grid(row=0, column=2, padx=(8, 4))
        self.primary_combo = ttk.Combobox(peak, textvariable=self.primary_series_var, state="readonly", width=22)
        self.primary_combo.grid(row=0, column=3, sticky="ew")
        ttk.Button(parent, text=self._text("Apply chart settings", "グラフ設定を反映"), command=self._commit_chart_fields).grid(row=12, column=1, sticky="e", pady=(8, 0))

    def _entry_row(self, parent: Any, row: int, label: str, variable: Any) -> None:
        self.ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2)
        self.ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=2)

    def _load_profile_into_form(self) -> None:
        profile = self.profile
        self.profile_id_var.set(str(profile["ProfileId"]))
        self.profile_version_var.set(str(profile["ProfileVersion"]))
        self.profile_en_var.set(str(profile["DisplayName"].get("EN", "")))
        self.profile_ja_var.set(str(profile["DisplayName"].get("JA", "")))
        policy = profile["RangePolicy"]
        self.event_priority_var.set(bool(policy["EventRangePriority"]))
        self.before_rows_var.set(str(policy["BeforeRows"]))
        self.after_rows_var.set(str(policy["AfterRows"]))
        self.open_folder_var.set(bool(profile["OutputPolicy"].get("OpenOutputFolder", False)))
        self.table_style_var.set(str(profile["OutputPolicy"].get("TableStyle", "TableStyleMedium2")))
        self.current_chart_index = min(self.current_chart_index, len(profile["Charts"]) - 1)
        self._refresh_available_columns()
        self._refresh_chart_list()
        self._display_chart()

    def _commit_profile_fields(self) -> None:
        before = int(self.before_rows_var.get().strip())
        after = int(self.after_rows_var.get().strip())
        require(0 <= before <= 10000 and 0 <= after <= 10000, "Before/After rows must be 0..10000.")
        self.profile["ProfileId"] = self.profile_id_var.get().strip()
        self.profile["ProfileVersion"] = self.profile_version_var.get().strip()
        self.profile["DisplayName"] = {"EN": self.profile_en_var.get().strip(), "JA": self.profile_ja_var.get().strip()}
        self.profile["RangePolicy"].update({"EventRangePriority": bool(self.event_priority_var.get()), "BeforeRows": before, "AfterRows": after})
        self.profile["OutputPolicy"]["OpenOutputFolder"] = bool(self.open_folder_var.get())
        self.profile["OutputPolicy"]["TableStyle"] = self.table_style_var.get().strip()

    def _current_chart(self) -> dict[str, Any]:
        charts = self.profile["Charts"]
        require(0 <= self.current_chart_index < len(charts), "Select one chart.")
        return charts[self.current_chart_index]

    def _commit_chart_fields(
        self,
        show_status: bool = True,
        refresh_list: bool = True,
    ) -> None:
        chart = self._current_chart()
        chart["ChartId"] = self.chart_id_var.get().strip().upper()
        chart["Title"] = {"EN": self.chart_title_en_var.get().strip(), "JA": self.chart_title_ja_var.get().strip()}
        chart["XAxisColumn"] = self.x_column_var.get().strip()
        chart["XAxisTitle"] = {"EN": self.x_title_en_var.get().strip(), "JA": self.x_title_ja_var.get().strip()}
        chart["YAxisTitle"] = {"EN": self.y_title_en_var.get().strip(), "JA": self.y_title_ja_var.get().strip()}
        chart["Unit"] = self.unit_var.get().strip()
        chart["PeakPolicy"] = {
            "Highlight": bool(self.peak_highlight_var.get()),
            "DataLabel": bool(self.peak_label_var.get()),
            "PrimarySeriesColumn": self.primary_series_var.get().strip() or None,
        }
        if refresh_list:
            self._refresh_chart_list()
        if show_status:
            self.status_var.set(self._text("Chart settings applied.", "グラフ設定を反映しました。"))

    def _display_chart(self) -> None:
        chart = self._current_chart()
        self.chart_id_var.set(str(chart["ChartId"]))
        self.chart_title_en_var.set(str(chart["Title"].get("EN", "")))
        self.chart_title_ja_var.set(str(chart["Title"].get("JA", "")))
        self.x_column_var.set(str(chart["XAxisColumn"]))
        self.x_title_en_var.set(str(chart["XAxisTitle"].get("EN", "")))
        self.x_title_ja_var.set(str(chart["XAxisTitle"].get("JA", "")))
        self.y_title_en_var.set(str(chart["YAxisTitle"].get("EN", "")))
        self.y_title_ja_var.set(str(chart["YAxisTitle"].get("JA", "")))
        self.unit_var.set(str(chart.get("Unit", "")))
        self.peak_highlight_var.set(bool(chart["PeakPolicy"].get("Highlight")))
        self.peak_label_var.set(bool(chart["PeakPolicy"].get("DataLabel")))
        self.primary_series_var.set(str(chart["PeakPolicy"].get("PrimarySeriesColumn") or ""))
        self._refresh_series_tree()

    def _refresh_chart_list(self) -> None:
        self.chart_list.delete(0, "end")
        for chart in self.profile["Charts"]:
            self.chart_list.insert("end", f"{chart['ChartId']} — {localized(chart['Title'], self.language)}")
        if self.profile["Charts"]:
            self.chart_list.selection_set(self.current_chart_index)

    def _chart_selected(self, _event: Any = None) -> None:
        selected = self.chart_list.curselection()
        if selected:
            selected_index = int(selected[0])
            if selected_index != self.current_chart_index:
                try:
                    self._commit_chart_fields(show_status=False, refresh_list=False)
                except Exception as error:
                    self._error(error)
                    self.chart_list.selection_clear(0, "end")
                    self.chart_list.selection_set(self.current_chart_index)
                    return
            self.current_chart_index = selected_index
            self.current_series_index = None
            self._refresh_chart_list()
            self._display_chart()

    def _add_chart(self) -> None:
        try:
            self._commit_chart_fields(show_status=False, refresh_list=False)
            require(len(self.profile["Charts"]) < MAX_CHARTS, "A Profile supports at most 12 charts.")
            self.profile["Charts"].append(default_chart(self.columns, len(self.profile["Charts"]) + 1))
            self.current_chart_index = len(self.profile["Charts"]) - 1
            self._refresh_chart_list()
            self._display_chart()
        except Exception as error:
            self._error(error)

    def _duplicate_chart(self) -> None:
        try:
            self._commit_chart_fields(show_status=False, refresh_list=False)
            require(len(self.profile["Charts"]) < MAX_CHARTS, "A Profile supports at most 12 charts.")
            existing = {str(item["ChartId"]) for item in self.profile["Charts"]}
            self.profile["Charts"].append(duplicate_chart(self._current_chart(), existing))
            self.current_chart_index = len(self.profile["Charts"]) - 1
            self._refresh_chart_list()
            self._display_chart()
        except Exception as error:
            self._error(error)

    def _delete_chart(self) -> None:
        try:
            require(len(self.profile["Charts"]) > 1, "A Profile must keep at least one chart.")
            del self.profile["Charts"][self.current_chart_index]
            self.current_chart_index = max(0, self.current_chart_index - 1)
            self._refresh_chart_list()
            self._display_chart()
        except Exception as error:
            self._error(error)

    def _refresh_available_columns(self) -> None:
        query = self.search_var.get().strip().casefold()
        self.available_list.delete(0, "end")
        for column in self.columns:
            if column != "FrameCount" and (not query or query in column.casefold()):
                self.available_list.insert("end", column)

    def _add_available_series(self) -> None:
        try:
            selected = self.available_list.curselection()
            require(bool(selected), "Select one available column.")
            column = str(self.available_list.get(selected[0]))
            chart = self._current_chart()
            require(len(chart["Series"]) < MAX_SERIES, "A chart supports at most 12 series.")
            require(column not in {item["Column"] for item in chart["Series"]}, "That column is already plotted.")
            chart["Series"].append(default_series(column, len(chart["Series"])))
            if not chart["PeakPolicy"].get("PrimarySeriesColumn"):
                chart["PeakPolicy"]["PrimarySeriesColumn"] = column
            self._refresh_series_tree()
        except Exception as error:
            self._error(error)

    def _refresh_series_tree(self) -> None:
        self.series_tree.delete(*self.series_tree.get_children())
        chart = self._current_chart()
        for index, series in enumerate(chart["Series"]):
            self.series_tree.insert("", "end", iid=f"S{index}", values=(series["Column"], series["DisplayName"].get("EN", ""), series["DisplayName"].get("JA", ""), series["Color"]))
        columns = [item["Column"] for item in chart["Series"]]
        self.primary_combo.configure(values=["", *columns])
        if chart["PeakPolicy"].get("PrimarySeriesColumn") not in columns:
            chart["PeakPolicy"]["PrimarySeriesColumn"] = columns[0] if columns else None
        self.primary_series_var.set(str(chart["PeakPolicy"].get("PrimarySeriesColumn") or ""))

    def _series_selected(self, _event: Any = None) -> None:
        selected = self.series_tree.selection()
        if not selected:
            return
        index = int(selected[0][1:])
        self.current_series_index = index
        series = self._current_chart()["Series"][index]
        self.series_column_var.set(str(series["Column"]))
        self.series_en_var.set(str(series["DisplayName"].get("EN", "")))
        self.series_ja_var.set(str(series["DisplayName"].get("JA", "")))
        self.series_color_var.set(str(series["Color"]))

    def _commit_series_fields(self) -> None:
        try:
            require(self.current_series_index is not None, "Select one plotted series.")
            series = self._current_chart()["Series"][self.current_series_index]
            color = self.series_color_var.get().strip().upper()
            require(re.fullmatch(r"#[0-9A-F]{6}", color) is not None, "Color must use #RRGGBB.")
            series["DisplayName"] = {"EN": self.series_en_var.get().strip(), "JA": self.series_ja_var.get().strip()}
            series["Color"] = color
            self._refresh_series_tree()
        except Exception as error:
            self._error(error)

    def _remove_series(self) -> None:
        try:
            require(self.current_series_index is not None, "Select one plotted series.")
            chart = self._current_chart()
            require(len(chart["Series"]) > 1, "A chart must keep at least one series.")
            del chart["Series"][self.current_series_index]
            self.current_series_index = None
            self._refresh_series_tree()
        except Exception as error:
            self._error(error)

    def _move_series(self, direction: int) -> None:
        try:
            require(self.current_series_index is not None, "Select one plotted series.")
            series = self._current_chart()["Series"]
            target = self.current_series_index + direction
            require(0 <= target < len(series), "Series is already at that boundary.")
            series[self.current_series_index], series[target] = series[target], series[self.current_series_index]
            self.current_series_index = target
            self._refresh_series_tree()
            self.series_tree.selection_set(f"S{target}")
        except Exception as error:
            self._error(error)

    def _choose_color(self) -> None:
        selected = self.colorchooser.askcolor(color=self.series_color_var.get(), parent=self.root)
        if selected and selected[1]:
            self.series_color_var.set(str(selected[1]).upper())

    def _new_profile(self) -> None:
        self.profile = default_profile(self.columns)
        self.current_chart_index = 0
        self.current_series_index = None
        self.active_profile_path = None
        self._load_profile_into_form()

    def _open_profile(self) -> None:
        path = self.filedialog.askopenfilename(parent=self.root, initialdir=str(self.profile_directory), filetypes=[("U003 Chart Profile", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            profile = read_json_object(Path(path), "Chart Profile")
            self.core.validate_profile(profile)
            self.core.required_columns(profile, self.columns)
            self.profile = profile
            self.active_profile_path = Path(path).resolve()
            self.current_chart_index = 0
            self.current_series_index = None
            self._load_profile_into_form()
            self.status_var.set(self._text("Profile loaded.", "Profileを読み込みました。"))
        except Exception as error:
            self._error(error)

    def _save_profile(self) -> None:
        try:
            self._commit_profile_fields()
            self._commit_chart_fields(show_status=False)
            self.core.validate_profile(self.profile)
            self.core.required_columns(self.profile, self.columns)
            default_name = safe_segment(str(self.profile["ProfileId"]), "U003_chart_profile") + ".json"
            path = self.filedialog.asksaveasfilename(parent=self.root, initialdir=str(self.profile_directory), initialfile=default_name, defaultextension=".json", filetypes=[("U003 Chart Profile", "*.json")])
            if not path:
                return
            target = Path(path).resolve()
            write_json_atomic(target, self.profile)
            self.active_profile_path = target
            self.status_var.set(self._text(f"Profile saved: {target.name}", f"Profile保存: {target.name}"))
        except Exception as error:
            self._error(error)

    def _browse_output(self) -> None:
        path = self.filedialog.askdirectory(parent=self.root, initialdir=self.output_var.get() or str(self.output_directory))
        if path:
            self.output_var.set(path)

    def _refresh_context(self, show_error: bool = False) -> dict[str, Any] | None:
        try:
            context = read_json_object(self.live_context_path, "Live Review Context")
            self.core.validate_live_context(context)
            sequence = int(context.get("Sequence", 0))
            self.latest_context = context
            self.last_sequence = sequence
            event_id = str(context.get("EventID", "NO_EVENT"))
            range_source = str(context.get("RangeSource", ""))
            start = context.get("DefaultRangeStartFrame")
            end = context.get("DefaultRangeEndFrame")
            peak = context.get("EffectivePeakFrame")
            current = context.get("CurrentCANFrameCount")
            self.context_var.set(self._text(f"U003 live | Event {event_id} | Current FC {current} | {range_source} {start}–{end} | Peak {peak}", f"U003連携 | Event {event_id} | 現在FC {current} | {range_source} {start}–{end} | Peak {peak}"))
            return context
        except Exception as error:
            if show_error:
                self._error(error)
            return None

    def _poll_context(self) -> None:
        if not self.root.winfo_exists():
            return
        self._refresh_context(show_error=False)
        self.root.after(POLL_MILLISECONDS, self._poll_context)

    def _active_profile_for_export(self) -> Path:
        self._commit_profile_fields()
        self._commit_chart_fields(show_status=False)
        self.core.validate_profile(self.profile)
        self.core.required_columns(self.profile, self.columns)
        profile_id = safe_segment(str(self.profile["ProfileId"]), "U003_chart_profile")[:32]
        snapshot_directory = self.profile_directory / "export_snapshots"
        timestamp = datetime.now().strftime("%Y%m%dT%H%M%S_%f")
        target = unique_path(snapshot_directory / f"{profile_id}_{timestamp}.json")
        write_json_atomic(target, self.profile)
        self.active_profile_path = target.resolve()
        return self.active_profile_path

    def _optional_int(self, value: str, label: str) -> int | None:
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError as error:
            raise ChartActionError(f"{label} must be an integer.") from error

    def _export(self) -> None:
        try:
            context = self._refresh_context(show_error=False)
            require(context is not None, "Live U003 context is unavailable.")
            profile_path = self._active_profile_for_export()
            output_directory = Path(self.output_var.get().strip()).resolve()
            output_directory.mkdir(parents=True, exist_ok=True)
            requested_name = self.output_name_var.get().strip()
            if requested_name:
                if not requested_name.lower().endswith(".xlsx"):
                    requested_name += ".xlsx"
                output_name = unique_path(output_directory / safe_segment(requested_name, "U003_export.xlsx")).name
            else:
                event_id = safe_segment(str(context.get("EventID", "NO_EVENT")), "NO_EVENT")
                timestamp = datetime.now().strftime("%Y%m%dT%H%M%S_%f")
                output_name = f"U3_{event_id}_{timestamp}.xlsx"
            start_frame = end_frame = None
            if self.explicit_range_var.get():
                start_frame = self._optional_int(self.start_frame_var.get(), "Start FrameCount")
                end_frame = self._optional_int(self.end_frame_var.get(), "End FrameCount")
                require(start_frame is not None and end_frame is not None, "Explicit range requires both FrameCounts.")
            result = self.core.export_editable_xlsx(
                review_data_path=self.review_data_path,
                live_context_path=self.live_context_path,
                profile_path=profile_path,
                output_directory=output_directory,
                output_name=output_name,
                language_override=self.language,
                start_frame=start_frame,
                end_frame=end_frame,
            )
            record = result.as_dict()
            record.update({"Sequence": context.get("Sequence"), "EventID": context.get("EventID"), "ProfilePath": str(profile_path)})
            self.export_records.append(record)
            for artifact in (result.workbook_path, profile_path):
                resolved = str(Path(artifact).resolve())
                if resolved not in self.artifact_paths:
                    self.artifact_paths.append(resolved)
            self.export_result = {
                "ArtifactPaths": list(self.artifact_paths),
                "WorkbookPath": str(result.workbook_path),
                "ProfilePath": str(profile_path),
                "ExportCount": len(self.export_records),
                "ExportRecords": list(self.export_records),
                "ActionSummary": self._text(f"Exported {len(self.export_records)} editable workbook(s); latest {result.start_framecount}–{result.end_framecount} with {result.chart_count} chart(s).", f"編集可能Workbookを{len(self.export_records)}件出力しました。最新範囲{result.start_framecount}–{result.end_framecount}、グラフ{result.chart_count}件です。"),
            }
            self.status_var.set(self._text(f"Exported: {result.workbook_path.name}", f"出力完了: {result.workbook_path.name}"))
            if self.open_folder_var.get():
                open_directory(output_directory)
        except Exception as error:
            self._error(error)

    def _error(self, error: Exception) -> None:
        self.status_var.set(f"ERROR: {error}")
        self.messagebox.showerror(self._text("U003 chart export error", "U003グラフ出力エラー"), str(error), parent=self.root)

    def _close(self) -> None:
        self.root.quit()
        self.root.destroy()

    def run(self) -> dict[str, Any] | None:
        self.root.mainloop()
        return self.export_result


def execute(request_path: Path, result_path: Path) -> int:
    """Execute one governed interactive action request."""

    request = read_json_object(request_path, "Module Action Request")
    require(request.get("ContractId") == "U003_MODULE_ACTION_REQUEST", "Unsupported request contract.")
    require(request.get("ActionId") == ACTION_ID, "Unsupported action identity.")
    context = request.get("Context")
    require(isinstance(context, dict), "Context must be one JSON object.")
    for field in ("SignalDataPath", "LiveReviewContextPath", "OutputDirectory", "ProfileDirectory"):
        require(context.get(field) is not None, f"Required Context field is missing: {field}")
    core = load_export_core(Path(__file__))
    window = EditableXlsxActionWindow(
        core=core,
        language=str(request.get("Language", "EN")),
        review_data_path=Path(str(context["SignalDataPath"])),
        live_context_path=Path(str(context["LiveReviewContextPath"])),
        profile_directory=Path(str(context["ProfileDirectory"])),
        output_directory=Path(str(context["OutputDirectory"])),
    )
    outputs = window.run()
    result = {
        "ContractId": "U003_MODULE_ACTION_RESULT",
        "ContractVersion": "0.1",
        "RequestId": request["RequestId"],
        "RunId": request["RunId"],
        "EventId": request["EventId"],
        "ActionId": request["ActionId"],
        "ModuleId": request["ModuleId"],
        "ModuleVersion": request["ModuleVersion"],
        "Status": "SUCCESS" if outputs is not None else "NO_RESULT",
        "Outputs": outputs or {},
        "Warnings": [],
        "RootCauseClaim": False,
    }
    write_json_atomic(result_path, result)
    return 0


def run_self_test() -> int:
    """Exercise header, Profile and accepted engine integration without opening GUI."""

    core = load_export_core(Path(__file__))
    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u3m9d_") as temporary:
        root = Path(temporary)
        review = root / "review.csv"
        review.write_text(
            "FrameCount,ActiveCandidateIds,IsCandidatePeak,CameraDistance_m,RadarDistance_m,CameraLateralPosition_m\n"
            "100,C001,0,21.0,19.0,0.4\n102,C001,0,20.8,18.7,0.6\n104,C001,1,20.6,,0.9\n"
            "106,C001,0,20.4,,1.2\n108,C001,0,20.2,18.0,0.5\n",
            encoding="utf-8",
        )
        columns = detect_csv_header(review)
        check(columns[0] == "FrameCount")
        check(len(columns) == 6)
        profile = default_profile(columns)
        check(profile["RangePolicy"]["BeforeRows"] == 100)
        check(len(profile["Charts"]) == 1)
        check(len(profile["Charts"][0]["Series"]) == 2)
        check(profile["Charts"][0]["Series"][0]["Column"] == "CameraDistance_m")
        check(profile["Charts"][0]["Series"][1]["Column"] == "RadarDistance_m")
        check(profile["OutputPolicy"]["TableStyle"] == "TableStyleMedium2")
        check(profile["Charts"][0]["XAxisColumn"] == "FrameCount")
        core.validate_profile(profile)
        check(core.required_columns(profile, columns)[0] == "FrameCount")
        copied = duplicate_chart(profile["Charts"][0], {"CHART_01"})
        check(copied["ChartId"] == "CHART_01_COPY")
        profile["Charts"].append(copied)
        core.validate_profile(profile)
        check(len(profile["Charts"]) == 2)
        context = {
            "ContractId": "U003_LIVE_REVIEW_CONTEXT",
            "ContractVersion": "0.1",
            "Sequence": 7,
            "CurrentCANFrameCount": 104,
            "EventID": "C001",
            "ReviewStartFrame": 101,
            "PeakFrameCount": 105,
            "ReviewEndFrame": 108,
            "EffectivePeakFrame": 105,
            "Language": "EN",
        }
        context_path = root / "live.json"
        write_json_atomic(context_path, context)
        profile_path = root / "profile.json"
        write_json_atomic(profile_path, profile)
        result = core.export_editable_xlsx(
            review_data_path=review,
            live_context_path=context_path,
            profile_path=profile_path,
            output_directory=root / "output",
            output_name="u3m9d.xlsx",
        )
        check(result.workbook_path.is_file())
        check(result.chart_count == 2)
        check(result.range_source == "EVENT")
        check(result.start_framecount == 102)
        check(result.end_framecount == 108)
        check(result.effective_peak_framecount == 104)
        check(result.copied_columns == ("FrameCount", "CameraDistance_m", "RadarDistance_m"))
        check(localized({"EN": "Name", "JA": "名前"}, "JA") == "名前")
        check(localized({"EN": "Name", "JA": ""}, "JA") == "Name")
        check(safe_segment("A / B", "X") == "A_B")
        occupied = root / "occupied.xlsx"
        occupied.write_bytes(b"x")
        check(unique_path(occupied).name == "occupied_002.xlsx")
        check(MODULE_VERSION == "0.2.2")
        check(MAX_CHARTS == 12 and MAX_SERIES == 12)
        profile_panel_source = inspect.getsource(EditableXlsxActionWindow._build_profile_panel)
        output_definition = profile_panel_source.find("output_box = ttk.LabelFrame")
        output_first_use = profile_panel_source.find("ttk.Label(output_box")
        check(output_definition >= 0)
        check(output_first_use > output_definition)

        class FakeWidget:
            def grid(self, *_args: Any, **_kwargs: Any) -> None:
                return None

            def columnconfigure(self, *_args: Any, **_kwargs: Any) -> None:
                return None

        class FakeTtk:
            def __getattr__(self, _name: str) -> Any:
                return lambda *_args, **_kwargs: FakeWidget()

        panel_probe = object.__new__(EditableXlsxActionWindow)
        panel_probe.ttk = FakeTtk()
        panel_probe._text = lambda english, _japanese: english
        panel_probe._entry_row = lambda *_args, **_kwargs: None
        for variable_name in (
            "profile_id_var",
            "profile_version_var",
            "profile_en_var",
            "profile_ja_var",
            "event_priority_var",
            "before_rows_var",
            "after_rows_var",
            "explicit_range_var",
            "start_frame_var",
            "end_frame_var",
            "output_var",
            "output_name_var",
            "open_folder_var",
            "table_style_var",
        ):
            setattr(panel_probe, variable_name, object())
        for callback_name in (
            "_open_profile",
            "_save_profile",
            "_new_profile",
            "_browse_output",
        ):
            setattr(panel_probe, callback_name, lambda: None)
        panel_probe._build_profile_panel(FakeWidget())
        check(isinstance(panel_probe.table_style_combo, FakeWidget))
        output = root / "result.json"
        write_json_atomic(output, result.as_dict())
        check(read_json_object(output, "Result")["Status"] == "SPASS")

    print(f"U3M9E-SELFTEST-PASS-{checks} C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--execute", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--result", type=Path)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    if arguments.self_test:
        return run_self_test()
    require(arguments.request is not None and arguments.result is not None, "--execute requires --request and --result.")
    return execute(arguments.request, arguments.result)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M9EE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
