#!/usr/bin/env python3
"""Independent acceptance gate for the U3M9E XLSX action GUI repair."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


MODULE_ID = "CameraRadar.U003.EditableXlsxCharts"
MODULE_VERSION = "0.2.2"
CORE_NAME = "u003_editable_xlsx_export_core_v0_2_1.py"
CORE_SELFTEST_CAPSULE = "U3M9D-CORE-SELFTEST-PASS-35 C-0"
MODULE_SELFTEST_CAPSULE = "U3M9E-SELFTEST-PASS-29 C-0"


class GateError(RuntimeError):
    """Raised when U3M9D cannot prove one required invariant."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_foundation(program_root: Path) -> Any:
    path = program_root / "u003_module_runtime_v0_2.py"
    if not path.is_file():
        raise GateError(f"U003 module runtime is missing: {path}")
    specification = importlib.util.spec_from_file_location("u003_module_runtime_v0_2", path)
    if specification is None or specification.loader is None:
        raise GateError("U003 module runtime could not be loaded.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def run_child(
    command: list[str],
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        timeout=180,
        check=False,
        env=environment,
    )


def run_gate(root: Path, module_directory: Path, core_path: Path) -> int:
    root = root.resolve()
    module_directory = module_directory.resolve()
    core_path = core_path.resolve()
    program_root = root / "01_PROGRAMS"
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise GateError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    required = (
        core_path,
        program_root / "u003_module_runtime_v0_2.py",
        program_root / "u003_module_executor_v0_3.py",
        program_root / "u003_module_action_gui_v0_2.py",
        program_root / "u003_live_review_context_v0_1.py",
        module_directory / "module_manifest.json",
        module_directory / "algorithm_card.json",
        module_directory / "implementation.py",
    )
    for path in required:
        check(path.is_file(), f"required file {path.name}", "prepared and installed topology is complete")

    manifest = json.loads((module_directory / "module_manifest.json").read_text(encoding="utf-8"))
    card = json.loads((module_directory / "algorithm_card.json").read_text(encoding="utf-8"))
    check(manifest["ModuleId"] == MODULE_ID, "Module identity", "registry key remains stable")
    check(manifest["ModuleVersion"] == MODULE_VERSION, "Module version", "visual repair is a new selectable version")
    check(manifest["ModuleSlot"] == "EXPORT", "Module slot", "workbook formatting does not change review evidence")
    check(manifest["EnabledByDefault"] is False, "explicit activation", "engineer controls optional export")
    check(len(manifest["UserActions"]) == 1, "one action", "action inventory is deterministic")
    action = manifest["UserActions"][0]
    check(action["ActionId"] == "EXPORT_EDITABLE_XLSX_CHARTS", "action identity", "v0.1 Profiles remain compatible")
    check(card["AlgorithmCardId"].endswith("0.2.2"), "Algorithm Card identity", "design and source version agree")
    check(len(card["Validation"]) >= 22, "validation coverage", "visual, path and GUI construction invariants are recorded")

    foundation = load_foundation(program_root)
    descriptor = foundation.validate_module_manifest(
        module_directory / "module_manifest.json",
        module_directory.parents[2],
    )
    check(descriptor.module_id == MODULE_ID, "runtime discovery", "U003 registry accepts the repaired Module")
    check(descriptor.module_version == MODULE_VERSION, "runtime version", "registry does not select the old release by mistake")
    check(descriptor.process_transport == "PYTHON_SOURCE", "source transport", "high-code implementation remains inspectable")

    core_source = core_path.read_text(encoding="utf-8")
    module_source = (module_directory / "implementation.py").read_text(encoding="utf-8")
    for token, reason in (
        ("ScatterChart", "FrameCount is a numeric axis"),
        ("TableStyleInfo", "Source Data is an Excel Table"),
        ("peak_marker_height", "Peak is one elevated marker"),
        ("nice_integer_step", "X labels use a readable interval"),
        ("compact_output_path", "Windows path length is bounded"),
        ("helpers.sheet_state = \"hidden\"", "chart helper cells stay out of the engineer view"),
    ):
        check(token in core_source, f"core token {token}", reason)
    for token, reason in (
        ("is_default_plot_column", "control metadata is excluded from default charts"),
        ("ActiveCandidateIds", "candidate ID exclusion is explicit"),
        ("IsCandidatePeak", "legacy peak flag exclusion is explicit"),
        ("TableStyleMedium2", "a native table style is selected by default"),
        ("Y-axis label EN", "axis label is visually editable"),
        ("Physical unit", "unit is visually editable as a separate field"),
    ):
        check(token in module_source, f"Module token {token}", reason)
    output_definition = module_source.find("output_box = ttk.LabelFrame")
    output_first_use = module_source.find("ttk.Label(output_box")
    check(output_definition >= 0, "Output panel definition", "the GUI declares the container explicitly")
    check(output_first_use > output_definition, "Output panel construction order", "widgets cannot reference an unbound container")

    core_result = run_child([sys.executable, str(core_path), "--self-test"])
    if core_result.stdout:
        print(core_result.stdout.strip())
    if core_result.stderr:
        print(core_result.stderr.strip())
    check(core_result.returncode == 0, "core self-test exit", "workbook semantics execute")
    check(CORE_SELFTEST_CAPSULE in core_result.stdout, "core self-test capsule", "35 checks completed")

    environment = dict(os.environ)
    environment["U003_EDITABLE_XLSX_CORE_PATH"] = str(core_path)
    module_result = run_child(
        [sys.executable, str(module_directory / "implementation.py"), "--self-test"],
        environment,
    )
    if module_result.stdout:
        print(module_result.stdout.strip())
    if module_result.stderr:
        print(module_result.stderr.strip())
    check(module_result.returncode == 0, "Module self-test exit", "Profile and engine integration execute")
    check(MODULE_SELFTEST_CAPSULE in module_result.stdout, "Module self-test capsule", "29 checks completed")

    check(sha256_file(core_path) != sha256_file(module_directory / "implementation.py"), "separate identities", "engine and GUI adapter remain decoupled")
    print(f"U3M9EG1 N-M1-C1-P1-T{checks}-X0 C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--module-dir", type=Path, required=True)
    parser.add_argument("--core", type=Path, required=True)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    return run_gate(arguments.root, arguments.module_dir, arguments.core)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M9EGE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
