#!/usr/bin/env python3
"""Deterministic synthetic adapter for U001 host qualification.

This is a contract fixture, not a production data source adapter.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from typing import Any


ADAPTER_ID = "Foundation.Test.SyntheticInputAdapter"
ADAPTER_VERSION = "0.1.0"
HOST_API_VERSION = "U001_INPUT_ADAPTER_HOST_API_V0_1"
REQUEST_SCHEMA = "U001_INPUT_ADAPTER_REQUEST_V0_1"
OUTPUT_SCHEMA = "U001_CANONICAL_SOURCE_UPDATES_V0_1"

UPDATE_FILE = "u001_adapter_source_updates.csv"
CATALOG_FILE = "u001_adapter_signal_catalog.csv"
QUALITY_FILE = "u001_adapter_quality.json"
MANIFEST_FILE = "u001_adapter_run_manifest.json"
CAPSULE_FILE = "u001_adapter_completion_capsule.txt"

UPDATE_COLUMNS = [
    "SourceRowIndex",
    "SourceId",
    "SourceType",
    "SourceAdapterId",
    "SourceAdapterVersion",
    "ClockDomain",
    "NativeTimestamp",
    "NativeSequence",
    "SyncKeyCandidate",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "RawCode",
    "PhysicalValue",
    "ValueLabel",
    "OriginalUnit",
    "ValueKindHint",
    "DecodeValid",
    "DecodeIssue",
]


class AdapterError(RuntimeError):
    """Fail-closed synthetic adapter error."""


def _read_request(path: Path) -> dict[str, Any]:
    try:
        request = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AdapterError(f"REQUEST_JSON:{exc}") from exc
    if not isinstance(request, dict):
        raise AdapterError("REQUEST_NOT_OBJECT")
    required = ("RequestSchemaVersion", "RequestId", "DatasetId", "RunId", "SegmentId", "SourceId")
    for key in required:
        if not isinstance(request.get(key), str) or not request[key].strip():
            raise AdapterError(f"REQUEST_FIELD:{key}")
    if request["RequestSchemaVersion"] != REQUEST_SCHEMA:
        raise AdapterError("REQUEST_SCHEMA")
    if request.get("TestMode") is not True:
        raise AdapterError("TEST_MODE_REQUIRED")
    return request


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def describe() -> dict[str, Any]:
    return {
        "AdapterId": ADAPTER_ID,
        "AdapterVersion": ADAPTER_VERSION,
        "HostApiVersion": HOST_API_VERSION,
        "OutputBoundary": OUTPUT_SCHEMA,
        "SupportedActions": ["DESCRIBE", "SELF_TEST", "PREFLIGHT", "RUN"],
    }


def preflight(request_path: Path, output_dir: Path) -> dict[str, Any]:
    request = _read_request(request_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    result = {
        "PreflightSchema": "U001_INPUT_ADAPTER_PREFLIGHT_V0_1",
        "AdapterId": ADAPTER_ID,
        "AdapterVersion": ADAPTER_VERSION,
        "RequestId": request["RequestId"],
        "Status": "READY",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    (output_dir / "u001_adapter_preflight.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return result


def _write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def run(request_path: Path, output_dir: Path) -> dict[str, Any]:
    request = _read_request(request_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise AdapterError("OUTPUT_NOT_EMPTY")

    source_id = request["SourceId"]
    rows = [
        {
            "SourceRowIndex": 0,
            "SourceId": source_id,
            "SourceType": "SYNTHETIC",
            "SourceAdapterId": ADAPTER_ID,
            "SourceAdapterVersion": ADAPTER_VERSION,
            "ClockDomain": "SYNTHETIC_SEQUENCE",
            "NativeTimestamp": "",
            "NativeSequence": 0,
            "SyncKeyCandidate": 100,
            "SourceChannel": "SYNTHETIC",
            "SourceMessageId": "FRAME",
            "SourceMessageName": "SyntheticFrame",
            "SourceSignalName": "FrameIndex",
            "CanonicalNameCandidate": "Synthetic.FrameIndex",
            "RawCode": 100,
            "PhysicalValue": 100,
            "ValueLabel": "",
            "OriginalUnit": "count",
            "ValueKindHint": "INTEGER",
            "DecodeValid": 1,
            "DecodeIssue": "",
        },
        {
            "SourceRowIndex": 0,
            "SourceId": source_id,
            "SourceType": "SYNTHETIC",
            "SourceAdapterId": ADAPTER_ID,
            "SourceAdapterVersion": ADAPTER_VERSION,
            "ClockDomain": "SYNTHETIC_SEQUENCE",
            "NativeTimestamp": "",
            "NativeSequence": 0,
            "SyncKeyCandidate": 100,
            "SourceChannel": "SYNTHETIC",
            "SourceMessageId": "VALUE",
            "SourceMessageName": "SyntheticValue",
            "SourceSignalName": "Distance",
            "CanonicalNameCandidate": "Synthetic.Distance",
            "RawCode": 1234,
            "PhysicalValue": 12.34,
            "ValueLabel": "",
            "OriginalUnit": "m",
            "ValueKindHint": "FLOAT",
            "DecodeValid": 1,
            "DecodeIssue": "",
        },
        {
            "SourceRowIndex": 1,
            "SourceId": source_id,
            "SourceType": "SYNTHETIC",
            "SourceAdapterId": ADAPTER_ID,
            "SourceAdapterVersion": ADAPTER_VERSION,
            "ClockDomain": "SYNTHETIC_SEQUENCE",
            "NativeTimestamp": "",
            "NativeSequence": 1,
            "SyncKeyCandidate": 101,
            "SourceChannel": "SYNTHETIC",
            "SourceMessageId": "VALUE",
            "SourceMessageName": "SyntheticValue",
            "SourceSignalName": "Distance",
            "CanonicalNameCandidate": "Synthetic.Distance",
            "RawCode": 1250,
            "PhysicalValue": 12.5,
            "ValueLabel": "",
            "OriginalUnit": "m",
            "ValueKindHint": "FLOAT",
            "DecodeValid": 1,
            "DecodeIssue": "",
        },
    ]
    updates_path = output_dir / UPDATE_FILE
    _write_csv(updates_path, UPDATE_COLUMNS, rows)

    catalog_columns = [
        "SourceAdapterId",
        "SourceAdapterVersion",
        "SourceType",
        "SourceChannel",
        "SourceMessageId",
        "SourceMessageName",
        "SourceSignalName",
        "CanonicalNameCandidate",
        "OriginalUnit",
        "ValueKindHint",
        "DecodeDefinition",
    ]
    catalog_rows = [
        {
            "SourceAdapterId": ADAPTER_ID,
            "SourceAdapterVersion": ADAPTER_VERSION,
            "SourceType": "SYNTHETIC",
            "SourceChannel": "SYNTHETIC",
            "SourceMessageId": "FRAME",
            "SourceMessageName": "SyntheticFrame",
            "SourceSignalName": "FrameIndex",
            "CanonicalNameCandidate": "Synthetic.FrameIndex",
            "OriginalUnit": "count",
            "ValueKindHint": "INTEGER",
            "DecodeDefinition": "IDENTITY",
        },
        {
            "SourceAdapterId": ADAPTER_ID,
            "SourceAdapterVersion": ADAPTER_VERSION,
            "SourceType": "SYNTHETIC",
            "SourceChannel": "SYNTHETIC",
            "SourceMessageId": "VALUE",
            "SourceMessageName": "SyntheticValue",
            "SourceSignalName": "Distance",
            "CanonicalNameCandidate": "Synthetic.Distance",
            "OriginalUnit": "m",
            "ValueKindHint": "FLOAT",
            "DecodeDefinition": "RAW_CODE*0.01",
        },
    ]
    catalog_path = output_dir / CATALOG_FILE
    _write_csv(catalog_path, catalog_columns, catalog_rows)

    quality = {
        "QualitySchema": "U001_INPUT_ADAPTER_QUALITY_V0_1",
        "AdapterId": ADAPTER_ID,
        "AdapterVersion": ADAPTER_VERSION,
        "SourceRowCount": 2,
        "DecodedUpdateCount": 3,
        "SignalCount": 2,
        "DecodeFailureCount": 0,
        "AbsolutePathLeakCount": 0,
        "Warnings": [],
        "Errors": [],
    }
    quality_path = output_dir / QUALITY_FILE
    quality_path.write_text(json.dumps(quality, indent=2) + "\n", encoding="utf-8")

    artifacts = []
    for path in (updates_path, catalog_path, quality_path):
        artifacts.append(
            {"FileName": path.name, "SizeBytes": path.stat().st_size, "SHA256": _sha256(path)}
        )
    manifest = {
        "ManifestSchema": "U001_INPUT_ADAPTER_RUN_MANIFEST_V0_1",
        "OutputBoundary": OUTPUT_SCHEMA,
        "AdapterId": ADAPTER_ID,
        "AdapterVersion": ADAPTER_VERSION,
        "RequestId": request["RequestId"],
        "DatasetId": request["DatasetId"],
        "RunId": request["RunId"],
        "SegmentId": request["SegmentId"],
        "SourceId": source_id,
        "InputBasenames": [],
        "Artifacts": artifacts,
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    manifest_path = output_dir / MANIFEST_FILE
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    capsule = "U1H1A-N2-S2-U3-X0-C0\n"
    (output_dir / CAPSULE_FILE).write_text(capsule, encoding="utf-8")
    return manifest


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    check(describe()["AdapterId"] == ADAPTER_ID, "T01")
    check(describe()["OutputBoundary"] == OUTPUT_SCHEMA, "T02")
    with tempfile.TemporaryDirectory(prefix="u001_h1_adapter_") as temporary:
        root = Path(temporary)
        request_path = root / "request.json"
        request = {
            "RequestSchemaVersion": REQUEST_SCHEMA,
            "RequestId": "QUALIFICATION_REQUEST",
            "DatasetId": "SYNTHETIC_DATASET",
            "RunId": "SYNTHETIC_RUN",
            "SegmentId": "SEGMENT_001",
            "SourceId": "SYNTHETIC_SOURCE",
            "TestMode": True,
            "Inputs": [],
            "Configuration": {},
        }
        request_path.write_text(json.dumps(request), encoding="utf-8")
        preflight_result = preflight(request_path, root / "preflight")
        check(preflight_result["Status"] == "READY", "T03")
        check(preflight_result["CompletionCode"] == 0, "T04")
        output = root / "output"
        manifest = run(request_path, output)
        check(manifest["Status"] == "COMPLETE", "T05")
        check(len(manifest["Artifacts"]) == 3, "T06")
        check((output / UPDATE_FILE).is_file(), "T07")
        check((output / CATALOG_FILE).is_file(), "T08")
        check((output / QUALITY_FILE).is_file(), "T09")
        check((output / MANIFEST_FILE).is_file(), "T10")
        check((output / CAPSULE_FILE).read_text(encoding="utf-8").strip().endswith("C0"), "T11")
        with updates_file_open(output / UPDATE_FILE) as rows:
            check(len(rows) == 3, "T12")
            check(list(rows[0]) == UPDATE_COLUMNS, "T13")
            check(rows[1]["PhysicalValue"] == "12.34", "T14")
        check(quality_path_has_no_error(output / QUALITY_FILE), "T15")
        check(all(len(item["SHA256"]) == 64 for item in manifest["Artifacts"]), "T16")

    if checks != 16:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H1-SYNTHETIC-ADAPTER-SELFTEST-PASS-16")


class updates_file_open:
    """Small context manager returning all CSV rows for deterministic tests."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.stream = None

    def __enter__(self) -> list[dict[str, str]]:
        self.stream = self.path.open("r", encoding="utf-8", newline="")
        return list(csv.DictReader(self.stream))

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.stream is not None:
            self.stream.close()


def quality_path_has_no_error(path: Path) -> bool:
    quality = json.loads(path.read_text(encoding="utf-8"))
    return quality["DecodeFailureCount"] == 0 and not quality["Errors"]


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Synthetic U001 Input Adapter")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--describe", action="store_true")
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--preflight", action="store_true")
    action.add_argument("--run", action="store_true")
    parser.add_argument("--request", type=Path)
    parser.add_argument("--out", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.describe:
            print(json.dumps(describe(), ensure_ascii=False))
            return 0
        if args.self_test:
            self_test()
            return 0
        if args.request is None or args.out is None:
            raise AdapterError("ACTION_ARGUMENTS")
        if args.preflight:
            preflight(args.request, args.out)
            print("U1H1AP-N1-X0-C0")
            return 0
        if args.run:
            run(args.request, args.out)
            print("U1H1A-N2-S2-U3-X0-C0")
            return 0
        raise AdapterError("ACTION")
    except (AdapterError, AssertionError) as exc:
        print(f"U1H1AE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())

