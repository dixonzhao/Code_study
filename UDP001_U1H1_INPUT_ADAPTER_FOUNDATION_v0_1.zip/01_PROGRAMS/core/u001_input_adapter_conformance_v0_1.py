#!/usr/bin/env python3
"""Independent conformance gate for U001 Input Adapters."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from u001_input_adapter_registry_v0_1 import RegistryError, validate_card


PROGRAM_NAME = "u001_input_adapter_conformance"
PROGRAM_VERSION = "0.1.0"
REQUEST_SCHEMA = "U001_INPUT_ADAPTER_REQUEST_V0_1"
QUALIFICATION_SCHEMA = "U001_INPUT_ADAPTER_QUALIFICATION_RECEIPT_V0_1"
EXPECTED_SOURCE_ARTIFACTS = {
    "u001_adapter_source_updates.csv",
    "u001_adapter_signal_catalog.csv",
    "u001_adapter_quality.json",
    "u001_adapter_run_manifest.json",
    "u001_adapter_completion_capsule.txt",
}
REQUIRED_UPDATE_COLUMNS = [
    "SourceRowIndex",
    "SourceId",
    "SourceType",
    "SourceAdapterId",
    "SourceAdapterVersion",
    "ClockDomain",
    "NativeTimestamp",
    "NativeSequence",
    "SyncKeyCandidate",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "RawCode",
    "PhysicalValue",
    "ValueLabel",
    "OriginalUnit",
    "ValueKindHint",
    "DecodeValid",
    "DecodeIssue",
]


class ConformanceError(RuntimeError):
    """Fail-closed adapter qualification error."""


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ConformanceError(f"JSON:{path.name}:{exc}") from exc
    if not isinstance(value, dict):
        raise ConformanceError(f"JSON_NOT_OBJECT:{path.name}")
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _run(command: list[str], timeout_seconds: int = 60) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise ConformanceError("ADAPTER_TIMEOUT") from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip().replace("\n", " | ")[:500]
        raise ConformanceError(f"ADAPTER_EXIT:{result.returncode}:{detail}")
    return result


def _contains_absolute_path(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_contains_absolute_path(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_absolute_path(item) for item in value)
    if not isinstance(value, str):
        return False
    return value.startswith(("/", "\\\\")) or bool(re.match(r"^[A-Za-z]:[\\/]", value))


def _validate_csv_header(path: Path, required: list[str]) -> int:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != required:
            raise ConformanceError(f"CSV_HEADER:{path.name}")
        return sum(1 for _ in reader)


def qualify_adapter(adapter_dir: Path, output_dir: Path) -> dict[str, Any]:
    adapter_dir = adapter_dir.resolve()
    card_path = adapter_dir / "adapter_card.json"
    if not card_path.is_file():
        raise ConformanceError("CARD_MISSING")
    try:
        record = validate_card(_load_json(card_path), adapter_dir, adapter_dir.parent.parent)
    except (RegistryError, ValueError) as exc:
        raise ConformanceError(f"CARD:{exc}") from exc

    entry_point = adapter_dir / record.entry_point
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise ConformanceError("QUALIFICATION_OUTPUT_NOT_EMPTY")

    describe_result = _run([sys.executable, str(entry_point), "--describe"])
    try:
        description = json.loads(describe_result.stdout)
    except json.JSONDecodeError as exc:
        raise ConformanceError("DESCRIBE_JSON") from exc
    if description.get("AdapterId") != record.adapter_id:
        raise ConformanceError("DESCRIBE_ID")
    if description.get("AdapterVersion") != record.adapter_version:
        raise ConformanceError("DESCRIBE_VERSION")
    if description.get("OutputBoundary") != record.output_boundary:
        raise ConformanceError("DESCRIBE_BOUNDARY")

    selftest_result = _run([sys.executable, str(entry_point), "--self-test"])
    if "SELFTEST-PASS" not in selftest_result.stdout:
        raise ConformanceError("SELFTEST_CAPSULE")

    request = {
        "RequestSchemaVersion": REQUEST_SCHEMA,
        "RequestId": "U001_H1_QUALIFICATION_REQUEST",
        "DatasetId": "U001_H1_SYNTHETIC_DATASET",
        "RunId": "U001_H1_SYNTHETIC_RUN",
        "SegmentId": "SEGMENT_001",
        "SourceId": "SYNTHETIC_SOURCE_001",
        "TestMode": True,
        "Inputs": [],
        "Configuration": {},
    }
    request_path = output_dir / "qualification_request.json"
    request_path.write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")

    preflight_dir = output_dir / "preflight"
    preflight_result = _run(
        [
            sys.executable,
            str(entry_point),
            "--preflight",
            "--request",
            str(request_path),
            "--out",
            str(preflight_dir),
        ]
    )
    preflight = _load_json(preflight_dir / "u001_adapter_preflight.json")
    if preflight.get("Status") != "READY" or preflight.get("CompletionCode") != 0:
        raise ConformanceError("PREFLIGHT_STATUS")
    if "C0" not in preflight_result.stdout.replace("-", ""):
        raise ConformanceError("PREFLIGHT_CAPSULE")

    run_dir = output_dir / "run"
    run_result = _run(
        [
            sys.executable,
            str(entry_point),
            "--run",
            "--request",
            str(request_path),
            "--out",
            str(run_dir),
        ]
    )
    actual_files = {path.name for path in run_dir.iterdir() if path.is_file()}
    if record.output_boundary == "U001_CANONICAL_SOURCE_UPDATES_V0_1":
        if actual_files != EXPECTED_SOURCE_ARTIFACTS:
            raise ConformanceError(f"ARTIFACT_SET:{sorted(actual_files)}")
        update_count = _validate_csv_header(run_dir / "u001_adapter_source_updates.csv", REQUIRED_UPDATE_COLUMNS)
        if update_count < 1:
            raise ConformanceError("EMPTY_UPDATES")
    else:
        raise ConformanceError("LEGACY_ADAPTER_QUALIFICATION_NOT_IMPLEMENTED")

    manifest = _load_json(run_dir / "u001_adapter_run_manifest.json")
    if manifest.get("AdapterId") != record.adapter_id or manifest.get("AdapterVersion") != record.adapter_version:
        raise ConformanceError("MANIFEST_IDENTITY")
    if manifest.get("OutputBoundary") != record.output_boundary:
        raise ConformanceError("MANIFEST_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise ConformanceError("MANIFEST_STATUS")
    if _contains_absolute_path(manifest):
        raise ConformanceError("ABSOLUTE_PATH_LEAK")

    artifact_entries = manifest.get("Artifacts")
    if not isinstance(artifact_entries, list) or not artifact_entries:
        raise ConformanceError("MANIFEST_ARTIFACTS")
    for artifact in artifact_entries:
        if not isinstance(artifact, dict):
            raise ConformanceError("MANIFEST_ARTIFACT_ENTRY")
        name = artifact.get("FileName")
        if not isinstance(name, str) or Path(name).name != name:
            raise ConformanceError("MANIFEST_ARTIFACT_NAME")
        artifact_path = run_dir / name
        if not artifact_path.is_file():
            raise ConformanceError(f"MANIFEST_ARTIFACT_MISSING:{name}")
        if artifact.get("SizeBytes") != artifact_path.stat().st_size:
            raise ConformanceError(f"MANIFEST_SIZE:{name}")
        if artifact.get("SHA256") != _sha256(artifact_path):
            raise ConformanceError(f"MANIFEST_HASH:{name}")

    quality = _load_json(run_dir / "u001_adapter_quality.json")
    if quality.get("Errors") not in ([], None) or quality.get("AbsolutePathLeakCount") != 0:
        raise ConformanceError("QUALITY_STATUS")
    completion_capsule = (run_dir / "u001_adapter_completion_capsule.txt").read_text(encoding="utf-8").strip()
    if not completion_capsule.endswith("C0") or "C7" in completion_capsule:
        raise ConformanceError("RUN_CAPSULE")
    if "C0" not in run_result.stdout.replace("-", ""):
        raise ConformanceError("RUN_STDOUT_CAPSULE")

    receipt = {
        "QualificationSchema": QUALIFICATION_SCHEMA,
        "GateProgram": PROGRAM_NAME,
        "GateProgramVersion": PROGRAM_VERSION,
        "AdapterId": record.adapter_id,
        "AdapterVersion": record.adapter_version,
        "AdapterClass": record.adapter_class,
        "OutputBoundary": record.output_boundary,
        "CardSHA256": _sha256(card_path),
        "EntryPointSHA256": _sha256(entry_point),
        "DescribePassed": True,
        "SelfTestPassed": True,
        "PreflightPassed": True,
        "SyntheticRunPassed": True,
        "ArtifactValidationPassed": True,
        "AbsolutePathLeakCount": 0,
        "Status": "QUALIFIED",
        "CompletionCode": 0,
    }
    receipt_path = output_dir / "qualification_receipt.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    (output_dir / "qualification_capsule.txt").write_text("U1H1Q-N1-T5-X0-C0\n", encoding="utf-8")
    return receipt


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    adapter_dir = (
        Path(__file__).resolve().parents[1]
        / "adapters"
        / "Foundation.Test.SyntheticInputAdapter"
        / "0.1.0"
    )
    check(adapter_dir.is_dir(), "T01")
    check((adapter_dir / "adapter_card.json").is_file(), "T02")
    check((adapter_dir / "adapter.py").is_file(), "T03")
    with tempfile.TemporaryDirectory(prefix="u001_h1_qualification_") as temporary:
        output_dir = Path(temporary) / "qualification"
        receipt = qualify_adapter(adapter_dir, output_dir)
        check(receipt["Status"] == "QUALIFIED", "T04")
        check(receipt["CompletionCode"] == 0, "T05")
        check(receipt["DescribePassed"] is True, "T06")
        check(receipt["SelfTestPassed"] is True, "T07")
        check(receipt["PreflightPassed"] is True, "T08")
        check(receipt["SyntheticRunPassed"] is True, "T09")
        check(receipt["ArtifactValidationPassed"] is True, "T10")
        check(receipt["AbsolutePathLeakCount"] == 0, "T11")
        check((output_dir / "qualification_receipt.json").is_file(), "T12")
        check((output_dir / "qualification_capsule.txt").read_text().strip().endswith("C0"), "T13")
        check((output_dir / "run" / "u001_adapter_source_updates.csv").is_file(), "T14")
        check((output_dir / "run" / "u001_adapter_signal_catalog.csv").is_file(), "T15")
        check((output_dir / "run" / "u001_adapter_quality.json").is_file(), "T16")
        check((output_dir / "run" / "u001_adapter_run_manifest.json").is_file(), "T17")
        check((output_dir / "run" / "u001_adapter_completion_capsule.txt").is_file(), "T18")
        check(len(receipt["CardSHA256"]) == 64, "T19")
        check(len(receipt["EntryPointSHA256"]) == 64, "T20")

    if checks != 20:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H1-CONFORMANCE-SELFTEST-PASS-20")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 Input Adapter Conformance Gate")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--qualify", action="store_true")
    parser.add_argument("--adapter-dir", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.adapter_dir is None or args.output is None:
            raise ConformanceError("QUALIFY_ARGUMENTS")
        receipt = qualify_adapter(args.adapter_dir, args.output)
        print(
            "U1H1Q-"
            f"N{1 if receipt['Status'] == 'QUALIFIED' else 0}-"
            "T5-X0-C0"
        )
        return 0
    except (ConformanceError, RegistryError, AssertionError) as exc:
        print(f"U1H1QE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())

