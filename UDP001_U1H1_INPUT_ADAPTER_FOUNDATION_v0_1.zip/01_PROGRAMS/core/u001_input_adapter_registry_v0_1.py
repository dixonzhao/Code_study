#!/usr/bin/env python3
"""Registry for versioned U001 source Input Adapters.

The registry performs structural discovery only. It never imports adapter code,
reads company source data or decides which signals are relevant to an analysis.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable


PROGRAM_NAME = "u001_input_adapter_registry"
PROGRAM_VERSION = "0.1.0"
CARD_VERSION = "U001_INPUT_ADAPTER_CARD_V0_1"
HOST_API_VERSION = "U001_INPUT_ADAPTER_HOST_API_V0_1"
REGISTRY_SCHEMA = "U001_INPUT_ADAPTER_REGISTRY_SNAPSHOT_V0_1"

ADAPTER_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*(\.[A-Za-z][A-Za-z0-9]*){2,}$")
SEMVER_RE = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
ENTRY_POINT_RE = re.compile(r"^[A-Za-z0-9_.-]+\.py$")
REQUIRED_ACTIONS = {"DESCRIBE", "SELF_TEST", "PREFLIGHT", "RUN"}
ALLOWED_CLASSES = {"SOURCE_ADAPTER", "LEGACY_PACKAGE_ADAPTER"}
ALLOWED_BOUNDARIES = {
    "U001_CANONICAL_SOURCE_UPDATES_V0_1",
    "U001_DATA_CONTRACT_PACKAGE_V0_1",
}


class RegistryError(RuntimeError):
    """Fail-closed adapter registry error."""


@dataclass(frozen=True)
class AdapterRecord:
    adapter_id: str
    adapter_version: str
    adapter_class: str
    output_boundary: str
    entry_point: str
    package_path: str
    display_name_en: str
    display_name_ja: str
    description_en: str
    description_ja: str
    input_kinds: list[str]


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RegistryError(f"CARD_JSON:{path.name}:{exc}") from exc
    if not isinstance(value, dict):
        raise RegistryError(f"CARD_NOT_OBJECT:{path.name}")
    return value


def _require_string(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        raise RegistryError(f"CARD_FIELD:{key}")
    return value.strip()


def _language_text(mapping: dict[str, Any], key: str) -> tuple[str, str]:
    value = mapping.get(key)
    if not isinstance(value, dict):
        raise RegistryError(f"CARD_FIELD:{key}")
    english = value.get("EN")
    japanese = value.get("JA", "")
    if not isinstance(english, str) or not english.strip():
        raise RegistryError(f"CARD_FIELD:{key}.EN")
    if not isinstance(japanese, str):
        raise RegistryError(f"CARD_FIELD:{key}.JA")
    return english.strip(), japanese.strip()


def _validate_boolean_block(card: dict[str, Any], key: str, fields: Iterable[str]) -> None:
    block = card.get(key)
    if not isinstance(block, dict):
        raise RegistryError(f"CARD_FIELD:{key}")
    for field in fields:
        if block.get(field) is not True:
            raise RegistryError(f"CARD_FIELD:{key}.{field}")


def validate_card(card: dict[str, Any], adapter_dir: Path, adapters_root: Path) -> AdapterRecord:
    if card.get("AdapterCardVersion") != CARD_VERSION:
        raise RegistryError("CARD_VERSION")

    adapter_id = _require_string(card, "AdapterId")
    adapter_version = _require_string(card, "AdapterVersion")
    if not ADAPTER_ID_RE.fullmatch(adapter_id):
        raise RegistryError("ADAPTER_ID")
    if not SEMVER_RE.fullmatch(adapter_version):
        raise RegistryError("ADAPTER_VERSION")
    if adapter_dir.name != adapter_version or adapter_dir.parent.name != adapter_id:
        raise RegistryError("PACKAGE_IDENTITY")

    adapter_class = _require_string(card, "AdapterClass")
    if adapter_class not in ALLOWED_CLASSES:
        raise RegistryError("ADAPTER_CLASS")
    output_boundary = _require_string(card, "OutputBoundary")
    if output_boundary not in ALLOWED_BOUNDARIES:
        raise RegistryError("OUTPUT_BOUNDARY")

    input_kinds = card.get("InputKinds")
    if (
        not isinstance(input_kinds, list)
        or not input_kinds
        or any(not isinstance(item, str) or not item.strip() for item in input_kinds)
        or len(set(input_kinds)) != len(input_kinds)
    ):
        raise RegistryError("INPUT_KINDS")

    entry_point = _require_string(card, "EntryPoint")
    if not ENTRY_POINT_RE.fullmatch(entry_point):
        raise RegistryError("ENTRY_POINT")
    if not (adapter_dir / entry_point).is_file():
        raise RegistryError("ENTRY_POINT_MISSING")

    actions = card.get("SupportedActions")
    if not isinstance(actions, list) or not REQUIRED_ACTIONS.issubset(set(actions)):
        raise RegistryError("SUPPORTED_ACTIONS")

    _validate_boolean_block(
        card,
        "Safety",
        (
            "ReadOnlySource",
            "PreservesProvenance",
            "NoAnalysisLogic",
            "NoAbsolutePathInPublicManifest",
        ),
    )
    qualification = card.get("Qualification")
    if not isinstance(qualification, dict) or qualification.get("SupportsSyntheticQualification") is not True:
        raise RegistryError("SYNTHETIC_QUALIFICATION")

    compatibility = card.get("Compatibility")
    if not isinstance(compatibility, dict):
        raise RegistryError("COMPATIBILITY")
    if compatibility.get("HostApiVersion") != HOST_API_VERSION:
        raise RegistryError("HOST_API_VERSION")
    contract_versions = compatibility.get("U001ContractVersions")
    if not isinstance(contract_versions, list) or not contract_versions:
        raise RegistryError("CONTRACT_VERSIONS")

    display_en, display_ja = _language_text(card, "DisplayName")
    description_en, description_ja = _language_text(card, "Description")
    relative_package = adapter_dir.resolve().relative_to(adapters_root.resolve()).as_posix()

    return AdapterRecord(
        adapter_id=adapter_id,
        adapter_version=adapter_version,
        adapter_class=adapter_class,
        output_boundary=output_boundary,
        entry_point=entry_point,
        package_path=relative_package,
        display_name_en=display_en,
        display_name_ja=display_ja,
        description_en=description_en,
        description_ja=description_ja,
        input_kinds=[item.strip() for item in input_kinds],
    )


def semantic_version(value: str) -> tuple[int, int, int]:
    match = SEMVER_RE.fullmatch(value)
    if not match:
        raise RegistryError("ADAPTER_VERSION")
    return tuple(int(part) for part in value.split("."))


def scan_adapters(adapters_root: Path) -> list[AdapterRecord]:
    if not adapters_root.is_dir():
        raise RegistryError("ADAPTER_ROOT")

    records: list[AdapterRecord] = []
    identities: set[tuple[str, str]] = set()
    for card_path in sorted(adapters_root.glob("*/*/adapter_card.json")):
        record = validate_card(_load_json(card_path), card_path.parent, adapters_root)
        identity = (record.adapter_id, record.adapter_version)
        if identity in identities:
            raise RegistryError("DUPLICATE_ADAPTER_IDENTITY")
        identities.add(identity)
        records.append(record)

    if not records:
        raise RegistryError("NO_ADAPTERS")
    return sorted(records, key=lambda item: (item.adapter_id, semantic_version(item.adapter_version)))


def build_snapshot(adapters_root: Path) -> dict[str, Any]:
    records = scan_adapters(adapters_root)
    latest: dict[str, str] = {}
    for record in records:
        previous = latest.get(record.adapter_id)
        if previous is None or semantic_version(record.adapter_version) > semantic_version(previous):
            latest[record.adapter_id] = record.adapter_version
    return {
        "RegistrySchema": REGISTRY_SCHEMA,
        "Program": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "AdapterCount": len(records),
        "AdapterFamilyCount": len(latest),
        "LatestVersions": latest,
        "Adapters": [asdict(record) for record in records],
        "Errors": [],
    }


def write_snapshot(adapters_root: Path, output_path: Path) -> dict[str, Any]:
    snapshot = build_snapshot(adapters_root)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return snapshot


def _valid_card(adapter_id: str = "Foundation.Test.Adapter", version: str = "0.1.0") -> dict[str, Any]:
    return {
        "AdapterCardVersion": CARD_VERSION,
        "AdapterId": adapter_id,
        "AdapterVersion": version,
        "DisplayName": {"EN": "Synthetic Adapter", "JA": "合成アダプター"},
        "Description": {"EN": "Synthetic qualification adapter.", "JA": "合成検証用。"},
        "AdapterClass": "SOURCE_ADAPTER",
        "InputKinds": ["SYNTHETIC"],
        "OutputBoundary": "U001_CANONICAL_SOURCE_UPDATES_V0_1",
        "EntryPoint": "adapter.py",
        "SupportedActions": ["DESCRIBE", "SELF_TEST", "PREFLIGHT", "RUN"],
        "ConfigurationSchema": {},
        "Qualification": {"SupportsSyntheticQualification": True},
        "Capabilities": {"Streaming": True, "MultipleInputs": False, "DeterministicOutput": True},
        "Safety": {
            "ReadOnlySource": True,
            "PreservesProvenance": True,
            "NoAnalysisLogic": True,
            "NoAbsolutePathInPublicManifest": True,
        },
        "Compatibility": {
            "HostApiVersion": HOST_API_VERSION,
            "U001ContractVersions": ["UDP001_UNIFIED_DATA_CONTRACT_V0_1"],
        },
    }


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_h1_registry_") as temporary:
        root = Path(temporary) / "adapters"
        package = root / "Foundation.Test.Adapter" / "0.1.0"
        package.mkdir(parents=True)
        (package / "adapter.py").write_text("# synthetic\n", encoding="utf-8")
        (package / "adapter_card.json").write_text(
            json.dumps(_valid_card(), indent=2), encoding="utf-8"
        )

        snapshot = build_snapshot(root)
        check(snapshot["AdapterCount"] == 1, "T01")
        check(snapshot["AdapterFamilyCount"] == 1, "T02")
        check(snapshot["LatestVersions"]["Foundation.Test.Adapter"] == "0.1.0", "T03")
        check(snapshot["Adapters"][0]["package_path"] == "Foundation.Test.Adapter/0.1.0", "T04")

        package2 = root / "Foundation.Test.Adapter" / "0.2.0"
        package2.mkdir(parents=True)
        (package2 / "adapter.py").write_text("# synthetic\n", encoding="utf-8")
        (package2 / "adapter_card.json").write_text(
            json.dumps(_valid_card(version="0.2.0"), indent=2), encoding="utf-8"
        )
        snapshot2 = build_snapshot(root)
        check(snapshot2["AdapterCount"] == 2, "T05")
        check(snapshot2["LatestVersions"]["Foundation.Test.Adapter"] == "0.2.0", "T06")
        check(semantic_version("10.2.3") > semantic_version("2.99.99"), "T07")

        bad_cards: list[tuple[str, Any]] = [
            ("T08", {**_valid_card(), "AdapterCardVersion": "BAD"}),
            ("T09", {**_valid_card(), "AdapterId": "bad"}),
            ("T10", {**_valid_card(), "AdapterVersion": "v1"}),
            ("T11", {**_valid_card(), "AdapterClass": "ANALYZER"}),
            ("T12", {**_valid_card(), "OutputBoundary": "RAW"}),
            ("T13", {**_valid_card(), "InputKinds": []}),
            ("T14", {**_valid_card(), "EntryPoint": "../escape.py"}),
            ("T15", {**_valid_card(), "SupportedActions": ["RUN"]}),
            ("T16", {**_valid_card(), "Safety": {}}),
            ("T17", {**_valid_card(), "Qualification": {}}),
            ("T18", {**_valid_card(), "Compatibility": {"HostApiVersion": "BAD", "U001ContractVersions": ["X"]}}),
        ]
        for label, bad_card in bad_cards:
            failed = False
            try:
                validate_card(bad_card, package, root)
            except RegistryError:
                failed = True
            check(failed, label)

    if checks != 18:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H1-REGISTRY-SELFTEST-PASS-18")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 Input Adapter Registry")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--scan", action="store_true")
    parser.add_argument("--adapter-root", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.adapter_root is None or args.output is None:
            raise RegistryError("SCAN_ARGUMENTS")
        snapshot = write_snapshot(args.adapter_root, args.output)
        print(
            "U1H1R-"
            f"N{snapshot['AdapterCount']}-"
            f"F{snapshot['AdapterFamilyCount']}-"
            "X0-C0"
        )
        return 0
    except (RegistryError, AssertionError) as exc:
        print(f"U1H1E-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())

