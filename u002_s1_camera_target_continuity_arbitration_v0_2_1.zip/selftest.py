#!/usr/bin/env python3
"""Controlled semantic fixtures for the B1B2 S1 reconstruction Module."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROLE_1 = "CAMERA_1_DISTANCE"
ROLE_3 = "CAMERA_3_DISTANCE"
HISTORICAL_FAILURE_COVERAGE = ("FP030",)
HISTORICAL_FAILURE_TEST_MAP = {
    "FP030": (
        "invalid_blank_age_is_legal_and_ineligible",
        "invalid_numeric_age_is_legal_and_ineligible",
        "valid_blank_age_fails_closed",
        "valid_blank_value_fails_closed",
        "negative_fractional_and_nonnumeric_age_fail_closed",
        "camera_roles_are_symmetric",
        "runtime_csv_blank_age_path",
    ),
}


def load_implementation(module_root):
    """Load only the implementation inside the selected Module root."""

    path = module_root / "implementation.py"
    spec = importlib.util.spec_from_file_location("u22b1b2_impl", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source(value, eligible=True, age=0):
    """Create one normalized candidate source fixture."""

    return {
        "Value": value,
        "Age": age,
        "Valid": bool(eligible),
        "Eligible": bool(eligible),
    }


def record(frame, camera_1, camera_3, e1=True, e3=True, a1=0, a3=0):
    """Create one normalized Frame fixture."""

    return {
        "FrameCount": frame,
        ROLE_1: source(camera_1, e1, a1),
        ROLE_3: source(camera_3, e3, a3),
    }


def base_configuration():
    """Return the approved TC001 provisional selector parameters."""

    return {
        "BindingProfilePath": "02_CONFIG/binding_profiles/test.json",
        "BindingProfileSha256": "0" * 64,
        "ContinuityScaleMeters": 0.38,
        "MaxContinuityCost": 3.0,
        "AcquireConfirmFrames": 3,
        "SwitchConfirmFrames": 3,
        "SwitchMargin": 1.0,
        "ResetAfterBothInvalidFrames": 3,
        "SeedFrame": 100,
        "SeedRole": ROLE_1,
        "ContextFrameStart": 100,
    }


def write_json(path, value):
    """Write one deterministic JSON fixture."""

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )


def sha256(path):
    """Hash one small self-test file."""

    return hashlib.sha256(path.read_bytes()).hexdigest()


def runtime_smoke(source_module_root):
    """Exercise request, binding, U001 Frame View and Artifact I/O end to end."""

    checks = []

    assert set(HISTORICAL_FAILURE_COVERAGE) == set(HISTORICAL_FAILURE_TEST_MAP)
    assert all(HISTORICAL_FAILURE_TEST_MAP.values())
    checks.append(True)
    with tempfile.TemporaryDirectory(prefix="u22b1b2_runtime_smoke_") as temporary:
        root = Path(temporary) / "U-UDP002"
        module_root = (
            root
            / "01_PROGRAMS/modules/S1"
            / "CameraRadar.S1.CameraTargetContinuityArbitration"
            / "0.2.1"
        )
        module_root.mkdir(parents=True)
        shutil.copy2(source_module_root / "implementation.py", module_root / "implementation.py")

        input_root = root / "03_CASES/TC_SELFTEST/U001_OUTPUT"
        input_root.mkdir(parents=True)
        suffixes = (
            "__value", "__label", "__updated", "__update_count",
            "__age", "__valid", "__missing_reason",
        )
        header = ["FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount"]
        for name in (ROLE_1, ROLE_3):
            header.extend(name + suffix for suffix in suffixes)
        frame_path = input_root / "u001_frame_values.csv"
        with frame_path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(header)
            for index, frame in enumerate(range(100, 105), start=1):
                row = [frame, index, index, 2]
                row.extend([10.0 + index / 10, "", 1, 1, 0, 1, "VALID_UPDATE"])
                if frame == 103:
                    row.extend(["", "", 0, 0, "", 0, "NO_UPDATE"])
                else:
                    row.extend([40.0 + index, "", 1, 1, 0, 1, "VALID_UPDATE"])
                writer.writerow(row)
        input_hash = sha256(frame_path)

        run_id = "RUN_B1B2_SELFTEST"
        run_root = root / "07_OUTPUT" / run_id
        write_json(
            run_root / "00_CONFIG/resolved_run_plan.json",
            {
                "RunId": run_id,
                "RunScope": "FRAME_RANGE",
                "FrameStart": 102,
                "FrameEnd": 104,
            },
        )
        parent_root = run_root / "03_ARTIFACTS/S0/ART_S0_SELFTEST"
        parent_root.mkdir(parents=True)
        inventory_path = parent_root / "u001_signal_inventory.csv"
        inventory_path.write_text(
            "CanonicalName,CAN_ID,Channel,SignalName,Unit\n"
            + ROLE_1 + ",0x221,2,Distance,m\n"
            + ROLE_3 + ",0x251,2,Distance,m\n",
            encoding="utf-8",
        )
        summary_path = parent_root / "u001_intake_summary.json"
        write_json(summary_path, {"Status": "INTAKE_ACCEPTED"})
        parent_manifest = {
            "ContractVersion": "U22.0.1",
            "ArtifactId": "ART_S0_SELFTEST",
            "ArtifactType": "U001_INTAKE_ACCEPTED",
            "SchemaId": "U002_U001_INTAKE_SUMMARY",
            "SchemaVersion": "0.1",
            "RunId": run_id,
            "Stage": "S0",
            "ProducerModuleId": "CameraRadar.S0.U001ControlledProfileIntake",
            "ProducerModuleVersion": "0.1.1",
            "ParentArtifactIds": [],
            "Payloads": [
                {
                    "RelativePath": summary_path.name,
                    "MediaType": "application/json",
                    "RowCount": None,
                    "Sha256": sha256(summary_path),
                    "ByteSize": summary_path.stat().st_size,
                    "PayloadKind": "PRIMARY",
                },
                {
                    "RelativePath": inventory_path.name,
                    "MediaType": "text/csv",
                    "RowCount": 2,
                    "Sha256": sha256(inventory_path),
                    "ByteSize": inventory_path.stat().st_size,
                    "PayloadKind": "AUXILIARY",
                },
            ],
            "Metadata": {},
        }
        parent_manifest_path = parent_root / "artifact_manifest.json"
        write_json(parent_manifest_path, parent_manifest)

        profile = {
            "ContractVersion": "U002_SIGNAL_BINDING_PROFILE_V0_1",
            "BindingProfileId": "TC001.CameraRadar.Base.PROVISIONAL",
            "BindingProfileVersion": "0.1",
            "DuplicateRoleCount": 0,
            "BlockingIssues": [],
            "SourceInventorySha256": sha256(inventory_path),
            "Prohibitions": ["comparison target is excluded from arbitration"],
            "Bindings": {},
        }
        for role, can_id in ((ROLE_1, "0x221"), (ROLE_3, "0x251")):
            profile["Bindings"][role] = [
                {
                    "CanonicalName": role,
                    "CAN_ID": can_id,
                    "Channel": "2",
                    "SignalName": "Distance",
                    "IncludeInFrameView": True,
                    "MaxAgeFrames": "1",
                }
            ]
        profile_path = root / "02_CONFIG/binding_profiles/test.json"
        write_json(profile_path, profile)
        configuration = base_configuration()
        configuration["BindingProfileSha256"] = sha256(profile_path)

        staging = run_root / "00_STAGING/0002_S1/packages"
        staging.mkdir(parents=True)
        request = {
            "Protocol": "U002_U22_MODULE_RUNTIME",
            "ProtocolVersion": "0.1",
            "ContractVersion": "U22.0.1",
            "RunId": run_id,
            "Sequence": 2,
            "Stage": "S1",
            "ModuleId": "CameraRadar.S1.CameraTargetContinuityArbitration",
            "ModuleVersion": "0.2.1",
            "ModuleRoot": str(module_root),
            "RunRoot": str(run_root),
            "InputPackage": str(input_root),
            "RequiredInputs": [ROLE_1, ROLE_3],
            "OptionalInputs": [],
            "InputArtifacts": [
                {
                    "ArtifactId": "ART_S0_SELFTEST",
                    "ArtifactType": "U001_INTAKE_ACCEPTED",
                    "ManifestRelativePath": parent_manifest_path.relative_to(run_root).as_posix(),
                    "ManifestSha256": sha256(parent_manifest_path),
                }
            ],
            "Configuration": configuration,
            "ExpectedOutputTypes": ["CAMERA_TARGET_RECONSTRUCTION"],
            "OutputRoot": str(staging),
        }
        request_path = run_root / "00_STAGING/0002_S1/module_request.json"
        result_path = run_root / "00_STAGING/0002_S1/module_result.json"
        write_json(request_path, request)
        completed = subprocess.run(
            [
                sys.executable,
                str(module_root / "implementation.py"),
                "--request-json",
                str(request_path),
                "--result-json",
                str(result_path),
            ],
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        assert completed.returncode == 0 and "C-0" in completed.stdout
        checks.append(True)
        result = json.loads(result_path.read_text(encoding="utf-8"))
        assert result["Status"] == "SUCCEEDED"
        checks.append(True)
        package_root = staging / "artifact_01"
        manifest = json.loads((package_root / "artifact_manifest.json").read_text(encoding="utf-8"))
        assert manifest["ParentArtifactIds"] == ["ART_S0_SELFTEST"]
        checks.append(True)
        with (package_root / "camera_target_reconstruction.csv").open(
            "r", encoding="utf-8", newline=""
        ) as stream:
            rows = list(csv.DictReader(stream))
        assert len(rows) == 3 and rows[0]["FrameCount"] == "102"
        checks.append(True)
        assert all(row["CanonicalCameraValid"] == "1" for row in rows)
        checks.append(True)
        quality = json.loads(
            (package_root / "camera_target_reconstruction_quality.json").read_text(
                encoding="utf-8"
            )
        )
        assert quality["ContextFrameRows"] == 5
        assert quality["WarmupFrameRows"] == 2
        assert quality["EvaluationFrameStart"] == 102
        checks.extend([True, True, True])
        assert sha256(frame_path) == input_hash
        checks.append(True)
    return checks


def main():
    """Exercise the thirteen approved fixture classes."""

    parser = argparse.ArgumentParser()
    parser.add_argument("--module-root", required=True)
    parser.add_argument("--workspace-root", required=True)
    args = parser.parse_args()
    implementation = load_implementation(Path(args.module_root).resolve())
    cfg = base_configuration()
    checks = []

    # F00: U001 nullable-age semantics are interpreted as one coupled state.
    bindings = {
        ROLE_1: {"CanonicalName": ROLE_1, "MaxAgeFramesParsed": 1},
        ROLE_3: {"CanonicalName": ROLE_3, "MaxAgeFramesParsed": 1},
    }

    def raw_row(c1_value, c1_age, c1_valid, c3_value, c3_age, c3_valid):
        return {
            ROLE_1 + "__value": c1_value,
            ROLE_1 + "__age": c1_age,
            ROLE_1 + "__valid": c1_valid,
            ROLE_3 + "__value": c3_value,
            ROLE_3 + "__age": c3_age,
            ROLE_3 + "__valid": c3_valid,
        }

    nullable = implementation.normalized_record(
        100,
        raw_row("", "", 0, "12.3", "0", 1),
        bindings,
    )
    assert nullable[ROLE_1]["Age"] is None
    assert nullable[ROLE_1]["Eligible"] is False
    assert nullable[ROLE_3]["Eligible"] is True
    checks.extend([True, True, True])

    stale = implementation.normalized_record(
        101,
        raw_row("10.0", "5", 0, "12.4", "0", 1),
        bindings,
    )
    assert stale[ROLE_1]["Age"] == 5
    assert stale[ROLE_1]["Eligible"] is False
    checks.extend([True, True])

    invalid_cases = (
        raw_row("10.0", "", 1, "12.0", "0", 1),
        raw_row("", "0", 1, "12.0", "0", 1),
        raw_row("10.0", "-1", 0, "12.0", "0", 1),
        raw_row("10.0", "1.5", 0, "12.0", "0", 1),
        raw_row("10.0", "bad", 0, "12.0", "0", 1),
        raw_row("10.0", "0", 1, "", "", 1),
    )
    for candidate in invalid_cases:
        try:
            implementation.normalized_record(102, candidate, bindings)
        except implementation.ModuleError:
            checks.append(True)
        else:
            raise AssertionError("NULLABLE_AGE_FAIL_CLOSED")

    # F01: stable Camera 1 after the configured seed.
    rows = implementation.reconstruct(
        [record(100 + i, 10.0 + 0.1 * i, 40.0 + i) for i in range(5)],
        cfg,
    )
    assert rows[0]["SelectionStatus"] == "SEEDED"
    assert all(row["SelectedCameraRole"] == ROLE_1 for row in rows)
    checks.extend([True, True])

    # F02: Camera 3 can be the documented seed.
    cfg3 = dict(cfg)
    cfg3["SeedRole"] = ROLE_3
    rows = implementation.reconstruct(
        [record(100 + i, 50.0 + i, 12.0 + 0.1 * i) for i in range(4)],
        cfg3,
    )
    assert rows[0]["SelectedCameraRole"] == ROLE_3
    checks.append(True)

    # F03/F04: Camera 1 invalid/default, Camera 3 continuity confirms a switch.
    fixture = [
        record(100, 10.0, 50.0),
        record(101, 10.1, 50.0),
        record(102, None, 10.2, False, True),
        record(103, None, 10.3, False, True),
        record(104, None, 10.4, False, True),
    ]
    rows = implementation.reconstruct(fixture, cfg)
    assert rows[2]["SelectionStatus"] == "SWITCH_PENDING"
    assert rows[4]["SelectionReason"] == "SWITCH_CONFIRMED"
    assert rows[4]["SelectionChanged"] == 1
    checks.extend([True, True, True])

    # F05: a distant alternative does not cause a switch.
    rows = implementation.reconstruct(
        [record(100 + i, 10.0 + 0.1 * i, 50.0 + i) for i in range(6)],
        cfg,
    )
    assert sum(row["SelectionChanged"] for row in rows) == 0
    checks.append(True)

    # F06: both invalid never emit a canonical value.
    rows = implementation.reconstruct(
        [
            record(100, 10.0, 20.0),
            record(101, None, None, False, False),
            record(102, None, None, False, False),
            record(103, None, None, False, False),
        ],
        cfg,
    )
    assert all(row["CanonicalCameraValid"] == 0 for row in rows[1:])
    assert rows[-1]["SelectionStatus"] == "SEGMENT_RESET"
    checks.extend([True, True])

    # F07: two unseeded plausible candidates preserve ambiguity.
    no_seed = dict(cfg)
    no_seed["SeedFrame"] = None
    no_seed["SeedRole"] = None
    rows = implementation.reconstruct(
        [record(200 + i, 10.0 + 0.1 * i, 11.0 + 0.1 * i) for i in range(4)],
        no_seed,
    )
    assert all(row["SelectionStatus"] == "AMBIGUOUS" for row in rows)
    checks.append(True)

    # F08: a FrameCount gap creates a new segment and requires reacquisition.
    rows = implementation.reconstruct(
        [
            record(100, 10.0, 50.0),
            record(101, 10.1, 50.0),
            record(105, 10.2, None, True, False),
        ],
        cfg,
    )
    assert rows[-1]["SegmentId"] == 2
    assert rows[-1]["SelectionStatus"] == "ACQUIRING"
    checks.extend([True, True])

    # F09: stale age is represented by ineligible normalized input.
    rows = implementation.reconstruct(
        [
            record(100, 10.0, 50.0),
            record(101, 10.1, 10.2),
            record(102, 10.2, 10.3, False, True, 5, 0),
            record(103, 10.3, 10.4, False, True, 5, 0),
            record(104, 10.4, 10.5, False, True, 5, 0),
        ],
        cfg,
    )
    assert rows[-1]["SelectedCameraRole"] == ROLE_3
    checks.append(True)

    # F10: pending switch rows are never analysis-grade canonical values.
    assert rows[2]["SelectionStatus"] == "SWITCH_PENDING"
    assert rows[2]["CanonicalCameraValid"] == 0
    checks.extend([True, True])

    # F11: deterministic replay produces identical row dictionaries.
    fixture = [record(100 + i, 10.0 + 0.1 * i, 40.0) for i in range(8)]
    assert implementation.reconstruct(fixture, cfg) == implementation.reconstruct(fixture, cfg)
    checks.append(True)

    # F12: selector does not mutate normalized input records.
    before = repr(fixture)
    implementation.reconstruct(fixture, cfg)
    assert repr(fixture) == before
    checks.append(True)

    # F13: public selector signature has no comparison-target argument.
    assert implementation.reconstruct.__code__.co_argcount == 2
    checks.append(True)

    # F14: a short evaluation exports only its evaluation rows after warm-up.
    context = [record(100 + i, 10.0 + 0.1 * i, 40.0 + i) for i in range(5)]
    reconstructed = implementation.reconstruct(context, cfg)
    evaluated = implementation.evaluation_rows(reconstructed, 102, 104)
    assert [row["FrameCount"] for row in evaluated] == [102, 103, 104]
    assert all(row["CanonicalCameraValid"] == 1 for row in evaluated)
    checks.extend([True, True])

    # F15: missing or late context fails closed for a bounded evaluation.
    for context_start in (None, 103):
        invalid = dict(cfg)
        invalid["ContextFrameStart"] = context_start
        try:
            implementation.context_and_evaluation_bounds(invalid, 102, 104)
        except implementation.ModuleError:
            checks.append(True)
        else:
            raise AssertionError("CONTEXT_FAIL_CLOSED")

    # F16: a configured seed outside context is rejected.
    invalid = dict(cfg)
    invalid["ContextFrameStart"] = 101
    try:
        implementation.context_and_evaluation_bounds(invalid, 102, 104)
    except implementation.ModuleError:
        checks.append(True)
    else:
        raise AssertionError("SEED_OUTSIDE_CONTEXT")

    checks.extend(runtime_smoke(Path(args.module_root).resolve()))

    assert len(checks) == 44
    print("U22B7T-MST N-T44-F18-IO9-X0 C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
