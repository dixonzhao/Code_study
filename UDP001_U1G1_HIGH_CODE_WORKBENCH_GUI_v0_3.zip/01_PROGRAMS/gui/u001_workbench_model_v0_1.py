#!/usr/bin/env python3
"""Pure state and discovery model for the U001 high-code Workbench GUI.

The model deliberately contains no tkinter code.  It discovers versioned input
Adapters, validates machine-local paths, persists editable Workbench profiles,
and exposes the fixed I0-I5 pipeline without owning any decoding algorithm.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


MODEL_ID = "CameraRadar.U001.HighCodeWorkbenchModel"
MODEL_VERSION = "0.1.0"
PROFILE_CONTRACT = "U001_WORKBENCH_PROFILE_V0_1"
STAGE_ORDER = ("I0", "I1", "I2", "I3", "I4", "I5")

STAGE_TITLES = {
    "I0": "Source Adapter",
    "I1": "Catalog & Mapping",
    "I2": "Decode & Canonical Mapping",
    "I3": "Frame Reconstruction",
    "I4": "Cadence & Bounded Hold",
    "I5": "Accepted Package & Quality Gate",
}

ADAPTER_ROOT_RELATIVE = Path("01_PROGRAMS/adapters")
CORE_ROOT_RELATIVE = Path("01_PROGRAMS/core")
CATALOG_GUI_RELATIVE = Path("01_PROGRAMS/core/u001_catalog_mapping_gui_v1_0.py")
CONTROLLER_RELATIVE = Path("01_PROGRAMS/core/u001_workbench_controller_v0_1.py")
USER_PROFILE_ROOT_RELATIVE = Path("02_CONTROL/workbench_profiles/user")
DEFAULT_OUTPUT_ROOT_RELATIVE = Path("03_CASES")


class WorkbenchError(RuntimeError):
    """One controlled, user-facing Workbench rejection."""

    def __init__(self, reason: object, detail: object = "NA") -> None:
        self.reason = stable_token(reason)
        self.detail = bounded_detail(detail)
        super().__init__(self.reason)


def stable_token(value: object, limit: int = 100) -> str:
    text = re.sub(r"[^A-Z0-9_]+", "_", str(value).upper()).strip("_")
    return (text or "NA")[:limit]


def bounded_detail(value: object, limit: int = 220) -> str:
    text = re.sub(r"[^A-Z0-9_.:/\\-]+", "_", str(value).upper()).strip("_.-")
    return (text or "NA")[:limit]


def canonical_bytes(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        + "\n"
    ).encode("utf-8")


def write_json_atomic(path: Path, value: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".writing")
    temporary.write_bytes(canonical_bytes(value))
    os.replace(temporary, path)


def read_json_object(path: Path, label: str) -> Dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise WorkbenchError(label + "_MISSING", path)
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as error:
        raise WorkbenchError(label + "_JSON", path.name) from error
    if not isinstance(value, dict):
        raise WorkbenchError(label + "_TYPE", path.name)
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def version_sort_key(value: object) -> Tuple[Tuple[int, object], ...]:
    parts = re.split(r"(\d+)", str(value))
    return tuple(
        (0, int(part)) if part.isdigit() else (1, part.lower())
        for part in parts
        if part
    )


def require_workspace(path_value: object) -> Path:
    root = Path(str(path_value)).resolve()
    if not root.is_dir() or root.name != "U-UDP001":
        raise WorkbenchError("WORKSPACE_ROOT", root)
    return root


def adapter_purpose(card: Mapping[str, object]) -> str:
    """Extract one bounded human explanation without assuming one card dialect."""

    for key in ("Purpose", "Description", "Summary", "AdapterPurpose"):
        value = card.get(key)
        if isinstance(value, str) and value.strip():
            return " ".join(value.split())
    return "Convert one external source family into the governed U001 source contract."


def scan_adapters(workspace_root: object) -> List[Dict[str, Any]]:
    """Discover versioned adapters from the fixed plug-in root."""

    root = require_workspace(workspace_root)
    adapter_root = root / ADAPTER_ROOT_RELATIVE
    if not adapter_root.is_dir():
        raise WorkbenchError("ADAPTER_ROOT_MISSING", adapter_root)
    entries: List[Dict[str, Any]] = []
    for card_path in sorted(adapter_root.glob("*/*/adapter_card.json")):
        card = read_json_object(card_path, "ADAPTER_CARD")
        version_root = card_path.parent
        implementation = version_root / "adapter.py"
        if not implementation.is_file() or implementation.is_symlink():
            continue
        adapter_id = str(
            card.get("AdapterId")
            or card.get("ProgramId")
            or version_root.parent.name
        ).strip()
        version = str(
            card.get("AdapterVersion")
            or card.get("ProgramVersion")
            or version_root.name
        ).strip()
        if not adapter_id or not version:
            raise WorkbenchError("ADAPTER_IDENTITY", card_path)
        entries.append(
            {
                "AdapterId": adapter_id,
                "AdapterVersion": version,
                "AdapterRoot": str(version_root.resolve()),
                "AdapterCardPath": str(card_path.resolve()),
                "ImplementationPath": str(implementation.resolve()),
                "Purpose": adapter_purpose(card),
                "Card": card,
            }
        )
    if not entries:
        raise WorkbenchError("ADAPTER_SCAN_EMPTY", adapter_root)
    return sorted(
        entries,
        key=lambda item: (
            str(item["AdapterId"]),
            version_sort_key(item["AdapterVersion"]),
        ),
    )


def grouped_adapters(entries: Sequence[Mapping[str, object]]) -> List[Dict[str, Any]]:
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for raw in entries:
        entry = dict(raw)
        grouped.setdefault(str(entry["AdapterId"]), []).append(entry)
    result: List[Dict[str, Any]] = []
    for adapter_id in sorted(grouped):
        versions = sorted(
            grouped[adapter_id],
            key=lambda item: version_sort_key(item["AdapterVersion"]),
            reverse=True,
        )
        result.append(
            {
                "AdapterId": adapter_id,
                "Versions": versions,
                "LatestVersion": versions[0]["AdapterVersion"],
                "Purpose": versions[0]["Purpose"],
            }
        )
    return result


def default_state(workspace_root: object) -> Dict[str, Any]:
    root = require_workspace(workspace_root)
    groups = grouped_adapters(scan_adapters(root))
    preferred = next(
        (
            item
            for item in groups
            if item["AdapterId"] == "CameraRadar.U001.MatlabCanCsvDbc"
        ),
        groups[0],
    )
    version = str(preferred["LatestVersion"])
    return {
        "ContractId": PROFILE_CONTRACT,
        "ContractVersion": "0.1",
        "ProfileName": "U001 Editable Working Profile",
        "RunId": "U001_RUN_NEW",
        "Language": "EN",
        "AdapterId": preferred["AdapterId"],
        "AdapterVersion": version,
        "SourceFiles": {"CANDump": "", "DBC1": "", "DBC2": ""},
        "CapabilityCatalogPath": "",
        "SelectionProfilePath": "",
        "FrameStart": None,
        "FrameEnd": None,
        "OutputRoot": str((root / DEFAULT_OUTPUT_ROOT_RELATIVE).resolve()),
        "U002Workspace": "",
        "ResourcePolicy": {
            "ChunkRows": 5000,
            "WorkerCount": 1,
            "MaxInFlightChunks": 2,
            "MaxResidentMemoryMB": 512,
            "OutputShardRows": 250000,
        },
    }


def normalize_nullable_frame(value: object, field: str) -> Optional[int]:
    if value is None or str(value).strip() == "":
        return None
    try:
        parsed = int(str(value).strip())
    except ValueError as error:
        raise WorkbenchError("FRAME_INTEGER", field) from error
    if parsed < 0:
        raise WorkbenchError("FRAME_NEGATIVE", field)
    return parsed


def selected_adapter(
    entries: Sequence[Mapping[str, object]], adapter_id: object, version: object
) -> Dict[str, Any]:
    matches = [
        dict(entry)
        for entry in entries
        if entry.get("AdapterId") == adapter_id
        and entry.get("AdapterVersion") == version
    ]
    if len(matches) != 1:
        raise WorkbenchError("ADAPTER_SELECTION", f"{adapter_id}@{version}")
    return matches[0]


def validate_state(
    workspace_root: object,
    state: Mapping[str, object],
    require_catalog: bool = False,
) -> Dict[str, Any]:
    root = require_workspace(workspace_root)
    if state.get("ContractId") != PROFILE_CONTRACT:
        raise WorkbenchError("PROFILE_CONTRACT")
    entries = scan_adapters(root)
    adapter = selected_adapter(entries, state.get("AdapterId"), state.get("AdapterVersion"))
    source_files = state.get("SourceFiles")
    if not isinstance(source_files, dict):
        raise WorkbenchError("SOURCE_FILES_TYPE")
    missing_sources: List[str] = []
    if adapter["AdapterId"] == "CameraRadar.U001.MatlabCanCsvDbc":
        required = ("CANDump", "DBC1", "DBC2")
        for key in required:
            path = Path(str(source_files.get(key, ""))).expanduser()
            if not path.is_file() or path.is_symlink():
                missing_sources.append(key)
    frame_start = normalize_nullable_frame(state.get("FrameStart"), "FrameStart")
    frame_end = normalize_nullable_frame(state.get("FrameEnd"), "FrameEnd")
    if frame_start is not None and frame_end is not None and frame_start > frame_end:
        raise WorkbenchError("FRAME_ORDER")
    output_root = Path(str(state.get("OutputRoot", ""))).expanduser()
    if not str(output_root):
        raise WorkbenchError("OUTPUT_ROOT_EMPTY")
    catalog_value = str(state.get("CapabilityCatalogPath", "")).strip()
    selection_value = str(state.get("SelectionProfilePath", "")).strip()
    catalog_ready = bool(catalog_value) and Path(catalog_value).is_file()
    selection_ready = bool(selection_value) and Path(selection_value).is_file()
    if require_catalog and not catalog_ready:
        raise WorkbenchError("CAPABILITY_CATALOG_MISSING", catalog_value or "EMPTY")
    run_id = str(state.get("RunId", "")).strip()
    if not run_id or re.fullmatch(r"[A-Za-z0-9_.-]+", run_id) is None:
        raise WorkbenchError("RUN_ID", run_id)
    return {
        "Adapter": adapter,
        "MissingSourceKeys": missing_sources,
        "SourceReady": not missing_sources,
        "CatalogReady": catalog_ready,
        "SelectionReady": selection_ready,
        "FrameStart": frame_start,
        "FrameEnd": frame_end,
        "OutputRoot": str(output_root.resolve()),
        "ControllerReady": (root / CONTROLLER_RELATIVE).is_file(),
        "CatalogGuiReady": (root / CATALOG_GUI_RELATIVE).is_file(),
    }


def stage_states(workspace_root: object, state: Mapping[str, object]) -> Dict[str, str]:
    try:
        report = validate_state(workspace_root, state)
    except WorkbenchError:
        return {stage: "EMPTY" for stage in STAGE_ORDER}
    result = {stage: "PLANNED" for stage in STAGE_ORDER}
    if report["SourceReady"]:
        result["I0"] = "READY"
    else:
        result["I0"] = "SELECTED"
    if report["CatalogReady"] and report["SelectionReady"]:
        result["I1"] = "READY"
        result["I2"] = "READY"
    elif report["CatalogReady"]:
        result["I1"] = "SELECTED"
    if report["ControllerReady"] and report["SourceReady"] and report["SelectionReady"]:
        for stage in ("I2", "I3", "I4", "I5"):
            result[stage] = "READY"
    return result


def save_profile(workspace_root: object, state: Mapping[str, object], path: Path) -> Path:
    root = require_workspace(workspace_root)
    validate_state(root, state)
    target = path.resolve()
    write_json_atomic(target, dict(state))
    return target


def default_profile_path(workspace_root: object, profile_name: object) -> Path:
    root = require_workspace(workspace_root)
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(profile_name)).strip("_")
    if not stem:
        stem = "u001_workbench_profile"
    return root / USER_PROFILE_ROOT_RELATIVE / (stem + ".json")


def load_profile(path: Path) -> Dict[str, Any]:
    value = read_json_object(path, "WORKBENCH_PROFILE")
    if value.get("ContractId") != PROFILE_CONTRACT:
        raise WorkbenchError("PROFILE_CONTRACT", path.name)
    return value


def catalog_gui_command(
    workspace_root: object,
    catalog_path: object,
    base_request_path: object = "",
) -> List[str]:
    root = require_workspace(workspace_root)
    gui = root / CATALOG_GUI_RELATIVE
    catalog = Path(str(catalog_path)).resolve()
    if not gui.is_file():
        raise WorkbenchError("CATALOG_GUI_MISSING", gui)
    if not catalog.is_file():
        raise WorkbenchError("CAPABILITY_CATALOG_MISSING", catalog)
    command = [sys.executable, str(gui), "--gui", "--catalog", str(catalog)]
    if str(base_request_path).strip():
        request = Path(str(base_request_path)).resolve()
        if request.is_file():
            command.extend(["--base-request", str(request)])
    return command


def workflow_command(workspace_root: object, profile_path: object) -> List[str]:
    root = require_workspace(workspace_root)
    controller = root / CONTROLLER_RELATIVE
    profile = Path(str(profile_path)).resolve()
    if not controller.is_file():
        raise WorkbenchError("U1G2_CONTROLLER_NOT_INSTALLED", controller)
    if not profile.is_file():
        raise WorkbenchError("WORKBENCH_PROFILE_MISSING", profile)
    return [
        sys.executable,
        str(controller),
        "--execute",
        "--workspace-root",
        str(root),
        "--profile",
        str(profile),
    ]


def self_test() -> str:
    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check_{checks + 1}")
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_g1_model_") as temporary:
        root = Path(temporary) / "U-UDP001"
        adapter = root / ADAPTER_ROOT_RELATIVE / "Test.Adapter" / "1.2.0"
        adapter.mkdir(parents=True)
        (adapter / "adapter.py").write_text("# test\n", encoding="utf-8")
        write_json_atomic(
            adapter / "adapter_card.json",
            {
                "AdapterId": "Test.Adapter",
                "AdapterVersion": "1.2.0",
                "Purpose": "Synthetic adapter for model tests.",
            },
        )
        (root / CORE_ROOT_RELATIVE).mkdir(parents=True)
        entries = scan_adapters(root)
        check(len(entries) == 1)
        check(entries[0]["AdapterVersion"] == "1.2.0")
        check(grouped_adapters(entries)[0]["LatestVersion"] == "1.2.0")
        state = default_state(root)
        check(state["AdapterId"] == "Test.Adapter")
        check(stage_states(root, state)["I0"] == "READY")
        profile_path = root / "profile.json"
        save_profile(root, state, profile_path)
        loaded = load_profile(profile_path)
        check(loaded["ContractId"] == PROFILE_CONTRACT)
        check(default_profile_path(root, "My Profile").name == "My_Profile.json")
        check(normalize_nullable_frame("7400", "x") == 7400)
        check(normalize_nullable_frame("", "x") is None)
        report = validate_state(root, state)
        check(report["SourceReady"] is True)
        check(report["ControllerReady"] is False)
        check(len(STAGE_ORDER) == 6)
        check(STAGE_TITLES["I5"].startswith("Accepted"))
        check(version_sort_key("1.10.0") > version_sort_key("1.2.0"))
        check(sha256_file(profile_path) == hashlib.sha256(profile_path.read_bytes()).hexdigest())
    capsule = f"U1G1-MODEL-SELFTEST-PASS-{checks}"
    print(capsule)
    return capsule


if __name__ == "__main__":
    if "--self-test" not in sys.argv:
        raise SystemExit("Use --self-test or launch the GUI program.")
    self_test()
