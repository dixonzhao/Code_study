#!/usr/bin/env python3
"""Atomically assemble the six-file U001 trusted handoff package."""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import u001_h5_contract_core_v1_0 as contract


PROGRAM_NAME = "u001_h5_package_assembler"
PROGRAM_VERSION = "1.0.0"


def _rows_by_name(path: Path, label: str) -> tuple[list[str], dict[str, dict[str, str]]]:
    header, rows = contract.read_csv_rows(path)
    if "CanonicalName" not in header:
        raise contract.H5ContractError(f"{label}_CANONICAL_NAME")
    result: dict[str, dict[str, str]] = {}
    for row in rows:
        name = row["CanonicalName"].strip()
        if not name or name in result:
            raise contract.H5ContractError(f"{label}_DUPLICATE:{name}")
        result[name] = row
    return header, result


def _review_selection(path: Path, signals: list[str]) -> list[str]:
    header, rows = contract.read_csv_rows(path)
    required = {"CanonicalName", "IncludeInReviewView", "ReviewOrder"}
    if not required.issubset(header):
        raise contract.H5ContractError("REVIEW_PROFILE_HEADER")
    selected: list[tuple[int, str]] = []
    seen: set[str] = set()
    for row in rows:
        name = row["CanonicalName"].strip()
        if name in seen or name not in signals:
            raise contract.H5ContractError(f"REVIEW_PROFILE_SIGNAL:{name}")
        seen.add(name)
        include = contract.parse_int(row["IncludeInReviewView"], f"REVIEW_INCLUDE:{name}", minimum=0)
        order = contract.parse_int(row["ReviewOrder"], f"REVIEW_ORDER:{name}", minimum=0)
        if include not in {0, 1} or order is None:
            raise contract.H5ContractError(f"REVIEW_PROFILE_VALUE:{name}")
        if include:
            selected.append((order, name))
    selected.sort(key=lambda item: (item[0], item[1]))
    names = [name for _, name in selected]
    if not names or len(names) != len(set(names)):
        raise contract.H5ContractError("REVIEW_PROFILE_SELECTION")
    return names


def _catalog_rows(
    h3_policy: Path,
    frame_policy: Path,
    hold_policy: Path,
    frame_signals: list[str],
    bindings: dict[str, set[str]],
    review_signals: set[str],
) -> list[dict[str, str]]:
    _, semantics = _rows_by_name(h3_policy, "H3_POLICY")
    _, frames = _rows_by_name(frame_policy, "FRAME_POLICY")
    _, holds = _rows_by_name(hold_policy, "HOLD_POLICY")
    if set(frame_signals) != set(holds):
        raise contract.H5ContractError("HOLD_POLICY_SIGNAL_SET")
    if not set(frame_signals).issubset(semantics) or not set(frame_signals).issubset(frames):
        raise contract.H5ContractError("FRAME_SIGNAL_METADATA_SET")
    output: list[dict[str, str]] = []
    for name in semantics:
        semantic = semantics[name]
        frame = frames.get(name, {})
        hold = holds.get(name, {})
        source_ids = bindings.get(name, set())
        if len(source_ids) > 1:
            raise contract.H5ContractError(f"CATALOG_MULTI_SOURCE:{name}")
        row = {column: "" for column in contract.D3_COLUMNS}
        mapping = {
            "CanonicalName": name,
            "CAN_ID": semantic.get("SourceMessageId", ""),
            "Channel": semantic.get("SourceChannel", ""),
            "MessageName": semantic.get("SourceMessageName", ""),
            "SignalName": semantic.get("SourceSignalName", ""),
            "Unit": semantic.get("OriginalUnit", ""),
            "ValueKind": semantic.get("ValueKind", ""),
            "SignalRole": semantic.get("SignalRole", ""),
            "UpdateMode": semantic.get("UpdateMode", ""),
            "StorageDtype": semantic.get("StorageDtype", ""),
            "StartBit": semantic.get("StartBit", ""),
            "BitLength": semantic.get("BitLength", ""),
            "ByteOrder": semantic.get("ByteOrder", ""),
            "Signed": semantic.get("Signed", ""),
            "Scale": semantic.get("Scale", ""),
            "Offset": semantic.get("Offset", ""),
            "DBCMinimum": semantic.get("DBCMinimum", ""),
            "DBCMaximum": semantic.get("DBCMaximum", ""),
            "EnumerationMap": semantic.get("EnumerationMap", ""),
            "ValidityRule": semantic.get("ValidityRule", ""),
            "WithinFramePolicy": frame.get("WithinFramePolicy", "KEEP_STREAM_ONLY"),
            "HoldPolicy": hold.get("HoldPolicy", "NOT_APPLICABLE"),
            "MaxAgeFrames": hold.get("MaxAgeFrames", "0"),
            "RequiredForAnalysis": semantic.get("Required", frame.get("Required", "0")),
            "IncludeInFrameView": frame.get("IncludeInFrameView", "0"),
            "IncludeInReviewView": "1" if name in review_signals else "0",
            "Notes": semantic.get("Notes", ""),
            "SourceType": semantic.get("SourceType", ""),
            "SourceAdapter": semantic.get("SourceAdapterId", ""),
            "OriginalUnit": semantic.get("OriginalUnit", ""),
            "CanonicalUnit": semantic.get("OriginalUnit", ""),
            "SourceId": next(iter(source_ids), ""),
            "SourceChannel": semantic.get("SourceChannel", ""),
            "SourceMessageId": semantic.get("SourceMessageId", ""),
            "PolicyStatus": semantic.get("PolicyStatus", ""),
            "PolicyBasis": hold.get("PolicyBasis", ""),
        }
        row.update(mapping)
        output.append(row)
    return output


def _quality_rows(
    h3: Path,
    h4b: Path,
    source_count: int,
    update_count: int,
    frame_count: int,
    signal_count: int,
    review_count: int,
) -> list[dict[str, str]]:
    h3f = contract.load_json(h3 / contract.H3_FILES["frame_quality"], "H3_FRAME_QUALITY")
    h3c = contract.load_json(h3 / contract.H3_FILES["canonical_quality"], "H3_CANONICAL_QUALITY")
    h3p = contract.load_json(h3 / contract.H3_FILES["policy_quality"], "H3_POLICY_QUALITY")
    h4q = contract.load_json(h4b / contract.H4B_FILES["quality"], "H4B_QUALITY")
    rows: list[dict[str, str]] = []

    def add(scope: str, name: str, metric: str, value: Any, unit: str, gate: str, status: str = "OK", notes: str = "") -> None:
        rows.append({
            "Scope": scope, "CanonicalName": name, "Metric": metric,
            "Value": "" if value is None else str(value), "Unit": unit,
            "SourceGate": gate, "Status": "NOT_AVAILABLE" if value is None else status,
            "Notes": notes,
        })

    add("PACKAGE", "", "package_file_count", 6, "files", "H5")
    add("PACKAGE", "", "package_error_count", 0, "errors", "H5")
    add("PACKAGE", "", "source_count", source_count, "sources", "H5")
    add("PACKAGE", "", "update_row_count", update_count, "rows", "H3")
    add("PACKAGE", "", "frame_row_count", frame_count, "frames", "H4B")
    add("PACKAGE", "", "frame_signal_count", signal_count, "signals", "H4B")
    add("PACKAGE", "", "review_signal_count", review_count, "signals", "H5")
    add("SYNCHRONIZATION", "", "unassigned_no_prior_source_row_count", h3f.get("unassigned_no_prior_source_row_count"), "rows", "H3")
    add("SYNCHRONIZATION", "", "unassigned_limit_source_row_count", h3f.get("unassigned_limit_source_row_count"), "rows", "H3")
    add("SEMANTICS", "", "valid_update_count", h3c.get("valid_update_count"), "updates", "H3")
    add("SEMANTICS", "", "invalid_update_count", h3c.get("invalid_update_count"), "updates", "H3")
    add("SEMANTICS", "", "provisional_policy_row_count", h3p.get("provisional_policy_row_count"), "signals", "H3")
    add("HOLD", "", "carried_cell_count", h4q.get("CarriedCellCount"), "cells", "H4B")
    add("HOLD", "", "stale_cell_count", h4q.get("StaleCellCount"), "cells", "H4B")
    add("HOLD", "", "hold_barrier_cell_count", h4q.get("HoldBarrierCellCount"), "cells", "H4B")
    add("HOLD", "", "unbounded_hold_count", h4q.get("UnboundedHoldCount"), "cells", "H4B")
    per_signal = h4q.get("PerSignal", {})
    if not isinstance(per_signal, dict):
        raise contract.H5ContractError("H4B_PER_SIGNAL")
    for name in sorted(per_signal):
        values = per_signal[name]
        if not isinstance(values, dict):
            raise contract.H5ContractError(f"H4B_PER_SIGNAL_ENTRY:{name}")
        for key, unit in (
            ("RealValidUpdateFrameCount", "frames"), ("RealInvalidUpdateFrameCount", "frames"),
            ("CarriedFrameCount", "frames"), ("StaleFrameCount", "frames"),
            ("HoldBarrierFrameCount", "frames"), ("AgeQ95", "frames"), ("AgeMax", "frames"),
        ):
            add("SIGNAL", name, key, values.get(key), unit, "H4B")
    return rows


def _write_review_view(d2: Path, output: Path, selected: list[str]) -> None:
    keep = ["FrameCount"] + [name + suffix for name in selected for suffix in contract.SIGNAL_SUFFIXES]
    with d2.open("r", encoding="utf-8-sig", newline="") as source, output.open("w", encoding="utf-8", newline="") as target:
        reader = csv.DictReader(source)
        if not set(keep).issubset(reader.fieldnames or []):
            raise contract.H5ContractError("D6_SOURCE_COLUMNS")
        writer = csv.DictWriter(target, fieldnames=keep, lineterminator="\n")
        writer.writeheader()
        for row in reader:
            writer.writerow({column: row[column] for column in keep})


def assemble(
    h3: Path,
    h4a: Path,
    h4b: Path,
    frame_policy: Path,
    hold_policy_package: Path,
    review_profile: Path,
    output: Path,
) -> dict[str, Any]:
    h3m, h4m, h4q = contract.validate_upstream(h3, h4a, h4b)
    if not frame_policy.is_file():
        raise contract.H5ContractError("FRAME_POLICY_FILE")
    hold_policy = hold_policy_package / contract.HOLD_POLICY_FILE
    hold_quality = hold_policy_package / "u001_h4b_hold_policy_quality.json"
    if not hold_policy.is_file() or not hold_quality.is_file():
        raise contract.H5ContractError("HOLD_POLICY_PACKAGE")
    holdq = contract.load_json(hold_quality, "HOLD_POLICY_QUALITY")
    if holdq.get("Status") != "COMPILED" or holdq.get("CompletionCode") != 0:
        raise contract.H5ContractError("HOLD_POLICY_STATUS")
    if h4m.get("CompiledHoldPolicySHA256") != contract.sha256_file(hold_policy):
        raise contract.H5ContractError("HOLD_POLICY_IDENTITY_CHAIN")

    contract.require_empty_output(output)
    staging = Path(tempfile.mkdtemp(prefix=".u001_h5_", dir=str(output.parent)))
    try:
        d1 = staging / contract.D1
        d2 = staging / contract.D2
        shutil.copyfile(h3 / contract.H3_FILES["updates"], d1)
        shutil.copyfile(h4b / contract.H4B_FILES["frame"], d2)
        registry, bindings, update_count = contract.source_registry_from_d1(d1)
        frame_count, frame_signals, frame_min, frame_max = contract.validate_frame_csv(d2)
        review_signals = _review_selection(review_profile, frame_signals)

        catalog = _catalog_rows(
            h3 / contract.H3_FILES["policy"], frame_policy, hold_policy,
            frame_signals, bindings, set(review_signals),
        )
        with (staging / contract.D3).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=contract.D3_COLUMNS, lineterminator="\n")
            writer.writeheader(); writer.writerows(catalog)

        quality = _quality_rows(h3, h4b, len(registry), update_count, frame_count, len(frame_signals), len(review_signals))
        with (staging / contract.D4).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=contract.D4_COLUMNS, lineterminator="\n")
            writer.writeheader(); writer.writerows(quality)

        _write_review_view(d2, staging / contract.D6, review_signals)
        manifest = {
            "ManifestSchema": contract.PACKAGE_SCHEMA,
            "OutputBoundary": contract.OUTPUT_BOUNDARY,
            "ProgramName": PROGRAM_NAME,
            "ProgramVersion": PROGRAM_VERSION,
            "DatasetId": h3m["DatasetId"],
            "RunId": h3m["RunId"],
            "SegmentId": h3m["SegmentId"],
            "SourceSetMode": "SINGLE_SOURCE" if len(registry) == 1 else "MULTI_SOURCE_SYNCHRONIZED",
            "SourceRegistry": registry,
            "FrameDomain": {"FrameKey": "FrameCount", "FrameMinimum": frame_min, "FrameMaximum": frame_max, "FrameRowCount": frame_count},
            "ReviewProfile": {"FileName": review_profile.name, "SHA256": contract.sha256_file(review_profile), "Signals": review_signals},
            "UpstreamIdentity": {
                "H3ManifestSHA256": contract.sha256_file(h3 / contract.H3_FILES["manifest"]),
                "H4AManifestSHA256": contract.sha256_file(h4a / contract.H4A_FILES["manifest"]),
                "H4BManifestSHA256": contract.sha256_file(h4b / contract.H4B_FILES["manifest"]),
                "FramePolicySHA256": contract.sha256_file(frame_policy),
                "HoldPolicySHA256": contract.sha256_file(hold_policy),
            },
            "ExternalArtifactPolicy": {
                "ScalarFrameDataEmbedded": True,
                "RawPointCloudEmbedded": False,
                "FutureArtifactIndexSupported": True,
            },
            "Artifacts": [contract.artifact_record(staging / name) for name in (contract.D1, contract.D2, contract.D3, contract.D4, contract.D6)],
            "Counts": {"PackageFiles": 6, "Sources": len(registry), "Updates": update_count, "Frames": frame_count, "FrameSignals": len(frame_signals), "ReviewSignals": len(review_signals)},
            "Status": "COMPLETE",
            "CompletionCode": 0,
            "CreatedUTC": datetime.now(timezone.utc).isoformat(),
            "Warnings": [],
            "Errors": [],
        }
        contract.path_safe_json(manifest)
        contract.write_json(staging / contract.D5, manifest)
        if set(path.name for path in staging.iterdir()) != set(contract.PACKAGE_FILES):
            raise contract.H5ContractError("STAGING_INVENTORY")
        for name in contract.PACKAGE_FILES:
            os.replace(staging / name, output / name)
        staging.rmdir()
        return manifest
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        for path in output.iterdir():
            if path.is_file():
                path.unlink()
        raise


def self_test() -> None:
    contract.self_test()
    assert PROGRAM_VERSION == "1.0.0"
    assert len(contract.PACKAGE_FILES) == 6


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--h3-package", type=Path)
    parser.add_argument("--h4a-package", type=Path)
    parser.add_argument("--h4b-package", type=Path)
    parser.add_argument("--frame-policy", type=Path)
    parser.add_argument("--hold-policy-package", type=Path)
    parser.add_argument("--review-profile", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test(); print("U001-H5-ASSEMBLER-SELFTEST-PASS-3"); return 0
    required = [args.h3_package, args.h4a_package, args.h4b_package, args.frame_policy, args.hold_policy_package, args.review_profile, args.out]
    if any(value is None for value in required):
        parser.error("assembly requires all package, policy, profile and output arguments")
    try:
        manifest = assemble(*required)
        counts = manifest["Counts"]
        print(f"U1H5-R{counts['Updates']}-F{counts['Frames']}-S{counts['FrameSignals']}-V{counts['ReviewSignals']}-N{counts['Sources']}-X0-C0")
        return 0
    except Exception as exc:
        print(f"U1H5-ERROR-{type(exc).__name__}-{str(exc)[:180]}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
