#!/usr/bin/env python3
"""Shared, source-agnostic contracts for the U001 H5 handoff package.

H5 is an atomic packager.  It does not decode, synchronize, arbitrate targets,
or interpret raw sensor payloads.  All source-specific work belongs upstream.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import re
from pathlib import Path, PurePath
from typing import Any, Iterator


PROGRAM_NAME = "u001_h5_contract_core"
PROGRAM_VERSION = "1.0.0"
PACKAGE_SCHEMA = "U001_HANDOFF_PACKAGE_V1_0"
OUTPUT_BOUNDARY = "U001_TRUSTED_ANALYSIS_SOURCE_PACKAGE_V1_0"

D1 = "u001_decoded_updates.csv"
D2 = "u001_frame_values.csv"
D3 = "u001_signal_catalog.csv"
D4 = "u001_quality_report.csv"
D5 = "u001_run_manifest.json"
D6 = "u001_review_view.csv"
PACKAGE_FILES = (D1, D2, D3, D4, D5, D6)

H3_FILES = {
    "updates": "u001_h3_canonical_updates.csv",
    "policy": "u001_h3_compiled_signal_policy.csv",
    "frame_quality": "u001_h3_frame_quality.json",
    "canonical_quality": "u001_h3_canonical_quality.json",
    "policy_quality": "u001_h3_policy_quality.json",
    "manifest": "u001_h3_run_manifest.json",
    "capsule": "u001_h3_completion_capsule.txt",
}
H4B_FILES = {
    "frame": "u001_h4_bounded_frame_view.csv",
    "quality": "u001_h4_bounded_frame_quality.json",
    "manifest": "u001_h4_bounded_frame_manifest.json",
    "capsule": "u001_h4_bounded_frame_capsule.txt",
}
H4A_FILES = {
    "frame": "u001_h4_raw_frame_view.csv",
    "quality": "u001_h4_raw_frame_quality.json",
    "manifest": "u001_h4_raw_frame_manifest.json",
    "capsule": "u001_h4_raw_frame_capsule.txt",
}
FRAME_POLICY_FILE = "u001_h4_compiled_frame_policy.csv"
HOLD_POLICY_FILE = "u001_h4b_compiled_hold_policy.csv"

LEADING_COLUMNS = ["FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount"]
SIGNAL_SUFFIXES = [
    "__value", "__label", "__updated", "__update_count", "__age",
    "__valid", "__missing_reason",
]

D4_COLUMNS = ["Scope", "CanonicalName", "Metric", "Value", "Unit", "SourceGate", "Status", "Notes"]
D3_BASE_COLUMNS = [
    "CanonicalName", "CAN_ID", "Channel", "MessageName", "SignalName", "Unit",
    "ValueKind", "SignalRole", "UpdateMode", "StorageDtype", "StartBit",
    "BitLength", "ByteOrder", "Signed", "Scale", "Offset", "DBCMinimum",
    "DBCMaximum", "EnumerationMap", "ValidityRule", "ValiditySourceSignal",
    "ValidityExpression", "WithinFramePolicy", "HoldPolicy", "MaxAgeFrames",
    "NominalRateHz", "RequiredForAnalysis", "IncludeInFrameView",
    "IncludeInReviewView", "Notes", "SourceType", "SourceAdapter", "SourceFormat",
    "ClockDomain", "CoordinateFrame", "ReferencePoint", "AxisConvention",
    "OriginalUnit", "CanonicalUnit", "UnitConversionRule", "TopicName",
    "MessageType", "CalibrationVersion",
]
D3_PROVENANCE_COLUMNS = ["SourceId", "SourceChannel", "SourceMessageId", "PolicyStatus", "PolicyBasis"]
D3_COLUMNS = D3_BASE_COLUMNS + D3_PROVENANCE_COLUMNS


class H5ContractError(RuntimeError):
    """Fail-closed H5 package error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise H5ContractError(f"{label}_JSON:{exc}") from exc
    if not isinstance(value, dict):
        raise H5ContractError(f"{label}_OBJECT")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def is_basename(value: str) -> bool:
    path = PurePath(value)
    return bool(value) and not path.is_absolute() and len(path.parts) == 1 and value not in {".", ".."}


def require_empty_output(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise H5ContractError("OUTPUT_NOT_EMPTY")


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            header = list(reader.fieldnames or [])
            return header, list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise H5ContractError(f"CSV_READ:{path.name}:{exc}") from exc


def parse_int(value: str, label: str, *, blank: bool = False, minimum: int | None = None) -> int | None:
    text = value.strip()
    if blank and not text:
        return None
    try:
        number = float(text)
    except ValueError as exc:
        raise H5ContractError(f"{label}_INTEGER:{text}") from exc
    if not math.isfinite(number) or not number.is_integer():
        raise H5ContractError(f"{label}_INTEGER:{text}")
    result = int(number)
    if minimum is not None and result < minimum:
        raise H5ContractError(f"{label}_MINIMUM:{result}")
    return result


def discover_signals(header: list[str]) -> list[str]:
    if header[:4] != LEADING_COLUMNS:
        raise H5ContractError("D2_LEADING_COLUMNS")
    rest = header[4:]
    width = len(SIGNAL_SUFFIXES)
    if not rest or len(rest) % width:
        raise H5ContractError("D2_SIGNAL_GROUP_WIDTH")
    names: list[str] = []
    for offset in range(0, len(rest), width):
        group = rest[offset : offset + width]
        if not group[0].endswith("__value"):
            raise H5ContractError(f"D2_SIGNAL_GROUP_START:{group[0]}")
        name = group[0][:-7]
        if not name or group != [name + suffix for suffix in SIGNAL_SUFFIXES] or name in names:
            raise H5ContractError(f"D2_SIGNAL_GROUP:{name}")
        names.append(name)
    return names


def validate_frame_csv(path: Path) -> tuple[int, list[str], int, int]:
    header, rows = read_csv_rows(path)
    names = discover_signals(header)
    previous: int | None = None
    first = last = -1
    for index, row in enumerate(rows):
        frame = parse_int(row["FrameCount"], "FRAMECOUNT", minimum=0)
        assert frame is not None
        if previous is not None and frame <= previous:
            raise H5ContractError("D2_FRAMECOUNT_NOT_STRICT")
        previous = frame
        if index == 0:
            first = frame
        last = frame
        for name in names:
            updated = parse_int(row[name + "__updated"], f"{name}_UPDATED", minimum=0)
            valid = parse_int(row[name + "__valid"], f"{name}_VALID", minimum=0)
            count = parse_int(row[name + "__update_count"], f"{name}_UPDATE_COUNT", minimum=0)
            age = parse_int(row[name + "__age"], f"{name}_AGE", blank=True, minimum=0)
            if updated not in {0, 1} or valid not in {0, 1}:
                raise H5ContractError(f"D2_FLAG_STATE:{name}")
            if updated == 1 and (count is None or count < 1 or age != 0):
                raise H5ContractError(f"D2_UPDATED_STATE:{name}")
            if valid == 1 and row[name + "__value"] == "":
                raise H5ContractError(f"D2_VALID_BLANK:{name}")
            if not row[name + "__missing_reason"].strip():
                raise H5ContractError(f"D2_MISSING_REASON:{name}")
    if not rows:
        raise H5ContractError("D2_EMPTY")
    return len(rows), names, first, last


def validate_manifest_artifacts(folder: Path, manifest: dict[str, Any], expected: set[str], label: str) -> None:
    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list):
        raise H5ContractError(f"{label}_ARTIFACT_LIST")
    seen: set[str] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise H5ContractError(f"{label}_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        if not is_basename(name) or name in seen:
            raise H5ContractError(f"{label}_ARTIFACT_NAME:{name}")
        seen.add(name)
        path = folder / name
        if not path.is_file():
            raise H5ContractError(f"{label}_ARTIFACT_MISSING:{name}")
        if item.get("SizeBytes") != path.stat().st_size or item.get("SHA256") != sha256_file(path):
            raise H5ContractError(f"{label}_ARTIFACT_IDENTITY:{name}")
    if seen != expected:
        raise H5ContractError(f"{label}_ARTIFACT_INVENTORY")


def validate_upstream(h3: Path, h4a: Path, h4b: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    if not h3.is_dir() or not h4a.is_dir() or not h4b.is_dir():
        raise H5ContractError("UPSTREAM_FOLDER")
    for name in H3_FILES.values():
        if not (h3 / name).is_file():
            raise H5ContractError(f"H3_FILE:{name}")
    for name in H4B_FILES.values():
        if not (h4b / name).is_file():
            raise H5ContractError(f"H4B_FILE:{name}")
    for name in H4A_FILES.values():
        if not (h4a / name).is_file():
            raise H5ContractError(f"H4A_FILE:{name}")
    h3m = load_json(h3 / H3_FILES["manifest"], "H3_MANIFEST")
    h4am = load_json(h4a / H4A_FILES["manifest"], "H4A_MANIFEST")
    h4m = load_json(h4b / H4B_FILES["manifest"], "H4B_MANIFEST")
    h4q = load_json(h4b / H4B_FILES["quality"], "H4B_QUALITY")
    if h3m.get("OutputBoundary") != "U001_H3_CANONICAL_UPDATE_PACKAGE_V1_0":
        raise H5ContractError("H3_BOUNDARY")
    if h4m.get("OutputBoundary") != "U001_H4B_BOUNDED_FRAME_VIEW_PACKAGE_V1_0":
        raise H5ContractError("H4B_BOUNDARY")
    if h4am.get("OutputBoundary") != "U001_H4_RAW_FRAME_VIEW_PACKAGE_V1_0":
        raise H5ContractError("H4A_BOUNDARY")
    for label, item in (("H3", h3m), ("H4A", h4am), ("H4B", h4m), ("H4B_QUALITY", h4q)):
        if item.get("Status") != "COMPLETE" or item.get("CompletionCode") != 0:
            raise H5ContractError(f"{label}_STATUS")
    h3_expected = {
        H3_FILES["updates"], H3_FILES["policy"], H3_FILES["frame_quality"],
        H3_FILES["canonical_quality"], H3_FILES["policy_quality"],
        "u001_h3_frame_map.csv",
    }
    validate_manifest_artifacts(h3, h3m, h3_expected, "H3")
    validate_manifest_artifacts(h4a, h4am, {H4A_FILES["frame"], H4A_FILES["quality"]}, "H4A")
    validate_manifest_artifacts(h4b, h4m, {H4B_FILES["frame"], H4B_FILES["quality"]}, "H4B")
    identities = [str(x) for x in (h3m.get("DatasetId"), h3m.get("RunId"), h3m.get("SegmentId"))]
    if identities != [str(x) for x in (h4m.get("DatasetId"), h4m.get("RunId"), h4m.get("SegmentId"))]:
        raise H5ContractError("UPSTREAM_IDENTITY_MISMATCH")
    if h4am.get("InputH3ManifestSHA256") != sha256_file(h3 / H3_FILES["manifest"]):
        raise H5ContractError("H3_H4A_IDENTITY_CHAIN")
    if h4m.get("InputH4AManifestSHA256") != sha256_file(h4a / H4A_FILES["manifest"]):
        raise H5ContractError("H4A_H4B_IDENTITY_CHAIN")
    if h4q.get("WholeFileMemoryLoadRequired") is not False or h4q.get("UnboundedHoldCount") != 0:
        raise H5ContractError("H4B_RESOURCE_OR_HOLD_BOUNDARY")
    return h3m, h4m, h4q


def source_registry_from_d1(path: Path) -> tuple[list[dict[str, str]], dict[str, set[str]], int]:
    required = {"SourceId", "SourceType", "ClockDomain", "CanonicalName"}
    registry: dict[tuple[str, str, str], int] = {}
    bindings: dict[str, set[str]] = {}
    header, rows = read_csv_rows(path)
    if not required.issubset(header):
        raise H5ContractError(f"D1_SOURCE_COLUMNS:{sorted(required-set(header))}")
    for row in rows:
        source_id = row["SourceId"].strip()
        source_type = row["SourceType"].strip()
        clock = row["ClockDomain"].strip()
        name = row["CanonicalName"].strip()
        if not all((source_id, source_type, clock, name)):
            raise H5ContractError("D1_SOURCE_IDENTITY_BLANK")
        key = (source_id, source_type, clock)
        registry[key] = registry.get(key, 0) + 1
        bindings.setdefault(name, set()).add(source_id)
    if not rows:
        raise H5ContractError("D1_EMPTY")
    ambiguous = sorted(name for name, ids in bindings.items() if len(ids) > 1)
    if ambiguous:
        raise H5ContractError(f"CANONICAL_MULTI_SOURCE_BINDING:{ambiguous[:5]}")
    result = [
        {"SourceId": key[0], "SourceType": key[1], "ClockDomain": key[2], "UpdateRowCount": str(count)}
        for key, count in sorted(registry.items())
    ]
    return result, bindings, len(rows)


def path_safe_json(value: Any, path: str = "ROOT") -> None:
    """Reject host paths/user paths while permitting basenames and identifiers."""
    if isinstance(value, dict):
        for key, item in value.items():
            path_safe_json(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            path_safe_json(item, f"{path}[{index}]")
    elif isinstance(value, str):
        lowered = value.lower()
        if re.search(r"(^|[\\/])[a-z]:[\\/]", lowered) or lowered.startswith(("/users/", "/home/", "\\\\")):
            raise H5ContractError(f"D5_HOST_PATH:{path}")


def artifact_record(path: Path) -> dict[str, Any]:
    return {"FileName": path.name, "SizeBytes": path.stat().st_size, "SHA256": sha256_file(path)}


def self_test() -> None:
    assert PACKAGE_FILES == (D1, D2, D3, D4, D5, D6)
    assert len(D3_COLUMNS) == len(set(D3_COLUMNS))
    assert len(D4_COLUMNS) == 8
    assert discover_signals(LEADING_COLUMNS + ["A" + suffix for suffix in SIGNAL_SUFFIXES]) == ["A"]
    assert is_basename("x.csv") and not is_basename("a/x.csv")
    path_safe_json({"FileName": "x.csv", "SourceId": "CAN_1"})


if __name__ == "__main__":
    self_test()
    print("U001-H5-CONTRACT-SELFTEST-PASS-5")
