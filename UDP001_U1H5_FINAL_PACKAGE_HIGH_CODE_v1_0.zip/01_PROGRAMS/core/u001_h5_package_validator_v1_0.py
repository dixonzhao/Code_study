#!/usr/bin/env python3
"""Independent structural and semantic validator for the U001 H5 package."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Any

import u001_h5_contract_core_v1_0 as contract


PROGRAM_NAME = "u001_h5_package_validator"
PROGRAM_VERSION = "1.0.0"


def _validate_catalog(path: Path, signals: list[str]) -> tuple[int, set[str]]:
    header, rows = contract.read_csv_rows(path)
    if header != contract.D3_COLUMNS:
        raise contract.H5ContractError("D3_HEADER")
    names = [row["CanonicalName"] for row in rows]
    if not names or len(names) != len(set(names)):
        raise contract.H5ContractError("D3_CANONICAL_UNIQUE")
    by_name = {row["CanonicalName"]: row for row in rows}
    if not set(signals).issubset(by_name):
        raise contract.H5ContractError("D3_FRAME_SIGNAL_COVERAGE")
    review = {name for name, row in by_name.items() if row["IncludeInReviewView"] == "1"}
    for name in signals:
        if by_name[name]["IncludeInFrameView"] != "1":
            raise contract.H5ContractError(f"D3_FRAME_FLAG:{name}")
        if by_name[name]["HoldPolicy"] not in {"NONE", "HOLD_LAST_BOUNDED"}:
            raise contract.H5ContractError(f"D3_HOLD_POLICY:{name}")
    return len(rows), review


def _validate_quality(path: Path) -> None:
    header, rows = contract.read_csv_rows(path)
    if header != contract.D4_COLUMNS or not rows:
        raise contract.H5ContractError("D4_STRUCTURE")
    values = {(row["Scope"], row["Metric"]): row for row in rows}
    for key, expected in (("package_file_count", "6"), ("package_error_count", "0")):
        row = values.get(("PACKAGE", key))
        if not row or row["Value"] != expected or row["Status"] != "OK":
            raise contract.H5ContractError(f"D4_PACKAGE_METRIC:{key}")
    for row in rows:
        if row["Status"] == "NOT_AVAILABLE" and row["Value"] != "":
            raise contract.H5ContractError("D4_NOT_AVAILABLE_VALUE")


def _validate_review(d2: Path, d6: Path, selected: set[str]) -> int:
    d2_header, d2_rows = contract.read_csv_rows(d2)
    d6_header, d6_rows = contract.read_csv_rows(d6)
    if not d6_header or d6_header[0] != "FrameCount" or len(d2_rows) != len(d6_rows):
        raise contract.H5ContractError("D6_SHAPE")
    expected_columns = {"FrameCount"} | {name + suffix for name in selected for suffix in contract.SIGNAL_SUFFIXES}
    if set(d6_header) != expected_columns or len(d6_header) != len(expected_columns):
        raise contract.H5ContractError("D6_COLUMNS")
    if any(column not in d2_header for column in d6_header):
        raise contract.H5ContractError("D6_D2_SUBSET")
    for source, review in zip(d2_rows, d6_rows):
        if any(source[column] != review[column] for column in d6_header):
            raise contract.H5ContractError("D6_VALUE_IDENTITY")
    return len(d6_rows)


def validate(package: Path) -> dict[str, Any]:
    if not package.is_dir():
        raise contract.H5ContractError("PACKAGE_FOLDER")
    names = {path.name for path in package.iterdir() if path.is_file()}
    if names != set(contract.PACKAGE_FILES):
        raise contract.H5ContractError(f"PACKAGE_INVENTORY:MISSING={sorted(set(contract.PACKAGE_FILES)-names)}:EXTRA={sorted(names-set(contract.PACKAGE_FILES))}")
    manifest = contract.load_json(package / contract.D5, "D5")
    if manifest.get("ManifestSchema") != contract.PACKAGE_SCHEMA or manifest.get("OutputBoundary") != contract.OUTPUT_BOUNDARY:
        raise contract.H5ContractError("D5_CONTRACT")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise contract.H5ContractError("D5_STATUS")
    contract.path_safe_json(manifest)
    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list) or len(artifacts) != 5:
        raise contract.H5ContractError("D5_ARTIFACT_LIST")
    expected = set(contract.PACKAGE_FILES) - {contract.D5}
    seen: set[str] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise contract.H5ContractError("D5_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        seen.add(name)
        path = package / name
        if name not in expected or not path.is_file() or item.get("SizeBytes") != path.stat().st_size or item.get("SHA256") != contract.sha256_file(path):
            raise contract.H5ContractError(f"D5_ARTIFACT_IDENTITY:{name}")
    if seen != expected:
        raise contract.H5ContractError("D5_ARTIFACT_INVENTORY")

    registry, _, updates = contract.source_registry_from_d1(package / contract.D1)
    frames, signals, frame_min, frame_max = contract.validate_frame_csv(package / contract.D2)
    catalog_rows, selected = _validate_catalog(package / contract.D3, signals)
    _validate_quality(package / contract.D4)
    review_rows = _validate_review(package / contract.D2, package / contract.D6, selected)
    counts = manifest.get("Counts", {})
    expected_counts = {
        "PackageFiles": 6, "Sources": len(registry), "Updates": updates,
        "Frames": frames, "FrameSignals": len(signals), "ReviewSignals": len(selected),
    }
    if counts != expected_counts:
        raise contract.H5ContractError("D5_COUNTS")
    if manifest.get("SourceRegistry") != registry:
        raise contract.H5ContractError("D5_SOURCE_REGISTRY")
    mode = "SINGLE_SOURCE" if len(registry) == 1 else "MULTI_SOURCE_SYNCHRONIZED"
    if manifest.get("SourceSetMode") != mode:
        raise contract.H5ContractError("D5_SOURCE_SET_MODE")
    domain = manifest.get("FrameDomain", {})
    if domain != {"FrameKey": "FrameCount", "FrameMinimum": frame_min, "FrameMaximum": frame_max, "FrameRowCount": frames}:
        raise contract.H5ContractError("D5_FRAME_DOMAIN")
    return {
        "Sources": len(registry), "Updates": updates, "Frames": frames,
        "Signals": len(signals), "ReviewSignals": len(selected),
        "CatalogRows": catalog_rows, "ReviewRows": review_rows,
    }


def self_test() -> None:
    contract.self_test()
    assert PROGRAM_NAME.endswith("validator")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--package", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test(); print("U001-H5-VALIDATOR-SELFTEST-PASS-2"); return 0
    if args.package is None:
        parser.error("--package is required")
    try:
        result = validate(args.package)
        print(f"U1H5V-N{result['Sources']}-R{result['Updates']}-F{result['Frames']}-S{result['Signals']}-V{result['ReviewSignals']}-X0-C0")
        return 0
    except Exception as exc:
        print(f"U1H5V-ERROR-{type(exc).__name__}-{str(exc)[:180]}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
