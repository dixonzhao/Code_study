#!/usr/bin/env python3
"""Black-box acceptance for H5, including a synchronized multi-source case."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_h5_package_acceptance"
PROGRAM_VERSION = "1.0.0"


class AcceptanceError(RuntimeError):
    pass


def _load(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise AcceptanceError(f"IMPORT:{path.name}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def _json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def _artifact(path: Path, core: Any) -> dict[str, Any]:
    return {"FileName": path.name, "SizeBytes": path.stat().st_size, "SHA256": core.sha256_file(path)}


def _fixture(root: Path, core: Any) -> tuple[Path, Path, Path, Path, Path, Path]:
    h3 = root / "h3"; h4a = root / "h4a"; h4b = root / "h4b"; hold = root / "hold"
    for folder in (h3, h4a, h4b, hold): folder.mkdir(parents=True)
    signals = ["CAN_RADAR_DISTANCE", "GNSS_VEHICLE_SPEED", "CAN_DETECTION_FLAG"]
    d1_header = [
        "SourceRowIndex", "SourceId", "SourceType", "SourceAdapterId", "SourceAdapterVersion",
        "ClockDomain", "NativeTimestamp", "NativeSequence", "FrameCount", "SyncKey",
        "SyncQuality", "FrameAssignmentStatus", "FrameAssignmentAgeRows", "CAN_ID", "Channel",
        "MessageName", "SignalName", "CanonicalName", "RawCode", "PhysicalValue", "ValueLabel",
        "Unit", "ValueKind", "SignalRole", "UpdateMode", "StorageDtype", "PolicyStatus",
        "ValidityRule", "DecodeValid", "DecodeIssue", "IntrinsicValid", "IntrinsicMissingReason",
        "Valid", "MissingReason",
    ]
    d1_rows = [
        {"SourceRowIndex":"0","SourceId":"CAN_BUS_A","SourceType":"CAN","SourceAdapterId":"CAN_ADAPTER","SourceAdapterVersion":"1.0","ClockDomain":"CAMERA_FRAME","NativeTimestamp":"","NativeSequence":"0","FrameCount":"100","SyncKey":"100","SyncQuality":"EXACT","FrameAssignmentStatus":"EXACT","FrameAssignmentAgeRows":"0","CAN_ID":"0x380","Channel":"1","MessageName":"RADAR","SignalName":"Distance","CanonicalName":"CAN_RADAR_DISTANCE","RawCode":"10","PhysicalValue":"20.0","ValueLabel":"","Unit":"m","ValueKind":"FLOAT","SignalRole":"MEASUREMENT","UpdateMode":"ASYNCHRONOUS","StorageDtype":"float64","PolicyStatus":"APPROVED","ValidityRule":"NONE","DecodeValid":"1","DecodeIssue":"","IntrinsicValid":"1","IntrinsicMissingReason":"","Valid":"1","MissingReason":"VALID_UPDATE"},
        {"SourceRowIndex":"1","SourceId":"GNSS_RECEIVER_A","SourceType":"GNSS","SourceAdapterId":"GNSS_ADAPTER","SourceAdapterVersion":"1.0","ClockDomain":"CAMERA_FRAME","NativeTimestamp":"1.0","NativeSequence":"1","FrameCount":"100","SyncKey":"100","SyncQuality":"INTERPOLATED","FrameAssignmentStatus":"WITHIN_LIMIT","FrameAssignmentAgeRows":"0","CAN_ID":"","Channel":"","MessageName":"GNSS_NAV","SignalName":"Speed","CanonicalName":"GNSS_VEHICLE_SPEED","RawCode":"","PhysicalValue":"5.0","ValueLabel":"","Unit":"m/s","ValueKind":"FLOAT","SignalRole":"VEHICLE_STATE","UpdateMode":"SAMPLED","StorageDtype":"float64","PolicyStatus":"APPROVED","ValidityRule":"FIX_QUALITY","DecodeValid":"1","DecodeIssue":"","IntrinsicValid":"1","IntrinsicMissingReason":"","Valid":"1","MissingReason":"VALID_UPDATE"},
        {"SourceRowIndex":"2","SourceId":"CAN_BUS_A","SourceType":"CAN","SourceAdapterId":"CAN_ADAPTER","SourceAdapterVersion":"1.0","ClockDomain":"CAMERA_FRAME","NativeTimestamp":"","NativeSequence":"2","FrameCount":"101","SyncKey":"101","SyncQuality":"EXACT","FrameAssignmentStatus":"EXACT","FrameAssignmentAgeRows":"0","CAN_ID":"0x380","Channel":"1","MessageName":"RADAR","SignalName":"Detection","CanonicalName":"CAN_DETECTION_FLAG","RawCode":"1","PhysicalValue":"1","ValueLabel":"true","Unit":"1","ValueKind":"BOOLEAN","SignalRole":"EVENT_FLAG","UpdateMode":"ASYNCHRONOUS","StorageDtype":"int8","PolicyStatus":"APPROVED","ValidityRule":"NONE","DecodeValid":"1","DecodeIssue":"","IntrinsicValid":"1","IntrinsicMissingReason":"","Valid":"1","MissingReason":"VALID_UPDATE"},
    ]
    _csv(h3 / core.H3_FILES["updates"], d1_header, d1_rows)

    policy_fields = ["SourceAdapterId","SourceAdapterVersion","SourceType","SourceChannel","SourceMessageId","SourceMessageName","SourceSignalName","CanonicalNameCandidate","OriginalUnit","ValueKindHint","StartBit","BitLength","ByteOrder","Signed","Scale","Offset","DBCMinimum","DBCMaximum","EnumerationMap","Required","CanonicalName","PolicyStatus","ValueKind","SignalRole","UpdateMode","StorageDtype","ValidityRule","InvalidExactValues","UserMinimum","UserMaximum","InvalidReasonCode","Notes"]
    policy_rows=[]
    for name, source_type, adapter, signal, unit, kind, role in [
        (signals[0],"CAN","CAN_ADAPTER","Distance","m","FLOAT","MEASUREMENT"),
        (signals[1],"GNSS","GNSS_ADAPTER","Speed","m/s","FLOAT","VEHICLE_STATE"),
        (signals[2],"CAN","CAN_ADAPTER","Detection","1","BOOLEAN","EVENT_FLAG"),
    ]:
        row={field:"" for field in policy_fields}; row.update({"SourceAdapterId":adapter,"SourceAdapterVersion":"1.0","SourceType":source_type,"SourceChannel":"1" if source_type=="CAN" else "","SourceMessageId":"0x380" if source_type=="CAN" else "","SourceMessageName":"RADAR" if source_type=="CAN" else "GNSS_NAV","SourceSignalName":signal,"CanonicalNameCandidate":name,"OriginalUnit":unit,"ValueKindHint":kind,"Required":"1","CanonicalName":name,"PolicyStatus":"APPROVED","ValueKind":kind,"SignalRole":role,"UpdateMode":"ASYNCHRONOUS","StorageDtype":"float64" if kind=="FLOAT" else "int8","ValidityRule":"NONE"}); policy_rows.append(row)
    _csv(h3 / core.H3_FILES["policy"], policy_fields, policy_rows)
    _csv(h3 / "u001_h3_frame_map.csv", ["SourceRowIndex","FrameCount"], [{"SourceRowIndex":i,"FrameCount":100+(i>1)} for i in range(3)])
    _json(h3 / core.H3_FILES["frame_quality"], {"unassigned_no_prior_source_row_count":0,"unassigned_limit_source_row_count":0})
    _json(h3 / core.H3_FILES["canonical_quality"], {"valid_update_count":3,"invalid_update_count":0})
    _json(h3 / core.H3_FILES["policy_quality"], {"provisional_policy_row_count":0})
    h3_artifacts=[_artifact(h3/name,core) for name in (core.H3_FILES["updates"],core.H3_FILES["policy"],core.H3_FILES["frame_quality"],core.H3_FILES["canonical_quality"],core.H3_FILES["policy_quality"],"u001_h3_frame_map.csv")]
    h3_manifest={"ManifestSchema":"U001_H3_RUN_MANIFEST_V1_0","OutputBoundary":"U001_H3_CANONICAL_UPDATE_PACKAGE_V1_0","DatasetId":"SYNTHETIC_MULTI_SOURCE","RunId":"RUN_A","SegmentId":"SEG_A","Artifacts":h3_artifacts,"Status":"COMPLETE","CompletionCode":0}
    _json(h3/core.H3_FILES["manifest"],h3_manifest); (h3/core.H3_FILES["capsule"]).write_text("U1H3-X0-C0\n")

    frame_fields=core.LEADING_COLUMNS+[name+s for name in signals for s in core.SIGNAL_SUFFIXES]
    frame_rows=[]
    for frame in (100,101,102):
        row={field:"" for field in frame_fields}; row.update({"FrameCount":str(frame),"SourceRowFirst":"0","SourceRowLast":"2","SourceUpdateCount":"1"})
        for name in signals:
            row.update({name+"__updated":"0",name+"__update_count":"0",name+"__age":"",name+"__valid":"0",name+"__missing_reason":"NO_UPDATE"})
        frame_rows.append(row)
    frame_rows[0].update({signals[0]+"__value":"20.0",signals[0]+"__updated":"1",signals[0]+"__update_count":"1",signals[0]+"__age":"0",signals[0]+"__valid":"1",signals[0]+"__missing_reason":"VALID_UPDATE"})
    frame_rows[0].update({signals[1]+"__value":"5.0",signals[1]+"__updated":"1",signals[1]+"__update_count":"1",signals[1]+"__age":"0",signals[1]+"__valid":"1",signals[1]+"__missing_reason":"VALID_UPDATE"})
    frame_rows[1].update({signals[2]+"__value":"1",signals[2]+"__label":"true",signals[2]+"__updated":"1",signals[2]+"__update_count":"1",signals[2]+"__age":"0",signals[2]+"__valid":"1",signals[2]+"__missing_reason":"VALID_UPDATE"})
    # H4A is raw/no cross-frame hold.
    _csv(h4a/core.H4A_FILES["frame"],frame_fields,frame_rows)
    h4aq={"Status":"COMPLETE","CompletionCode":0,"CrossFrameHeldCellCount":0,"ZeroFillCount":0,"SyntheticFrameCount":0,"WholeFileMemoryLoadRequired":False}
    _json(h4a/core.H4A_FILES["quality"],h4aq)
    h4am={"ManifestSchema":"U001_H4_RAW_FRAME_MANIFEST_V1_0","OutputBoundary":"U001_H4_RAW_FRAME_VIEW_PACKAGE_V1_0","DatasetId":"SYNTHETIC_MULTI_SOURCE","RunId":"RUN_A","SegmentId":"SEG_A","InputH3ManifestSHA256":core.sha256_file(h3/core.H3_FILES["manifest"]),"Artifacts":[_artifact(h4a/core.H4A_FILES["frame"],core),_artifact(h4a/core.H4A_FILES["quality"],core)],"Status":"COMPLETE","CompletionCode":0}
    _json(h4a/core.H4A_FILES["manifest"],h4am); (h4a/core.H4A_FILES["capsule"]).write_text("U1H4A-X0-C0\n")

    # H4B carries bounded values but never invents a source update.
    bounded=[dict(row) for row in frame_rows]
    for index in (1,2):
        for name in signals[:2]:
            bounded[index][name+"__value"] = bounded[0][name+"__value"]
            bounded[index][name+"__updated"] = "0"
            bounded[index][name+"__update_count"] = "0"
            bounded[index][name+"__age"] = str(index)
            bounded[index][name+"__valid"] = "1"
            bounded[index][name+"__missing_reason"] = "CARRIED_VALID"
    _csv(h4b/core.H4B_FILES["frame"],frame_fields,bounded)
    per={name:{"HoldPolicy":"NONE" if name==signals[2] else "HOLD_LAST_BOUNDED","MaxAgeFrames":0 if name==signals[2] else 2,"RealValidUpdateFrameCount":1,"RealInvalidUpdateFrameCount":0,"CarriedFrameCount":0 if name==signals[2] else 2,"StaleFrameCount":0,"HoldBarrierFrameCount":0,"AgeQ95":None if name==signals[2] else 2,"AgeMax":None if name==signals[2] else 2} for name in signals}
    h4bq={"Status":"COMPLETE","CompletionCode":0,"WholeFileMemoryLoadRequired":False,"UnboundedHoldCount":0,"CarriedCellCount":4,"StaleCellCount":0,"HoldBarrierCellCount":0,"PerSignal":per}
    _json(h4b/core.H4B_FILES["quality"],h4bq)
    frame_policy=root/"u001_h4_compiled_frame_policy.csv"
    frame_policy_fields=["PolicySchema","CanonicalName","ValueKind","SignalRole","IncludeInFrameView","WithinFramePolicy","Required","PolicyStatus","Notes"]
    _csv(frame_policy,frame_policy_fields,[{"PolicySchema":"U001_H4_FRAME_POLICY_V1_0","CanonicalName":name,"ValueKind":"BOOLEAN" if name==signals[2] else "FLOAT","SignalRole":"EVENT_FLAG" if name==signals[2] else "MEASUREMENT","IncludeInFrameView":"1","WithinFramePolicy":"ANY_TRUE" if name==signals[2] else "LAST_UPDATE","Required":"1","PolicyStatus":"APPROVED","Notes":""} for name in signals])
    hold_fields=["PolicySchema","CanonicalName","ValueKind","SignalRole","Required","HoldPolicy","MaxAgeFrames","PolicyBasis","PolicyStatus","ObservedGapQ95","ObservedGapQ99","ObservedGapMax","Notes"]
    hold_rows=[{"PolicySchema":"U001_H4B_HOLD_POLICY_V1_0","CanonicalName":name,"ValueKind":"BOOLEAN" if name==signals[2] else "FLOAT","SignalRole":"EVENT_FLAG" if name==signals[2] else "MEASUREMENT","Required":"1","HoldPolicy":"NONE" if name==signals[2] else "HOLD_LAST_BOUNDED","MaxAgeFrames":"0" if name==signals[2] else "2","PolicyBasis":"SYNTHETIC_APPROVAL","PolicyStatus":"APPROVED","ObservedGapQ95":"2","ObservedGapQ99":"2","ObservedGapMax":"2","Notes":""} for name in signals]
    _csv(hold/core.HOLD_POLICY_FILE,hold_fields,hold_rows)
    _json(hold/"u001_h4b_hold_policy_quality.json",{"Status":"COMPILED","CompletionCode":0})
    h4bm={"ManifestSchema":"U001_H4B_BOUNDED_FRAME_MANIFEST_V1_0","OutputBoundary":"U001_H4B_BOUNDED_FRAME_VIEW_PACKAGE_V1_0","DatasetId":"SYNTHETIC_MULTI_SOURCE","RunId":"RUN_A","SegmentId":"SEG_A","InputH4AManifestSHA256":core.sha256_file(h4a/core.H4A_FILES["manifest"]),"CompiledHoldPolicySHA256":core.sha256_file(hold/core.HOLD_POLICY_FILE),"Artifacts":[_artifact(h4b/core.H4B_FILES["frame"],core),_artifact(h4b/core.H4B_FILES["quality"],core)],"Status":"COMPLETE","CompletionCode":0}
    _json(h4b/core.H4B_FILES["manifest"],h4bm); (h4b/core.H4B_FILES["capsule"]).write_text("U1H4B-X0-C0\n")
    profile=root/"review_profile.csv"
    _csv(profile,["ReviewProfileSchema","CanonicalName","IncludeInReviewView","ReviewOrder"],[{"ReviewProfileSchema":"U001_H5_REVIEW_PROFILE_V1_0","CanonicalName":name,"IncludeInReviewView":"1" if name!=signals[2] else "0","ReviewOrder":str(i)} for i,name in enumerate(signals)])
    return h3,h4a,h4b,frame_policy,hold,profile


def validate(core_dir: Path, output_root: Path) -> dict[str, Any]:
    names=["u001_h5_contract_core_v1_0.py","u001_h5_package_assembler_v1_0.py","u001_h5_package_validator_v1_0.py"]
    if any(not (core_dir/name).is_file() for name in names): raise AcceptanceError("PROGRAM_FILESET")
    sys.path.insert(0,str(core_dir.resolve()))
    core=_load(core_dir/names[0],"h5_accept_core"); assembler=_load(core_dir/names[1],"h5_accept_assembler"); validator=_load(core_dir/names[2],"h5_accept_validator")
    output_root.mkdir(parents=True,exist_ok=False); checks=0
    def check(value: bool,label: str)->None:
        nonlocal checks
        if not value: raise AcceptanceError(label)
        checks+=1
    core.self_test(); assembler.self_test(); validator.self_test(); check(True,"T01_SELFTESTS")
    h3,h4a,h4b,frame_policy,hold,profile=_fixture(output_root/"fixture",core); check(True,"T02_MULTI_SOURCE_FIXTURE")
    run_a=output_root/"run_a"; manifest=assembler.assemble(h3,h4a,h4b,frame_policy,hold,profile,run_a); check(manifest["SourceSetMode"]=="MULTI_SOURCE_SYNCHRONIZED","T03_MULTI_SOURCE_MODE")
    result=validator.validate(run_a); check(result["Sources"]==2 and result["Signals"]==3,"T04_VALIDATE")
    check((run_a/core.D1).read_bytes()==(h3/core.H3_FILES["updates"]).read_bytes(),"T05_D1_IDENTITY")
    check((run_a/core.D2).read_bytes()==(h4b/core.H4B_FILES["frame"]).read_bytes(),"T06_D2_IDENTITY")
    _,d6=core.read_csv_rows(run_a/core.D6); check(len(d6)==3 and result["ReviewSignals"]==2,"T07_D6_SUBSET")
    run_b=output_root/"run_b"; assembler.assemble(h3,h4a,h4b,frame_policy,hold,profile,run_b)
    check(all(core.sha256_file(run_a/name)==core.sha256_file(run_b/name) for name in (core.D1,core.D2,core.D3,core.D4,core.D6)),"T08_DETERMINISTIC_DATA")
    tampered=output_root/"tampered"; shutil.copytree(run_a,tampered); (tampered/core.D2).write_text((tampered/core.D2).read_text()+"\n")
    try: validator.validate(tampered)
    except Exception: check(True,"T09_TAMPER_REJECT")
    else: raise AcceptanceError("T09_TAMPER_REJECT")
    collision=output_root/"collision_h3"; shutil.copytree(h3,collision)
    header,rows=core.read_csv_rows(collision/core.H3_FILES["updates"]); rows[1]["CanonicalName"]="CAN_RADAR_DISTANCE"; _csv(collision/core.H3_FILES["updates"],header,rows)
    h3m=core.load_json(collision/core.H3_FILES["manifest"],"COLLISION");
    for item in h3m["Artifacts"]:
        if item["FileName"]==core.H3_FILES["updates"]: item.update(_artifact(collision/core.H3_FILES["updates"],core))
    _json(collision/core.H3_FILES["manifest"],h3m)
    h4am=core.load_json(h4a/core.H4A_FILES["manifest"],"H4A"); h4am["InputH3ManifestSHA256"]=core.sha256_file(collision/core.H3_FILES["manifest"]); collision_h4a=output_root/"collision_h4a"; shutil.copytree(h4a,collision_h4a); _json(collision_h4a/core.H4A_FILES["manifest"],h4am)
    h4bm=core.load_json(h4b/core.H4B_FILES["manifest"],"H4B"); h4bm["InputH4AManifestSHA256"]=core.sha256_file(collision_h4a/core.H4A_FILES["manifest"]); collision_h4b=output_root/"collision_h4b"; shutil.copytree(h4b,collision_h4b); _json(collision_h4b/core.H4B_FILES["manifest"],h4bm)
    try: assembler.assemble(collision,collision_h4a,collision_h4b,frame_policy,hold,profile,output_root/"collision_out")
    except Exception as exc: check("CANONICAL_MULTI_SOURCE_BINDING" in str(exc),"T10_BINDING_REJECT")
    else: raise AcceptanceError("T10_BINDING_REJECT")
    receipt={"AcceptanceSchema":"U001_H5_PACKAGE_ACCEPTANCE_V1_0","CheckCount":checks,"SourceCount":result["Sources"],"SignalCount":result["Signals"],"FrameCount":result["Frames"],"Status":"PASS","CompletionCode":0}
    _json(output_root/"u001_h5_acceptance_receipt.json",receipt); (output_root/"u001_h5_acceptance_capsule.txt").write_text(f"U1H5Q-T{checks}-N{result['Sources']}-S{result['Signals']}-F{result['Frames']}-X0-C0\n")
    return receipt


def self_test(core_dir: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="u1h5_") as temp: validate(core_dir,Path(temp)/"acceptance")


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument("--self-test",action="store_true"); parser.add_argument("--core-dir",type=Path,required=True); parser.add_argument("--out",type=Path)
    args=parser.parse_args()
    try:
        if args.self_test: self_test(args.core_dir); print("U001-H5-ACCEPTANCE-SELFTEST-PASS-10"); return 0
        if args.out is None: parser.error("--out is required")
        result=validate(args.core_dir,args.out); print(f"U1H5Q-T{result['CheckCount']}-N{result['SourceCount']}-S{result['SignalCount']}-F{result['FrameCount']}-X0-C0"); return 0
    except Exception as exc:
        print(f"U1H5Q-ERROR-{type(exc).__name__}-{str(exc)[:180]}-X1-C7"); return 7


if __name__=="__main__": raise SystemExit(main())
