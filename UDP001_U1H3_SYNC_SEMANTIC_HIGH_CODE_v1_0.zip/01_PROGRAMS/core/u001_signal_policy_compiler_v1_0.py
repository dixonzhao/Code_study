#!/usr/bin/env python3
"""Compile explicit signal identity, type and intrinsic-validity policy.

The compiler never guesses a business role from a signal name.  Controlled
profiles require approved policy rows.  Discovery inventory may retain
UNCLASSIFIED provisional rows, but those rows are not formal U002 input.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import tempfile
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_signal_policy_compiler"
PROGRAM_VERSION = "1.0.0"
CONTRACT_VERSION = "U001_H3_SIGNAL_POLICY_V1_0"

ALLOWED_MODES = {"CONTROLLED_PROFILE", "DISCOVERY_INVENTORY"}
ALLOWED_VALUE_KINDS = {"FLOAT", "INTEGER", "BOOLEAN", "ENUM", "BITFIELD"}
ALLOWED_SIGNAL_ROLES = {
    "MEASUREMENT",
    "STATE",
    "EVENT_FLAG",
    "VALIDITY_FLAG",
    "COUNTER",
    "IDENTIFIER",
    "FRAME_KEY",
}
ALLOWED_UPDATE_MODES = {"PERIODIC", "ON_CHANGE", "EVENT", "UNKNOWN"}
ALLOWED_VALIDITY_RULES = {"NONE", "EXACT_VALUES", "OUTSIDE_DBC_RANGE", "USER_RANGE"}
ALLOWED_POLICY_STATUS = {"APPROVED", "PROVISIONAL", "REQUIRES_ENGINEER"}

CATALOG_REQUIRED_COLUMNS = (
    "SourceAdapterId",
    "SourceAdapterVersion",
    "SourceType",
    "SourceChannel",
    "SourceMessageId",
    "SourceMessageName",
    "SourceSignalName",
    "CanonicalNameCandidate",
    "OriginalUnit",
    "ValueKindHint",
    "StartBit",
    "BitLength",
    "ByteOrder",
    "Signed",
    "Scale",
    "Offset",
    "DBCMinimum",
    "DBCMaximum",
    "EnumerationMap",
    "Required",
)

POLICY_COLUMNS = (
    "SourceCanonicalNameCandidate",
    "CanonicalName",
    "PolicyStatus",
    "ValueKind",
    "SignalRole",
    "UpdateMode",
    "StorageDtype",
    "ValidityRule",
    "InvalidExactValues",
    "DBCMinimum",
    "DBCMaximum",
    "UserMinimum",
    "UserMaximum",
    "InvalidReasonCode",
    "Required",
    "Notes",
)

COMPILED_COLUMNS = tuple(dict.fromkeys(CATALOG_REQUIRED_COLUMNS + POLICY_COLUMNS[1:]))

DEFAULT_STORAGE_DTYPES = {
    "FLOAT": "Float64",
    "INTEGER": "Int64",
    "BOOLEAN": "boolean",
    "ENUM": "Int64",
    "BITFIELD": "UInt64",
}


class SignalPolicyError(RuntimeError):
    """Fail-closed policy error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_csv(path: Path, required: tuple[str, ...], label: str) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        raise SignalPolicyError(f"{label}_FILE")
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None:
            raise SignalPolicyError(f"{label}_HEADER")
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise SignalPolicyError(f"{label}_DUPLICATE_HEADER")
        missing = sorted(set(required) - set(reader.fieldnames))
        if missing:
            raise SignalPolicyError(f"{label}_COLUMNS:{missing}")
        return list(reader.fieldnames), list(reader)


def _nonblank(value: Any, label: str) -> str:
    text = "" if value is None else str(value).strip()
    if not text:
        raise SignalPolicyError(f"{label}_EMPTY")
    return text


def _zero_one(value: Any, label: str) -> int:
    text = _nonblank(value, label)
    if text not in {"0", "1"}:
        raise SignalPolicyError(f"{label}_BOOLEAN")
    return int(text)


def _finite_decimal_or_blank(value: Any, label: str) -> Decimal | None:
    text = "" if value is None else str(value).strip()
    if not text:
        return None
    try:
        parsed = Decimal(text)
    except InvalidOperation as exc:
        raise SignalPolicyError(f"{label}_NUMERIC") from exc
    if not parsed.is_finite():
        raise SignalPolicyError(f"{label}_FINITE")
    return parsed


def _catalog_index(catalog_rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for row in catalog_rows:
        candidate = _nonblank(row["CanonicalNameCandidate"], "CATALOG_CANDIDATE")
        if candidate in result:
            raise SignalPolicyError(f"CATALOG_DUPLICATE_CANDIDATE:{candidate}")
        result[candidate] = row
    if not result:
        raise SignalPolicyError("CATALOG_EMPTY")
    return result


def make_policy_template(
    catalog_path: Path,
    output_path: Path,
    frame_signal_candidate: str,
    mode: str,
) -> int:
    mode = mode.strip().upper()
    if mode not in ALLOWED_MODES:
        raise SignalPolicyError("MODE")
    _, catalog_rows = _read_csv(catalog_path, CATALOG_REQUIRED_COLUMNS, "CATALOG")
    catalog = _catalog_index(catalog_rows)
    if frame_signal_candidate not in catalog:
        raise SignalPolicyError("FRAME_SIGNAL_NOT_IN_CATALOG")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for candidate, row in catalog.items():
            hint = row["ValueKindHint"].strip().upper()
            value_kind = hint if hint in ALLOWED_VALUE_KINDS else "FLOAT"
            is_frame = candidate == frame_signal_candidate
            status = "APPROVED" if is_frame else (
                "PROVISIONAL" if mode == "DISCOVERY_INVENTORY" else "REQUIRES_ENGINEER"
            )
            writer.writerow({
                "SourceCanonicalNameCandidate": candidate,
                "CanonicalName": candidate,
                "PolicyStatus": status,
                "ValueKind": "INTEGER" if is_frame else value_kind,
                "SignalRole": "FRAME_KEY" if is_frame else "UNCLASSIFIED",
                "UpdateMode": "PERIODIC" if is_frame else "UNKNOWN",
                "StorageDtype": "Int64" if is_frame else DEFAULT_STORAGE_DTYPES[value_kind],
                "ValidityRule": "NONE",
                "InvalidExactValues": "",
                "DBCMinimum": row["DBCMinimum"],
                "DBCMaximum": row["DBCMaximum"],
                "UserMinimum": "",
                "UserMaximum": "",
                "InvalidReasonCode": "",
                "Required": row["Required"] or "0",
                "Notes": "Authoritative frame identity" if is_frame else "Engineer classification required before controlled use",
            })
    return len(catalog)


def _validate_rule(row: dict[str, str]) -> None:
    rule = row["ValidityRule"].strip().upper()
    if rule not in ALLOWED_VALIDITY_RULES:
        raise SignalPolicyError(f"VALIDITY_RULE:{rule}")
    exact = row["InvalidExactValues"].strip()
    dbc_min = _finite_decimal_or_blank(row["DBCMinimum"], "DBC_MINIMUM")
    dbc_max = _finite_decimal_or_blank(row["DBCMaximum"], "DBC_MAXIMUM")
    user_min = _finite_decimal_or_blank(row["UserMinimum"], "USER_MINIMUM")
    user_max = _finite_decimal_or_blank(row["UserMaximum"], "USER_MAXIMUM")
    reason = row["InvalidReasonCode"].strip()
    if rule == "NONE":
        if exact or user_min is not None or user_max is not None or reason:
            raise SignalPolicyError("NONE_RULE_PARAMETERS")
    elif rule == "EXACT_VALUES":
        tokens = [token.strip() for token in exact.split(";") if token.strip()]
        if not tokens:
            raise SignalPolicyError("EXACT_VALUES_EMPTY")
        for token in tokens:
            _finite_decimal_or_blank(token, "EXACT_VALUE")
        if reason not in {"DBC_INVALID_DEFAULT", "USER_INVALID_RULE"}:
            raise SignalPolicyError("EXACT_REASON")
        if user_min is not None or user_max is not None:
            raise SignalPolicyError("EXACT_RANGE_PARAMETERS")
    elif rule == "OUTSIDE_DBC_RANGE":
        if dbc_min is None or dbc_max is None or dbc_min > dbc_max:
            raise SignalPolicyError("DBC_RANGE")
        if exact or user_min is not None or user_max is not None or reason:
            raise SignalPolicyError("DBC_RANGE_PARAMETERS")
    elif rule == "USER_RANGE":
        if user_min is None or user_max is None or user_min > user_max:
            raise SignalPolicyError("USER_RANGE")
        if exact or reason:
            raise SignalPolicyError("USER_RANGE_PARAMETERS")


def compile_signal_policy(
    catalog_path: Path,
    policy_path: Path,
    output_path: Path,
    quality_path: Path,
    frame_signal_candidate: str,
    mode: str,
) -> dict[str, Any]:
    started = time.perf_counter()
    mode = mode.strip().upper()
    if mode not in ALLOWED_MODES:
        raise SignalPolicyError("MODE")
    _, catalog_rows = _read_csv(catalog_path, CATALOG_REQUIRED_COLUMNS, "CATALOG")
    _, policy_rows = _read_csv(policy_path, POLICY_COLUMNS, "POLICY")
    catalog = _catalog_index(catalog_rows)
    if frame_signal_candidate not in catalog:
        raise SignalPolicyError("FRAME_SIGNAL_NOT_IN_CATALOG")

    policy_by_source: dict[str, dict[str, str]] = {}
    canonical_names: set[str] = set()
    provisional_count = 0
    required_count = 0
    for row in policy_rows:
        source_name = _nonblank(row["SourceCanonicalNameCandidate"], "POLICY_SOURCE_NAME")
        if source_name in policy_by_source:
            raise SignalPolicyError(f"POLICY_DUPLICATE_SOURCE:{source_name}")
        if source_name not in catalog:
            raise SignalPolicyError(f"POLICY_UNKNOWN_SOURCE:{source_name}")
        canonical_name = _nonblank(row["CanonicalName"], "POLICY_CANONICAL_NAME")
        if canonical_name in canonical_names:
            raise SignalPolicyError(f"POLICY_DUPLICATE_CANONICAL:{canonical_name}")
        canonical_names.add(canonical_name)
        status = row["PolicyStatus"].strip().upper()
        if status not in ALLOWED_POLICY_STATUS:
            raise SignalPolicyError(f"POLICY_STATUS:{status}")
        value_kind = row["ValueKind"].strip().upper()
        role = row["SignalRole"].strip().upper()
        update_mode = row["UpdateMode"].strip().upper()
        if value_kind not in ALLOWED_VALUE_KINDS:
            raise SignalPolicyError(f"VALUE_KIND:{value_kind}")
        if role != "UNCLASSIFIED" and role not in ALLOWED_SIGNAL_ROLES:
            raise SignalPolicyError(f"SIGNAL_ROLE:{role}")
        if update_mode not in ALLOWED_UPDATE_MODES:
            raise SignalPolicyError(f"UPDATE_MODE:{update_mode}")
        if row["StorageDtype"].strip() != DEFAULT_STORAGE_DTYPES[value_kind]:
            raise SignalPolicyError(f"STORAGE_DTYPE:{source_name}")
        required = _zero_one(row["Required"], "REQUIRED")
        required_count += required
        if mode == "CONTROLLED_PROFILE":
            if status != "APPROVED" or role == "UNCLASSIFIED":
                raise SignalPolicyError(f"CONTROLLED_POLICY_NOT_APPROVED:{source_name}")
        elif status != "APPROVED":
            provisional_count += 1
        _validate_rule(row)
        normalized = dict(row)
        for key in ("PolicyStatus", "ValueKind", "SignalRole", "UpdateMode", "ValidityRule"):
            normalized[key] = normalized[key].strip().upper()
        policy_by_source[source_name] = normalized

    missing_policy = sorted(set(catalog) - set(policy_by_source))
    if missing_policy:
        raise SignalPolicyError(f"POLICY_MISSING_SOURCE:{missing_policy[:5]}:{len(missing_policy)}")

    frame_policy = policy_by_source[frame_signal_candidate]
    if not (
        frame_policy["ValueKind"] == "INTEGER"
        and frame_policy["SignalRole"] == "FRAME_KEY"
        and frame_policy["UpdateMode"] == "PERIODIC"
        and frame_policy["ValidityRule"] == "NONE"
        and frame_policy["PolicyStatus"] == "APPROVED"
    ):
        raise SignalPolicyError("FRAME_POLICY_SEMANTICS")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(COMPILED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for catalog_row in catalog_rows:
            source_name = catalog_row["CanonicalNameCandidate"].strip()
            policy_row = policy_by_source[source_name]
            output = {key: catalog_row.get(key, "") for key in CATALOG_REQUIRED_COLUMNS}
            output.update({key: policy_row.get(key, "") for key in POLICY_COLUMNS[1:]})
            writer.writerow(output)

    quality: dict[str, Any] = {
        "QualitySchema": "U001_H3_SIGNAL_POLICY_QUALITY_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "Mode": mode,
        "CatalogSHA256": sha256_file(catalog_path),
        "PolicySHA256": sha256_file(policy_path),
        "catalog_row_count": len(catalog_rows),
        "compiled_policy_row_count": len(policy_rows),
        "required_policy_row_count": required_count,
        "provisional_policy_row_count": provisional_count,
        "approved_policy_row_count": len(policy_rows) - provisional_count,
        "formal_ready": mode == "CONTROLLED_PROFILE" and provisional_count == 0,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "Warnings": ["DISCOVERY_POLICY_NOT_FORMAL"] if provisional_count else [],
        "Errors": [],
    }
    quality_path.write_text(json.dumps(quality, indent=2) + "\n", encoding="utf-8")
    return quality


def _write_catalog(path: Path) -> None:
    rows = [
        ("FRAME", "INTEGER", "count", "0", "65535", "1"),
        ("DIST", "FLOAT", "m", "0", "655.35", "1"),
        ("FLAG", "BOOLEAN", "", "0", "1", "0"),
    ]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(CATALOG_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for order, (name, kind, unit, low, high, required) in enumerate(rows):
            row = {field: "" for field in CATALOG_REQUIRED_COLUMNS}
            row.update({
                "SourceAdapterId": "TEST",
                "SourceAdapterVersion": "1",
                "SourceType": "CAN",
                "SourceChannel": "1",
                "SourceMessageId": f"0x{order + 1:X}",
                "SourceMessageName": "M",
                "SourceSignalName": name,
                "CanonicalNameCandidate": name,
                "OriginalUnit": unit,
                "ValueKindHint": kind,
                "DBCMinimum": low,
                "DBCMaximum": high,
                "Required": required,
            })
            writer.writerow(row)


def _approve_template(path: Path) -> None:
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for row in rows:
            row["PolicyStatus"] = "APPROVED"
            if row["SourceCanonicalNameCandidate"] == "DIST":
                row["SignalRole"] = "MEASUREMENT"
            elif row["SourceCanonicalNameCandidate"] == "FLAG":
                row["SignalRole"] = "VALIDITY_FLAG"
            writer.writerow(row)


def self_test() -> None:
    checks = 0

    def ck(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_h3_policy_") as temp_text:
        temp = Path(temp_text)
        catalog = temp / "catalog.csv"
        policy = temp / "policy.csv"
        compiled = temp / "compiled.csv"
        quality = temp / "quality.json"
        _write_catalog(catalog)
        count = make_policy_template(catalog, policy, "FRAME", "CONTROLLED_PROFILE")
        rows = list(csv.DictReader(policy.open(encoding="utf-8")))
        ck(count == 3 and len(rows) == 3, "T01_TEMPLATE_COUNT")
        ck(rows[0]["SignalRole"] == "FRAME_KEY" and rows[0]["PolicyStatus"] == "APPROVED", "T02_FRAME_TEMPLATE")
        ck(rows[1]["SignalRole"] == "UNCLASSIFIED" and rows[1]["PolicyStatus"] == "REQUIRES_ENGINEER", "T03_NO_ROLE_GUESS")
        try:
            compile_signal_policy(catalog, policy, compiled, quality, "FRAME", "CONTROLLED_PROFILE")
        except SignalPolicyError as exc:
            ck("NOT_APPROVED" in str(exc), "T04_CONTROLLED_BLOCK")
        else:
            raise AssertionError("T04_CONTROLLED_BLOCK")
        _approve_template(policy)
        result = compile_signal_policy(catalog, policy, compiled, quality, "FRAME", "CONTROLLED_PROFILE")
        ck(result["formal_ready"] and result["compiled_policy_row_count"] == 3, "T05_APPROVED")
        compiled_rows = list(csv.DictReader(compiled.open(encoding="utf-8")))
        ck(compiled_rows[1]["OriginalUnit"] == "m" and compiled_rows[1]["SignalRole"] == "MEASUREMENT", "T06_JOIN")
        ck(compiled_rows[2]["StorageDtype"] == "boolean", "T07_DTYPE")

        discovery = temp / "discovery.csv"
        make_policy_template(catalog, discovery, "FRAME", "DISCOVERY_INVENTORY")
        discovery_result = compile_signal_policy(catalog, discovery, temp / "dc.csv", temp / "dq.json", "FRAME", "DISCOVERY_INVENTORY")
        ck(not discovery_result["formal_ready"] and discovery_result["provisional_policy_row_count"] == 2, "T08_DISCOVERY")

        exact_rows = list(csv.DictReader(policy.open(encoding="utf-8")))
        exact_rows[1]["ValidityRule"] = "EXACT_VALUES"
        exact_rows[1]["InvalidExactValues"] = "327.66;0"
        exact_rows[1]["InvalidReasonCode"] = "USER_INVALID_RULE"
        with (temp / "exact.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
            writer.writeheader(); writer.writerows(exact_rows)
        exact_result = compile_signal_policy(catalog, temp / "exact.csv", temp / "ec.csv", temp / "eq.json", "FRAME", "CONTROLLED_PROFILE")
        ck(exact_result["formal_ready"], "T09_EXACT")

        bad_none = [dict(row) for row in exact_rows]
        bad_none[1]["ValidityRule"] = "NONE"
        with (temp / "bad_none.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
            writer.writeheader(); writer.writerows(bad_none)
        try:
            compile_signal_policy(catalog, temp / "bad_none.csv", temp / "bn.csv", temp / "bn.json", "FRAME", "CONTROLLED_PROFILE")
        except SignalPolicyError as exc:
            ck("NONE_RULE_PARAMETERS" in str(exc), "T10_NONE_PARAMS")
        else:
            raise AssertionError("T10_NONE_PARAMS")

        duplicate = [dict(row) for row in list(csv.DictReader(policy.open(encoding="utf-8")))]
        duplicate[2]["CanonicalName"] = duplicate[1]["CanonicalName"]
        with (temp / "duplicate.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
            writer.writeheader(); writer.writerows(duplicate)
        try:
            compile_signal_policy(catalog, temp / "duplicate.csv", temp / "du.csv", temp / "du.json", "FRAME", "CONTROLLED_PROFILE")
        except SignalPolicyError as exc:
            ck("DUPLICATE_CANONICAL" in str(exc), "T11_DUPLICATE")
        else:
            raise AssertionError("T11_DUPLICATE")

        bad_dtype = [dict(row) for row in list(csv.DictReader(policy.open(encoding="utf-8")))]
        bad_dtype[1]["StorageDtype"] = "Int64"
        with (temp / "dtype.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
            writer.writeheader(); writer.writerows(bad_dtype)
        try:
            compile_signal_policy(catalog, temp / "dtype.csv", temp / "dt.csv", temp / "dt.json", "FRAME", "CONTROLLED_PROFILE")
        except SignalPolicyError as exc:
            ck("STORAGE_DTYPE" in str(exc), "T12_DTYPE_FAIL")
        else:
            raise AssertionError("T12_DTYPE_FAIL")

        missing = list(csv.DictReader(policy.open(encoding="utf-8")))[:-1]
        with (temp / "missing.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
            writer.writeheader(); writer.writerows(missing)
        try:
            compile_signal_policy(catalog, temp / "missing.csv", temp / "mi.csv", temp / "mi.json", "FRAME", "CONTROLLED_PROFILE")
        except SignalPolicyError as exc:
            ck("MISSING_SOURCE" in str(exc), "T13_MISSING")
        else:
            raise AssertionError("T13_MISSING")

        before = sha256_file(catalog)
        compile_signal_policy(catalog, policy, temp / "again.csv", temp / "again.json", "FRAME", "CONTROLLED_PROFILE")
        ck(sha256_file(catalog) == before, "T14_INPUT_IMMUTABLE")

    if checks != 14:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H3-SIGNAL-POLICY-SELFTEST-PASS-14")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Compile U001 H3 signal policy")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--make-template", action="store_true")
    action.add_argument("--compile", action="store_true")
    result.add_argument("--catalog", type=Path)
    result.add_argument("--policy", type=Path)
    result.add_argument("--output", type=Path)
    result.add_argument("--quality", type=Path)
    result.add_argument("--frame-signal")
    result.add_argument("--mode", default="CONTROLLED_PROFILE")
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test(); return 0
        if args.make_template:
            if not all((args.catalog, args.output, args.frame_signal)):
                raise SignalPolicyError("TEMPLATE_ARGUMENTS")
            count = make_policy_template(args.catalog, args.output, args.frame_signal, args.mode)
            print(f"U1H3PT-N{count}-X0-C0")
            return 0
        if not all((args.catalog, args.policy, args.output, args.quality, args.frame_signal)):
            raise SignalPolicyError("COMPILE_ARGUMENTS")
        quality = compile_signal_policy(args.catalog, args.policy, args.output, args.quality, args.frame_signal, args.mode)
        print(
            f"U1H3P-N{quality['compiled_policy_row_count']}-"
            f"A{quality['approved_policy_row_count']}-"
            f"P{quality['provisional_policy_row_count']}-"
            f"F{int(quality['formal_ready'])}-X0-C0"
        )
        return 0
    except (SignalPolicyError, OSError, ValueError, csv.Error, AssertionError) as exc:
        print(f"U1H3PE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
