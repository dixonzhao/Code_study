#!/usr/bin/env python3
"""Project adapter updates into traceable H3 canonical update records."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import tempfile
import time
from decimal import Decimal, InvalidOperation
from itertools import groupby
from pathlib import Path
from typing import Any, Iterator


PROGRAM_NAME = "u001_canonical_update_projector"
PROGRAM_VERSION = "1.0.0"
CONTRACT_VERSION = "U001_H3_CANONICAL_UPDATES_V1_0"

UPDATE_REQUIRED_COLUMNS = (
    "SourceRowIndex", "SourceId", "SourceType", "SourceAdapterId",
    "SourceAdapterVersion", "ClockDomain", "NativeTimestamp", "NativeSequence",
    "SyncKeyCandidate", "SourceChannel", "SourceMessageId", "SourceMessageName",
    "SourceSignalName", "CanonicalNameCandidate", "RawCode", "PhysicalValue",
    "ValueLabel", "OriginalUnit", "ValueKindHint", "DecodeValid", "DecodeIssue",
)

FRAME_MAP_REQUIRED_COLUMNS = (
    "SourceRowIndex", "FrameCount", "SyncKey", "SyncQuality",
    "FrameAssignmentStatus", "FrameAssignmentAgeRows", "FrameObservationCount",
)

POLICY_REQUIRED_COLUMNS = (
    "CanonicalNameCandidate", "CanonicalName", "OriginalUnit", "ValueKind",
    "SignalRole", "UpdateMode", "StorageDtype", "PolicyStatus", "ValidityRule",
    "InvalidExactValues", "DBCMinimum", "DBCMaximum", "UserMinimum",
    "UserMaximum", "InvalidReasonCode", "Required", "EnumerationMap",
)

OUTPUT_COLUMNS = (
    "SourceRowIndex", "SourceId", "SourceType", "SourceAdapterId",
    "SourceAdapterVersion", "ClockDomain", "NativeTimestamp", "NativeSequence",
    "FrameCount", "SyncKey", "SyncQuality", "FrameAssignmentStatus",
    "FrameAssignmentAgeRows", "CAN_ID", "Channel", "MessageName", "SignalName",
    "CanonicalName", "RawCode", "PhysicalValue", "ValueLabel", "Unit",
    "ValueKind", "SignalRole", "UpdateMode", "StorageDtype", "PolicyStatus",
    "ValidityRule", "DecodeValid", "DecodeIssue", "IntrinsicValid",
    "IntrinsicMissingReason", "Valid", "MissingReason",
)


class CanonicalUpdateError(RuntimeError):
    """Fail-closed canonical projection error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _reader(path: Path, required: tuple[str, ...], label: str) -> tuple[csv.DictReader, Any]:
    if not path.is_file():
        raise CanonicalUpdateError(f"{label}_FILE")
    stream = path.open("r", encoding="utf-8-sig", newline="")
    reader = csv.DictReader(stream)
    if reader.fieldnames is None:
        stream.close(); raise CanonicalUpdateError(f"{label}_HEADER")
    if len(reader.fieldnames) != len(set(reader.fieldnames)):
        stream.close(); raise CanonicalUpdateError(f"{label}_DUPLICATE_HEADER")
    missing = sorted(set(required) - set(reader.fieldnames))
    if missing:
        stream.close(); raise CanonicalUpdateError(f"{label}_COLUMNS:{missing}")
    return reader, stream


def _integer(value: Any, label: str) -> int:
    text = "" if value is None else str(value).strip()
    try:
        parsed = Decimal(text)
    except InvalidOperation as exc:
        raise CanonicalUpdateError(f"{label}_INTEGER") from exc
    if not parsed.is_finite() or parsed != parsed.to_integral_value():
        raise CanonicalUpdateError(f"{label}_INTEGER")
    return int(parsed)


def _decimal(value: Any) -> Decimal | None:
    text = "" if value is None else str(value).strip()
    if not text:
        return None
    try:
        parsed = Decimal(text)
    except InvalidOperation:
        return None
    return parsed if parsed.is_finite() else None


def _truth(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true"}


def _policy_index(path: Path) -> tuple[dict[str, dict[str, str]], dict[str, int]]:
    reader, stream = _reader(path, POLICY_REQUIRED_COLUMNS, "POLICY")
    result: dict[str, dict[str, str]] = {}
    required = {}
    canonical: set[str] = set()
    try:
        for row in reader:
            source_name = row["CanonicalNameCandidate"].strip()
            if not source_name or source_name in result:
                raise CanonicalUpdateError("POLICY_SOURCE_IDENTITY")
            output_name = row["CanonicalName"].strip()
            if not output_name or output_name in canonical:
                raise CanonicalUpdateError("POLICY_CANONICAL_IDENTITY")
            canonical.add(output_name)
            result[source_name] = row
            required[source_name] = _integer(row["Required"], "POLICY_REQUIRED")
            if required[source_name] not in {0, 1}:
                raise CanonicalUpdateError("POLICY_REQUIRED_BOOLEAN")
    finally:
        stream.close()
    if not result:
        raise CanonicalUpdateError("POLICY_EMPTY")
    return result, required


def _iter_update_groups(path: Path) -> Iterator[tuple[int, list[dict[str, str]]]]:
    reader, stream = _reader(path, UPDATE_REQUIRED_COLUMNS, "UPDATES")
    previous: int | None = None
    try:
        def indexed() -> Iterator[tuple[int, dict[str, str]]]:
            nonlocal previous
            for row in reader:
                index = _integer(row["SourceRowIndex"], "SOURCE_ROW_INDEX")
                if previous is not None and index < previous:
                    raise CanonicalUpdateError("SOURCE_ROW_INDEX_DECREASE")
                previous = index
                yield index, row
        for index, group in groupby(indexed(), key=lambda item: item[0]):
            yield index, [row for _, row in group]
    finally:
        stream.close()


def _iter_frame_map(path: Path) -> Iterator[tuple[int, dict[str, str]]]:
    reader, stream = _reader(path, FRAME_MAP_REQUIRED_COLUMNS, "FRAME_MAP")
    previous: int | None = None
    try:
        for row in reader:
            index = _integer(row["SourceRowIndex"], "FRAME_SOURCE_ROW_INDEX")
            if previous is not None and index <= previous:
                raise CanonicalUpdateError("FRAME_MAP_ORDER")
            previous = index
            yield index, row
    finally:
        stream.close()


def _type_and_intrinsic_validity(row: dict[str, str], policy: dict[str, str]) -> tuple[bool, str, bool]:
    """Return intrinsic validity, reason and unknown-enum warning."""
    if not _truth(row["DecodeValid"]):
        return False, "SOURCE_DECODE_INVALID", False
    value_kind = policy["ValueKind"].strip().upper()
    physical = _decimal(row["PhysicalValue"])
    raw = _decimal(row["RawCode"])
    type_valid = True
    unknown_enum = False
    if value_kind == "FLOAT":
        type_valid = physical is not None
    elif value_kind == "INTEGER":
        type_valid = physical is not None and physical == physical.to_integral_value()
    elif value_kind == "BOOLEAN":
        type_valid = physical in {Decimal(0), Decimal(1)}
    elif value_kind == "ENUM":
        type_valid = raw is not None and raw == raw.to_integral_value()
        if type_valid:
            try:
                enum_map = json.loads(policy["EnumerationMap"] or "{}")
            except json.JSONDecodeError as exc:
                raise CanonicalUpdateError("ENUMERATION_MAP_JSON") from exc
            if enum_map and str(int(raw)) not in {str(key) for key in enum_map} and not row["ValueLabel"].strip():
                unknown_enum = True
    elif value_kind == "BITFIELD":
        type_valid = raw is not None and raw == raw.to_integral_value() and raw >= 0
    else:
        raise CanonicalUpdateError(f"VALUE_KIND:{value_kind}")
    if not type_valid:
        return False, "SOURCE_TYPE_MISMATCH", False

    rule = policy["ValidityRule"].strip().upper()
    if rule == "NONE":
        return True, "UNKNOWN_ENUM_CODE" if unknown_enum else "VALID_UPDATE", unknown_enum
    comparison = physical if physical is not None else raw
    if comparison is None:
        return False, "SOURCE_TYPE_MISMATCH", unknown_enum
    if rule == "EXACT_VALUES":
        invalid = {
            Decimal(token.strip())
            for token in policy["InvalidExactValues"].split(";")
            if token.strip()
        }
        if comparison in invalid:
            return False, policy["InvalidReasonCode"].strip(), unknown_enum
    elif rule == "OUTSIDE_DBC_RANGE":
        lower = _decimal(policy["DBCMinimum"]); upper = _decimal(policy["DBCMaximum"])
        if lower is None or upper is None:
            raise CanonicalUpdateError("DBC_RANGE_POLICY")
        if comparison < lower or comparison > upper:
            return False, "OUT_OF_DBC_RANGE", unknown_enum
    elif rule == "USER_RANGE":
        lower = _decimal(policy["UserMinimum"]); upper = _decimal(policy["UserMaximum"])
        if lower is None or upper is None:
            raise CanonicalUpdateError("USER_RANGE_POLICY")
        if comparison < lower or comparison > upper:
            return False, "USER_INVALID_RULE", unknown_enum
    else:
        raise CanonicalUpdateError(f"VALIDITY_RULE:{rule}")
    return True, "UNKNOWN_ENUM_CODE" if unknown_enum else "VALID_UPDATE", unknown_enum


def project_canonical_updates(
    updates_path: Path,
    frame_map_path: Path,
    compiled_policy_path: Path,
    output_path: Path,
    quality_path: Path,
) -> dict[str, Any]:
    started = time.perf_counter()
    if output_path.resolve() in {updates_path.resolve(), frame_map_path.resolve(), compiled_policy_path.resolve()}:
        raise CanonicalUpdateError("OUTPUT_OVERWRITES_INPUT")
    policies, required = _policy_index(compiled_policy_path)
    observed = {name: 0 for name in policies}
    counts = {
        "input_update_row_count": 0,
        "output_update_row_count": 0,
        "valid_update_count": 0,
        "invalid_update_count": 0,
        "intrinsic_invalid_count": 0,
        "frame_unassigned_update_count": 0,
        "provisional_policy_update_count": 0,
        "valid_zero_count": 0,
        "valid_boolean_false_count": 0,
        "exact_invalid_count": 0,
        "outside_dbc_range_count": 0,
        "user_range_invalid_count": 0,
        "unknown_enum_code_count": 0,
        "dtype_conversion_failure_count": 0,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    quality_path.parent.mkdir(parents=True, exist_ok=True)
    frame_iterator = iter(_iter_frame_map(frame_map_path))
    current_frame = next(frame_iterator, None)

    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(OUTPUT_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for source_index, rows in _iter_update_groups(updates_path):
            if current_frame is None or current_frame[0] != source_index:
                raise CanonicalUpdateError(f"FRAME_MAP_IDENTITY:{source_index}")
            frame = current_frame[1]
            current_frame = next(frame_iterator, None)
            for row in rows:
                counts["input_update_row_count"] += 1
                source_name = row["CanonicalNameCandidate"].strip()
                if source_name not in policies:
                    raise CanonicalUpdateError(f"POLICY_MISSING_UPDATE:{source_name}")
                policy = policies[source_name]
                observed[source_name] += 1
                intrinsic_valid, intrinsic_reason, unknown_enum = _type_and_intrinsic_validity(row, policy)
                if not intrinsic_valid:
                    counts["intrinsic_invalid_count"] += 1
                    if intrinsic_reason == "SOURCE_TYPE_MISMATCH":
                        counts["dtype_conversion_failure_count"] += 1
                    elif intrinsic_reason in {"DBC_INVALID_DEFAULT", "USER_INVALID_RULE"} and policy["ValidityRule"] == "EXACT_VALUES":
                        counts["exact_invalid_count"] += 1
                    elif intrinsic_reason == "OUT_OF_DBC_RANGE":
                        counts["outside_dbc_range_count"] += 1
                    elif intrinsic_reason == "USER_INVALID_RULE":
                        counts["user_range_invalid_count"] += 1
                if unknown_enum:
                    counts["unknown_enum_code_count"] += 1

                policy_approved = policy["PolicyStatus"].strip().upper() == "APPROVED"
                frame_assigned = bool(frame["FrameCount"].strip())
                if not policy_approved:
                    final_valid = False; final_reason = "POLICY_PROVISIONAL"
                    counts["provisional_policy_update_count"] += 1
                elif not frame_assigned:
                    final_valid = False
                    final_reason = (
                        "FRAME_UNASSIGNED_NO_PRIOR"
                        if frame["FrameAssignmentStatus"] == "FRAME_UNASSIGNED_NO_PRIOR"
                        else "FRAME_UNASSIGNED_LIMIT"
                    )
                    counts["frame_unassigned_update_count"] += 1
                elif not intrinsic_valid:
                    final_valid = False; final_reason = intrinsic_reason
                else:
                    final_valid = True; final_reason = intrinsic_reason

                physical = _decimal(row["PhysicalValue"])
                if final_valid and physical == 0:
                    counts["valid_zero_count"] += 1
                    if policy["ValueKind"] == "BOOLEAN":
                        counts["valid_boolean_false_count"] += 1
                counts["valid_update_count" if final_valid else "invalid_update_count"] += 1

                output = {
                    "SourceRowIndex": row["SourceRowIndex"],
                    "SourceId": row["SourceId"],
                    "SourceType": row["SourceType"],
                    "SourceAdapterId": row["SourceAdapterId"],
                    "SourceAdapterVersion": row["SourceAdapterVersion"],
                    "ClockDomain": "FRAMECOUNT_VIDEO",
                    "NativeTimestamp": row["NativeTimestamp"],
                    "NativeSequence": row["NativeSequence"],
                    "FrameCount": frame["FrameCount"],
                    "SyncKey": frame["SyncKey"],
                    "SyncQuality": frame["SyncQuality"],
                    "FrameAssignmentStatus": frame["FrameAssignmentStatus"],
                    "FrameAssignmentAgeRows": frame["FrameAssignmentAgeRows"],
                    "CAN_ID": row["SourceMessageId"],
                    "Channel": row["SourceChannel"],
                    "MessageName": row["SourceMessageName"],
                    "SignalName": row["SourceSignalName"],
                    "CanonicalName": policy["CanonicalName"],
                    "RawCode": row["RawCode"],
                    "PhysicalValue": row["PhysicalValue"],
                    "ValueLabel": row["ValueLabel"],
                    "Unit": policy["OriginalUnit"],
                    "ValueKind": policy["ValueKind"],
                    "SignalRole": policy["SignalRole"],
                    "UpdateMode": policy["UpdateMode"],
                    "StorageDtype": policy["StorageDtype"],
                    "PolicyStatus": policy["PolicyStatus"],
                    "ValidityRule": policy["ValidityRule"],
                    "DecodeValid": row["DecodeValid"],
                    "DecodeIssue": row["DecodeIssue"],
                    "IntrinsicValid": int(intrinsic_valid),
                    "IntrinsicMissingReason": intrinsic_reason,
                    "Valid": int(final_valid),
                    "MissingReason": final_reason,
                }
                writer.writerow(output)
                counts["output_update_row_count"] += 1
    if current_frame is not None or next(frame_iterator, None) is not None:
        raise CanonicalUpdateError("FRAME_MAP_EXTRA_ROWS")
    if counts["input_update_row_count"] == 0:
        raise CanonicalUpdateError("UPDATES_EMPTY")
    missing_required = sorted(name for name, flag in required.items() if flag and observed[name] == 0)
    if missing_required:
        raise CanonicalUpdateError(f"REQUIRED_SIGNAL_NOT_OBSERVED:{missing_required}")
    if counts["input_update_row_count"] != counts["output_update_row_count"]:
        raise CanonicalUpdateError("ROW_COUNT_MISMATCH")

    quality: dict[str, Any] = {
        "QualitySchema": "U001_H3_CANONICAL_UPDATES_QUALITY_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "UpdatesSHA256": sha256_file(updates_path),
        "FrameMapSHA256": sha256_file(frame_map_path),
        "CompiledPolicySHA256": sha256_file(compiled_policy_path),
        **counts,
        "policy_signal_count": len(policies),
        "observed_signal_count": sum(1 for count in observed.values() if count),
        "source_row_order_preserved": True,
        "raw_value_mutation_count": 0,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "Warnings": ["UNKNOWN_ENUM_CODE"] if counts["unknown_enum_code_count"] else [],
        "Errors": [],
    }
    quality_path.write_text(json.dumps(quality, indent=2) + "\n", encoding="utf-8")
    return quality


def _write_fixture(temp: Path) -> tuple[Path, Path, Path]:
    updates = temp / "updates.csv"; frame_map = temp / "frame.csv"; policy = temp / "policy.csv"
    update_rows = [
        (0, "FRAME", "10", "10", "", "INTEGER", 1),
        (0, "FLOAT", "0", "0", "", "FLOAT", 1),
        (1, "BOOL", "0", "0", "", "BOOLEAN", 1),
        (1, "ENUM", "2", "2", "", "ENUM", 1),
        (2, "FLOAT", "32766", "327.66", "", "FLOAT", 1),
        (3, "FLOAT", "12", "12", "", "FLOAT", 0),
    ]
    with updates.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(UPDATE_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for index, name, raw, physical, label, hint, decode in update_rows:
            row = {field: "" for field in UPDATE_REQUIRED_COLUMNS}
            row.update({"SourceRowIndex": index, "SourceId": "S", "SourceType": "CAN", "SourceAdapterId": "A", "SourceAdapterVersion": "1", "ClockDomain": "SOURCE", "NativeSequence": index, "SourceChannel": 1, "SourceMessageId": "0x1", "SourceMessageName": "M", "SourceSignalName": name, "CanonicalNameCandidate": name, "RawCode": raw, "PhysicalValue": physical, "ValueLabel": label, "OriginalUnit": "m" if name == "FLOAT" else "", "ValueKindHint": hint, "DecodeValid": decode, "DecodeIssue": "BAD" if not decode else ""})
            writer.writerow(row)
    with frame_map.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(FRAME_MAP_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for index, frame, status, age in [(0, 10, "FRAME_EXACT", 0), (1, 10, "FRAME_ASSIGNED", 1), (2, "", "FRAME_UNASSIGNED_LIMIT", 2), (3, 11, "FRAME_EXACT", 0)]:
            writer.writerow({"SourceRowIndex": index, "FrameCount": frame, "SyncKey": frame, "SyncQuality": "EXACT_FRAME_UPDATE" if status == "FRAME_EXACT" else ("ASSIGNED_WITHIN_LIMIT" if status == "FRAME_ASSIGNED" else "UNSYNCHRONIZED"), "FrameAssignmentStatus": status, "FrameAssignmentAgeRows": age, "FrameObservationCount": int(status == "FRAME_EXACT")})
    policies = [
        ("FRAME", "INTEGER", "FRAME_KEY", "PERIODIC", "Int64", "NONE", "", "", "1", "{}"),
        ("FLOAT", "FLOAT", "MEASUREMENT", "UNKNOWN", "Float64", "EXACT_VALUES", "327.66", "USER_INVALID_RULE", "1", "{}"),
        ("BOOL", "BOOLEAN", "VALIDITY_FLAG", "UNKNOWN", "boolean", "NONE", "", "", "0", "{}"),
        ("ENUM", "ENUM", "STATE", "ON_CHANGE", "Int64", "NONE", "", "", "0", '{"1":"ONE"}'),
    ]
    with policy.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(POLICY_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for name, kind, role, update, dtype, rule, exact, reason, required, enum_map in policies:
            row = {field: "" for field in POLICY_REQUIRED_COLUMNS}
            row.update({"CanonicalNameCandidate": name, "CanonicalName": name, "OriginalUnit": "m" if name == "FLOAT" else "", "ValueKind": kind, "SignalRole": role, "UpdateMode": update, "StorageDtype": dtype, "PolicyStatus": "APPROVED", "ValidityRule": rule, "InvalidExactValues": exact, "DBCMinimum": "0", "DBCMaximum": "655", "InvalidReasonCode": reason, "Required": required, "EnumerationMap": enum_map})
            writer.writerow(row)
    return updates, frame_map, policy


def self_test() -> None:
    checks = 0
    def ck(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition: raise AssertionError(label)
        checks += 1
    with tempfile.TemporaryDirectory(prefix="u001_h3_project_") as temp_text:
        temp = Path(temp_text); updates, frame_map, policy = _write_fixture(temp)
        output = temp / "output.csv"; quality_path = temp / "quality.json"
        quality = project_canonical_updates(updates, frame_map, policy, output, quality_path)
        rows = list(csv.DictReader(output.open(encoding="utf-8")))
        ck(len(rows) == 6 and quality["input_update_row_count"] == quality["output_update_row_count"], "T01_ROWS")
        ck(rows[0]["FrameCount"] == "10" and rows[0]["FrameAssignmentStatus"] == "FRAME_EXACT", "T02_FRAME_EXACT")
        ck(rows[2]["FrameCount"] == "10" and rows[2]["FrameAssignmentAgeRows"] == "1", "T03_FRAME_ASSIGNED")
        ck(rows[1]["Valid"] == "1" and rows[1]["PhysicalValue"] == "0", "T04_ZERO_VALID")
        ck(rows[2]["Valid"] == "1" and quality["valid_boolean_false_count"] == 1, "T05_FALSE_VALID")
        ck(rows[3]["Valid"] == "1" and rows[3]["MissingReason"] == "UNKNOWN_ENUM_CODE", "T06_ENUM")
        ck(rows[4]["IntrinsicValid"] == "0" and rows[4]["IntrinsicMissingReason"] == "USER_INVALID_RULE", "T07_EXACT_INVALID")
        ck(rows[4]["MissingReason"] == "FRAME_UNASSIGNED_LIMIT", "T08_SYNC_PRECEDENCE")
        ck(rows[5]["Valid"] == "0" and rows[5]["IntrinsicMissingReason"] == "SOURCE_DECODE_INVALID", "T09_DECODE")
        ck(quality["raw_value_mutation_count"] == 0 and rows[4]["PhysicalValue"] == "327.66", "T10_IMMUTABLE")
        ck([row["SourceRowIndex"] for row in rows] == ["0", "0", "1", "1", "2", "3"], "T11_ORDER")
        ck(quality["unknown_enum_code_count"] == 1 and quality["exact_invalid_count"] == 1, "T12_COUNTS")
        provisional = list(csv.DictReader(policy.open(encoding="utf-8")))
        provisional[1]["PolicyStatus"] = "PROVISIONAL"
        with (temp / "provisional.csv").open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(POLICY_REQUIRED_COLUMNS), lineterminator="\n"); writer.writeheader(); writer.writerows(provisional)
        project_canonical_updates(updates, frame_map, temp / "provisional.csv", temp / "po.csv", temp / "pq.json")
        po = list(csv.DictReader((temp / "po.csv").open(encoding="utf-8")))
        ck(po[1]["Valid"] == "0" and po[1]["MissingReason"] == "POLICY_PROVISIONAL", "T13_PROVISIONAL")
        before = sha256_file(updates)
        project_canonical_updates(updates, frame_map, policy, temp / "again.csv", temp / "again.json")
        ck(sha256_file(updates) == before and sha256_file(output) == sha256_file(temp / "again.csv"), "T14_DETERMINISTIC")
    if checks != 14: raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H3-CANONICAL-PROJECTOR-SELFTEST-PASS-14")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Project U001 H3 canonical updates")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--project", action="store_true")
    result.add_argument("--updates", type=Path); result.add_argument("--frame-map", type=Path)
    result.add_argument("--policy", type=Path); result.add_argument("--output", type=Path)
    result.add_argument("--quality", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test: self_test(); return 0
        if not all((args.updates, args.frame_map, args.policy, args.output, args.quality)):
            raise CanonicalUpdateError("PROJECT_ARGUMENTS")
        quality = project_canonical_updates(args.updates, args.frame_map, args.policy, args.output, args.quality)
        print(f"U1H3U-R{quality['output_update_row_count']}-V{quality['valid_update_count']}-I{quality['invalid_update_count']}-X0-C0")
        return 0
    except (CanonicalUpdateError, OSError, ValueError, csv.Error, AssertionError) as exc:
        print(f"U1H3UE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
