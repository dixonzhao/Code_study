#!/usr/bin/env python3
"""Orchestrate U001 H3 frame-domain and semantic compilation."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_h3_sync_semantic_engine"
PROGRAM_VERSION = "1.0.0"
REQUEST_SCHEMA = "U001_H3_RUN_REQUEST_V1_0"
OUTPUT_BOUNDARY = "U001_H3_CANONICAL_UPDATE_PACKAGE_V1_0"

MODULE_DIRECTORY = Path(__file__).resolve().parent
if str(MODULE_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(MODULE_DIRECTORY))

from u001_frame_domain_compiler_v1_0 import (  # noqa: E402
    FrameDomainPolicy,
    compile_frame_domain,
    self_test as frame_self_test,
)
from u001_signal_policy_compiler_v1_0 import (  # noqa: E402
    CATALOG_REQUIRED_COLUMNS,
    POLICY_COLUMNS,
    compile_signal_policy,
    self_test as policy_self_test,
)
from u001_canonical_update_projector_v1_0 import (  # noqa: E402
    UPDATE_REQUIRED_COLUMNS,
    project_canonical_updates,
    self_test as projector_self_test,
)


H2_FILES = {
    "updates": "u001_adapter_source_updates.csv",
    "catalog": "u001_adapter_signal_catalog.csv",
    "quality": "u001_adapter_quality.json",
    "manifest": "u001_adapter_run_manifest.json",
    "capsule": "u001_adapter_completion_capsule.txt",
}

H3_ARTIFACTS = (
    "u001_h3_frame_map.csv",
    "u001_h3_frame_quality.json",
    "u001_h3_compiled_signal_policy.csv",
    "u001_h3_policy_quality.json",
    "u001_h3_canonical_updates.csv",
    "u001_h3_canonical_quality.json",
)


class H3EngineError(RuntimeError):
    """Fail-closed H3 orchestration error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_identity(value: Any, label: str) -> str:
    text = "" if value is None else str(value).strip()
    if not text or len(text) > 128:
        raise H3EngineError(f"{label}_IDENTITY")
    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
    if any(character not in allowed for character in text):
        raise H3EngineError(f"{label}_IDENTITY")
    return text


def _load_json(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise H3EngineError(f"{label}_FILE")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise H3EngineError(f"{label}_JSON") from exc
    if not isinstance(value, dict):
        raise H3EngineError(f"{label}_OBJECT")
    return value


def validate_h2_package(folder: Path) -> dict[str, Any]:
    if not folder.is_dir():
        raise H3EngineError("H2_PACKAGE_FOLDER")
    paths = {key: folder / name for key, name in H2_FILES.items()}
    missing = sorted(path.name for path in paths.values() if not path.is_file())
    if missing:
        raise H3EngineError(f"H2_PACKAGE_FILES:{missing}")
    manifest = _load_json(paths["manifest"], "H2_MANIFEST")
    quality = _load_json(paths["quality"], "H2_QUALITY")
    if manifest.get("OutputBoundary") != "U001_CANONICAL_SOURCE_UPDATES_V0_1":
        raise H3EngineError("H2_OUTPUT_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise H3EngineError("H2_STATUS")
    if quality.get("Errors"):
        raise H3EngineError("H2_QUALITY_ERRORS")
    manifest_artifacts = {
        item.get("FileName"): item
        for item in manifest.get("Artifacts", [])
        if isinstance(item, dict)
    }
    for key in ("updates", "catalog", "quality"):
        path = paths[key]
        item = manifest_artifacts.get(path.name)
        if not item:
            raise H3EngineError(f"H2_MANIFEST_ARTIFACT:{path.name}")
        if item.get("SHA256") != sha256_file(path) or item.get("SizeBytes") != path.stat().st_size:
            raise H3EngineError(f"H2_ARTIFACT_IDENTITY:{path.name}")
    capsule = paths["capsule"].read_text(encoding="utf-8-sig").strip()
    if "C0" not in capsule.replace("-", ""):
        raise H3EngineError("H2_CAPSULE")
    return {
        "paths": paths,
        "manifest": manifest,
        "quality": quality,
        "package_hashes": {path.name: sha256_file(path) for path in paths.values()},
    }


def validate_request(request: dict[str, Any], request_path: Path) -> dict[str, Any]:
    if request.get("RequestSchema") != REQUEST_SCHEMA:
        raise H3EngineError("REQUEST_SCHEMA")
    mode = str(request.get("Mode", "")).strip().upper()
    if mode not in {"CONTROLLED_PROFILE", "DISCOVERY_INVENTORY"}:
        raise H3EngineError("REQUEST_MODE")
    adapter_folder = Path(str(request.get("AdapterOutputFolder", ""))).expanduser().resolve()
    output_folder = Path(str(request.get("OutputFolder", ""))).expanduser().resolve()
    policy_path = Path(str(request.get("SemanticPolicyPath", ""))).expanduser().resolve()
    if not policy_path.is_file():
        raise H3EngineError("REQUEST_POLICY_FILE")
    if output_folder.exists():
        raise H3EngineError("OUTPUT_ALREADY_EXISTS")
    if output_folder == adapter_folder or adapter_folder in output_folder.parents:
        raise H3EngineError("OUTPUT_INSIDE_SOURCE_PACKAGE")
    if output_folder == request_path.resolve() or output_folder == policy_path:
        raise H3EngineError("OUTPUT_IDENTITY")
    frame_data = request.get("FrameDomain")
    if not isinstance(frame_data, dict):
        raise H3EngineError("FRAME_DOMAIN_OBJECT")
    frame_policy = FrameDomainPolicy.from_mapping(frame_data)
    return {
        "mode": mode,
        "adapter_folder": adapter_folder,
        "output_folder": output_folder,
        "policy_path": policy_path,
        "frame_policy": frame_policy,
        "dataset_id": _safe_identity(request.get("DatasetId"), "DATASET"),
        "run_id": _safe_identity(request.get("RunId"), "RUN"),
        "segment_id": _safe_identity(request.get("SegmentId"), "SEGMENT"),
    }


def _artifact_entry(path: Path) -> dict[str, Any]:
    return {"FileName": path.name, "SizeBytes": path.stat().st_size, "SHA256": sha256_file(path)}


def run_h3(request_path: Path) -> tuple[Path, str]:
    started = time.perf_counter()
    request = _load_json(request_path, "REQUEST")
    config = validate_request(request, request_path)
    h2 = validate_h2_package(config["adapter_folder"])
    output = config["output_folder"]
    incomplete = output.parent / f".{output.name}.U1H3_INCOMPLETE"
    if incomplete.exists():
        raise H3EngineError("INCOMPLETE_OUTPUT_EXISTS")
    incomplete.mkdir(parents=True, exist_ok=False)
    try:
        frame_map = incomplete / "u001_h3_frame_map.csv"
        frame_quality_path = incomplete / "u001_h3_frame_quality.json"
        policy_output = incomplete / "u001_h3_compiled_signal_policy.csv"
        policy_quality_path = incomplete / "u001_h3_policy_quality.json"
        canonical_output = incomplete / "u001_h3_canonical_updates.csv"
        canonical_quality_path = incomplete / "u001_h3_canonical_quality.json"

        frame_quality = compile_frame_domain(
            h2["paths"]["updates"], config["frame_policy"], frame_map, frame_quality_path
        )
        policy_quality = compile_signal_policy(
            h2["paths"]["catalog"], config["policy_path"], policy_output,
            policy_quality_path, config["frame_policy"].frame_signal_candidate,
            config["mode"],
        )
        canonical_quality = project_canonical_updates(
            h2["paths"]["updates"], frame_map, policy_output,
            canonical_output, canonical_quality_path,
        )

        if config["mode"] == "CONTROLLED_PROFILE" and not policy_quality["formal_ready"]:
            raise H3EngineError("CONTROLLED_POLICY_NOT_FORMAL")
        artifacts = [_artifact_entry(incomplete / name) for name in H3_ARTIFACTS]
        manifest = {
            "ManifestSchema": "U001_H3_RUN_MANIFEST_V1_0",
            "OutputBoundary": OUTPUT_BOUNDARY,
            "ProgramName": PROGRAM_NAME,
            "ProgramVersion": PROGRAM_VERSION,
            "DatasetId": config["dataset_id"],
            "RunId": config["run_id"],
            "SegmentId": config["segment_id"],
            "Mode": config["mode"],
            "InputAdapterIdentity": {
                "AdapterId": h2["manifest"].get("AdapterId"),
                "AdapterVersion": h2["manifest"].get("AdapterVersion"),
                "RequestId": h2["manifest"].get("RequestId"),
            },
            "InputArtifactHashes": h2["package_hashes"],
            "SemanticPolicySHA256": sha256_file(config["policy_path"]),
            "FrameDomainPolicy": {
                "FrameSignalCandidate": config["frame_policy"].frame_signal_candidate,
                "MaxAssignmentAgeRows": config["frame_policy"].max_assignment_age_rows,
                "RequireSyncKeyCandidateAgreement": config["frame_policy"].require_sync_candidate_agreement,
                "DecreasePolicy": config["frame_policy"].decrease_policy,
            },
            "Artifacts": artifacts,
            "Counts": {
                "InputUpdateRows": canonical_quality["input_update_row_count"],
                "SourceRows": frame_quality["unique_source_row_count"],
                "DistinctFrames": frame_quality["distinct_frame_count"],
                "Signals": policy_quality["compiled_policy_row_count"],
                "ValidUpdates": canonical_quality["valid_update_count"],
                "InvalidUpdates": canonical_quality["invalid_update_count"],
            },
            "Status": "COMPLETE",
            "CompletionCode": 0,
            "CreatedUTC": datetime.now(timezone.utc).isoformat(),
            "ElapsedSeconds": round(time.perf_counter() - started, 6),
            "Warnings": sorted(set(frame_quality["Warnings"] + policy_quality["Warnings"] + canonical_quality["Warnings"])),
            "Errors": [],
        }
        manifest_path = incomplete / "u001_h3_run_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        capsule = (
            f"U1H3-R{manifest['Counts']['InputUpdateRows']}-"
            f"F{manifest['Counts']['DistinctFrames']}-S{manifest['Counts']['Signals']}-"
            f"V{manifest['Counts']['ValidUpdates']}-I{manifest['Counts']['InvalidUpdates']}-X0-C0"
        )
        (incomplete / "u001_h3_completion_capsule.txt").write_text(capsule + "\n", encoding="utf-8")
        incomplete.replace(output)
        return output, capsule
    except Exception:
        # Keep incomplete evidence for diagnosis.  Never present it as complete.
        raise


def _write_h2_fixture(folder: Path) -> tuple[Path, str]:
    folder.mkdir(parents=True)
    updates = folder / H2_FILES["updates"]
    catalog = folder / H2_FILES["catalog"]
    quality = folder / H2_FILES["quality"]
    manifest = folder / H2_FILES["manifest"]
    capsule = folder / H2_FILES["capsule"]
    update_rows = [
        (0, "FRAME", 100, 100, "INTEGER", 1),
        (0, "DIST", 1200, 12.0, "FLOAT", 1),
        (1, "FLAG", 0, 0, "BOOLEAN", 1),
        (2, "DIST", 32766, 327.66, "FLOAT", 1),
        (3, "FRAME", 101, 101, "INTEGER", 1),
        (3, "DIST", 1300, 13.0, "FLOAT", 1),
    ]
    with updates.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(UPDATE_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for source_index, name, raw, physical, hint, valid in update_rows:
            row = {field: "" for field in UPDATE_REQUIRED_COLUMNS}
            row.update({
                "SourceRowIndex": source_index, "SourceId": "SYNTHETIC_SOURCE",
                "SourceType": "CAN", "SourceAdapterId": "SYNTHETIC.DRIVER",
                "SourceAdapterVersion": "1.0.0", "ClockDomain": "SOURCE_ORDER",
                "NativeSequence": source_index,
                "SyncKeyCandidate": physical if name == "FRAME" else "",
                "SourceChannel": 2 if name != "FLAG" else 1,
                "SourceMessageId": "0x620" if name == "FRAME" else "0x100",
                "SourceMessageName": "Message", "SourceSignalName": name,
                "CanonicalNameCandidate": name, "RawCode": raw,
                "PhysicalValue": physical, "OriginalUnit": "count" if name == "FRAME" else ("m" if name == "DIST" else ""),
                "ValueKindHint": hint, "DecodeValid": valid,
            })
            writer.writerow(row)
    with catalog.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(CATALOG_REQUIRED_COLUMNS) + ["DecodeDefinition", "MessageDLC", "SourceGroupComplete", "SourceByteColumns", "SelectionOrder"], lineterminator="\n")
        writer.writeheader()
        for order, (name, kind, unit, low, high, required) in enumerate([
            ("FRAME", "INTEGER", "count", "0", "65535", "1"),
            ("DIST", "FLOAT", "m", "0", "655.35", "1"),
            ("FLAG", "BOOLEAN", "", "0", "1", "0"),
        ]):
            row = {field: "" for field in writer.fieldnames}
            row.update({
                "SourceAdapterId": "SYNTHETIC.DRIVER", "SourceAdapterVersion": "1.0.0",
                "SourceType": "CAN", "SourceChannel": "2", "SourceMessageId": "0x100",
                "SourceMessageName": "Message", "SourceSignalName": name,
                "CanonicalNameCandidate": name, "OriginalUnit": unit,
                "ValueKindHint": kind, "DBCMinimum": low, "DBCMaximum": high,
                "EnumerationMap": "{}", "Required": required, "SelectionOrder": order,
            })
            writer.writerow(row)
    quality_value = {"QualitySchema": "U001_INPUT_ADAPTER_QUALITY_V0_1", "Errors": [], "Warnings": []}
    quality.write_text(json.dumps(quality_value, indent=2) + "\n", encoding="utf-8")
    artifacts = [_artifact_entry(path) for path in (updates, catalog, quality)]
    manifest_value = {
        "ManifestSchema": "U001_INPUT_ADAPTER_RUN_MANIFEST_V0_1",
        "OutputBoundary": "U001_CANONICAL_SOURCE_UPDATES_V0_1",
        "AdapterId": "SYNTHETIC.DRIVER", "AdapterVersion": "1.0.0",
        "RequestId": "SYNTHETIC", "Artifacts": artifacts,
        "Status": "COMPLETE", "CompletionCode": 0,
    }
    manifest.write_text(json.dumps(manifest_value, indent=2) + "\n", encoding="utf-8")
    capsule_text = "U1H2-SYNTHETIC-X0-C0"
    capsule.write_text(capsule_text + "\n", encoding="utf-8")
    return folder, capsule_text


def _write_policy(path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(POLICY_COLUMNS), lineterminator="\n")
        writer.writeheader()
        for name, kind, role, mode, dtype, rule, exact, reason, required in [
            ("FRAME", "INTEGER", "FRAME_KEY", "PERIODIC", "Int64", "NONE", "", "", "1"),
            ("DIST", "FLOAT", "MEASUREMENT", "UNKNOWN", "Float64", "EXACT_VALUES", "327.66", "USER_INVALID_RULE", "1"),
            ("FLAG", "BOOLEAN", "VALIDITY_FLAG", "UNKNOWN", "boolean", "NONE", "", "", "0"),
        ]:
            writer.writerow({
                "SourceCanonicalNameCandidate": name, "CanonicalName": name,
                "PolicyStatus": "APPROVED", "ValueKind": kind, "SignalRole": role,
                "UpdateMode": mode, "StorageDtype": dtype, "ValidityRule": rule,
                "InvalidExactValues": exact, "DBCMinimum": "0", "DBCMaximum": "65535",
                "UserMinimum": "", "UserMaximum": "", "InvalidReasonCode": reason,
                "Required": required, "Notes": "Synthetic qualification",
            })


def _write_request(path: Path, h2: Path, policy: Path, output: Path) -> None:
    value = {
        "RequestSchema": REQUEST_SCHEMA, "Mode": "CONTROLLED_PROFILE",
        "AdapterOutputFolder": str(h2), "SemanticPolicyPath": str(policy),
        "OutputFolder": str(output), "DatasetId": "SYNTHETIC_DATASET",
        "RunId": "RUN_001", "SegmentId": "SEGMENT_001",
        "FrameDomain": {"FrameSignalCandidate": "FRAME", "MaxAssignmentAgeRows": 2, "RequireSyncKeyCandidateAgreement": True, "DecreasePolicy": "FAIL"},
    }
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def self_test() -> None:
    frame_self_test(); policy_self_test(); projector_self_test()
    checks = 0
    def ck(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition: raise AssertionError(label)
        checks += 1
    with tempfile.TemporaryDirectory(prefix="u001_h3_engine_") as temp_text:
        temp = Path(temp_text); h2, _ = _write_h2_fixture(temp / "h2")
        policy = temp / "policy.csv"; _write_policy(policy)
        request = temp / "request.json"; output = temp / "output"
        _write_request(request, h2, policy, output)
        produced, capsule = run_h3(request)
        ck(produced == output.resolve() and produced.is_dir(), "T01_OUTPUT")
        ck(capsule.startswith("U1H3-R6-F2-S3") and capsule.endswith("X0-C0"), "T02_CAPSULE")
        ck(all((output / name).is_file() for name in H3_ARTIFACTS), "T03_ARTIFACTS")
        ck((output / "u001_h3_run_manifest.json").is_file() and (output / "u001_h3_completion_capsule.txt").is_file(), "T04_CONTROL")
        manifest = _load_json(output / "u001_h3_run_manifest.json", "RESULT_MANIFEST")
        ck(manifest["Status"] == "COMPLETE" and manifest["Counts"]["InvalidUpdates"] == 1, "T05_MANIFEST")
        rows = list(csv.DictReader((output / "u001_h3_canonical_updates.csv").open(encoding="utf-8")))
        ck(len(rows) == 6 and rows[3]["PhysicalValue"] == "327.66", "T06_VALUES")
        ck(rows[3]["Valid"] == "0" and rows[3]["MissingReason"] == "USER_INVALID_RULE", "T07_VALIDITY")
        ck(rows[2]["PhysicalValue"] == "0" and rows[2]["Valid"] == "1", "T08_ZERO")
        ck(not (temp / ".output.U1H3_INCOMPLETE").exists(), "T09_ATOMIC")
        before = sha256_file(h2 / H2_FILES["updates"])
        second_request = temp / "request2.json"; second_output = temp / "output2"
        _write_request(second_request, h2, policy, second_output)
        run_h3(second_request)
        ck(before == sha256_file(h2 / H2_FILES["updates"]), "T10_SOURCE_IMMUTABLE")
        ck(sha256_file(output / "u001_h3_canonical_updates.csv") == sha256_file(second_output / "u001_h3_canonical_updates.csv"), "T11_DETERMINISTIC")
        bad_manifest = _load_json(h2 / H2_FILES["manifest"], "H2")
        bad_manifest["Artifacts"][0]["SHA256"] = "0" * 64
        (h2 / H2_FILES["manifest"]).write_text(json.dumps(bad_manifest), encoding="utf-8")
        third_request = temp / "request3.json"; _write_request(third_request, h2, policy, temp / "output3")
        try:
            run_h3(third_request)
        except H3EngineError as exc:
            ck("IDENTITY" in str(exc), "T12_INPUT_HASH")
        else:
            raise AssertionError("T12_INPUT_HASH")
    if checks != 12: raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H3-ENGINE-SELFTEST-PASS-12")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Run U001 H3 synchronization and semantic compilation")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--run", action="store_true")
    result.add_argument("--request", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test: self_test(); return 0
        if args.request is None: raise H3EngineError("REQUEST_ARGUMENT")
        _, capsule = run_h3(args.request); print(capsule); return 0
    except (H3EngineError, OSError, ValueError, csv.Error, json.JSONDecodeError, AssertionError) as exc:
        print(f"U1H3E-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
