#!/usr/bin/env python3
"""Compile a traceable frame-domain map from canonical source updates.

The compiler is source-format independent.  It consumes the canonical source
update boundary produced by any qualified U001 input adapter.  It never sorts,
fills a measurement, aggregates a signal, or infers business validity.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import tempfile
import time
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from itertools import groupby
from pathlib import Path
from typing import Any, Iterator


PROGRAM_NAME = "u001_frame_domain_compiler"
PROGRAM_VERSION = "1.0.0"
CONTRACT_VERSION = "U001_H3_FRAME_DOMAIN_V1_0"

REQUIRED_UPDATE_COLUMNS = (
    "SourceRowIndex",
    "SourceId",
    "SourceType",
    "ClockDomain",
    "NativeSequence",
    "SyncKeyCandidate",
    "CanonicalNameCandidate",
    "RawCode",
    "PhysicalValue",
    "DecodeValid",
)

FRAME_MAP_COLUMNS = (
    "SourceRowIndex",
    "FrameCount",
    "SyncKey",
    "SyncQuality",
    "FrameAssignmentStatus",
    "FrameAssignmentAgeRows",
    "FrameObservationCount",
)


class FrameDomainError(RuntimeError):
    """Fail-closed synchronization error."""


@dataclass(frozen=True)
class FrameDomainPolicy:
    frame_signal_candidate: str
    max_assignment_age_rows: int
    require_sync_candidate_agreement: bool = True
    decrease_policy: str = "FAIL"

    @classmethod
    def from_mapping(cls, value: dict[str, Any]) -> "FrameDomainPolicy":
        required = {"FrameSignalCandidate", "MaxAssignmentAgeRows"}
        missing = sorted(required - set(value))
        if missing:
            raise FrameDomainError(f"FRAME_POLICY_FIELDS:{missing}")
        frame_signal = str(value["FrameSignalCandidate"]).strip()
        if not frame_signal:
            raise FrameDomainError("FRAME_SIGNAL_EMPTY")
        try:
            max_age = int(value["MaxAssignmentAgeRows"])
        except (TypeError, ValueError) as exc:
            raise FrameDomainError("MAX_ASSIGNMENT_AGE_TYPE") from exc
        if max_age < 0:
            raise FrameDomainError("MAX_ASSIGNMENT_AGE_NEGATIVE")
        decrease_policy = str(value.get("DecreasePolicy", "FAIL")).strip().upper()
        if decrease_policy != "FAIL":
            raise FrameDomainError("DECREASE_POLICY_UNSUPPORTED")
        return cls(
            frame_signal_candidate=frame_signal,
            max_assignment_age_rows=max_age,
            require_sync_candidate_agreement=bool(
                value.get("RequireSyncKeyCandidateAgreement", True)
            ),
            decrease_policy=decrease_policy,
        )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _decimal(value: Any, label: str) -> Decimal:
    text = "" if value is None else str(value).strip()
    if not text:
        raise FrameDomainError(f"{label}_MISSING")
    try:
        parsed = Decimal(text)
    except InvalidOperation as exc:
        raise FrameDomainError(f"{label}_NON_NUMERIC") from exc
    if not parsed.is_finite():
        raise FrameDomainError(f"{label}_NON_FINITE")
    return parsed


def exact_integer(value: Any, label: str) -> int:
    parsed = _decimal(value, label)
    integral = parsed.to_integral_value()
    if parsed != integral:
        raise FrameDomainError(f"{label}_FRACTIONAL")
    result = int(integral)
    if result < -(2**63) or result > 2**63 - 1:
        raise FrameDomainError(f"{label}_INT64_RANGE")
    return result


def _reader(path: Path) -> tuple[csv.DictReader, Any]:
    if not path.is_file():
        raise FrameDomainError("UPDATES_FILE")
    stream = path.open("r", encoding="utf-8-sig", newline="")
    reader = csv.DictReader(stream)
    if reader.fieldnames is None:
        stream.close()
        raise FrameDomainError("UPDATES_HEADER")
    if len(reader.fieldnames) != len(set(reader.fieldnames)):
        stream.close()
        raise FrameDomainError("UPDATES_DUPLICATE_HEADER")
    missing = sorted(set(REQUIRED_UPDATE_COLUMNS) - set(reader.fieldnames))
    if missing:
        stream.close()
        raise FrameDomainError(f"UPDATES_COLUMNS:{missing}")
    return reader, stream


def _iter_indexed_rows(path: Path) -> Iterator[tuple[int, dict[str, str]]]:
    reader, stream = _reader(path)
    last_index: int | None = None
    try:
        for row in reader:
            source_index = exact_integer(row["SourceRowIndex"], "SOURCE_ROW_INDEX")
            if source_index < 0:
                raise FrameDomainError("SOURCE_ROW_INDEX_NEGATIVE")
            if last_index is not None and source_index < last_index:
                raise FrameDomainError("SOURCE_ROW_INDEX_DECREASE")
            last_index = source_index
            yield source_index, row
    finally:
        stream.close()


def _frame_observations(
    rows: list[dict[str, str]], policy: FrameDomainPolicy
) -> list[int]:
    values: list[int] = []
    for row in rows:
        if row["CanonicalNameCandidate"].strip() != policy.frame_signal_candidate:
            continue
        if row["DecodeValid"].strip() not in {"1", "true", "True", "TRUE"}:
            raise FrameDomainError("FRAME_DECODE_INVALID")
        frame_value = exact_integer(row["PhysicalValue"], "FRAME_VALUE")
        if policy.require_sync_candidate_agreement:
            sync_candidate = exact_integer(row["SyncKeyCandidate"], "SYNC_CANDIDATE")
            if sync_candidate != frame_value:
                raise FrameDomainError("SYNC_CANDIDATE_DISAGREEMENT")
        values.append(frame_value)
    if values and len(set(values)) != 1:
        raise FrameDomainError("SAME_SOURCE_ROW_FRAME_CONFLICT")
    return values


def compile_frame_domain(
    updates_path: Path,
    policy: FrameDomainPolicy,
    frame_map_path: Path,
    quality_path: Path,
) -> dict[str, Any]:
    """Compile one synchronization record per observed source row."""

    if updates_path.resolve() in {frame_map_path.resolve(), quality_path.resolve()}:
        raise FrameDomainError("OUTPUT_OVERWRITES_INPUT")
    started = time.perf_counter()
    frame_map_path.parent.mkdir(parents=True, exist_ok=True)
    quality_path.parent.mkdir(parents=True, exist_ok=True)

    counts = {
        "input_update_row_count": 0,
        "unique_source_row_count": 0,
        "frame_observation_count": 0,
        "distinct_frame_count": 0,
        "repeated_equal_frame_observation_count": 0,
        "exact_assignment_source_row_count": 0,
        "assigned_within_limit_source_row_count": 0,
        "unassigned_no_prior_source_row_count": 0,
        "unassigned_limit_source_row_count": 0,
    }
    observed_frames: set[int] = set()
    assigned_ages: list[int] = []
    frame_min: int | None = None
    frame_max: int | None = None
    last_frame: int | None = None
    last_frame_source_row: int | None = None

    with frame_map_path.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(FRAME_MAP_COLUMNS), lineterminator="\n")
        writer.writeheader()
        grouped = groupby(_iter_indexed_rows(updates_path), key=lambda item: item[0])
        for source_index, group in grouped:
            rows = [row for _, row in group]
            counts["input_update_row_count"] += len(rows)
            counts["unique_source_row_count"] += 1
            observations = _frame_observations(rows, policy)
            counts["frame_observation_count"] += len(observations)
            if observations:
                current = observations[0]
                if last_frame is not None and current < last_frame:
                    raise FrameDomainError("FRAME_DECREASE")
                if last_frame is not None and current == last_frame:
                    counts["repeated_equal_frame_observation_count"] += len(observations)
                elif len(observations) > 1:
                    counts["repeated_equal_frame_observation_count"] += len(observations) - 1
                last_frame = current
                last_frame_source_row = source_index
                observed_frames.add(current)
                frame_min = current if frame_min is None else min(frame_min, current)
                frame_max = current if frame_max is None else max(frame_max, current)
                record = {
                    "SourceRowIndex": source_index,
                    "FrameCount": current,
                    "SyncKey": current,
                    "SyncQuality": "EXACT_FRAME_UPDATE",
                    "FrameAssignmentStatus": "FRAME_EXACT",
                    "FrameAssignmentAgeRows": 0,
                    "FrameObservationCount": len(observations),
                }
                counts["exact_assignment_source_row_count"] += 1
                assigned_ages.append(0)
            elif last_frame is None or last_frame_source_row is None:
                record = {
                    "SourceRowIndex": source_index,
                    "FrameCount": "",
                    "SyncKey": "",
                    "SyncQuality": "UNSYNCHRONIZED",
                    "FrameAssignmentStatus": "FRAME_UNASSIGNED_NO_PRIOR",
                    "FrameAssignmentAgeRows": "",
                    "FrameObservationCount": 0,
                }
                counts["unassigned_no_prior_source_row_count"] += 1
            else:
                age = source_index - last_frame_source_row
                if age <= 0:
                    raise FrameDomainError("FRAME_ASSIGNMENT_AGE_INTERNAL")
                if age <= policy.max_assignment_age_rows:
                    record = {
                        "SourceRowIndex": source_index,
                        "FrameCount": last_frame,
                        "SyncKey": last_frame,
                        "SyncQuality": "ASSIGNED_WITHIN_LIMIT",
                        "FrameAssignmentStatus": "FRAME_ASSIGNED",
                        "FrameAssignmentAgeRows": age,
                        "FrameObservationCount": 0,
                    }
                    counts["assigned_within_limit_source_row_count"] += 1
                    assigned_ages.append(age)
                else:
                    record = {
                        "SourceRowIndex": source_index,
                        "FrameCount": "",
                        "SyncKey": "",
                        "SyncQuality": "UNSYNCHRONIZED",
                        "FrameAssignmentStatus": "FRAME_UNASSIGNED_LIMIT",
                        "FrameAssignmentAgeRows": age,
                        "FrameObservationCount": 0,
                    }
                    counts["unassigned_limit_source_row_count"] += 1
            writer.writerow(record)

    if counts["input_update_row_count"] == 0:
        raise FrameDomainError("UPDATES_EMPTY")
    if counts["frame_observation_count"] == 0:
        raise FrameDomainError("FRAME_SIGNAL_NOT_OBSERVED")
    counts["distinct_frame_count"] = len(observed_frames)
    sorted_ages = sorted(assigned_ages)

    def quantile(fraction: float) -> int | None:
        if not sorted_ages:
            return None
        position = int(round((len(sorted_ages) - 1) * fraction))
        return sorted_ages[position]

    quality: dict[str, Any] = {
        "QualitySchema": "U001_H3_FRAME_DOMAIN_QUALITY_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "InputSHA256": sha256_file(updates_path),
        "Policy": asdict(policy),
        **counts,
        "frame_min": frame_min,
        "frame_max": frame_max,
        "assignment_age_q50": quantile(0.50),
        "assignment_age_q95": quantile(0.95),
        "assignment_age_max": max(sorted_ages) if sorted_ages else None,
        "source_row_monotonic": True,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "Warnings": [],
        "Errors": [],
    }
    quality_path.write_text(json.dumps(quality, indent=2) + "\n", encoding="utf-8")
    return quality


def _write_updates(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(REQUIRED_UPDATE_COLUMNS)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            base = {field: "" for field in fields}
            base.update(row)
            base["SourceId"] = base["SourceId"] or "S"
            base["SourceType"] = base["SourceType"] or "CAN"
            base["ClockDomain"] = base["ClockDomain"] or "SOURCE_ORDER"
            base["NativeSequence"] = base["NativeSequence"] or base["SourceRowIndex"]
            base["RawCode"] = base["RawCode"] or base.get("PhysicalValue", "")
            base["DecodeValid"] = base["DecodeValid"] or 1
            writer.writerow(base)


def self_test() -> None:
    checks = 0

    def ck(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_h3_frame_") as temp_text:
        temp = Path(temp_text)
        updates = temp / "updates.csv"
        frame_map = temp / "map.csv"
        quality = temp / "quality.json"
        policy = FrameDomainPolicy("FRAME", 2)
        rows = [
            {"SourceRowIndex": 0, "CanonicalNameCandidate": "A", "PhysicalValue": 1},
            {"SourceRowIndex": 1, "CanonicalNameCandidate": "FRAME", "PhysicalValue": "10.0", "SyncKeyCandidate": "10"},
            {"SourceRowIndex": 1, "CanonicalNameCandidate": "A", "PhysicalValue": 2},
            {"SourceRowIndex": 2, "CanonicalNameCandidate": "B", "PhysicalValue": 3},
            {"SourceRowIndex": 4, "CanonicalNameCandidate": "B", "PhysicalValue": 4},
            {"SourceRowIndex": 5, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 11, "SyncKeyCandidate": 11},
            {"SourceRowIndex": 5, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 11, "SyncKeyCandidate": 11},
        ]
        _write_updates(updates, rows)
        result = compile_frame_domain(updates, policy, frame_map, quality)
        mapped = list(csv.DictReader(frame_map.open(encoding="utf-8")))
        ck(len(mapped) == 5 and result["input_update_row_count"] == 7, "T01_COUNTS")
        ck(mapped[0]["FrameAssignmentStatus"] == "FRAME_UNASSIGNED_NO_PRIOR", "T02_BEFORE")
        ck(mapped[1]["FrameCount"] == "10" and mapped[1]["FrameAssignmentStatus"] == "FRAME_EXACT", "T03_EXACT")
        ck(mapped[2]["FrameCount"] == "10" and mapped[2]["FrameAssignmentAgeRows"] == "1", "T04_ASSIGNED")
        ck(mapped[3]["FrameAssignmentStatus"] == "FRAME_UNASSIGNED_LIMIT" and mapped[3]["FrameAssignmentAgeRows"] == "3", "T05_LIMIT")
        ck(result["repeated_equal_frame_observation_count"] == 1, "T06_REPEAT")
        ck(result["frame_min"] == 10 and result["frame_max"] == 11, "T07_RANGE")

        conflict = temp / "conflict.csv"
        _write_updates(conflict, [
            {"SourceRowIndex": 0, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 1, "SyncKeyCandidate": 1},
            {"SourceRowIndex": 0, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 2, "SyncKeyCandidate": 2},
        ])
        try:
            compile_frame_domain(conflict, policy, temp / "c.csv", temp / "c.json")
        except FrameDomainError as exc:
            ck("CONFLICT" in str(exc), "T08_CONFLICT")
        else:
            raise AssertionError("T08_CONFLICT")

        fractional = temp / "fractional.csv"
        _write_updates(fractional, [{"SourceRowIndex": 0, "CanonicalNameCandidate": "FRAME", "PhysicalValue": "1.5", "SyncKeyCandidate": "1.5"}])
        try:
            compile_frame_domain(fractional, policy, temp / "f.csv", temp / "f.json")
        except FrameDomainError as exc:
            ck("FRACTIONAL" in str(exc), "T09_FRACTION")
        else:
            raise AssertionError("T09_FRACTION")

        decrease = temp / "decrease.csv"
        _write_updates(decrease, [
            {"SourceRowIndex": 0, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 2, "SyncKeyCandidate": 2},
            {"SourceRowIndex": 1, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 1, "SyncKeyCandidate": 1},
        ])
        try:
            compile_frame_domain(decrease, policy, temp / "d.csv", temp / "d.json")
        except FrameDomainError as exc:
            ck(str(exc) == "FRAME_DECREASE", "T10_DECREASE")
        else:
            raise AssertionError("T10_DECREASE")

        mismatch = temp / "mismatch.csv"
        _write_updates(mismatch, [{"SourceRowIndex": 0, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 2, "SyncKeyCandidate": 3}])
        try:
            compile_frame_domain(mismatch, policy, temp / "m.csv", temp / "m.json")
        except FrameDomainError as exc:
            ck("DISAGREEMENT" in str(exc), "T11_CANDIDATE")
        else:
            raise AssertionError("T11_CANDIDATE")

        source_decrease = temp / "source_decrease.csv"
        _write_updates(source_decrease, [
            {"SourceRowIndex": 1, "CanonicalNameCandidate": "FRAME", "PhysicalValue": 1, "SyncKeyCandidate": 1},
            {"SourceRowIndex": 0, "CanonicalNameCandidate": "A", "PhysicalValue": 2},
        ])
        try:
            compile_frame_domain(source_decrease, policy, temp / "s.csv", temp / "s.json")
        except FrameDomainError as exc:
            ck(str(exc) == "SOURCE_ROW_INDEX_DECREASE", "T12_SOURCE_ORDER")
        else:
            raise AssertionError("T12_SOURCE_ORDER")

    if checks != 12:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H3-FRAME-DOMAIN-SELFTEST-PASS-12")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Compile U001 H3 frame-domain metadata")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--compile", action="store_true")
    result.add_argument("--updates", type=Path)
    result.add_argument("--policy", type=Path)
    result.add_argument("--frame-map", type=Path)
    result.add_argument("--quality", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if not all((args.updates, args.policy, args.frame_map, args.quality)):
            raise FrameDomainError("COMPILE_ARGUMENTS")
        policy_data = json.loads(args.policy.read_text(encoding="utf-8-sig"))
        policy = FrameDomainPolicy.from_mapping(policy_data)
        quality = compile_frame_domain(args.updates, policy, args.frame_map, args.quality)
        print(
            f"U1H3F-R{quality['unique_source_row_count']}-"
            f"O{quality['frame_observation_count']}-"
            f"E{quality['exact_assignment_source_row_count']}-"
            f"A{quality['assigned_within_limit_source_row_count']}-"
            f"U{quality['unassigned_no_prior_source_row_count'] + quality['unassigned_limit_source_row_count']}-X0-C0"
        )
        return 0
    except (FrameDomainError, OSError, ValueError, json.JSONDecodeError, AssertionError) as exc:
        print(f"U1H3FE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
