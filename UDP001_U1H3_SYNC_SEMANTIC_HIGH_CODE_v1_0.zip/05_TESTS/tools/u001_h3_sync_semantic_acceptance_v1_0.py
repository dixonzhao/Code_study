#!/usr/bin/env python3
"""Independent black-box acceptance for U001 H3."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any


class H3AcceptanceError(RuntimeError):
    """Independent acceptance failure."""


CORE_FILES = (
    "u001_frame_domain_compiler_v1_0.py",
    "u001_signal_policy_compiler_v1_0.py",
    "u001_canonical_update_projector_v1_0.py",
    "u001_h3_sync_semantic_engine_v1_0.py",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise H3AcceptanceError(f"IMPORT_SPEC:{path.name}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def validate(core_dir: Path, output_root: Path) -> dict[str, Any]:
    if not core_dir.is_dir():
        raise H3AcceptanceError("CORE_DIRECTORY")
    missing = [name for name in CORE_FILES if not (core_dir / name).is_file()]
    if missing:
        raise H3AcceptanceError(f"CORE_FILES:{missing}")
    if str(core_dir.resolve()) not in sys.path:
        sys.path.insert(0, str(core_dir.resolve()))
    frame = _load_module(core_dir / CORE_FILES[0], "u1h3_accept_frame")
    policy = _load_module(core_dir / CORE_FILES[1], "u1h3_accept_policy")
    projector = _load_module(core_dir / CORE_FILES[2], "u1h3_accept_projector")
    engine = _load_module(core_dir / CORE_FILES[3], "u1h3_accept_engine")

    checks = 0
    def ck(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise H3AcceptanceError(label)
        checks += 1

    output_root.mkdir(parents=True, exist_ok=False)
    frame.self_test(); ck(True, "T01_FRAME_SELFTEST")
    policy.self_test(); ck(True, "T02_POLICY_SELFTEST")
    projector.self_test(); ck(True, "T03_PROJECTOR_SELFTEST")

    fixture = output_root / "fixture"
    h2, _ = engine._write_h2_fixture(fixture / "h2")
    policy_path = fixture / "policy.csv"; engine._write_policy(policy_path)
    request_a = fixture / "request_a.json"; run_a = output_root / "run_a"
    engine._write_request(request_a, h2, policy_path, run_a)
    result_a, capsule_a = engine.run_h3(request_a)
    ck(result_a.is_dir() and capsule_a.endswith("X0-C0"), "T04_RUN")
    expected_names = set(engine.H3_ARTIFACTS) | {"u001_h3_run_manifest.json", "u001_h3_completion_capsule.txt"}
    actual_names = {path.name for path in result_a.iterdir() if path.is_file()}
    ck(actual_names == expected_names, "T05_INVENTORY")
    manifest = json.loads((result_a / "u001_h3_run_manifest.json").read_text(encoding="utf-8"))
    ck(manifest["OutputBoundary"] == engine.OUTPUT_BOUNDARY and manifest["Status"] == "COMPLETE", "T06_MANIFEST")
    ck(manifest["Counts"] == {"InputUpdateRows": 6, "SourceRows": 4, "DistinctFrames": 2, "Signals": 3, "ValidUpdates": 5, "InvalidUpdates": 1}, "T07_COUNTS")
    for item in manifest["Artifacts"]:
        path = result_a / item["FileName"]
        ck(path.stat().st_size == item["SizeBytes"] and sha256_file(path) == item["SHA256"], f"T08_HASH:{path.name}")
    artifact_hash_checks = len(manifest["Artifacts"])

    canonical = list(csv.DictReader((result_a / "u001_h3_canonical_updates.csv").open(encoding="utf-8")))
    ck([row["SourceRowIndex"] for row in canonical] == ["0", "0", "1", "2", "3", "3"], "T09_ORDER")
    ck(canonical[3]["PhysicalValue"] == "327.66" and canonical[3]["Valid"] == "0", "T10_INVALID_DEFAULT")
    ck(canonical[2]["PhysicalValue"] == "0" and canonical[2]["Valid"] == "1", "T11_ZERO_FALSE")
    ck(canonical[3]["MissingReason"] == "USER_INVALID_RULE", "T12_REASON")
    ck(canonical[0]["FrameAssignmentStatus"] == "FRAME_EXACT" and canonical[2]["FrameAssignmentStatus"] == "FRAME_ASSIGNED", "T13_FRAME_STATUS")
    ck(canonical[2]["FrameAssignmentAgeRows"] == "1", "T14_FRAME_AGE")

    request_b = fixture / "request_b.json"; run_b = output_root / "run_b"
    engine._write_request(request_b, h2, policy_path, run_b)
    engine.run_h3(request_b)
    ck(sha256_file(run_a / "u001_h3_canonical_updates.csv") == sha256_file(run_b / "u001_h3_canonical_updates.csv"), "T15_DETERMINISTIC_UPDATES")
    ck(sha256_file(run_a / "u001_h3_frame_map.csv") == sha256_file(run_b / "u001_h3_frame_map.csv"), "T16_DETERMINISTIC_FRAME")
    ck(sha256_file(run_a / "u001_h3_compiled_signal_policy.csv") == sha256_file(run_b / "u001_h3_compiled_signal_policy.csv"), "T17_DETERMINISTIC_POLICY")

    source_before = sha256_file(h2 / engine.H2_FILES["updates"])
    ck(source_before == sha256_file(h2 / engine.H2_FILES["updates"]), "T18_SOURCE_IMMUTABLE")

    provisional = list(csv.DictReader(policy_path.open(encoding="utf-8")))
    provisional[1]["PolicyStatus"] = "PROVISIONAL"
    provisional_path = fixture / "provisional.csv"
    with provisional_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(policy.POLICY_COLUMNS), lineterminator="\n")
        writer.writeheader(); writer.writerows(provisional)
    provisional_request = fixture / "provisional_request.json"
    engine._write_request(provisional_request, h2, provisional_path, output_root / "provisional")
    try:
        engine.run_h3(provisional_request)
    except Exception as exc:
        ck("NOT_APPROVED" in str(exc), "T19_PROVISIONAL_BLOCK")
    else:
        raise H3AcceptanceError("T19_PROVISIONAL_BLOCK")

    decrease_h2 = output_root / "decrease_h2"
    shutil.copytree(h2, decrease_h2)
    updates_path = decrease_h2 / engine.H2_FILES["updates"]
    rows = list(csv.DictReader(updates_path.open(encoding="utf-8")))
    frame_rows = [row for row in rows if row["CanonicalNameCandidate"] == "FRAME"]
    frame_rows[-1]["PhysicalValue"] = "99"; frame_rows[-1]["SyncKeyCandidate"] = "99"
    with updates_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(projector.UPDATE_REQUIRED_COLUMNS), lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    h2_manifest_path = decrease_h2 / engine.H2_FILES["manifest"]
    h2_manifest = json.loads(h2_manifest_path.read_text(encoding="utf-8"))
    for item in h2_manifest["Artifacts"]:
        path = decrease_h2 / item["FileName"]
        item["SizeBytes"] = path.stat().st_size; item["SHA256"] = sha256_file(path)
    h2_manifest_path.write_text(json.dumps(h2_manifest, indent=2) + "\n", encoding="utf-8")
    decrease_request = fixture / "decrease_request.json"
    engine._write_request(decrease_request, decrease_h2, policy_path, output_root / "decrease")
    try:
        engine.run_h3(decrease_request)
    except Exception as exc:
        ck("FRAME_DECREASE" in str(exc), "T20_FRAME_DECREASE")
    else:
        raise H3AcceptanceError("T20_FRAME_DECREASE")

    bad_hash_h2 = output_root / "bad_hash_h2"; shutil.copytree(h2, bad_hash_h2)
    with (bad_hash_h2 / engine.H2_FILES["updates"]).open("a", encoding="utf-8") as stream:
        stream.write("\n")
    bad_hash_request = fixture / "bad_hash_request.json"
    engine._write_request(bad_hash_request, bad_hash_h2, policy_path, output_root / "bad_hash")
    try:
        engine.run_h3(bad_hash_request)
    except Exception as exc:
        ck("IDENTITY" in str(exc), "T21_HASH_BLOCK")
    else:
        raise H3AcceptanceError("T21_HASH_BLOCK")

    ck(not any("/Users/" in path.read_text(encoding="utf-8", errors="ignore") for path in run_a.iterdir() if path.is_file()), "T22_PATH_LEAK")
    ck(not any("C:\\" in path.read_text(encoding="utf-8", errors="ignore") for path in run_a.iterdir() if path.is_file()), "T23_WINDOWS_PATH_LEAK")
    ck(not any(path.name.endswith(".tmp") for path in run_a.rglob("*")), "T24_NO_TEMP")

    expected_checks = 23 + artifact_hash_checks
    if checks != expected_checks:
        raise H3AcceptanceError(f"SELFTEST_COUNT:{checks}:{expected_checks}")
    receipt = {
        "AcceptanceSchema": "U001_H3_INDEPENDENT_ACCEPTANCE_V1_0",
        "CoreHashes": {name: sha256_file(core_dir / name) for name in CORE_FILES},
        "CheckCount": checks,
        "ArtifactHashCheckCount": artifact_hash_checks,
        "Status": "PASS",
        "CompletionCode": 0,
    }
    (output_root / "u001_h3_acceptance_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    capsule = f"U001-H3-INDEPENDENT-ACCEPTANCE-PASS-{checks}"
    (output_root / "u001_h3_acceptance_capsule.txt").write_text(capsule + "\n", encoding="utf-8")
    return receipt


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="u001_h3_acceptance_self_") as temp_text:
        temp = Path(temp_text)
        source_core = Path(__file__).resolve().parents[2] / "01_PROGRAMS" / "core"
        receipt = validate(source_core, temp / "acceptance")
        if receipt["Status"] != "PASS":
            raise AssertionError("ACCEPTANCE_STATUS")
    print("U001-H3-ACCEPTANCE-SELFTEST-PASS-16")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Independently qualify U001 H3")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--validate", action="store_true")
    result.add_argument("--core-dir", type=Path)
    result.add_argument("--output", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test(); return 0
        if args.core_dir is None or args.output is None:
            raise H3AcceptanceError("VALIDATE_ARGUMENTS")
        receipt = validate(args.core_dir, args.output)
        print(f"U1H3Q-N4-T{receipt['CheckCount']}-X0-C0")
        return 0
    except (H3AcceptanceError, OSError, ValueError, csv.Error, json.JSONDecodeError, AssertionError) as exc:
        print(f"U1H3QE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
