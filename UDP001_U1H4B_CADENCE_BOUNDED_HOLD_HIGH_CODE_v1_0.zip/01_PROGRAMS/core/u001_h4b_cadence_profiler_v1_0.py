#!/usr/bin/env python3
"""Profile real per-signal update cadence from an immutable H4A Frame View."""

from __future__ import annotations

import argparse
import csv
import json
import math
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from u001_h4_frame_policy_compiler_v1_0 import POLICY_COLUMNS, POLICY_SCHEMA
from u001_h4b_contract_core_v1_0 import (
    H4A_FRAME_FILE,
    H4A_MANIFEST_FILE,
    H4BContractError,
    iter_raw_frames,
    nearest_rank,
    parse_flag,
    parse_integer,
    require_empty_output,
    sha256_file,
    validate_h4a_package,
    validate_raw_signal_state,
    write_json,
)


PROGRAM_NAME = "u001_h4b_cadence_profiler"
PROGRAM_VERSION = "1.0.0"
PROFILE_SCHEMA = "U001_H4B_CADENCE_PROFILE_V1_0"
OUTPUT_BOUNDARY = "U001_H4B_CADENCE_PACKAGE_V1_0"

PROFILE_FILE = "u001_h4b_cadence_profile.csv"
QUALITY_FILE = "u001_h4b_cadence_quality.json"
MANIFEST_FILE = "u001_h4b_cadence_manifest.json"
CAPSULE_FILE = "u001_h4b_cadence_capsule.txt"

PROFILE_COLUMNS = [
    "ProfileSchema",
    "CanonicalName",
    "ValueKind",
    "SignalRole",
    "Required",
    "TotalFrameCount",
    "UpdatedFrameCount",
    "NoUpdateFrameCount",
    "ValidUpdateFrameCount",
    "InvalidUpdateFrameCount",
    "UpdateCoverageRatio",
    "InterUpdateGapQ50",
    "InterUpdateGapQ95",
    "InterUpdateGapQ99",
    "InterUpdateGapMax",
    "LongestConsecutiveNoUpdateRows",
    "FirstUpdateFrameCount",
    "LastUpdateFrameCount",
    "MultiUpdateFrameCount",
]


class CadenceError(RuntimeError):
    """Fail-closed cadence profiling error."""


@dataclass
class SignalCadence:
    total: int = 0
    updated: int = 0
    no_update: int = 0
    valid_update: int = 0
    invalid_update: int = 0
    multi_update: int = 0
    first_update_frame: int | None = None
    last_update_frame: int | None = None
    current_no_update_run: int = 0
    longest_no_update_run: int = 0
    gap_histogram: dict[int, int] = field(default_factory=dict)

    def observe(self, frame: int, state: dict[str, Any]) -> None:
        self.total += 1
        if state["updated"] == 0:
            self.no_update += 1
            self.current_no_update_run += 1
            self.longest_no_update_run = max(self.longest_no_update_run, self.current_no_update_run)
            return

        self.updated += 1
        if state["valid"] == 1:
            self.valid_update += 1
        else:
            self.invalid_update += 1
        if state["update_count"] > 1:
            self.multi_update += 1
        if self.first_update_frame is None:
            self.first_update_frame = frame
        if self.last_update_frame is not None:
            gap = frame - self.last_update_frame
            if gap <= 0:
                raise CadenceError("NONPOSITIVE_UPDATE_GAP")
            self.gap_histogram[gap] = self.gap_histogram.get(gap, 0) + 1
        self.last_update_frame = frame
        self.current_no_update_run = 0

    def expanded_gap_values(self) -> list[int]:
        values: list[int] = []
        for gap in sorted(self.gap_histogram):
            values.extend([gap] * self.gap_histogram[gap])
        return values


def _read_frame_policy(path: Path, expected_hash: str) -> list[dict[str, str]]:
    if sha256_file(path) != expected_hash:
        raise CadenceError("FRAME_POLICY_IDENTITY")
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            missing = sorted(set(POLICY_COLUMNS) - set(reader.fieldnames or []))
            if missing:
                raise CadenceError(f"FRAME_POLICY_COLUMNS:{'.'.join(missing)}")
            rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise CadenceError(f"FRAME_POLICY_READ:{exc}") from exc
    included: list[dict[str, str]] = []
    for row in rows:
        name = row["CanonicalName"].strip()
        if row["PolicySchema"].strip() != POLICY_SCHEMA:
            raise CadenceError(f"FRAME_POLICY_SCHEMA:{name}")
        if row["PolicyStatus"].strip().upper() != "APPROVED":
            raise CadenceError(f"FRAME_POLICY_NOT_APPROVED:{name}")
        if parse_flag(row["IncludeInFrameView"], f"INCLUDE_{name}") == 1:
            included.append(row)
    names = [row["CanonicalName"].strip() for row in included]
    if not names or len(names) != len(set(names)):
        raise CadenceError("FRAME_POLICY_INCLUDED_IDENTITY")
    return included


def _nearest_rank_from_histogram(histogram: dict[int, int], probability: float) -> int | None:
    count = sum(histogram.values())
    if count == 0:
        return None
    rank = max(1, math.ceil(probability * count))
    cumulative = 0
    for gap in sorted(histogram):
        cumulative += histogram[gap]
        if cumulative >= rank:
            return gap
    raise CadenceError("HISTOGRAM_RANK")


def _profile_rows(
    rows: Iterable[tuple[dict[str, str], list[str]]],
    policy_rows: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    policy_names = [row["CanonicalName"].strip() for row in policy_rows]
    statistics = {name: SignalCadence() for name in policy_names}
    frame_rows = 0
    previous_frame: int | None = None
    missing_frame_count = 0
    maximum_step = 0
    discovered_names: list[str] | None = None

    for row, names in rows:
        if discovered_names is None:
            discovered_names = names
            if names != policy_names:
                raise CadenceError("FRAME_POLICY_SIGNAL_ORDER")
        elif names != discovered_names:
            raise CadenceError("FRAME_SIGNAL_ORDER_DRIFT")
        frame = parse_integer(row["FrameCount"], "FRAME_COUNT", minimum=0)
        assert frame is not None
        if previous_frame is not None:
            step = frame - previous_frame
            maximum_step = max(maximum_step, step)
            if step > 1:
                missing_frame_count += step - 1
        previous_frame = frame
        frame_rows += 1
        for name in policy_names:
            statistics[name].observe(frame, validate_raw_signal_state(row, name))

    if frame_rows == 0:
        raise CadenceError("FRAME_VIEW_EMPTY")
    profile: list[dict[str, Any]] = []
    total_gap_buckets = 0
    for policy_row in policy_rows:
        name = policy_row["CanonicalName"].strip()
        stat = statistics[name]
        total_gap_buckets += len(stat.gap_histogram)
        profile.append(
            {
                "ProfileSchema": PROFILE_SCHEMA,
                "CanonicalName": name,
                "ValueKind": policy_row["ValueKind"].strip().upper(),
                "SignalRole": policy_row["SignalRole"].strip().upper(),
                "Required": policy_row["Required"].strip(),
                "TotalFrameCount": stat.total,
                "UpdatedFrameCount": stat.updated,
                "NoUpdateFrameCount": stat.no_update,
                "ValidUpdateFrameCount": stat.valid_update,
                "InvalidUpdateFrameCount": stat.invalid_update,
                "UpdateCoverageRatio": f"{stat.updated / stat.total:.12g}",
                "InterUpdateGapQ50": _nearest_rank_from_histogram(stat.gap_histogram, 0.50) or "",
                "InterUpdateGapQ95": _nearest_rank_from_histogram(stat.gap_histogram, 0.95) or "",
                "InterUpdateGapQ99": _nearest_rank_from_histogram(stat.gap_histogram, 0.99) or "",
                "InterUpdateGapMax": max(stat.gap_histogram) if stat.gap_histogram else "",
                "LongestConsecutiveNoUpdateRows": stat.longest_no_update_run,
                "FirstUpdateFrameCount": stat.first_update_frame if stat.first_update_frame is not None else "",
                "LastUpdateFrameCount": stat.last_update_frame if stat.last_update_frame is not None else "",
                "MultiUpdateFrameCount": stat.multi_update,
            }
        )
    summary = {
        "InputFrameCount": frame_rows,
        "SignalCount": len(policy_names),
        "MissingFrameCount": missing_frame_count,
        "MaximumAdjacentFrameStep": maximum_step,
        "DistinctGapBucketCount": total_gap_buckets,
    }
    return profile, summary


def profile_cadence(h4a_package: Path, frame_policy: Path, output_dir: Path) -> dict[str, Any]:
    started = time.perf_counter()
    manifest = validate_h4a_package(h4a_package)
    require_empty_output(output_dir)
    policy_rows = _read_frame_policy(frame_policy, str(manifest.get("FramePolicySHA256", "")))
    source = h4a_package / H4A_FRAME_FILE
    source_hash = sha256_file(source)
    profile_rows, summary = _profile_rows(iter_raw_frames(source), policy_rows)
    if source_hash != sha256_file(source):
        raise CadenceError("H4A_SOURCE_MUTATED")

    profile_path = output_dir / PROFILE_FILE
    with profile_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=PROFILE_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(profile_rows)
    quality = {
        "QualitySchema": "U001_H4B_CADENCE_QUALITY_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "H4AManifestSHA256": sha256_file(h4a_package / H4A_MANIFEST_FILE),
        "FramePolicySHA256": sha256_file(frame_policy),
        "RawFrameViewSHA256": source_hash,
        "CadenceProfileSHA256": sha256_file(profile_path),
        **summary,
        "InputMutationCount": 0,
        "HeldCellCount": 0,
        "ZeroFillCount": 0,
        "WholeFileMemoryLoadRequired": False,
        "ElapsedSeconds": round(time.perf_counter() - started, 6),
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / QUALITY_FILE, quality)
    artifacts = []
    for name in (PROFILE_FILE, QUALITY_FILE):
        path = output_dir / name
        artifacts.append({"FileName": name, "SizeBytes": path.stat().st_size, "SHA256": sha256_file(path)})
    output_manifest = {
        "ManifestSchema": "U001_H4B_CADENCE_MANIFEST_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "DatasetId": manifest.get("DatasetId"),
        "RunId": manifest.get("RunId"),
        "SegmentId": manifest.get("SegmentId"),
        "InputH4AManifestSHA256": quality["H4AManifestSHA256"],
        "FramePolicySHA256": quality["FramePolicySHA256"],
        "Artifacts": artifacts,
        "Counts": {"Frames": summary["InputFrameCount"], "Signals": summary["SignalCount"]},
        "Status": "COMPLETE",
        "CompletionCode": 0,
    }
    write_json(output_dir / MANIFEST_FILE, output_manifest)
    capsule = (
        f"U1H4BP-R{summary['InputFrameCount']}-S{summary['SignalCount']}-"
        f"G{summary['MissingFrameCount']}-L{summary['MaximumAdjacentFrameStep']}-X0-C0"
    )
    (output_dir / CAPSULE_FILE).write_text(capsule + "\n", encoding="utf-8")
    return quality


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    policy_rows = [
        {"CanonicalName": "A", "ValueKind": "FLOAT", "SignalRole": "MEASUREMENT", "Required": "1"},
        {"CanonicalName": "B", "ValueKind": "BOOLEAN", "SignalRole": "EVENT_FLAG", "Required": "0"},
    ]

    def signal(name: str, *, value: str = "", updated: int = 0, valid: int = 0, count: int = 0, reason: str = "NO_UPDATE") -> dict[str, str]:
        return {
            name + "__value": value,
            name + "__label": "",
            name + "__updated": str(updated),
            name + "__update_count": str(count),
            name + "__age": "0" if updated else "",
            name + "__valid": str(valid),
            name + "__missing_reason": reason,
        }

    rows: list[tuple[dict[str, str], list[str]]] = []
    for frame in (10, 11, 13, 14, 20):
        row = {"FrameCount": str(frame)}
        row.update(signal("A"))
        row.update(signal("B"))
        if frame in {10, 13, 20}:
            row.update(signal("A", value=str(frame), updated=1, valid=1, count=2 if frame == 13 else 1, reason="VALID_UPDATE"))
        if frame == 11:
            row.update(signal("B", value="1", updated=1, valid=1, count=1, reason="VALID_UPDATE"))
        rows.append((row, ["A", "B"]))
    profile, summary = _profile_rows(rows, policy_rows)
    a, b = profile
    check(summary["InputFrameCount"] == 5, "T01_FRAMES")
    check(summary["SignalCount"] == 2, "T02_SIGNALS")
    check(summary["MissingFrameCount"] == 6, "T03_MISSING_FRAMES")
    check(summary["MaximumAdjacentFrameStep"] == 6, "T04_MAX_STEP")
    check(a["UpdatedFrameCount"] == 3 and a["NoUpdateFrameCount"] == 2, "T05_A_COUNTS")
    check(a["ValidUpdateFrameCount"] == 3 and a["InvalidUpdateFrameCount"] == 0, "T06_A_VALIDITY")
    check(a["InterUpdateGapQ50"] == 3, "T07_A_Q50")
    check(a["InterUpdateGapQ95"] == 7 and a["InterUpdateGapQ99"] == 7, "T08_A_Q95_Q99")
    check(a["InterUpdateGapMax"] == 7, "T09_A_MAX")
    check(a["LongestConsecutiveNoUpdateRows"] == 1, "T10_A_NO_UPDATE_RUN")
    check(a["FirstUpdateFrameCount"] == 10 and a["LastUpdateFrameCount"] == 20, "T11_A_RANGE")
    check(a["MultiUpdateFrameCount"] == 1, "T12_A_MULTI")
    check(b["UpdatedFrameCount"] == 1 and b["NoUpdateFrameCount"] == 4, "T13_B_COUNTS")
    check(b["InterUpdateGapQ50"] == "", "T14_SINGLE_UPDATE_GAP_BLANK")
    check(b["LongestConsecutiveNoUpdateRows"] == 3, "T15_TRAILING_RUN")
    check(a["UpdateCoverageRatio"] == "0.6", "T16_RATIO")
    stat = SignalCadence(); stat.gap_histogram = {1: 95, 10: 5}
    check(_nearest_rank_from_histogram(stat.gap_histogram, 0.95) == 1, "T17_HISTOGRAM_Q95")
    check(_nearest_rank_from_histogram(stat.gap_histogram, 0.99) == 10, "T18_HISTOGRAM_Q99")
    check(PROGRAM_VERSION == "1.0.0", "T19_VERSION")
    if checks != 19:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4B-CADENCE-PROFILER-SELFTEST-PASS-19")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="U001 H4B cadence profiler")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--profile", action="store_true")
    parser.add_argument("--h4a-package", type=Path)
    parser.add_argument("--frame-policy", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.h4a_package is None or args.frame_policy is None or args.out is None:
            raise CadenceError("ARGUMENTS")
        quality = profile_cadence(args.h4a_package, args.frame_policy, args.out)
        print(
            f"U1H4BP-R{quality['InputFrameCount']}-S{quality['SignalCount']}-"
            f"G{quality['MissingFrameCount']}-L{quality['MaximumAdjacentFrameStep']}-X0-C0"
        )
        return 0
    except Exception as exc:
        detail = " ".join(str(exc).split())[-320:] or "NO_DETAIL"
        print(f"U1H4BPE-K{type(exc).__name__.upper()}-D{detail}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
