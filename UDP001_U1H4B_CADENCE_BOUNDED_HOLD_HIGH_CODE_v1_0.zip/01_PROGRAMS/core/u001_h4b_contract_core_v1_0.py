#!/usr/bin/env python3
"""Shared contracts for U001 H4B cadence and bounded-hold processing.

H4B consumes the immutable H4A Raw Frame View package.  This module owns
package identity, dynamic signal-group discovery and coupled state validation.
It has no import-time I/O and never assumes a fixed source signal count.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path, PurePath
from typing import Any, Iterator


PROGRAM_NAME = "u001_h4b_contract_core"
PROGRAM_VERSION = "1.0.0"

H4A_MANIFEST_SCHEMA = "U001_H4_RAW_FRAME_MANIFEST_V1_0"
H4A_OUTPUT_BOUNDARY = "U001_H4_RAW_FRAME_VIEW_PACKAGE_V1_0"
H4A_FRAME_FILE = "u001_h4_raw_frame_view.csv"
H4A_QUALITY_FILE = "u001_h4_raw_frame_quality.json"
H4A_MANIFEST_FILE = "u001_h4_raw_frame_manifest.json"
H4A_CAPSULE_FILE = "u001_h4_raw_frame_capsule.txt"
H4A_ARTIFACTS = {H4A_FRAME_FILE, H4A_QUALITY_FILE}

LEADING_COLUMNS = [
    "FrameCount",
    "SourceRowFirst",
    "SourceRowLast",
    "SourceUpdateCount",
]
SIGNAL_SUFFIXES = [
    "__value",
    "__label",
    "__updated",
    "__update_count",
    "__age",
    "__valid",
    "__missing_reason",
]


class H4BContractError(RuntimeError):
    """Fail-closed H4B boundary error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise H4BContractError(f"{label}_JSON:{exc}") from exc
    if not isinstance(value, dict):
        raise H4BContractError(f"{label}_OBJECT")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def parse_integer(
    text: str,
    label: str,
    *,
    allow_blank: bool = False,
    minimum: int | None = None,
) -> int | None:
    value = text.strip()
    if not value and allow_blank:
        return None
    try:
        number = float(value)
    except ValueError as exc:
        raise H4BContractError(f"{label}_INTEGER:{value}") from exc
    if not math.isfinite(number) or not number.is_integer():
        raise H4BContractError(f"{label}_INTEGER:{value}")
    result = int(number)
    if minimum is not None and result < minimum:
        raise H4BContractError(f"{label}_MINIMUM:{result}:{minimum}")
    return result


def parse_flag(text: str, label: str) -> int:
    value = parse_integer(text, label)
    if value not in {0, 1}:
        raise H4BContractError(f"{label}_FLAG:{text}")
    return int(value)


def nearest_rank(values: list[int], probability: float) -> int | None:
    """Return the deterministic nearest-rank quantile for integer evidence."""
    if not values:
        return None
    if not 0 < probability <= 1:
        raise H4BContractError(f"QUANTILE_PROBABILITY:{probability}")
    ordered = sorted(values)
    rank = max(1, math.ceil(probability * len(ordered)))
    return ordered[rank - 1]


def require_empty_output(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise H4BContractError("OUTPUT_NOT_EMPTY")


def _is_basename(value: str) -> bool:
    path = PurePath(value)
    return bool(value) and not path.is_absolute() and len(path.parts) == 1 and value not in {".", ".."}


def validate_h4a_package(folder: Path) -> dict[str, Any]:
    """Validate the complete H4A package and return its manifest."""
    if not folder.is_dir():
        raise H4BContractError("H4A_PACKAGE_FOLDER")
    manifest_path = folder / H4A_MANIFEST_FILE
    quality_path = folder / H4A_QUALITY_FILE
    capsule_path = folder / H4A_CAPSULE_FILE
    if not manifest_path.is_file() or not quality_path.is_file() or not capsule_path.is_file():
        raise H4BContractError("H4A_CONTROL_FILES")

    manifest = load_json_object(manifest_path, "H4A_MANIFEST")
    quality = load_json_object(quality_path, "H4A_QUALITY")
    if manifest.get("ManifestSchema") != H4A_MANIFEST_SCHEMA:
        raise H4BContractError("H4A_MANIFEST_SCHEMA")
    if manifest.get("OutputBoundary") != H4A_OUTPUT_BOUNDARY:
        raise H4BContractError("H4A_OUTPUT_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise H4BContractError("H4A_MANIFEST_STATUS")
    if quality.get("Status") != "COMPLETE" or quality.get("CompletionCode") != 0:
        raise H4BContractError("H4A_QUALITY_STATUS")
    for field in ("CrossFrameHeldCellCount", "ZeroFillCount", "SyntheticFrameCount"):
        if quality.get(field) != 0:
            raise H4BContractError(f"H4A_RAW_SEMANTIC:{field}")
    if quality.get("WholeFileMemoryLoadRequired") is not False:
        raise H4BContractError("H4A_MEMORY_BOUNDARY")

    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list):
        raise H4BContractError("H4A_ARTIFACT_LIST")
    names: set[str] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise H4BContractError("H4A_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        if not _is_basename(name) or name in names:
            raise H4BContractError(f"H4A_ARTIFACT_NAME:{name}")
        names.add(name)
        path = folder / name
        if not path.is_file():
            raise H4BContractError(f"H4A_ARTIFACT_MISSING:{name}")
        if path.stat().st_size != item.get("SizeBytes") or sha256_file(path) != item.get("SHA256"):
            raise H4BContractError(f"H4A_ARTIFACT_IDENTITY:{name}")
    if names != H4A_ARTIFACTS:
        raise H4BContractError(
            f"H4A_ARTIFACT_INVENTORY:MISSING={sorted(H4A_ARTIFACTS-names)}:"
            f"EXTRA={sorted(names-H4A_ARTIFACTS)}"
        )
    if quality.get("RawFrameViewSHA256") != sha256_file(folder / H4A_FRAME_FILE):
        raise H4BContractError("H4A_QUALITY_FRAME_IDENTITY")
    if not capsule_path.read_text(encoding="utf-8-sig").strip().endswith("C0"):
        raise H4BContractError("H4A_CAPSULE")
    return manifest


def discover_signal_names(fieldnames: list[str] | None) -> list[str]:
    """Discover ordered seven-column signal groups from a Frame View header."""
    header = list(fieldnames or [])
    if header[: len(LEADING_COLUMNS)] != LEADING_COLUMNS:
        raise H4BContractError("FRAME_LEADING_COLUMNS")
    remaining = header[len(LEADING_COLUMNS) :]
    if not remaining or len(remaining) % len(SIGNAL_SUFFIXES) != 0:
        raise H4BContractError("FRAME_SIGNAL_GROUP_WIDTH")
    names: list[str] = []
    width = len(SIGNAL_SUFFIXES)
    for offset in range(0, len(remaining), width):
        group = remaining[offset : offset + width]
        first = group[0]
        if not first.endswith(SIGNAL_SUFFIXES[0]):
            raise H4BContractError(f"FRAME_SIGNAL_VALUE_COLUMN:{first}")
        name = first[: -len(SIGNAL_SUFFIXES[0])]
        if not name or group != [name + suffix for suffix in SIGNAL_SUFFIXES]:
            raise H4BContractError(f"FRAME_SIGNAL_GROUP:{name}")
        if name in names:
            raise H4BContractError(f"FRAME_SIGNAL_DUPLICATE:{name}")
        names.append(name)
    return names


def validate_raw_signal_state(row: dict[str, str], name: str) -> dict[str, Any]:
    """Validate one H4A signal group as one coupled semantic state."""
    value = row[name + "__value"]
    label = row[name + "__label"]
    updated = parse_flag(row[name + "__updated"], f"{name}_UPDATED")
    update_count = parse_integer(row[name + "__update_count"], f"{name}_UPDATE_COUNT", minimum=0)
    age = parse_integer(row[name + "__age"], f"{name}_AGE", allow_blank=True, minimum=0)
    valid = parse_flag(row[name + "__valid"], f"{name}_VALID")
    reason = row[name + "__missing_reason"].strip()
    assert update_count is not None

    if updated == 1:
        if update_count < 1 or age != 0 or not reason:
            raise H4BContractError(f"RAW_UPDATED_STATE:{name}")
        if valid == 1 and value == "":
            raise H4BContractError(f"RAW_VALID_VALUE:{name}")
    else:
        if update_count != 0 or age is not None or valid != 0:
            raise H4BContractError(f"RAW_NO_UPDATE_STATE:{name}")
        if value != "" or label != "" or reason != "NO_UPDATE":
            raise H4BContractError(f"RAW_NO_UPDATE_CONTENT:{name}")
    return {
        "value": value,
        "label": label,
        "updated": updated,
        "update_count": update_count,
        "age": age,
        "valid": valid,
        "reason": reason,
    }


def iter_raw_frames(path: Path) -> Iterator[tuple[dict[str, str], list[str]]]:
    """Stream and validate H4A rows without materializing the full table."""
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            names = discover_signal_names(reader.fieldnames)
            previous_frame: int | None = None
            for row in reader:
                frame = parse_integer(row["FrameCount"], "FRAME_COUNT", minimum=0)
                source_first = parse_integer(row["SourceRowFirst"], "SOURCE_ROW_FIRST", minimum=0)
                source_last = parse_integer(row["SourceRowLast"], "SOURCE_ROW_LAST", minimum=0)
                source_count = parse_integer(row["SourceUpdateCount"], "SOURCE_UPDATE_COUNT", minimum=1)
                assert frame is not None and source_first is not None and source_last is not None
                assert source_count is not None
                if source_last < source_first:
                    raise H4BContractError("SOURCE_ROW_RANGE")
                if previous_frame is not None and frame <= previous_frame:
                    raise H4BContractError("FRAMECOUNT_NOT_STRICT")
                previous_frame = frame
                for name in names:
                    validate_raw_signal_state(row, name)
                yield row, names
    except (OSError, UnicodeError, csv.Error, KeyError) as exc:
        if isinstance(exc, H4BContractError):
            raise
        raise H4BContractError(f"FRAME_READ:{exc}") from exc


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    header = LEADING_COLUMNS + ["A" + suffix for suffix in SIGNAL_SUFFIXES] + [
        "B" + suffix for suffix in SIGNAL_SUFFIXES
    ]
    check(discover_signal_names(header) == ["A", "B"], "T01_DYNAMIC_GROUPS")
    check(nearest_rank([1, 2, 8, 10], 0.5) == 2, "T02_Q50")
    check(nearest_rank([1, 2, 8, 10], 0.95) == 10, "T03_Q95")
    check(parse_integer("0", "X", minimum=0) == 0, "T04_ZERO_INTEGER")
    check(parse_integer("", "X", allow_blank=True) is None, "T05_BLANK_INTEGER")

    base = {
        "A__value": "",
        "A__label": "",
        "A__updated": "0",
        "A__update_count": "0",
        "A__age": "",
        "A__valid": "0",
        "A__missing_reason": "NO_UPDATE",
    }
    state = validate_raw_signal_state(base, "A")
    check(state["age"] is None and state["valid"] == 0, "T06_INVALID_BLANK_AGE")
    valid = dict(base)
    valid.update({"A__value": "0", "A__updated": "1", "A__update_count": "1", "A__age": "0", "A__valid": "1", "A__missing_reason": "VALID_UPDATE"})
    check(validate_raw_signal_state(valid, "A")["value"] == "0", "T07_TRUE_ZERO")
    invalid = dict(valid)
    invalid.update({"A__value": "327.66", "A__valid": "0", "A__missing_reason": "USER_INVALID_RULE"})
    check(validate_raw_signal_state(invalid, "A")["age"] == 0, "T08_INVALID_UPDATE")

    bad = dict(base); bad["A__age"] = "1"
    try:
        validate_raw_signal_state(bad, "A")
    except H4BContractError:
        check(True, "T09_NO_UPDATE_NUMERIC_AGE_BLOCKED")
    else:
        raise AssertionError("T09_NO_UPDATE_NUMERIC_AGE_BLOCKED")
    bad = dict(valid); bad["A__age"] = ""
    try:
        validate_raw_signal_state(bad, "A")
    except H4BContractError:
        check(True, "T10_VALID_BLANK_AGE_BLOCKED")
    else:
        raise AssertionError("T10_VALID_BLANK_AGE_BLOCKED")
    try:
        discover_signal_names(header[:-1])
    except H4BContractError:
        check(True, "T11_INCOMPLETE_GROUP_BLOCKED")
    else:
        raise AssertionError("T11_INCOMPLETE_GROUP_BLOCKED")
    check(len(SIGNAL_SUFFIXES) == 7, "T12_SEVEN_COLUMN_CONTRACT")
    check(H4A_ARTIFACTS == {H4A_FRAME_FILE, H4A_QUALITY_FILE}, "T13_H4A_ARTIFACTS")
    check(PROGRAM_VERSION == "1.0.0", "T14_VERSION")
    if checks != 14:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4B-CONTRACT-CORE-SELFTEST-PASS-14")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="U001 H4B contract core")
    parser.add_argument("--self-test", action="store_true", required=True)
    parser.parse_args(argv)
    try:
        self_test()
        return 0
    except (H4BContractError, AssertionError, OSError, ValueError, csv.Error) as exc:
        print(f"U1H4BCE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
