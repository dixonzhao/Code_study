#!/usr/bin/env python3
"""Apply explicit per-signal bounded hold to an immutable H4A Frame View."""

from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

from u001_h4b_contract_core_v1_0 import (
    H4A_FRAME_FILE,
    H4A_MANIFEST_FILE,
    H4BContractError,
    SIGNAL_SUFFIXES,
    iter_raw_frames,
    load_json_object,
    parse_integer,
    require_empty_output,
    sha256_file,
    validate_h4a_package,
    validate_raw_signal_state,
    write_json,
)
from u001_h4b_hold_policy_compiler_v1_0 import (
    CAPSULE_FILE as POLICY_CAPSULE_FILE,
    COMPILED_FILE,
    POLICY_COLUMNS,
    POLICY_SCHEMA,
    QUALITY_FILE as POLICY_QUALITY_FILE,
)


PROGRAM_NAME = "u001_h4b_bounded_hold_engine"
PROGRAM_VERSION = "1.0.0"
OUTPUT_BOUNDARY = "U001_H4B_BOUNDED_FRAME_VIEW_PACKAGE_V1_0"

OUTPUT_FRAME_VIEW = "u001_h4_bounded_frame_view.csv"
OUTPUT_QUALITY = "u001_h4_bounded_frame_quality.json"
OUTPUT_MANIFEST = "u001_h4_bounded_frame_manifest.json"
OUTPUT_CAPSULE = "u001_h4_bounded_frame_capsule.txt"


class BoundedHoldError(RuntimeError):
    """Fail-closed bounded-hold error."""


@dataclass
class RuntimeState:
    origin_value: str | None = None
    origin_label: str = ""
    origin_frame: int | None = None
    barrier: bool = False
    previous_real_valid_value: str | None = None


@dataclass
class SignalMetrics:
    real_valid_updates: int = 0
    real_invalid_updates: int = 0
    carried: int = 0
    stale: int = 0
    no_prior: int = 0
    unheld_no_update: int = 0
    barrier: int = 0
    value_changed_on_real_update: int = 0
    age_histogram: dict[int, int] = field(default_factory=dict)

    def observe_age(self, age: int) -> None:
        self.age_histogram[age] = self.age_histogram.get(age, 0) + 1


def _histogram_quantile(histogram: dict[int, int], probability: float) -> int | None:
    count = sum(histogram.values())
    if count == 0:
        return None
    import math

    rank = max(1, math.ceil(probability * count))
    cumulative = 0
    for value in sorted(histogram):
        cumulative += histogram[value]
        if cumulative >= rank:
            return value
    raise BoundedHoldError("AGE_HISTOGRAM_RANK")


def _read_policy_package(folder: Path, h4a_manifest_hash: str) -> list[dict[str, Any]]:
    compiled_path = folder / COMPILED_FILE
    quality_path = folder / POLICY_QUALITY_FILE
    capsule_path = folder / POLICY_CAPSULE_FILE
    if not compiled_path.is_file() or not quality_path.is_file() or not capsule_path.is_file():
        raise BoundedHoldError("HOLD_POLICY_PACKAGE_FILES")
    quality = load_json_object(quality_path, "HOLD_POLICY_QUALITY")
    if quality.get("Status") != "COMPILED" or quality.get("CompletionCode") != 0:
        raise BoundedHoldError("HOLD_POLICY_STATUS")
    if quality.get("CompiledPolicySHA256") != sha256_file(compiled_path):
        raise BoundedHoldError("HOLD_POLICY_IDENTITY")
    if quality.get("InputH4AManifestSHA256") != h4a_manifest_hash:
        raise BoundedHoldError("HOLD_POLICY_H4A_IDENTITY")
    if quality.get("BlankCompiledMaxAgeCount") != 0:
        raise BoundedHoldError("HOLD_POLICY_BLANK_MAX_AGE")
    if not capsule_path.read_text(encoding="utf-8-sig").strip().endswith("C0"):
        raise BoundedHoldError("HOLD_POLICY_CAPSULE")
    try:
        with compiled_path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if list(reader.fieldnames or []) != POLICY_COLUMNS:
                raise BoundedHoldError("HOLD_POLICY_COLUMNS")
            raw_rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise BoundedHoldError(f"HOLD_POLICY_READ:{exc}") from exc

    result: list[dict[str, Any]] = []
    names: list[str] = []
    for row in raw_rows:
        name = row["CanonicalName"].strip()
        method = row["HoldPolicy"].strip().upper()
        role = row["SignalRole"].strip().upper()
        if row["PolicySchema"].strip() != POLICY_SCHEMA or row["PolicyStatus"].strip().upper() != "APPROVED":
            raise BoundedHoldError(f"HOLD_POLICY_APPROVAL:{name}")
        if method not in {"NONE", "HOLD_LAST_BOUNDED"}:
            raise BoundedHoldError(f"HOLD_POLICY_METHOD:{name}")
        if role == "EVENT_FLAG" and method != "NONE":
            raise BoundedHoldError(f"EVENT_FLAG_HOLD:{name}")
        maximum_age = parse_integer(row["MaxAgeFrames"], f"MAX_AGE_{name}", minimum=0)
        assert maximum_age is not None
        if method == "NONE" and maximum_age != 0:
            raise BoundedHoldError(f"NONE_EFFECTIVE_MAX_AGE:{name}")
        names.append(name)
        result.append({**row, "CanonicalName": name, "HoldPolicy": method, "MaxAgeFrames": maximum_age})
    if not names or len(names) != len(set(names)):
        raise BoundedHoldError("HOLD_POLICY_SIGNAL_IDENTITY")
    if len(result) != quality.get("PolicyRowCount"):
        raise BoundedHoldError("HOLD_POLICY_ROW_COUNT")
    return result


def _blank_state(name: str, reason: str, age: int | None = None) -> dict[str, Any]:
    return {
        name + "__value": "",
        name + "__label": "",
        name + "__updated": 0,
        name + "__update_count": 0,
        name + "__age": "" if age is None else age,
        name + "__valid": 0,
        name + "__missing_reason": reason,
    }


def transform_signal(
    row: dict[str, str],
    name: str,
    frame: int,
    policy: dict[str, Any],
    runtime: RuntimeState,
    metrics: SignalMetrics,
) -> dict[str, Any]:
    """Transform one signal while retaining current-frame provenance."""
    state = validate_raw_signal_state(row, name)
    method = policy["HoldPolicy"]
    maximum_age = int(policy["MaxAgeFrames"])
    if method == "NONE":
        if state["updated"] == 1 and state["valid"] == 1:
            metrics.real_valid_updates += 1
        elif state["updated"] == 1:
            metrics.real_invalid_updates += 1
        else:
            metrics.unheld_no_update += 1
        return {name + suffix: row[name + suffix] for suffix in SIGNAL_SUFFIXES}

    if state["updated"] == 1:
        if state["valid"] == 1:
            metrics.real_valid_updates += 1
            if runtime.previous_real_valid_value is not None and runtime.previous_real_valid_value != state["value"]:
                metrics.value_changed_on_real_update += 1
            runtime.previous_real_valid_value = state["value"]
            runtime.origin_value = state["value"]
            runtime.origin_label = state["label"]
            runtime.origin_frame = frame
            runtime.barrier = False
        else:
            metrics.real_invalid_updates += 1
            runtime.origin_value = None
            runtime.origin_label = ""
            runtime.origin_frame = None
            runtime.barrier = True
        return {name + suffix: row[name + suffix] for suffix in SIGNAL_SUFFIXES}

    if runtime.barrier:
        metrics.barrier += 1
        return _blank_state(name, "INVALID_UPDATE_BARRIER")
    if runtime.origin_frame is None or runtime.origin_value is None:
        metrics.no_prior += 1
        return _blank_state(name, "NO_UPDATE")

    age = frame - runtime.origin_frame
    if age <= 0:
        raise BoundedHoldError(f"NONPOSITIVE_HOLD_AGE:{name}:{age}")
    metrics.observe_age(age)
    if age <= maximum_age:
        metrics.carried += 1
        return {
            name + "__value": runtime.origin_value,
            name + "__label": runtime.origin_label,
            name + "__updated": 0,
            name + "__update_count": 0,
            name + "__age": age,
            name + "__valid": 1,
            name + "__missing_reason": "VALID_CARRIED",
        }
    metrics.stale += 1
    return _blank_state(name, "STALE", age)


def _process_rows(
    rows: Iterator[tuple[dict[str, str], list[str]]],
    policy_rows: list[dict[str, Any]],
    writer: csv.DictWriter,
) -> tuple[int, dict[str, SignalMetrics], int, int]:
    policy_names = [row["CanonicalName"] for row in policy_rows]
    policy_by_name = {row["CanonicalName"]: row for row in policy_rows}
    runtime = {name: RuntimeState() for name in policy_names}
    metrics = {name: SignalMetrics() for name in policy_names}
    frame_rows = 0
    provenance_changes = 0
    leading_changes = 0
    for row, names in rows:
        if names != policy_names:
            raise BoundedHoldError("HOLD_POLICY_SIGNAL_ORDER")
        frame = parse_integer(row["FrameCount"], "FRAME_COUNT", minimum=0)
        assert frame is not None
        output = {
            key: row[key]
            for key in ("FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount")
        }
        for name in names:
            transformed = transform_signal(row, name, frame, policy_by_name[name], runtime[name], metrics[name])
            if str(transformed[name + "__updated"]) != row[name + "__updated"]:
                provenance_changes += 1
            if str(transformed[name + "__update_count"]) != row[name + "__update_count"]:
                provenance_changes += 1
            output.update(transformed)
        for key in ("FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount"):
            if output[key] != row[key]:
                leading_changes += 1
        writer.writerow(output)
        frame_rows += 1
    return frame_rows, metrics, provenance_changes, leading_changes


def apply_bounded_hold(h4a_package: Path, policy_package: Path, output_dir: Path) -> dict[str, Any]:
    started = time.perf_counter()
    h4a_manifest = validate_h4a_package(h4a_package)
    h4a_manifest_hash = sha256_file(h4a_package / H4A_MANIFEST_FILE)
    policy_rows = _read_policy_package(policy_package, h4a_manifest_hash)
    require_empty_output(output_dir)
    source = h4a_package / H4A_FRAME_FILE
    source_hash = sha256_file(source)
    iterator = iter_raw_frames(source)
    try:
        first_row, first_names = next(iterator)
    except StopIteration as exc:
        raise BoundedHoldError("FRAME_VIEW_EMPTY") from exc
    fieldnames = list(first_row)

    def rows_with_first() -> Iterator[tuple[dict[str, str], list[str]]]:
        yield first_row, first_names
        yield from iterator

    output_path = output_dir / OUTPUT_FRAME_VIEW
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        frame_count, metrics, provenance_changes, leading_changes = _process_rows(
            rows_with_first(), policy_rows, writer
        )
    if source_hash != sha256_file(source):
        raise BoundedHoldError("H4A_SOURCE_MUTATED")
    expected_frames = h4a_manifest.get("Counts", {}).get("OutputFrames")
    if frame_count != expected_frames:
        raise BoundedHoldError(f"FRAME_COUNT_MISMATCH:{frame_count}:{expected_frames}")
    if provenance_changes != 0 or leading_changes != 0:
        raise BoundedHoldError(f"PROVENANCE_MUTATION:{provenance_changes}:{leading_changes}")

    per_signal: dict[str, Any] = {}
    carried_total = 0
    stale_total = 0
    barrier_total = 0
    no_prior_total = 0
    for row in policy_rows:
        name = row["CanonicalName"]
        item = metrics[name]
        carried_total += item.carried
        stale_total += item.stale
        barrier_total += item.barrier
        no_prior_total += item.no_prior
        per_signal[name] = {
            "HoldPolicy": row["HoldPolicy"],
            "MaxAgeFrames": row["MaxAgeFrames"],
            "RealValidUpdateFrameCount": item.real_valid_updates,
            "RealInvalidUpdateFrameCount": item.real_invalid_updates,
            "CarriedFrameCount": item.carried,
            "StaleFrameCount": item.stale,
            "NoPriorUpdateFrameCount": item.no_prior,
            "UnheldNoUpdateFrameCount": item.unheld_no_update,
            "HoldBarrierFrameCount": item.barrier,
            "AgeQ95": _histogram_quantile(item.age_histogram, 0.95),
            "AgeMax": max(item.age_histogram) if item.age_histogram else None,
            "ValueChangedOnRealUpdateCount": item.value_changed_on_real_update,
        }
    quality = {
        "QualitySchema": "U001_H4B_BOUNDED_FRAME_QUALITY_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "H4AManifestSHA256": h4a_manifest_hash,
        "RawFrameViewSHA256": source_hash,
        "CompiledHoldPolicySHA256": sha256_file(policy_package / COMPILED_FILE),
        "BoundedFrameViewSHA256": sha256_file(output_path),
        "InputFrameCount": frame_count,
        "OutputFrameCount": frame_count,
        "SignalCount": len(policy_rows),
        "CarriedCellCount": carried_total,
        "StaleCellCount": stale_total,
        "HoldBarrierCellCount": barrier_total,
        "NoPriorUpdateCellCount": no_prior_total,
        "CurrentUpdateProvenanceChangeCount": 0,
        "LeadingColumnChangeCount": 0,
        "SyntheticFrameCount": 0,
        "SyntheticZeroFillCount": 0,
        "UnboundedHoldCount": 0,
        "InputMutationCount": 0,
        "WholeFileMemoryLoadRequired": False,
        "StatefulParallelExecutionAllowed": False,
        "PerSignal": per_signal,
        "ElapsedSeconds": round(time.perf_counter() - started, 6),
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / OUTPUT_QUALITY, quality)
    artifacts = []
    for name in (OUTPUT_FRAME_VIEW, OUTPUT_QUALITY):
        path = output_dir / name
        artifacts.append({"FileName": name, "SizeBytes": path.stat().st_size, "SHA256": sha256_file(path)})
    manifest = {
        "ManifestSchema": "U001_H4B_BOUNDED_FRAME_MANIFEST_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "DatasetId": h4a_manifest.get("DatasetId"),
        "RunId": h4a_manifest.get("RunId"),
        "SegmentId": h4a_manifest.get("SegmentId"),
        "InputH4AManifestSHA256": h4a_manifest_hash,
        "CompiledHoldPolicySHA256": quality["CompiledHoldPolicySHA256"],
        "Artifacts": artifacts,
        "Counts": {"Frames": frame_count, "Signals": len(policy_rows)},
        "Status": "COMPLETE",
        "CompletionCode": 0,
    }
    write_json(output_dir / OUTPUT_MANIFEST, manifest)
    (output_dir / OUTPUT_CAPSULE).write_text(
        f"U1H4B-R{frame_count}-S{len(policy_rows)}-C{carried_total}-T{stale_total}-B{barrier_total}-X0-C0\n",
        encoding="utf-8",
    )
    return quality


def _raw(name: str, value: str = "", updated: int = 0, valid: int = 0, reason: str = "NO_UPDATE") -> dict[str, str]:
    return {
        name + "__value": value,
        name + "__label": "",
        name + "__updated": str(updated),
        name + "__update_count": "1" if updated else "0",
        name + "__age": "0" if updated else "",
        name + "__valid": str(valid),
        name + "__missing_reason": reason,
    }


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    bounded = {"HoldPolicy": "HOLD_LAST_BOUNDED", "MaxAgeFrames": 3}
    none = {"HoldPolicy": "NONE", "MaxAgeFrames": 0}
    runtime = RuntimeState(); metrics = SignalMetrics()
    no_update = _raw("A")
    result = transform_signal(no_update, "A", 100, bounded, runtime, metrics)
    check(result["A__missing_reason"] == "NO_UPDATE" and result["A__age"] == "", "T01_NO_PRIOR")

    valid = _raw("A", "10", 1, 1, "VALID_UPDATE")
    result = transform_signal(valid, "A", 101, bounded, runtime, metrics)
    check(result["A__value"] == "10" and result["A__age"] == "0", "T02_VALID_ORIGIN")
    result = transform_signal(no_update, "A", 103, bounded, runtime, metrics)
    check(result["A__value"] == "10" and result["A__age"] == 2, "T03_CARRY_WITHIN")
    check(result["A__updated"] == 0 and result["A__update_count"] == 0, "T04_CARRY_PROVENANCE")
    check(result["A__missing_reason"] == "VALID_CARRIED", "T05_CARRY_REASON")
    result = transform_signal(no_update, "A", 105, bounded, runtime, metrics)
    check(result["A__value"] == "" and result["A__age"] == 4, "T06_STALE_BLANK")
    check(result["A__missing_reason"] == "STALE" and result["A__valid"] == 0, "T07_STALE_REASON")

    invalid = _raw("A", "327.66", 1, 0, "USER_INVALID_RULE")
    result = transform_signal(invalid, "A", 106, bounded, runtime, metrics)
    check(result["A__value"] == "327.66" and result["A__valid"] == "0", "T08_INVALID_PRESERVED")
    result = transform_signal(no_update, "A", 107, bounded, runtime, metrics)
    check(result["A__missing_reason"] == "INVALID_UPDATE_BARRIER", "T09_BARRIER")
    check(result["A__age"] == "" and result["A__value"] == "", "T10_BARRIER_BLANK")

    zero = _raw("A", "0", 1, 1, "VALID_UPDATE")
    transform_signal(zero, "A", 108, bounded, runtime, metrics)
    result = transform_signal(no_update, "A", 109, bounded, runtime, metrics)
    check(result["A__value"] == "0" and result["A__valid"] == 1, "T11_TRUE_ZERO_CARRIED")
    result = transform_signal(no_update, "A", 111, bounded, runtime, metrics)
    check(result["A__age"] == 3 and result["A__valid"] == 1, "T12_BOUNDARY_INCLUSIVE")
    result = transform_signal(no_update, "A", 112, bounded, runtime, metrics)
    check(result["A__age"] == 4 and result["A__valid"] == 0, "T13_BOUNDARY_EXCEEDED")

    none_runtime = RuntimeState(); none_metrics = SignalMetrics()
    original = _raw("F", "1", 1, 1, "VALID_UPDATE")
    copied = transform_signal(original, "F", 1, none, none_runtime, none_metrics)
    check(all(str(copied[key]) == value for key, value in original.items()), "T14_NONE_EXACT")
    absent = _raw("F")
    copied_absent = transform_signal(absent, "F", 2, none, none_runtime, none_metrics)
    check(all(str(copied_absent[key]) == value for key, value in absent.items()), "T15_NONE_NO_UPDATE_EXACT")
    check(copied_absent["F__age"] == "", "T16_NONE_INVALID_BLANK_AGE")

    second_runtime = RuntimeState(); second_metrics = SignalMetrics()
    transform_signal(_raw("B", "5", 1, 1, "VALID_UPDATE"), "B", 10, bounded, second_runtime, second_metrics)
    first_carry = transform_signal(_raw("B"), "B", 11, bounded, second_runtime, second_metrics)
    second_carry = transform_signal(_raw("B"), "B", 12, bounded, second_runtime, second_metrics)
    check(first_carry["B__age"] == 1 and second_carry["B__age"] == 2, "T17_CARRY_NOT_NEW_ORIGIN")
    jump = transform_signal(_raw("B"), "B", 20, bounded, second_runtime, second_metrics)
    check(jump["B__age"] == 10 and jump["B__missing_reason"] == "STALE", "T18_FRAMECOUNT_GAP_AGE")
    check(second_metrics.carried == 2 and second_metrics.stale == 1, "T19_METRICS")
    check(metrics.real_valid_updates == 2 and metrics.real_invalid_updates == 1, "T20_UPDATE_METRICS")
    check(metrics.barrier == 1, "T21_BARRIER_METRICS")
    check(_histogram_quantile({1: 95, 10: 5}, 0.95) == 1, "T22_AGE_Q95")
    check(_histogram_quantile({1: 95, 10: 5}, 0.99) == 10, "T23_AGE_Q99")
    check(PROGRAM_VERSION == "1.0.0", "T24_VERSION")
    check(OUTPUT_BOUNDARY.endswith("V1_0"), "T25_BOUNDARY")
    if checks != 25:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4B-BOUNDED-HOLD-ENGINE-SELFTEST-PASS-25")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="U001 H4B bounded-hold engine")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--apply", action="store_true")
    parser.add_argument("--h4a-package", type=Path)
    parser.add_argument("--policy-package", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.h4a_package is None or args.policy_package is None or args.out is None:
            raise BoundedHoldError("ARGUMENTS")
        quality = apply_bounded_hold(args.h4a_package, args.policy_package, args.out)
        print(
            f"U1H4B-R{quality['OutputFrameCount']}-S{quality['SignalCount']}-"
            f"C{quality['CarriedCellCount']}-T{quality['StaleCellCount']}-"
            f"B{quality['HoldBarrierCellCount']}-X0-C0"
        )
        return 0
    except Exception as exc:
        detail = " ".join(str(exc).split())[-320:] or "NO_DETAIL"
        print(f"U1H4BE-K{type(exc).__name__.upper()}-D{detail}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
