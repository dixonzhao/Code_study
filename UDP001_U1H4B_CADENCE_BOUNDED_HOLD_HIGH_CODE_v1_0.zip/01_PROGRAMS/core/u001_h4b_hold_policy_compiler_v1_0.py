#!/usr/bin/env python3
"""Create and compile explicit per-signal H4B bounded-hold policies."""

from __future__ import annotations

import argparse
import csv
import json
import tempfile
from pathlib import Path, PurePath
from typing import Any

from u001_h4b_cadence_profiler_v1_0 import (
    MANIFEST_FILE as CADENCE_MANIFEST_FILE,
    OUTPUT_BOUNDARY as CADENCE_BOUNDARY,
    PROFILE_COLUMNS,
    PROFILE_FILE,
    PROFILE_SCHEMA,
    QUALITY_FILE as CADENCE_QUALITY_FILE,
)
from u001_h4b_contract_core_v1_0 import (
    H4BContractError,
    load_json_object,
    parse_integer,
    require_empty_output,
    sha256_file,
    write_json,
)


PROGRAM_NAME = "u001_h4b_hold_policy_compiler"
PROGRAM_VERSION = "1.0.0"
POLICY_SCHEMA = "U001_H4B_HOLD_POLICY_V1_0"

TEMPLATE_FILE = "u001_h4b_hold_policy_template.csv"
COMPILED_FILE = "u001_h4b_compiled_hold_policy.csv"
QUALITY_FILE = "u001_h4b_hold_policy_quality.json"
CAPSULE_FILE = "u001_h4b_hold_policy_capsule.txt"

POLICY_COLUMNS = [
    "PolicySchema",
    "CanonicalName",
    "ValueKind",
    "SignalRole",
    "Required",
    "HoldPolicy",
    "MaxAgeFrames",
    "PolicyBasis",
    "PolicyStatus",
    "ObservedGapQ95",
    "ObservedGapQ99",
    "ObservedGapMax",
    "Notes",
]

ALLOWED_POLICIES = {"UNDECIDED", "NONE", "HOLD_LAST_BOUNDED"}


class HoldPolicyError(RuntimeError):
    """Fail-closed hold-policy error."""


def _is_basename(value: str) -> bool:
    path = PurePath(value)
    return bool(value) and not path.is_absolute() and len(path.parts) == 1 and value not in {".", ".."}


def _read_csv(path: Path, columns: list[str], label: str) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if list(reader.fieldnames or []) != columns:
                raise HoldPolicyError(f"{label}_COLUMNS")
            return list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise HoldPolicyError(f"{label}_READ:{exc}") from exc


def validate_cadence_package(folder: Path) -> tuple[dict[str, Any], list[dict[str, str]]]:
    if not folder.is_dir():
        raise HoldPolicyError("CADENCE_PACKAGE_FOLDER")
    manifest = load_json_object(folder / CADENCE_MANIFEST_FILE, "CADENCE_MANIFEST")
    quality = load_json_object(folder / CADENCE_QUALITY_FILE, "CADENCE_QUALITY")
    if manifest.get("ManifestSchema") != "U001_H4B_CADENCE_MANIFEST_V1_0":
        raise HoldPolicyError("CADENCE_MANIFEST_SCHEMA")
    if manifest.get("OutputBoundary") != CADENCE_BOUNDARY:
        raise HoldPolicyError("CADENCE_OUTPUT_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise HoldPolicyError("CADENCE_MANIFEST_STATUS")
    if quality.get("Status") != "COMPLETE" or quality.get("CompletionCode") != 0:
        raise HoldPolicyError("CADENCE_QUALITY_STATUS")
    expected = {PROFILE_FILE, CADENCE_QUALITY_FILE}
    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list):
        raise HoldPolicyError("CADENCE_ARTIFACT_LIST")
    names: set[str] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise HoldPolicyError("CADENCE_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        if not _is_basename(name) or name in names:
            raise HoldPolicyError(f"CADENCE_ARTIFACT_NAME:{name}")
        names.add(name)
        path = folder / name
        if not path.is_file():
            raise HoldPolicyError(f"CADENCE_ARTIFACT_MISSING:{name}")
        if path.stat().st_size != item.get("SizeBytes") or sha256_file(path) != item.get("SHA256"):
            raise HoldPolicyError(f"CADENCE_ARTIFACT_IDENTITY:{name}")
    if names != expected:
        raise HoldPolicyError("CADENCE_ARTIFACT_INVENTORY")
    rows = _read_csv(folder / PROFILE_FILE, PROFILE_COLUMNS, "CADENCE_PROFILE")
    if len(rows) != manifest.get("Counts", {}).get("Signals"):
        raise HoldPolicyError("CADENCE_SIGNAL_COUNT")
    names_in_rows = [row["CanonicalName"].strip() for row in rows]
    if not names_in_rows or any(not name for name in names_in_rows) or len(names_in_rows) != len(set(names_in_rows)):
        raise HoldPolicyError("CADENCE_SIGNAL_IDENTITY")
    if any(row["ProfileSchema"].strip() != PROFILE_SCHEMA for row in rows):
        raise HoldPolicyError("CADENCE_PROFILE_SCHEMA")
    return manifest, rows


def proposal_rows(cadence_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    """Produce a neutral proposal; statistics never auto-approve hold semantics."""
    result: list[dict[str, str]] = []
    for row in cadence_rows:
        result.append(
            {
                "PolicySchema": POLICY_SCHEMA,
                "CanonicalName": row["CanonicalName"].strip(),
                "ValueKind": row["ValueKind"].strip().upper(),
                "SignalRole": row["SignalRole"].strip().upper(),
                "Required": row["Required"].strip(),
                "HoldPolicy": "UNDECIDED",
                "MaxAgeFrames": "",
                "PolicyBasis": "",
                "PolicyStatus": "PROVISIONAL",
                "ObservedGapQ95": row["InterUpdateGapQ95"].strip(),
                "ObservedGapQ99": row["InterUpdateGapQ99"].strip(),
                "ObservedGapMax": row["InterUpdateGapMax"].strip(),
                "Notes": "Engineer decision required; cadence is evidence, not approval",
            }
        )
    return result


def write_template(cadence_package: Path, output_path: Path) -> int:
    _, cadence_rows = validate_cadence_package(cadence_package)
    if output_path.exists():
        raise HoldPolicyError("TEMPLATE_ALREADY_EXISTS")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(proposal_rows(cadence_rows))
    return len(cadence_rows)


def _compile_rows(
    candidate_rows: list[dict[str, str]],
    cadence_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    if not candidate_rows:
        raise HoldPolicyError("HOLD_POLICY_EMPTY")
    cadence_by_name = {row["CanonicalName"].strip(): row for row in cadence_rows}
    names = [row["CanonicalName"].strip() for row in candidate_rows]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise HoldPolicyError("HOLD_POLICY_IDENTITY")
    if names != list(cadence_by_name):
        raise HoldPolicyError("HOLD_POLICY_SIGNAL_ORDER")

    compiled: list[dict[str, str]] = []
    for row in candidate_rows:
        name = row["CanonicalName"].strip()
        source = cadence_by_name[name]
        schema = row["PolicySchema"].strip()
        kind = row["ValueKind"].strip().upper()
        role = row["SignalRole"].strip().upper()
        required = row["Required"].strip()
        method = row["HoldPolicy"].strip().upper()
        status = row["PolicyStatus"].strip().upper()
        basis = row["PolicyBasis"].strip()
        requested_age = row["MaxAgeFrames"].strip()
        if schema != POLICY_SCHEMA:
            raise HoldPolicyError(f"POLICY_SCHEMA:{name}")
        if kind != source["ValueKind"].strip().upper() or role != source["SignalRole"].strip().upper():
            raise HoldPolicyError(f"POLICY_SEMANTIC_DRIFT:{name}")
        if required != source["Required"].strip():
            raise HoldPolicyError(f"POLICY_REQUIRED_DRIFT:{name}")
        if [row["ObservedGapQ95"].strip(), row["ObservedGapQ99"].strip(), row["ObservedGapMax"].strip()] != [
            source["InterUpdateGapQ95"].strip(), source["InterUpdateGapQ99"].strip(), source["InterUpdateGapMax"].strip()
        ]:
            raise HoldPolicyError(f"POLICY_CADENCE_DRIFT:{name}")
        if status != "APPROVED":
            raise HoldPolicyError(f"POLICY_NOT_APPROVED:{name}")
        if method not in ALLOWED_POLICIES or method == "UNDECIDED":
            raise HoldPolicyError(f"POLICY_METHOD:{name}:{method}")
        if not basis:
            raise HoldPolicyError(f"POLICY_BASIS:{name}")
        if role == "EVENT_FLAG" and method != "NONE":
            raise HoldPolicyError(f"EVENT_FLAG_HOLD:{name}")

        if method == "NONE":
            if requested_age not in {"", "0"}:
                raise HoldPolicyError(f"NONE_MAX_AGE:{name}:{requested_age}")
            effective_age = 0
        else:
            try:
                parsed = parse_integer(requested_age, f"MAX_AGE_{name}", minimum=0)
            except H4BContractError as exc:
                raise HoldPolicyError(f"BOUNDED_MAX_AGE:{name}:{requested_age}") from exc
            if parsed is None:
                raise HoldPolicyError(f"BOUNDED_MAX_AGE:{name}:BLANK")
            effective_age = parsed
        compiled.append(
            {
                "PolicySchema": POLICY_SCHEMA,
                "CanonicalName": name,
                "ValueKind": kind,
                "SignalRole": role,
                "Required": required,
                "HoldPolicy": method,
                "MaxAgeFrames": str(effective_age),
                "PolicyBasis": basis,
                "PolicyStatus": "APPROVED",
                "ObservedGapQ95": row["ObservedGapQ95"].strip(),
                "ObservedGapQ99": row["ObservedGapQ99"].strip(),
                "ObservedGapMax": row["ObservedGapMax"].strip(),
                "Notes": row.get("Notes", "").strip(),
            }
        )
    return compiled


def compile_policy(cadence_package: Path, candidate_path: Path, output_dir: Path) -> dict[str, Any]:
    manifest, cadence_rows = validate_cadence_package(cadence_package)
    require_empty_output(output_dir)
    candidate_rows = _read_csv(candidate_path, POLICY_COLUMNS, "HOLD_POLICY")
    compiled = _compile_rows(candidate_rows, cadence_rows)
    output_path = output_dir / COMPILED_FILE
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(compiled)
    bounded = sum(row["HoldPolicy"] == "HOLD_LAST_BOUNDED" for row in compiled)
    none = len(compiled) - bounded
    quality = {
        "QualitySchema": "U001_H4B_HOLD_POLICY_QUALITY_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "CadenceManifestSHA256": sha256_file(cadence_package / CADENCE_MANIFEST_FILE),
        "InputH4AManifestSHA256": manifest.get("InputH4AManifestSHA256"),
        "FramePolicySHA256": manifest.get("FramePolicySHA256"),
        "CandidatePolicySHA256": sha256_file(candidate_path),
        "CompiledPolicySHA256": sha256_file(output_path),
        "PolicyRowCount": len(compiled),
        "BoundedHoldSignalCount": bounded,
        "NoHoldSignalCount": none,
        "UnapprovedPolicyCount": 0,
        "BlankCompiledMaxAgeCount": 0,
        "Status": "COMPILED",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / QUALITY_FILE, quality)
    (output_dir / CAPSULE_FILE).write_text(
        f"U1H4BH-N{len(compiled)}-B{bounded}-O{none}-X0-C0\n",
        encoding="utf-8",
    )
    return quality


def _cadence_rows() -> list[dict[str, str]]:
    base = {column: "" for column in PROFILE_COLUMNS}
    rows = []
    for name, kind, role, required in (
        ("DIST", "FLOAT", "MEASUREMENT", "1"),
        ("STATE", "INTEGER", "STATE", "0"),
        ("FLAG", "BOOLEAN", "EVENT_FLAG", "0"),
    ):
        row = dict(base)
        row.update({
            "ProfileSchema": PROFILE_SCHEMA,
            "CanonicalName": name,
            "ValueKind": kind,
            "SignalRole": role,
            "Required": required,
            "InterUpdateGapQ95": "2",
            "InterUpdateGapQ99": "3",
            "InterUpdateGapMax": "5",
        })
        rows.append(row)
    return rows


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    cadence = _cadence_rows()
    template = proposal_rows(cadence)
    check(len(template) == 3, "T01_DYNAMIC_TEMPLATE")
    check(all(row["HoldPolicy"] == "UNDECIDED" for row in template), "T02_NO_AUTO_POLICY")
    check(all(row["PolicyStatus"] == "PROVISIONAL" for row in template), "T03_NO_AUTO_APPROVAL")

    approved = [dict(row) for row in template]
    approved[0].update({"HoldPolicy": "HOLD_LAST_BOUNDED", "MaxAgeFrames": "3", "PolicyBasis": "Approved from cadence and semantics", "PolicyStatus": "APPROVED"})
    approved[1].update({"HoldPolicy": "NONE", "MaxAgeFrames": "", "PolicyBasis": "Current update required", "PolicyStatus": "APPROVED"})
    approved[2].update({"HoldPolicy": "NONE", "MaxAgeFrames": "", "PolicyBasis": "Event flags are never held", "PolicyStatus": "APPROVED"})
    compiled = _compile_rows(approved, cadence)
    check(compiled[0]["MaxAgeFrames"] == "3", "T04_BOUNDED_INTEGER")
    check(compiled[1]["MaxAgeFrames"] == "0", "T05_NONE_BLANK_TO_ZERO")
    check(compiled[2]["HoldPolicy"] == "NONE", "T06_EVENT_NONE")

    def rejected(mutator: Any, token: str) -> bool:
        rows = [dict(row) for row in approved]
        mutator(rows)
        try:
            _compile_rows(rows, cadence)
        except HoldPolicyError as exc:
            return token in str(exc)
        return False

    check(rejected(lambda rows: rows[0].update(PolicyStatus="PROVISIONAL"), "NOT_APPROVED"), "T07_UNAPPROVED")
    check(rejected(lambda rows: rows[0].update(HoldPolicy="UNDECIDED"), "METHOD"), "T08_UNDECIDED")
    check(rejected(lambda rows: rows[0].update(MaxAgeFrames=""), "BOUNDED_MAX_AGE"), "T09_BOUNDED_BLANK")
    check(rejected(lambda rows: rows[0].update(MaxAgeFrames="-1"), "BOUNDED_MAX_AGE"), "T10_BOUNDED_NEGATIVE")
    check(rejected(lambda rows: rows[0].update(MaxAgeFrames="1.5"), "BOUNDED_MAX_AGE"), "T11_BOUNDED_FRACTION")
    check(rejected(lambda rows: rows[0].update(MaxAgeFrames="infinite"), "BOUNDED_MAX_AGE"), "T12_BOUNDED_UNBOUNDED_TEXT")
    check(rejected(lambda rows: rows[1].update(MaxAgeFrames="2"), "NONE_MAX_AGE"), "T13_NONE_NONZERO")
    check(rejected(lambda rows: rows[2].update(HoldPolicy="HOLD_LAST_BOUNDED", MaxAgeFrames="1"), "EVENT_FLAG_HOLD"), "T14_EVENT_HOLD")
    check(rejected(lambda rows: rows[0].update(PolicyBasis=""), "POLICY_BASIS"), "T15_BASIS_REQUIRED")
    check(rejected(lambda rows: rows[0].update(ValueKind="INTEGER"), "SEMANTIC_DRIFT"), "T16_SEMANTIC_DRIFT")
    check(rejected(lambda rows: rows[0].update(ObservedGapQ95="9"), "CADENCE_DRIFT"), "T17_CADENCE_DRIFT")
    check(rejected(lambda rows: rows.append(dict(rows[0])), "IDENTITY"), "T18_DUPLICATE")
    zero = [dict(row) for row in approved]
    zero[0]["MaxAgeFrames"] = "0"
    check(_compile_rows(zero, cadence)[0]["MaxAgeFrames"] == "0", "T19_ZERO_BOUND")
    none_zero = [dict(row) for row in approved]
    none_zero[1]["MaxAgeFrames"] = "0"
    check(_compile_rows(none_zero, cadence)[1]["MaxAgeFrames"] == "0", "T20_NONE_EXPLICIT_ZERO")
    check(PROGRAM_VERSION == "1.0.0", "T21_VERSION")
    if checks != 21:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4B-HOLD-POLICY-SELFTEST-PASS-21")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="U001 H4B hold-policy compiler")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--make-template", action="store_true")
    action.add_argument("--compile", action="store_true")
    parser.add_argument("--cadence-package", type=Path)
    parser.add_argument("--policy", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.cadence_package is None or args.out is None:
            raise HoldPolicyError("ARGUMENTS")
        if args.make_template:
            count = write_template(args.cadence_package, args.out)
            print(f"U1H4BHT-N{count}-X0-C0")
            return 0
        if args.policy is None:
            raise HoldPolicyError("POLICY_ARGUMENT")
        quality = compile_policy(args.cadence_package, args.policy, args.out)
        print(
            f"U1H4BH-N{quality['PolicyRowCount']}-B{quality['BoundedHoldSignalCount']}-"
            f"O{quality['NoHoldSignalCount']}-X0-C0"
        )
        return 0
    except Exception as exc:
        detail = " ".join(str(exc).split())[-320:] or "NO_DETAIL"
        print(f"U1H4BHE-K{type(exc).__name__.upper()}-D{detail}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
