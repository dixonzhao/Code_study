#!/usr/bin/env python3
"""Independent black-box acceptance for U001 H4B cadence and bounded hold."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_h4b_bounded_hold_acceptance"
PROGRAM_VERSION = "1.0.0"


class H4BAcceptanceError(RuntimeError):
    """Independent H4B acceptance error."""


def _load(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise H4BAcceptanceError(f"IMPORT_SPEC:{path.name}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _signal(
    name: str,
    *,
    value: str = "",
    label: str = "",
    updated: int = 0,
    valid: int = 0,
    reason: str = "NO_UPDATE",
) -> dict[str, str]:
    return {
        name + "__value": value,
        name + "__label": label,
        name + "__updated": str(updated),
        name + "__update_count": "1" if updated else "0",
        name + "__age": "0" if updated else "",
        name + "__valid": str(valid),
        name + "__missing_reason": reason,
    }


def _write_h4a_fixture(root: Path, contract: Any, h4_policy: Any) -> tuple[Path, Path]:
    package = root / "h4a"
    package.mkdir(parents=True)
    frame_policy = root / "u001_h4_compiled_frame_policy.csv"
    policy_rows = [
        {"PolicySchema": h4_policy.POLICY_SCHEMA, "CanonicalName": "FRAME", "ValueKind": "INTEGER", "SignalRole": "FRAME_KEY", "IncludeInFrameView": "0", "WithinFramePolicy": "KEEP_STREAM_ONLY", "Required": "1", "PolicyStatus": "APPROVED", "Notes": ""},
        {"PolicySchema": h4_policy.POLICY_SCHEMA, "CanonicalName": "DIST", "ValueKind": "FLOAT", "SignalRole": "MEASUREMENT", "IncludeInFrameView": "1", "WithinFramePolicy": "LAST_UPDATE", "Required": "1", "PolicyStatus": "APPROVED", "Notes": ""},
        {"PolicySchema": h4_policy.POLICY_SCHEMA, "CanonicalName": "STATE", "ValueKind": "INTEGER", "SignalRole": "STATE", "IncludeInFrameView": "1", "WithinFramePolicy": "LAST_UPDATE", "Required": "0", "PolicyStatus": "APPROVED", "Notes": ""},
        {"PolicySchema": h4_policy.POLICY_SCHEMA, "CanonicalName": "FLAG", "ValueKind": "BOOLEAN", "SignalRole": "EVENT_FLAG", "IncludeInFrameView": "1", "WithinFramePolicy": "ANY_TRUE", "Required": "0", "PolicyStatus": "APPROVED", "Notes": ""},
    ]
    with frame_policy.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=h4_policy.POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(policy_rows)

    frames = [100, 101, 103, 104, 108, 109, 110, 114]
    rows: list[dict[str, str]] = []
    for index, frame in enumerate(frames):
        row = {
            "FrameCount": str(frame),
            "SourceRowFirst": str(index),
            "SourceRowLast": str(index),
            "SourceUpdateCount": "1",
        }
        row.update(_signal("DIST"))
        row.update(_signal("STATE"))
        row.update(_signal("FLAG"))
        rows.append(row)
    rows[1].update(_signal("DIST", value="10", updated=1, valid=1, reason="VALID_UPDATE"))
    rows[3].update(_signal("DIST", value="327.66", updated=1, valid=0, reason="USER_INVALID_RULE"))
    rows[5].update(_signal("DIST", value="0", updated=1, valid=1, reason="VALID_UPDATE"))

    rows[0].update(_signal("STATE", value="1", updated=1, valid=1, reason="VALID_UPDATE"))
    rows[3].update(_signal("STATE", value="2", updated=1, valid=1, reason="VALID_UPDATE"))
    rows[6].update(_signal("STATE", value="99", updated=1, valid=0, reason="USER_INVALID_RULE"))

    rows[0].update(_signal("FLAG", value="1", label="true", updated=1, valid=1, reason="VALID_UPDATE"))
    rows[2].update(_signal("FLAG", value="0", label="false", updated=1, valid=1, reason="VALID_UPDATE"))

    fieldnames = list(rows[0])
    frame_path = package / contract.H4A_FRAME_FILE
    with frame_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    quality = {
        "QualitySchema": "U001_H4_RAW_FRAME_QUALITY_V1_0",
        "OutputBoundary": contract.H4A_OUTPUT_BOUNDARY,
        "RawFrameViewSHA256": contract.sha256_file(frame_path),
        "OutputFrameRowCount": len(rows),
        "IncludedSignalCount": 3,
        "CrossFrameHeldCellCount": 0,
        "ZeroFillCount": 0,
        "SyntheticFrameCount": 0,
        "WholeFileMemoryLoadRequired": False,
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    contract.write_json(package / contract.H4A_QUALITY_FILE, quality)
    artifacts = []
    for name in (contract.H4A_FRAME_FILE, contract.H4A_QUALITY_FILE):
        path = package / name
        artifacts.append({"FileName": name, "SizeBytes": path.stat().st_size, "SHA256": contract.sha256_file(path)})
    manifest = {
        "ManifestSchema": contract.H4A_MANIFEST_SCHEMA,
        "OutputBoundary": contract.H4A_OUTPUT_BOUNDARY,
        "DatasetId": "SYNTHETIC_DATASET",
        "RunId": "SYNTHETIC_RUN",
        "SegmentId": "SYNTHETIC_SEGMENT",
        "FramePolicySHA256": contract.sha256_file(frame_policy),
        "Artifacts": artifacts,
        "Counts": {"InputUpdateRows": 8, "OutputFrames": len(rows), "IncludedSignals": 3},
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    contract.write_json(package / contract.H4A_MANIFEST_FILE, manifest)
    (package / contract.H4A_CAPSULE_FILE).write_text("U1H4A-R8-F8-I3-G6-H0-Z0-X0-C0\n", encoding="utf-8")
    return package, frame_policy


def _approve_policy(template: Path, output: Path) -> None:
    rows = _read_csv(template)
    decisions = {
        "DIST": ("HOLD_LAST_BOUNDED", "3", "Measurement cadence and invalid barrier reviewed"),
        "STATE": ("HOLD_LAST_BOUNDED", "2", "State persistence explicitly approved"),
        "FLAG": ("NONE", "", "Event flag requires a current update"),
    }
    for row in rows:
        method, age, basis = decisions[row["CanonicalName"]]
        row["HoldPolicy"] = method
        row["MaxAgeFrames"] = age
        row["PolicyBasis"] = basis
        row["PolicyStatus"] = "APPROVED"
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate(
    core_dir: Path,
    output_root: Path,
    foundation_core_dir: Path | None = None,
) -> dict[str, Any]:
    foundation_core_dir = foundation_core_dir or core_dir
    required = [
        "u001_h4b_contract_core_v1_0.py",
        "u001_h4b_cadence_profiler_v1_0.py",
        "u001_h4b_hold_policy_compiler_v1_0.py",
        "u001_h4b_bounded_hold_engine_v1_0.py",
        "u001_h4_frame_policy_compiler_v1_0.py",
    ]
    missing = [name for name in required[:4] if not (core_dir / name).is_file()]
    if not (foundation_core_dir / required[4]).is_file():
        missing.append(required[4])
    if missing:
        raise H4BAcceptanceError(f"PROGRAM_FILESET:{missing}")
    for import_root in (foundation_core_dir.resolve(), core_dir.resolve()):
        if str(import_root) not in sys.path:
            sys.path.insert(0, str(import_root))
    contract = _load(core_dir / required[0], "u1h4b_accept_contract")
    profiler = _load(core_dir / required[1], "u1h4b_accept_profiler")
    compiler = _load(core_dir / required[2], "u1h4b_accept_compiler")
    engine = _load(core_dir / required[3], "u1h4b_accept_engine")
    h4_policy = _load(foundation_core_dir / required[4], "u1h4b_accept_h4_policy")

    output_root.mkdir(parents=True, exist_ok=False)
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise H4BAcceptanceError(label)
        checks += 1

    contract.self_test(); profiler.self_test(); compiler.self_test(); engine.self_test()
    check(True, "T01_COMPONENT_SELFTESTS")
    h4a, frame_policy = _write_h4a_fixture(output_root / "fixture", contract, h4_policy)
    source_hash = contract.sha256_file(h4a / contract.H4A_FRAME_FILE)
    manifest = contract.validate_h4a_package(h4a)
    check(manifest["Counts"]["OutputFrames"] == 8, "T02_H4A_BOUNDARY")

    cadence = output_root / "cadence"
    cadence_quality = profiler.profile_cadence(h4a, frame_policy, cadence)
    check(cadence_quality["InputFrameCount"] == 8, "T03_CADENCE_FRAMES")
    check(cadence_quality["SignalCount"] == 3, "T04_CADENCE_SIGNALS")
    check(cadence_quality["MissingFrameCount"] == 7, "T05_REAL_FRAME_GAPS")
    cadence_rows = {row["CanonicalName"]: row for row in _read_csv(cadence / profiler.PROFILE_FILE)}
    check(cadence_rows["DIST"]["InterUpdateGapQ50"] == "3", "T06_DIST_Q50")
    check(cadence_rows["DIST"]["InterUpdateGapQ95"] == "5", "T07_DIST_Q95")
    check(cadence_rows["FLAG"]["InterUpdateGapMax"] == "3", "T08_FLAG_GAP")
    check(cadence_quality["HeldCellCount"] == 0 and cadence_quality["ZeroFillCount"] == 0, "T09_PROFILE_READ_ONLY")

    template = output_root / "hold_policy_template.csv"
    check(compiler.write_template(cadence, template) == 3, "T10_TEMPLATE_COUNT")
    template_rows = _read_csv(template)
    check(all(row["HoldPolicy"] == "UNDECIDED" for row in template_rows), "T11_TEMPLATE_NEUTRAL")
    check(all(row["PolicyStatus"] == "PROVISIONAL" for row in template_rows), "T12_TEMPLATE_PROVISIONAL")
    approved = output_root / "approved_hold_policy.csv"
    _approve_policy(template, approved)
    policy_package = output_root / "compiled_policy"
    policy_quality = compiler.compile_policy(cadence, approved, policy_package)
    check(policy_quality["BoundedHoldSignalCount"] == 2, "T13_BOUNDED_COUNT")
    check(policy_quality["NoHoldSignalCount"] == 1, "T14_NONE_COUNT")
    compiled_rows = {row["CanonicalName"]: row for row in _read_csv(policy_package / compiler.COMPILED_FILE)}
    check(compiled_rows["FLAG"]["MaxAgeFrames"] == "0", "T15_NONE_COMPILED_INTEGER")

    run_a = output_root / "run_a"
    quality = engine.apply_bounded_hold(h4a, policy_package, run_a)
    check(quality["OutputFrameCount"] == 8 and quality["SignalCount"] == 3, "T16_OUTPUT_COUNTS")
    output_rows = {row["FrameCount"]: row for row in _read_csv(run_a / engine.OUTPUT_FRAME_VIEW)}
    check(output_rows["103"]["DIST__value"] == "10" and output_rows["103"]["DIST__age"] == "2", "T17_DIST_CARRIED")
    check(output_rows["104"]["DIST__value"] == "327.66" and output_rows["104"]["DIST__valid"] == "0", "T18_INVALID_PRESERVED")
    check(output_rows["108"]["DIST__missing_reason"] == "INVALID_UPDATE_BARRIER", "T19_DIST_BARRIER")
    check(output_rows["109"]["DIST__value"] == "0" and output_rows["109"]["DIST__valid"] == "1", "T20_TRUE_ZERO")
    check(output_rows["110"]["DIST__value"] == "0" and output_rows["110"]["DIST__age"] == "1", "T21_ZERO_CARRIED")
    check(output_rows["114"]["DIST__missing_reason"] == "STALE" and output_rows["114"]["DIST__age"] == "5", "T22_DIST_STALE")
    check(output_rows["101"]["STATE__value"] == "1" and output_rows["101"]["STATE__age"] == "1", "T23_STATE_CARRY")
    check(output_rows["103"]["STATE__missing_reason"] == "STALE", "T24_STATE_STALE")
    check(output_rows["114"]["STATE__missing_reason"] == "INVALID_UPDATE_BARRIER", "T25_STATE_BARRIER")
    raw_rows = {row["FrameCount"]: row for row in _read_csv(h4a / contract.H4A_FRAME_FILE)}
    check(all(output_rows[frame]["FLAG__value"] == raw_rows[frame]["FLAG__value"] for frame in output_rows), "T26_EVENT_NONE_VALUE")
    check(all(output_rows[frame]["FLAG__age"] == raw_rows[frame]["FLAG__age"] for frame in output_rows), "T27_EVENT_NONE_AGE")
    check(quality["CurrentUpdateProvenanceChangeCount"] == 0, "T28_PROVENANCE")
    check(quality["SyntheticFrameCount"] == 0 and quality["SyntheticZeroFillCount"] == 0, "T29_NO_SYNTHETIC")
    check(source_hash == contract.sha256_file(h4a / contract.H4A_FRAME_FILE), "T30_INPUT_IMMUTABLE")

    run_b = output_root / "run_b"
    engine.apply_bounded_hold(h4a, policy_package, run_b)
    check(contract.sha256_file(run_a / engine.OUTPUT_FRAME_VIEW) == contract.sha256_file(run_b / engine.OUTPUT_FRAME_VIEW), "T31_DETERMINISTIC")
    check(quality["WholeFileMemoryLoadRequired"] is False and quality["StatefulParallelExecutionAllowed"] is False, "T32_RESOURCE_MODEL")

    provisional = output_root / "provisional.csv"
    with provisional.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=compiler.POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader(); writer.writerows(template_rows)
    try:
        compiler.compile_policy(cadence, provisional, output_root / "provisional_compile")
    except Exception as exc:
        check("NOT_APPROVED" in str(exc) or "METHOD" in str(exc), "T33_PROVISIONAL_BLOCK")
    else:
        raise H4BAcceptanceError("T33_PROVISIONAL_BLOCK")

    event_hold_rows = _read_csv(approved)
    for row in event_hold_rows:
        if row["CanonicalName"] == "FLAG":
            row["HoldPolicy"] = "HOLD_LAST_BOUNDED"; row["MaxAgeFrames"] = "1"
    event_hold = output_root / "event_hold.csv"
    with event_hold.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=compiler.POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader(); writer.writerows(event_hold_rows)
    try:
        compiler.compile_policy(cadence, event_hold, output_root / "event_hold_compile")
    except Exception as exc:
        check("EVENT_FLAG_HOLD" in str(exc), "T34_EVENT_HOLD_BLOCK")
    else:
        raise H4BAcceptanceError("T34_EVENT_HOLD_BLOCK")

    tampered = output_root / "tampered_h4a"
    shutil.copytree(h4a, tampered)
    with (tampered / contract.H4A_FRAME_FILE).open("a", encoding="utf-8") as stream:
        stream.write("\n")
    try:
        profiler.profile_cadence(tampered, frame_policy, output_root / "tampered_profile")
    except Exception as exc:
        check("IDENTITY" in str(exc), "T35_H4A_TAMPER_BLOCK")
    else:
        raise H4BAcceptanceError("T35_H4A_TAMPER_BLOCK")
    output_manifest = json.loads((run_a / engine.OUTPUT_MANIFEST).read_text(encoding="utf-8"))
    check(output_manifest["InputH4AManifestSHA256"] == contract.sha256_file(h4a / contract.H4A_MANIFEST_FILE), "T36_IDENTITY_CHAIN")

    if checks != 36:
        raise H4BAcceptanceError(f"CHECK_COUNT:{checks}")
    receipt = {
        "AcceptanceSchema": "U001_H4B_BOUNDED_HOLD_ACCEPTANCE_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "CheckCount": checks,
        "FrameCount": quality["OutputFrameCount"],
        "SignalCount": quality["SignalCount"],
        "CarriedCellCount": quality["CarriedCellCount"],
        "StaleCellCount": quality["StaleCellCount"],
        "HoldBarrierCellCount": quality["HoldBarrierCellCount"],
        "Status": "PASS",
        "CompletionCode": 0,
    }
    (output_root / "u001_h4b_acceptance_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    (output_root / "u001_h4b_acceptance_capsule.txt").write_text(
        f"U1H4BQ-T{checks}-F{receipt['FrameCount']}-S{receipt['SignalCount']}-X0-C0\n",
        encoding="utf-8",
    )
    return receipt


def self_test() -> None:
    root = Path(__file__).resolve().parents[2]
    with tempfile.TemporaryDirectory(prefix="u1h4b_accept_") as temporary:
        receipt = validate(root / "01_PROGRAMS" / "core", Path(temporary) / "acceptance")
        if receipt["Status"] != "PASS" or receipt["CheckCount"] != 36:
            raise AssertionError("ACCEPTANCE_RECEIPT")
    print("U001-H4B-ACCEPTANCE-SELFTEST-PASS-36")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="U001 H4B independent acceptance")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--validate", action="store_true")
    parser.add_argument("--core-dir", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--foundation-core-dir", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.core_dir is None or args.out is None:
            raise H4BAcceptanceError("ARGUMENTS")
        receipt = validate(args.core_dir, args.out, args.foundation_core_dir)
        print(f"U1H4BQ-T{receipt['CheckCount']}-F{receipt['FrameCount']}-S{receipt['SignalCount']}-X0-C0")
        return 0
    except Exception as exc:
        detail = " ".join(str(exc).split())[-320:] or "NO_DETAIL"
        print(f"U1H4BQE-K{type(exc).__name__.upper()}-D{detail}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
