#!/usr/bin/env python3
"""Self-test the U001 H5 compatible S0 intake Module."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
from pathlib import Path
import tempfile


def load_implementation(module_root: Path):
    path = module_root / "implementation.py"
    spec = importlib.util.spec_from_file_location("u002_s0_h5_impl", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("IMPLEMENTATION_LOAD")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, header: list[str], rows: list[list[object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def create_h5_package(root: Path, module) -> None:
    root.mkdir()
    d1_rows = []
    for index, (source, source_type, name, value, can_id) in enumerate(
        (
            ("CAN_BUS_A", "CAN", "CAN_RADAR_DISTANCE", "20.0", "0x380"),
            ("GNSS_A", "GNSS", "GNSS_SPEED", "5.0", ""),
        )
    ):
        row = {column: "" for column in module.D1_REQUIRED}
        row.update(
            {
                "SourceRowIndex": str(index),
                "SourceId": source,
                "SourceType": source_type,
                "SourceAdapterId": "TEST_ADAPTER",
                "SourceAdapterVersion": "1.0",
                "ClockDomain": "CAMERA_FRAME",
                "NativeSequence": str(index),
                "FrameCount": "100",
                "SyncKey": "100",
                "SyncQuality": "EXACT",
                "FrameAssignmentStatus": "EXACT",
                "FrameAssignmentAgeRows": "0",
                "CAN_ID": can_id,
                "Channel": "1" if can_id else "",
                "MessageName": name,
                "SignalName": name,
                "CanonicalName": name,
                "RawCode": str(index),
                "PhysicalValue": value,
                "Unit": "m" if "DISTANCE" in name else "m/s",
                "ValueKind": "FLOAT",
                "SignalRole": "MEASUREMENT",
                "UpdateMode": "ASYNCHRONOUS",
                "StorageDtype": "float64",
                "PolicyStatus": "APPROVED",
                "ValidityRule": "NONE",
                "DecodeValid": "1",
                "IntrinsicValid": "1",
                "Valid": "1",
                "MissingReason": "VALID_UPDATE",
            }
        )
        d1_rows.append([row[column] for column in module.D1_REQUIRED])
    write_csv(root / module.PACKAGE_NAMES[0], list(module.D1_REQUIRED), d1_rows)

    groups = ["CAN_RADAR_DISTANCE", "GNSS_SPEED"]
    d2_header = list(module.D2_LEADING)
    for group in groups:
        d2_header.extend(group + suffix for suffix in module.D2_SUFFIXES)
    d2_rows = []
    for frame, radar, speed in ((100, "20.0", "5.0"), (101, "21.0", "5.1")):
        row: list[object] = [frame, 0, 1, 2]
        for value in (radar, speed):
            row.extend([value, "", 1, 1, 0, 1, "VALID_UPDATE"])
        d2_rows.append(row)
    write_csv(root / module.PACKAGE_NAMES[1], d2_header, d2_rows)

    catalog_rows = []
    for name, source, source_type, can_id, unit in (
        ("CAN_RADAR_DISTANCE", "CAN_BUS_A", "CAN", "0x380", "m"),
        ("GNSS_SPEED", "GNSS_A", "GNSS", "", "m/s"),
    ):
        row = {column: "" for column in module.D3_COLUMNS}
        row.update(
            {
                "CanonicalName": name,
                "CAN_ID": can_id,
                "Channel": "1" if can_id else "",
                "MessageName": name,
                "SignalName": name,
                "Unit": unit,
                "ValueKind": "FLOAT",
                "SignalRole": "MEASUREMENT",
                "UpdateMode": "ASYNCHRONOUS",
                "StorageDtype": "float64",
                "ValidityRule": "NONE",
                "WithinFramePolicy": "LAST_UPDATE",
                "HoldPolicy": "NONE",
                "RequiredForAnalysis": "1",
                "IncludeInFrameView": "1",
                "IncludeInReviewView": "1",
                "SourceType": source_type,
                "SourceAdapter": "TEST_ADAPTER",
                "OriginalUnit": unit,
                "CanonicalUnit": unit,
                "SourceId": source,
                "SourceChannel": "1" if can_id else "",
                "SourceMessageId": can_id,
                "PolicyStatus": "APPROVED",
                "PolicyBasis": "SELFTEST",
            }
        )
        catalog_rows.append([row[column] for column in module.D3_COLUMNS])
    write_csv(root / module.PACKAGE_NAMES[2], list(module.D3_COLUMNS), catalog_rows)

    quality_rows = [
        ["PACKAGE", "", "package_file_count", "6", "files", "H5", "OK", ""],
        ["PACKAGE", "", "package_error_count", "0", "errors", "H5", "OK", ""],
    ]
    write_csv(root / module.PACKAGE_NAMES[3], list(module.D4_COLUMNS), quality_rows)

    review_header = ["FrameCount"]
    for group in groups:
        review_header.extend(group + suffix for suffix in module.D2_SUFFIXES)
    review_indices = [d2_header.index(column) for column in review_header]
    review_rows = [[row[index] for index in review_indices] for row in d2_rows]
    write_csv(root / module.PACKAGE_NAMES[5], review_header, review_rows)

    artifact_names = [name for name in module.PACKAGE_NAMES if name != "u001_run_manifest.json"]
    manifest = {
        "ManifestSchema": module.U001_MANIFEST_SCHEMA,
        "OutputBoundary": module.U001_OUTPUT_BOUNDARY,
        "DatasetId": "SELFTEST_DATASET",
        "RunId": "SELFTEST_U001_H5",
        "SegmentId": "SEGMENT_A",
        "SourceSetMode": "MULTI_SOURCE_SYNCHRONIZED",
        "SourceRegistry": [
            {
                "SourceId": "CAN_BUS_A",
                "SourceType": "CAN",
                "ClockDomain": "CAMERA_FRAME",
                "UpdateRowCount": "1",
            },
            {
                "SourceId": "GNSS_A",
                "SourceType": "GNSS",
                "ClockDomain": "CAMERA_FRAME",
                "UpdateRowCount": "1",
            },
        ],
        "FrameDomain": {
            "FrameKey": "FrameCount",
            "FrameMinimum": 100,
            "FrameMaximum": 101,
            "FrameRowCount": 2,
        },
        "Artifacts": [
            {
                "FileName": name,
                "SizeBytes": (root / name).stat().st_size,
                "SHA256": module.sha256_file(root / name),
            }
            for name in artifact_names
        ],
        "Counts": {
            "PackageFiles": 6,
            "Sources": 2,
            "Updates": 2,
            "Frames": 2,
            "FrameSignals": 2,
            "ReviewSignals": 2,
        },
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    (root / module.PACKAGE_NAMES[4]).write_bytes(module.canonical_bytes(manifest))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--module-root", required=True)
    parser.add_argument("--workspace-root", required=True)
    args = parser.parse_args()
    module_root = Path(args.module_root).resolve()
    module = load_implementation(module_root)
    checks: list[bool] = []

    def check(value: bool) -> None:
        if not value:
            raise AssertionError("SELFTEST")
        checks.append(True)

    with tempfile.TemporaryDirectory(prefix="u002_s0_h5_") as temporary:
        package = Path(temporary) / "package"
        create_h5_package(package, module)
        summary, inventory = module.inspect_package(package)
        check(summary["Status"] == "INTAKE_ACCEPTED")
        check(summary["U001Contract"] == module.U001_MANIFEST_SCHEMA)
        check(summary["FrameDomain"]["FrameRows"] == 2)
        check(summary["FrameDomain"]["FrameMin"] == 100)
        check(summary["FrameDomain"]["FrameMax"] == 101)
        check(summary["SignalCount"] == 2)
        check(summary["ReviewSignalCount"] == 2)
        check(len(summary["SourceRegistry"]) == 2)
        check(len(inventory) == 2)
        check(summary["QualityGate"]["package_error_count"] == 0)
        check(len(summary["Files"]) == 6)
        check(len(summary["PackageFingerprintSha256"]) == 64)
        original = (package / "u001_decoded_updates.csv").read_bytes()
        (package / "u001_decoded_updates.csv").write_bytes(
            original.replace(b"SourceAdapterId", b"LegacyFieldName")
        )
        try:
            module.inspect_package(package)
            raise AssertionError("LEGACY_SCHEMA_ACCEPTED")
        except module.ModuleError:
            check(True)

    check(module.MODULE_VERSION == "0.2.0")
    check(module.ARTIFACT_TYPE == "U001_INTAKE_ACCEPTED")
    check(Path(args.workspace_root).name == "U-UDP002")
    check(len(checks) == 16)
    print("U2S0H5-ST-N16-X0-C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
