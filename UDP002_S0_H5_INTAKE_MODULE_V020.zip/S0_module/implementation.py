#!/usr/bin/env python3
"""Accept one U001 H5 trusted six-file package into a U002 Run.

This S0 module is intentionally source-agnostic.  It validates the public H5
handoff boundary, not CAN/DBC internals, and emits the same governed
U001_INTAKE_ACCEPTED Artifact type consumed by existing S1 modules.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path, PurePath
import re
import sys
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple


MODULE_ID = "CameraRadar.S0.U001ControlledProfileIntake"
MODULE_VERSION = "0.2.0"
CONTRACT_VERSION = "U22.0.1"
PROTOCOL = "U002_U22_MODULE_RUNTIME"
PROTOCOL_VERSION = "0.1"
ARTIFACT_TYPE = "U001_INTAKE_ACCEPTED"
U001_MANIFEST_SCHEMA = "U001_HANDOFF_PACKAGE_V1_0"
U001_OUTPUT_BOUNDARY = "U001_TRUSTED_ANALYSIS_SOURCE_PACKAGE_V1_0"

PACKAGE_NAMES = (
    "u001_decoded_updates.csv",
    "u001_frame_values.csv",
    "u001_signal_catalog.csv",
    "u001_quality_report.csv",
    "u001_run_manifest.json",
    "u001_review_view.csv",
)

D1_REQUIRED = (
    "SourceRowIndex", "SourceId", "SourceType", "SourceAdapterId",
    "SourceAdapterVersion", "ClockDomain", "NativeTimestamp",
    "NativeSequence", "FrameCount", "SyncKey", "SyncQuality",
    "FrameAssignmentStatus", "FrameAssignmentAgeRows", "CAN_ID", "Channel",
    "MessageName", "SignalName", "CanonicalName", "RawCode", "PhysicalValue",
    "ValueLabel", "Unit", "ValueKind", "SignalRole", "UpdateMode",
    "StorageDtype", "PolicyStatus", "ValidityRule", "DecodeValid",
    "DecodeIssue", "IntrinsicValid", "IntrinsicMissingReason", "Valid",
    "MissingReason",
)
D2_LEADING = (
    "FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount",
)
D2_SUFFIXES = (
    "__value", "__label", "__updated", "__update_count", "__age",
    "__valid", "__missing_reason",
)
D3_BASE = (
    "CanonicalName", "CAN_ID", "Channel", "MessageName", "SignalName", "Unit",
    "ValueKind", "SignalRole", "UpdateMode", "StorageDtype", "StartBit",
    "BitLength", "ByteOrder", "Signed", "Scale", "Offset", "DBCMinimum",
    "DBCMaximum", "EnumerationMap", "ValidityRule", "ValiditySourceSignal",
    "ValidityExpression", "WithinFramePolicy", "HoldPolicy", "MaxAgeFrames",
    "NominalRateHz", "RequiredForAnalysis", "IncludeInFrameView",
    "IncludeInReviewView", "Notes", "SourceType", "SourceAdapter",
    "SourceFormat", "ClockDomain", "CoordinateFrame", "ReferencePoint",
    "AxisConvention", "OriginalUnit", "CanonicalUnit", "UnitConversionRule",
    "TopicName", "MessageType", "CalibrationVersion",
)
D3_PROVENANCE = (
    "SourceId", "SourceChannel", "SourceMessageId", "PolicyStatus", "PolicyBasis",
)
D3_COLUMNS = D3_BASE + D3_PROVENANCE
D4_COLUMNS = (
    "Scope", "CanonicalName", "Metric", "Value", "Unit", "SourceGate",
    "Status", "Notes",
)
INVENTORY_COLUMNS = (
    "CanonicalName", "CAN_ID", "Channel", "MessageName", "SignalName", "Unit",
    "ValueKind", "SignalRole", "UpdateMode", "StorageDtype",
    "WithinFramePolicy", "HoldPolicy", "MaxAgeFrames", "RequiredForAnalysis",
    "IncludeInFrameView", "IncludeInReviewView",
)


class ModuleError(RuntimeError):
    """One deterministic, fail-closed H5 intake rejection."""


def stable(value: object, limit: int = 100) -> str:
    text = re.sub(r"[^A-Z0-9_]+", "_", str(value).upper()).strip("_")
    return (text or "INTERNAL")[:limit]


def canonical_bytes(value: object) -> bytes:
    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    return (text + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink()


def file_state(path: Path) -> Tuple[int, int]:
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns


def read_json(path: Path, label: str) -> Dict[str, Any]:
    if not regular_file(path):
        raise ModuleError(label + "_MISSING")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise ModuleError(label + "_JSON") from exc
    if not isinstance(value, dict):
        raise ModuleError(label + "_TYPE")
    return value


def read_csv(path: Path, label: str) -> Tuple[List[str], List[Dict[str, str]]]:
    if not regular_file(path):
        raise ModuleError(label + "_MISSING")
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            header = list(reader.fieldnames or [])
            if not header or len(header) != len(set(header)):
                raise ModuleError(label + "_HEADER")
            return header, list(reader)
    except ModuleError:
        raise
    except Exception as exc:
        raise ModuleError(label + "_CSV") from exc


def parse_integer(
    value: object,
    field: str,
    *,
    allow_blank: bool = False,
    minimum: int | None = None,
) -> int | None:
    text = str(value if value is not None else "").strip()
    if allow_blank and not text:
        return None
    try:
        number = float(text)
    except ValueError as exc:
        raise ModuleError("INTEGER_" + field) from exc
    if not math.isfinite(number) or not number.is_integer():
        raise ModuleError("INTEGER_" + field)
    result = int(number)
    if minimum is not None and result < minimum:
        raise ModuleError("INTEGER_MIN_" + field)
    return result


def parse_boolean(value: object, field: str) -> bool:
    text = str(value if value is not None else "").strip().lower()
    if text in {"1", "true"}:
        return True
    if text in {"0", "false"}:
        return False
    raise ModuleError("BOOLEAN_" + field)


def is_basename(value: object) -> bool:
    text = str(value)
    path = PurePath(text)
    return bool(text) and not path.is_absolute() and len(path.parts) == 1 and text not in {".", ".."}


def path_safe_json(value: object, location: str = "ROOT") -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            path_safe_json(item, location + "." + str(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            path_safe_json(item, f"{location}[{index}]")
    elif isinstance(value, str):
        lower = value.lower()
        if re.search(r"(^|[\\/])[a-z]:[\\/]", lower) or lower.startswith(
            ("/users/", "/home/", "\\\\")
        ):
            raise ModuleError("D5_HOST_PATH")


def find_package_files(input_root: Path) -> Dict[str, Path]:
    if not input_root.is_dir() or input_root.is_symlink():
        raise ModuleError("INPUT_PACKAGE_DIRECTORY")
    observed = {path.name: path for path in input_root.iterdir() if regular_file(path)}
    if set(observed) != set(PACKAGE_NAMES):
        missing = sorted(set(PACKAGE_NAMES) - set(observed))
        extra = sorted(set(observed) - set(PACKAGE_NAMES))
        detail = (missing or extra or ["UNKNOWN"])[0]
        raise ModuleError("PACKAGE_INVENTORY_" + stable(detail))
    return {name: observed[name] for name in PACKAGE_NAMES}


def inspect_updates(path: Path) -> Tuple[int, List[Dict[str, str]]]:
    header, rows = read_csv(path, "D1")
    if header != list(D1_REQUIRED):
        missing = [name for name in D1_REQUIRED if name not in header]
        raise ModuleError("D1_HEADER_" + stable(missing[0] if missing else "ORDER"))
    if not rows:
        raise ModuleError("D1_EMPTY")
    registry: Dict[Tuple[str, str, str], int] = {}
    bindings: Dict[str, set[str]] = {}
    for row in rows:
        source_id = row["SourceId"].strip()
        source_type = row["SourceType"].strip()
        clock = row["ClockDomain"].strip()
        name = row["CanonicalName"].strip()
        if not all((source_id, source_type, clock, name)):
            raise ModuleError("D1_SOURCE_IDENTITY_BLANK")
        parse_boolean(row["DecodeValid"], "D1_DECODE_VALID")
        parse_boolean(row["IntrinsicValid"], "D1_INTRINSIC_VALID")
        parse_boolean(row["Valid"], "D1_VALID")
        key = (source_id, source_type, clock)
        registry[key] = registry.get(key, 0) + 1
        bindings.setdefault(name, set()).add(source_id)
    ambiguous = [name for name, sources in bindings.items() if len(sources) > 1]
    if ambiguous:
        raise ModuleError("D1_CANONICAL_MULTI_SOURCE_" + stable(ambiguous[0]))
    source_registry = [
        {
            "SourceId": key[0],
            "SourceType": key[1],
            "ClockDomain": key[2],
            "UpdateRowCount": str(count),
        }
        for key, count in sorted(registry.items())
    ]
    return len(rows), source_registry


def frame_groups(header: Sequence[str]) -> List[str]:
    if tuple(header[:4]) != D2_LEADING:
        raise ModuleError("D2_LEADING_COLUMNS")
    rest = list(header[4:])
    width = len(D2_SUFFIXES)
    if not rest or len(rest) % width:
        raise ModuleError("D2_SIGNAL_GROUP_WIDTH")
    groups: List[str] = []
    for offset in range(0, len(rest), width):
        columns = rest[offset : offset + width]
        if not columns[0].endswith("__value"):
            raise ModuleError("D2_SIGNAL_GROUP_START")
        name = columns[0][:-7]
        if not name or name in groups or columns != [name + suffix for suffix in D2_SUFFIXES]:
            raise ModuleError("D2_SIGNAL_GROUP_" + stable(name))
        groups.append(name)
    return groups


def inspect_frame_values(path: Path) -> Dict[str, object]:
    header, rows = read_csv(path, "D2")
    groups = frame_groups(header)
    previous = None
    first = None
    last = None
    gap_count = 0
    largest_gap = 0
    for row in rows:
        frame = parse_integer(row["FrameCount"], "FRAMECOUNT", minimum=0)
        assert frame is not None
        if previous is not None:
            if frame <= previous:
                raise ModuleError("D2_FRAME_NOT_STRICT")
            if frame - previous > 1:
                gap_count += 1
                largest_gap = max(largest_gap, frame - previous - 1)
        first = frame if first is None else first
        last = frame
        previous = frame
        for group in groups:
            updated = parse_integer(row[group + "__updated"], group + "_UPDATED", minimum=0)
            valid = parse_integer(row[group + "__valid"], group + "_VALID", minimum=0)
            count = parse_integer(row[group + "__update_count"], group + "_COUNT", minimum=0)
            age = parse_integer(
                row[group + "__age"],
                group + "_AGE",
                allow_blank=True,
                minimum=0,
            )
            if updated not in {0, 1} or valid not in {0, 1}:
                raise ModuleError("D2_FLAG_STATE_" + stable(group))
            if updated == 1 and (count is None or count < 1 or age != 0):
                raise ModuleError("D2_UPDATED_STATE_" + stable(group))
            if valid == 1 and row[group + "__value"] == "":
                raise ModuleError("D2_VALID_BLANK_" + stable(group))
            if not row[group + "__missing_reason"].strip():
                raise ModuleError("D2_MISSING_REASON_" + stable(group))
    if not rows:
        raise ModuleError("D2_EMPTY")
    return {
        "FrameRows": len(rows),
        "FrameMin": first,
        "FrameMax": last,
        "MissingFrameGapCount": gap_count,
        "LargestMissingFrameGap": largest_gap,
        "SignalGroups": groups,
    }


def inspect_catalog(path: Path, frame_signals: Sequence[str]) -> Tuple[List[Dict[str, str]], List[str]]:
    header, rows = read_csv(path, "D3")
    if header != list(D3_COLUMNS):
        missing = [name for name in D3_COLUMNS if name not in header]
        raise ModuleError("D3_HEADER_" + stable(missing[0] if missing else "ORDER"))
    if not rows:
        raise ModuleError("D3_EMPTY")
    by_name: Dict[str, Dict[str, str]] = {}
    inventory: List[Dict[str, str]] = []
    for row in rows:
        name = row["CanonicalName"].strip()
        if not name or name in by_name:
            raise ModuleError("D3_CANONICAL_IDENTITY")
        by_name[name] = row
        inventory.append({column: row.get(column, "") for column in INVENTORY_COLUMNS})
    if not set(frame_signals).issubset(by_name):
        raise ModuleError("D3_FRAME_SIGNAL_COVERAGE")
    for name in frame_signals:
        if by_name[name]["IncludeInFrameView"] != "1":
            raise ModuleError("D3_FRAME_FLAG_" + stable(name))
        if by_name[name]["HoldPolicy"] not in {"NONE", "HOLD_LAST_BOUNDED"}:
            raise ModuleError("D3_HOLD_POLICY_" + stable(name))
    review = [
        name for name, row in by_name.items()
        if row["IncludeInReviewView"] == "1"
    ]
    return inventory, review


def inspect_quality(path: Path) -> Dict[str, int]:
    header, rows = read_csv(path, "D4")
    if header != list(D4_COLUMNS) or not rows:
        raise ModuleError("D4_STRUCTURE")
    values = {(row["Scope"], row["Metric"]): row for row in rows}
    found: Dict[str, int] = {}
    for metric, expected in (("package_file_count", 6), ("package_error_count", 0)):
        row = values.get(("PACKAGE", metric))
        if row is None or row["Status"] != "OK":
            raise ModuleError("D4_PACKAGE_METRIC_" + metric)
        value = parse_integer(row["Value"], metric, minimum=0)
        if value != expected:
            raise ModuleError("D4_PACKAGE_VALUE_" + metric)
        found[metric] = int(value)
    for row in rows:
        if row["Status"] == "NOT_AVAILABLE" and row["Value"] != "":
            raise ModuleError("D4_NOT_AVAILABLE_VALUE")
    return found


def inspect_review(frame_path: Path, review_path: Path, selected: Sequence[str]) -> int:
    frame_header, frame_rows = read_csv(frame_path, "D2")
    review_header, review_rows = read_csv(review_path, "D6")
    expected = {"FrameCount"} | {
        name + suffix for name in selected for suffix in D2_SUFFIXES
    }
    if (
        not review_header
        or review_header[0] != "FrameCount"
        or set(review_header) != expected
        or len(review_header) != len(expected)
        or any(column not in frame_header for column in review_header)
        or len(frame_rows) != len(review_rows)
    ):
        raise ModuleError("D6_SHAPE")
    for source, review in zip(frame_rows, review_rows):
        if any(source[column] != review[column] for column in review_header):
            raise ModuleError("D6_VALUE_IDENTITY")
    return len(review_rows)


def inspect_manifest(
    path: Path,
    files: Mapping[str, Path],
    updates: int,
    source_registry: Sequence[Mapping[str, str]],
    frame: Mapping[str, object],
    signal_count: int,
    review_count: int,
) -> Dict[str, object]:
    manifest = read_json(path, "D5")
    if manifest.get("ManifestSchema") != U001_MANIFEST_SCHEMA:
        raise ModuleError("D5_MANIFEST_SCHEMA")
    if manifest.get("OutputBoundary") != U001_OUTPUT_BOUNDARY:
        raise ModuleError("D5_OUTPUT_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise ModuleError("D5_STATUS")
    path_safe_json(manifest)
    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list) or len(artifacts) != 5:
        raise ModuleError("D5_ARTIFACT_LIST")
    expected = set(PACKAGE_NAMES) - {"u001_run_manifest.json"}
    seen = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise ModuleError("D5_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        if not is_basename(name) or name not in expected:
            raise ModuleError("D5_ARTIFACT_NAME")
        artifact = files[name]
        if item.get("SizeBytes") != artifact.stat().st_size or item.get("SHA256") != sha256_file(artifact):
            raise ModuleError("D5_ARTIFACT_IDENTITY_" + stable(name))
        seen.add(name)
    if seen != expected:
        raise ModuleError("D5_ARTIFACT_INVENTORY")
    expected_counts = {
        "PackageFiles": 6,
        "Sources": len(source_registry),
        "Updates": updates,
        "Frames": frame["FrameRows"],
        "FrameSignals": signal_count,
        "ReviewSignals": review_count,
    }
    if manifest.get("Counts") != expected_counts:
        raise ModuleError("D5_COUNTS")
    if manifest.get("SourceRegistry") != list(source_registry):
        raise ModuleError("D5_SOURCE_REGISTRY")
    expected_mode = "SINGLE_SOURCE" if len(source_registry) == 1 else "MULTI_SOURCE_SYNCHRONIZED"
    if manifest.get("SourceSetMode") != expected_mode:
        raise ModuleError("D5_SOURCE_SET_MODE")
    expected_domain = {
        "FrameKey": "FrameCount",
        "FrameMinimum": frame["FrameMin"],
        "FrameMaximum": frame["FrameMax"],
        "FrameRowCount": frame["FrameRows"],
    }
    if manifest.get("FrameDomain") != expected_domain:
        raise ModuleError("D5_FRAME_DOMAIN")
    return manifest


def package_records(files: Mapping[str, Path]) -> Tuple[List[Dict[str, object]], Dict[str, Tuple[int, int]]]:
    records = []
    states: Dict[str, Tuple[int, int]] = {}
    for name in PACKAGE_NAMES:
        path = files[name]
        states[name] = file_state(path)
        records.append({"Basename": name, "Bytes": path.stat().st_size, "Sha256": sha256_file(path)})
    return records, states


def package_fingerprint(records: Sequence[Mapping[str, object]]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: str(item["Basename"])):
        digest.update(str(record["Basename"]).encode("utf-8"))
        digest.update(str(record["Sha256"]).encode("ascii"))
        digest.update(str(record["Bytes"]).encode("ascii"))
    return digest.hexdigest()


def inspect_package(input_root: Path) -> Tuple[Dict[str, object], List[Dict[str, str]]]:
    files = find_package_files(input_root)
    records, states = package_records(files)
    updates, source_registry = inspect_updates(files[PACKAGE_NAMES[0]])
    frame = inspect_frame_values(files[PACKAGE_NAMES[1]])
    inventory, review_signals = inspect_catalog(files[PACKAGE_NAMES[2]], frame["SignalGroups"])
    quality = inspect_quality(files[PACKAGE_NAMES[3]])
    review_rows = inspect_review(files[PACKAGE_NAMES[1]], files[PACKAGE_NAMES[5]], review_signals)
    manifest = inspect_manifest(
        files[PACKAGE_NAMES[4]], files, updates, source_registry, frame,
        len(frame["SignalGroups"]), len(review_signals),
    )
    for name, state in states.items():
        if file_state(files[name]) != state:
            raise ModuleError("INPUT_CHANGED_" + stable(name))
    summary: Dict[str, object] = {
        "Interface": U001_OUTPUT_BOUNDARY,
        "InterfaceVersion": "1.0",
        "U001Contract": U001_MANIFEST_SCHEMA,
        "InputPackageBasename": input_root.name,
        "PackageFingerprintSha256": package_fingerprint(records),
        "Files": records,
        "FrameDomain": frame,
        "SignalCount": len(inventory),
        "ReviewSignalCount": len(review_signals),
        "ReviewRows": review_rows,
        "SourceRegistry": source_registry,
        "QualityGate": quality,
        "U001ManifestIdentity": {
            key: manifest.get(key)
            for key in ("DatasetId", "RunId", "SegmentId", "SourceSetMode", "Status")
        },
        "Status": "INTAKE_ACCEPTED",
        "Warnings": list(manifest.get("Warnings", [])),
        "Prohibitions": [
            "Radar is not asserted as ground truth",
            "No target selection was performed",
            "No missing value was converted to zero",
            "No discrepancy, baseline, evidence, or candidate was calculated",
        ],
    }
    return summary, inventory


def write_inventory(path: Path, rows: Iterable[Mapping[str, str]]) -> int:
    count = 0
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=INVENTORY_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in INVENTORY_COLUMNS})
            count += 1
    return count


def validate_request(request: Mapping[str, object]) -> None:
    expected = {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Stage": "S0",
    }
    for field, value in expected.items():
        if request.get(field) != value:
            raise ModuleError("REQUEST_" + field.upper())
    if request.get("ExpectedOutputTypes") != [ARTIFACT_TYPE]:
        raise ModuleError("REQUEST_OUTPUT_TYPE")
    if request.get("InputArtifacts") != []:
        raise ModuleError("REQUEST_INPUT_ARTIFACTS")


def write_artifact_package(
    request: Mapping[str, object],
    summary: Mapping[str, object],
    inventory: Sequence[Mapping[str, str]],
) -> str:
    output_root = Path(str(request["OutputRoot"]))
    package_root = output_root / "artifact_01"
    package_root.mkdir(parents=True)
    summary_path = package_root / "u001_intake_summary.json"
    summary_path.write_bytes(canonical_bytes(summary))
    inventory_path = package_root / "u001_signal_inventory.csv"
    inventory_rows = write_inventory(inventory_path, inventory)
    artifact_id = f"{request['RunId']}.{MODULE_ID}.{request['Sequence']}"
    payloads = [
        {
            "RelativePath": summary_path.name,
            "MediaType": "application/json",
            "RowCount": None,
            "Sha256": sha256_file(summary_path),
            "ByteSize": summary_path.stat().st_size,
            "PayloadKind": "PRIMARY",
        },
        {
            "RelativePath": inventory_path.name,
            "MediaType": "text/csv",
            "RowCount": inventory_rows,
            "Sha256": sha256_file(inventory_path),
            "ByteSize": inventory_path.stat().st_size,
            "PayloadKind": "AUXILIARY",
        },
    ]
    manifest = {
        "ContractVersion": CONTRACT_VERSION,
        "ArtifactId": artifact_id,
        "ArtifactType": ARTIFACT_TYPE,
        "SchemaId": "U002_U001_H5_INTAKE_SUMMARY",
        "SchemaVersion": "1.0",
        "RunId": request["RunId"],
        "Stage": request["Stage"],
        "ProducerModuleId": MODULE_ID,
        "ProducerModuleVersion": MODULE_VERSION,
        "ParentArtifactIds": [],
        "Payloads": payloads,
        "Metadata": {
            "PackageFingerprintSha256": summary["PackageFingerprintSha256"],
            "FrameRows": summary["FrameDomain"]["FrameRows"],
            "SignalCount": summary["SignalCount"],
            "SourceCount": len(summary["SourceRegistry"]),
            "EngineeringClaim": "U001_H5_STRUCTURAL_AND_SEMANTIC_INTAKE_ONLY",
        },
    }
    (package_root / "artifact_manifest.json").write_bytes(canonical_bytes(manifest))
    return package_root.name


def runtime_result(
    request: Mapping[str, object],
    package_name: str,
    summary: Mapping[str, object],
) -> Dict[str, object]:
    return {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "RunId": request["RunId"],
        "Sequence": request["Sequence"],
        "Stage": request["Stage"],
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Status": "SUCCEEDED",
        "ProducedPackages": [package_name],
        "Capsule": (
            f"U2S0H5-NF{summary['FrameDomain']['FrameRows']}"
            f"-K{summary['SignalCount']}-R{summary['ReviewSignalCount']}"
            f"-S{len(summary['SourceRegistry'])}-X0-C-0"
        ),
        "Diagnostics": [],
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request-json", required=True)
    parser.add_argument("--result-json", required=True)
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        request = read_json(Path(args.request_json), "REQUEST")
        validate_request(request)
        summary, inventory = inspect_package(Path(str(request["InputPackage"])))
        package_name = write_artifact_package(request, summary, inventory)
        result = runtime_result(request, package_name, summary)
        Path(args.result_json).write_bytes(canonical_bytes(result))
        print(result["Capsule"])
        return 0
    except ModuleError as exc:
        print("U2S0H5-NF0-K0-R0-S0-X1-C-7-K" + stable(exc))
        return 7
    except Exception as exc:
        print("U2S0H5-NF0-K0-R0-S0-X1-C-7-K" + stable(exc.__class__.__name__))
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
