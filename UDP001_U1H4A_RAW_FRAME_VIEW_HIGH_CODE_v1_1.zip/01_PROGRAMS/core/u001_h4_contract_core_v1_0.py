#!/usr/bin/env python3
"""Shared, import-safe contract utilities for U001 H4.

H4 consumes an immutable H3 canonical-update package.  This module validates
that boundary before any frame aggregation is allowed.  Importing the module
has no file-system or GUI side effects.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePath
from typing import Any, Iterable


PROGRAM_NAME = "u001_h4_contract_core"
PROGRAM_VERSION = "1.0.0"
H3_MANIFEST_SCHEMA = "U001_H3_RUN_MANIFEST_V1_0"
H3_OUTPUT_BOUNDARY = "U001_H3_CANONICAL_UPDATE_PACKAGE_V1_0"

H3_ARTIFACTS = {
    "u001_h3_frame_map.csv",
    "u001_h3_frame_quality.json",
    "u001_h3_compiled_signal_policy.csv",
    "u001_h3_policy_quality.json",
    "u001_h3_canonical_updates.csv",
    "u001_h3_canonical_quality.json",
}

CANONICAL_UPDATE_REQUIRED_COLUMNS = {
    "SourceRowIndex",
    "FrameCount",
    "CanonicalName",
    "PhysicalValue",
    "ValueLabel",
    "Unit",
    "ValueKind",
    "SignalRole",
    "Valid",
    "MissingReason",
}

H3_POLICY_REQUIRED_COLUMNS = {
    "CanonicalName",
    "PolicyStatus",
    "ValueKind",
    "SignalRole",
    "Required",
}


class H4ContractError(RuntimeError):
    """Fail-closed H4 boundary error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise H4ContractError(f"{label}_JSON:{exc}") from exc
    if not isinstance(value, dict):
        raise H4ContractError(f"{label}_NOT_OBJECT")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def read_csv_rows(path: Path, required: Iterable[str], label: str) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            header = set(reader.fieldnames or [])
            missing = sorted(set(required) - header)
            if missing:
                raise H4ContractError(f"{label}_COLUMNS:{'.'.join(missing)}")
            return list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        raise H4ContractError(f"{label}_READ:{exc}") from exc


def require_empty_output(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise H4ContractError("OUTPUT_NOT_EMPTY")


def _is_basename(value: str) -> bool:
    path = PurePath(value)
    return bool(value) and not path.is_absolute() and len(path.parts) == 1 and value not in {".", ".."}


def validate_h3_package(folder: Path) -> dict[str, Any]:
    if not folder.is_dir():
        raise H4ContractError("H3_PACKAGE_FOLDER")
    manifest_path = folder / "u001_h3_run_manifest.json"
    capsule_path = folder / "u001_h3_completion_capsule.txt"
    if not manifest_path.is_file() or not capsule_path.is_file():
        raise H4ContractError("H3_PACKAGE_CONTROL_FILES")
    manifest = load_json_object(manifest_path, "H3_MANIFEST")
    if manifest.get("ManifestSchema") != H3_MANIFEST_SCHEMA:
        raise H4ContractError("H3_MANIFEST_SCHEMA")
    if manifest.get("OutputBoundary") != H3_OUTPUT_BOUNDARY:
        raise H4ContractError("H3_OUTPUT_BOUNDARY")
    if manifest.get("Status") != "COMPLETE" or manifest.get("CompletionCode") != 0:
        raise H4ContractError("H3_STATUS")
    for key in ("DatasetId", "RunId", "SegmentId"):
        if not str(manifest.get(key, "")).strip():
            raise H4ContractError(f"H3_{key.upper()}")
    artifacts = manifest.get("Artifacts")
    if not isinstance(artifacts, list):
        raise H4ContractError("H3_ARTIFACT_LIST")
    observed_names: set[str] = set()
    for item in artifacts:
        if not isinstance(item, dict):
            raise H4ContractError("H3_ARTIFACT_ENTRY")
        name = str(item.get("FileName", ""))
        if not _is_basename(name) or name in observed_names:
            raise H4ContractError(f"H3_ARTIFACT_NAME:{name}")
        observed_names.add(name)
        path = folder / name
        if not path.is_file():
            raise H4ContractError(f"H3_ARTIFACT_MISSING:{name}")
        if path.stat().st_size != item.get("SizeBytes") or sha256_file(path) != item.get("SHA256"):
            raise H4ContractError(f"H3_ARTIFACT_IDENTITY:{name}")
    if observed_names != H3_ARTIFACTS:
        raise H4ContractError(
            f"H3_ARTIFACT_INVENTORY:MISSING={sorted(H3_ARTIFACTS-observed_names)}:"
            f"EXTRA={sorted(observed_names-H3_ARTIFACTS)}"
        )
    if not capsule_path.read_text(encoding="utf-8").strip().endswith("C0"):
        raise H4ContractError("H3_CAPSULE")
    return manifest


def parse_integer(text: str, label: str, allow_blank: bool = False) -> int | None:
    value = text.strip()
    if not value and allow_blank:
        return None
    try:
        number = int(value)
    except ValueError as exc:
        raise H4ContractError(f"{label}_INTEGER:{value}") from exc
    return number


def parse_flag(text: str, label: str) -> int:
    value = parse_integer(text, label)
    if value not in {0, 1}:
        raise H4ContractError(f"{label}_FLAG:{text}")
    return int(value)


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    check(_is_basename("artifact.csv"), "T01")
    check(not _is_basename("folder/artifact.csv"), "T02")
    check(not _is_basename("../artifact.csv"), "T03")
    check(parse_integer("12", "X") == 12, "T04")
    check(parse_integer("", "X", allow_blank=True) is None, "T05")
    check(parse_flag("0", "X") == 0, "T06")
    check(parse_flag("1", "X") == 1, "T07")
    failed_flag = False
    try:
        parse_flag("2", "X")
    except H4ContractError:
        failed_flag = True
    check(failed_flag, "T08")
    check(len(H3_ARTIFACTS) == 6, "T09")
    check("FrameCount" in CANONICAL_UPDATE_REQUIRED_COLUMNS, "T10")
    check("SignalRole" in H3_POLICY_REQUIRED_COLUMNS, "T11")
    check(PROGRAM_VERSION == "1.0.0", "T12")
    if checks != 12:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4-CONTRACT-CORE-SELFTEST-PASS-12")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="U001 H4 contract utilities")
    result.add_argument("--self-test", action="store_true", required=True)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
        return 0
    except (H4ContractError, AssertionError, OSError, ValueError, csv.Error) as exc:
        print(f"U1H4CE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
