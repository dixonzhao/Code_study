#!/usr/bin/env python3
"""Build the U001 H4 raw one-row-per-FrameCount view.

This stage performs within-frame aggregation only.  It never carries values
across frames, synthesizes missing FrameCount rows, interpolates, smooths,
fuses targets or performs analysis.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import tempfile
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterator

from u001_h4_contract_core_v1_0 import (
    CANONICAL_UPDATE_REQUIRED_COLUMNS,
    H4ContractError,
    load_json_object,
    parse_flag,
    parse_integer,
    read_csv_rows,
    require_empty_output,
    sha256_file,
    validate_h3_package,
    write_json,
)
from u001_h4_frame_policy_compiler_v1_0 import POLICY_COLUMNS, POLICY_SCHEMA


PROGRAM_NAME = "u001_h4_raw_frame_view_builder"
PROGRAM_VERSION = "1.0.0"
OUTPUT_BOUNDARY = "U001_H4_RAW_FRAME_VIEW_PACKAGE_V1_0"

OUTPUT_FRAME_VIEW = "u001_h4_raw_frame_view.csv"
OUTPUT_QUALITY = "u001_h4_raw_frame_quality.json"
OUTPUT_MANIFEST = "u001_h4_raw_frame_manifest.json"
OUTPUT_CAPSULE = "u001_h4_raw_frame_capsule.txt"

LEADING_COLUMNS = ["FrameCount", "SourceRowFirst", "SourceRowLast", "SourceUpdateCount"]
SIGNAL_SUFFIXES = [
    "__value",
    "__label",
    "__updated",
    "__update_count",
    "__age",
    "__valid",
    "__missing_reason",
]


class H4FrameError(RuntimeError):
    """Fail-closed raw Frame View error."""


def _read_compiled_policy(path: Path) -> list[dict[str, str]]:
    rows = read_csv_rows(path, POLICY_COLUMNS, "H4_FRAME_POLICY")
    if not rows:
        raise H4FrameError("FRAME_POLICY_EMPTY")
    names = [row["CanonicalName"].strip() for row in rows]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise H4FrameError("FRAME_POLICY_IDENTITY")
    for row in rows:
        name = row["CanonicalName"].strip()
        if row["PolicySchema"].strip() != POLICY_SCHEMA:
            raise H4FrameError(f"FRAME_POLICY_SCHEMA:{name}")
        if row["PolicyStatus"].strip().upper() != "APPROVED":
            raise H4FrameError(f"FRAME_POLICY_NOT_APPROVED:{name}")
        parse_flag(row["IncludeInFrameView"], f"INCLUDE_{name}")
    return rows


def _boolean_value(text: str, label: str) -> bool:
    value = text.strip().lower()
    if value in {"1", "1.0", "true"}:
        return True
    if value in {"0", "0.0", "false"}:
        return False
    raise H4FrameError(f"BOOLEAN_VALUE:{label}:{text}")


def _integer_value(text: str, label: str) -> int:
    value = text.strip()
    try:
        number = float(value)
    except ValueError as exc:
        raise H4FrameError(f"INTEGER_VALUE:{label}:{text}") from exc
    if not math.isfinite(number) or not number.is_integer() or number < 0:
        raise H4FrameError(f"INTEGER_VALUE:{label}:{text}")
    return int(number)


def _blank_signal(name: str) -> dict[str, str | int]:
    return {
        f"{name}__value": "",
        f"{name}__label": "",
        f"{name}__updated": 0,
        f"{name}__update_count": 0,
        f"{name}__age": "",
        f"{name}__valid": 0,
        f"{name}__missing_reason": "NO_UPDATE",
    }


def _selected_result(row: dict[str, str], name: str, update_count: int) -> dict[str, str | int]:
    return {
        f"{name}__value": row["PhysicalValue"],
        f"{name}__label": row["ValueLabel"],
        f"{name}__updated": 1,
        f"{name}__update_count": update_count,
        f"{name}__age": 0,
        f"{name}__valid": parse_flag(row["Valid"], f"VALID_{name}"),
        f"{name}__missing_reason": row["MissingReason"].strip() or "UNSPECIFIED",
    }


def aggregate_signal(
    name: str,
    policy: str,
    updates: list[dict[str, str]],
) -> dict[str, str | int]:
    if not updates:
        return _blank_signal(name)
    count = len(updates)
    if policy == "LAST_UPDATE":
        return _selected_result(updates[-1], name, count)
    if policy == "FIRST_UPDATE":
        return _selected_result(updates[0], name, count)
    valid_updates = [row for row in updates if parse_flag(row["Valid"], f"VALID_{name}") == 1]
    if not valid_updates:
        return {
            f"{name}__value": "",
            f"{name}__label": "",
            f"{name}__updated": 1,
            f"{name}__update_count": count,
            f"{name}__age": 0,
            f"{name}__valid": 0,
            f"{name}__missing_reason": "ALL_UPDATES_INVALID",
        }
    if policy == "ANY_TRUE":
        values = [_boolean_value(row["PhysicalValue"], name) for row in valid_updates]
        result = any(values)
        return {
            f"{name}__value": "1" if result else "0",
            f"{name}__label": "true" if result else "false",
            f"{name}__updated": 1,
            f"{name}__update_count": count,
            f"{name}__age": 0,
            f"{name}__valid": 1,
            f"{name}__missing_reason": "VALID_AGGREGATED",
        }
    if policy == "BITWISE_OR":
        result = 0
        for row in valid_updates:
            result |= _integer_value(row["PhysicalValue"], name)
        return {
            f"{name}__value": str(result),
            f"{name}__label": "",
            f"{name}__updated": 1,
            f"{name}__update_count": count,
            f"{name}__age": 0,
            f"{name}__valid": 1,
            f"{name}__missing_reason": "VALID_AGGREGATED",
        }
    raise H4FrameError(f"WITHIN_FRAME_POLICY:{name}:{policy}")


def _iter_canonical_updates(path: Path) -> Iterator[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            missing = sorted(CANONICAL_UPDATE_REQUIRED_COLUMNS - set(reader.fieldnames or []))
            if missing:
                raise H4FrameError(f"CANONICAL_COLUMNS:{'.'.join(missing)}")
            yield from reader
    except (OSError, UnicodeError, csv.Error) as exc:
        raise H4FrameError(f"CANONICAL_READ:{exc}") from exc


def _fieldnames(included: list[dict[str, str]]) -> list[str]:
    result = list(LEADING_COLUMNS)
    for row in included:
        name = row["CanonicalName"].strip()
        result.extend(name + suffix for suffix in SIGNAL_SUFFIXES)
    return result


def _emit_frame(
    writer: csv.DictWriter,
    frame_count: int,
    source_rows: list[int],
    source_update_count: int,
    buffers: dict[str, list[dict[str, str]]],
    included: list[dict[str, str]],
) -> None:
    if not source_rows or source_update_count <= 0:
        raise H4FrameError("OPEN_FRAME_EMPTY")
    output: dict[str, Any] = {
        "FrameCount": frame_count,
        "SourceRowFirst": min(source_rows),
        "SourceRowLast": max(source_rows),
        "SourceUpdateCount": source_update_count,
    }
    for policy_row in included:
        name = policy_row["CanonicalName"].strip()
        output.update(
            aggregate_signal(name, policy_row["WithinFramePolicy"].strip().upper(), buffers.get(name, []))
        )
    writer.writerow(output)


def build_raw_frame_view(
    h3_package: Path,
    frame_policy_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    start = time.perf_counter()
    h3_manifest = validate_h3_package(h3_package)
    require_empty_output(output_dir)
    policies = _read_compiled_policy(frame_policy_path)
    included = [row for row in policies if row["IncludeInFrameView"].strip() == "1"]
    if not included:
        raise H4FrameError("NO_INCLUDED_SIGNAL")
    policy_by_name = {row["CanonicalName"].strip(): row for row in policies}
    if not any(row["SignalRole"].strip().upper() == "FRAME_KEY" for row in policies):
        raise H4FrameError("FRAME_KEY_POLICY_MISSING")

    source_path = h3_package / "u001_h3_canonical_updates.csv"
    source_hash_before = sha256_file(source_path)
    output_path = output_dir / OUTPUT_FRAME_VIEW
    fieldnames = _fieldnames(included)
    current_frame: int | None = None
    previous_frame: int | None = None
    previous_source_row = -1
    source_rows: list[int] = []
    source_update_count = 0
    buffers: dict[str, list[dict[str, str]]] = defaultdict(list)
    output_rows = 0
    input_rows = 0
    multi_update_frames = 0
    missing_frame_gap_count = 0
    maximum_frame_step = 0
    maximum_open_frame_updates = 0
    observed_names: set[str] = set()

    with output_path.open("w", encoding="utf-8", newline="") as output_stream:
        writer = csv.DictWriter(output_stream, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for row in _iter_canonical_updates(source_path):
            input_rows += 1
            source_row = parse_integer(row["SourceRowIndex"], "SOURCE_ROW")
            frame_count = parse_integer(row["FrameCount"], "FRAME_COUNT")
            assert source_row is not None and frame_count is not None
            if source_row < previous_source_row:
                raise H4FrameError("SOURCE_ROW_DECREASE")
            previous_source_row = source_row
            name = row["CanonicalName"].strip()
            if not name or name not in policy_by_name:
                raise H4FrameError(f"CANONICAL_POLICY:{name}")
            observed_names.add(name)
            if current_frame is None:
                current_frame = frame_count
            elif frame_count < current_frame:
                raise H4FrameError("FRAMECOUNT_DECREASE")
            elif frame_count != current_frame:
                _emit_frame(writer, current_frame, source_rows, source_update_count, buffers, included)
                output_rows += 1
                if source_update_count > 1:
                    multi_update_frames += 1
                if previous_frame is not None:
                    step = current_frame - previous_frame
                    maximum_frame_step = max(maximum_frame_step, step)
                    if step > 1:
                        missing_frame_gap_count += step - 1
                previous_frame = current_frame
                current_frame = frame_count
                source_rows = []
                source_update_count = 0
                buffers = defaultdict(list)
            source_rows.append(source_row)
            source_update_count += 1
            if policy_by_name[name]["IncludeInFrameView"].strip() == "1":
                buffers[name].append(row)
            maximum_open_frame_updates = max(maximum_open_frame_updates, source_update_count)
        if current_frame is None:
            raise H4FrameError("CANONICAL_EMPTY")
        _emit_frame(writer, current_frame, source_rows, source_update_count, buffers, included)
        output_rows += 1
        if source_update_count > 1:
            multi_update_frames += 1
        if previous_frame is not None:
            step = current_frame - previous_frame
            maximum_frame_step = max(maximum_frame_step, step)
            if step > 1:
                missing_frame_gap_count += step - 1

    if source_hash_before != sha256_file(source_path):
        raise H4FrameError("H3_SOURCE_MUTATED")
    expected_frames = h3_manifest.get("Counts", {}).get("DistinctFrames")
    if output_rows != expected_frames:
        raise H4FrameError(f"FRAME_COUNT_MISMATCH:{output_rows}:{expected_frames}")
    required_names = {
        row["CanonicalName"].strip()
        for row in policies
        if row["Required"].strip() == "1"
    }
    missing_required = sorted(required_names - observed_names)
    if missing_required:
        raise H4FrameError(f"REQUIRED_SIGNAL_UNOBSERVED:{'.'.join(missing_required)}")

    quality = {
        "QualitySchema": "U001_H4_RAW_FRAME_QUALITY_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "H3ManifestSHA256": sha256_file(h3_package / "u001_h3_run_manifest.json"),
        "FramePolicySHA256": sha256_file(frame_policy_path),
        "CanonicalUpdatesSHA256": source_hash_before,
        "RawFrameViewSHA256": sha256_file(output_path),
        "InputUpdateRowCount": input_rows,
        "OutputFrameRowCount": output_rows,
        "IncludedSignalCount": len(included),
        "StreamOnlySignalCount": len(policies) - len(included),
        "MultiUpdateFrameCount": multi_update_frames,
        "MissingFrameGapCount": missing_frame_gap_count,
        "MaximumAdjacentFrameStep": maximum_frame_step,
        "MaximumOpenFrameUpdateCount": maximum_open_frame_updates,
        "SyntheticFrameCount": 0,
        "CrossFrameHeldCellCount": 0,
        "ZeroFillCount": 0,
        "InputMutationCount": 0,
        "WholeFileMemoryLoadRequired": False,
        "ElapsedSeconds": round(time.perf_counter() - start, 6),
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / OUTPUT_QUALITY, quality)
    artifacts = []
    for name in (OUTPUT_FRAME_VIEW, OUTPUT_QUALITY):
        path = output_dir / name
        artifacts.append({"FileName": name, "SizeBytes": path.stat().st_size, "SHA256": sha256_file(path)})
    manifest = {
        "ManifestSchema": "U001_H4_RAW_FRAME_MANIFEST_V1_0",
        "OutputBoundary": OUTPUT_BOUNDARY,
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "DatasetId": h3_manifest["DatasetId"],
        "RunId": h3_manifest["RunId"],
        "SegmentId": h3_manifest["SegmentId"],
        "InputH3ManifestSHA256": quality["H3ManifestSHA256"],
        "FramePolicySHA256": quality["FramePolicySHA256"],
        "Artifacts": artifacts,
        "Counts": {
            "InputUpdateRows": input_rows,
            "OutputFrames": output_rows,
            "IncludedSignals": len(included),
        },
        "Status": "COMPLETE",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / OUTPUT_MANIFEST, manifest)
    capsule = (
        f"U1H4A-R{input_rows}-F{output_rows}-I{len(included)}-"
        f"G{missing_frame_gap_count}-H0-Z0-X0-C0"
    )
    (output_dir / OUTPUT_CAPSULE).write_text(capsule + "\n", encoding="utf-8")
    return quality


def _write_fixture(root: Path) -> tuple[Path, Path]:
    h3 = root / "h3"
    h3.mkdir(parents=True)
    canonical_fields = [
        "SourceRowIndex", "FrameCount", "CanonicalName", "PhysicalValue", "ValueLabel",
        "Unit", "ValueKind", "SignalRole", "Valid", "MissingReason",
    ]
    canonical_rows = [
        [0, 100, "FRAME", 100, "", "count", "INTEGER", "FRAME_KEY", 1, "VALID_UPDATE"],
        [0, 100, "DIST", 10.0, "", "m", "FLOAT", "MEASUREMENT", 1, "VALID_UPDATE"],
        [1, 100, "FLAG", 0, "false", "", "BOOLEAN", "EVENT_FLAG", 1, "VALID_UPDATE"],
        [2, 100, "FLAG", 1, "true", "", "BOOLEAN", "EVENT_FLAG", 1, "VALID_UPDATE"],
        [3, 101, "FRAME", 101, "", "count", "INTEGER", "FRAME_KEY", 1, "VALID_UPDATE"],
        [3, 101, "DIST", 327.66, "", "m", "FLOAT", "MEASUREMENT", 0, "USER_INVALID_RULE"],
        [4, 102, "FRAME", 102, "", "count", "INTEGER", "FRAME_KEY", 1, "VALID_UPDATE"],
        [4, 102, "DIST", 12.0, "", "m", "FLOAT", "MEASUREMENT", 1, "VALID_UPDATE"],
        [4, 102, "FLAG", 0, "false", "", "BOOLEAN", "EVENT_FLAG", 1, "VALID_UPDATE"],
    ]
    canonical = h3 / "u001_h3_canonical_updates.csv"
    with canonical.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(canonical_fields)
        writer.writerows(canonical_rows)
    h3_policy = h3 / "u001_h3_compiled_signal_policy.csv"
    with h3_policy.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["CanonicalName", "PolicyStatus", "ValueKind", "SignalRole", "Required"], lineterminator="\n")
        writer.writeheader()
        writer.writerows([
            {"CanonicalName": "FRAME", "PolicyStatus": "APPROVED", "ValueKind": "INTEGER", "SignalRole": "FRAME_KEY", "Required": 1},
            {"CanonicalName": "DIST", "PolicyStatus": "APPROVED", "ValueKind": "FLOAT", "SignalRole": "MEASUREMENT", "Required": 1},
            {"CanonicalName": "FLAG", "PolicyStatus": "APPROVED", "ValueKind": "BOOLEAN", "SignalRole": "EVENT_FLAG", "Required": 0},
        ])
    for name, value in (
        ("u001_h3_frame_map.csv", "SourceRowIndex,FrameCount\n0,100\n3,101\n4,102\n"),
        ("u001_h3_frame_quality.json", "{}\n"),
        ("u001_h3_policy_quality.json", "{}\n"),
        ("u001_h3_canonical_quality.json", "{}\n"),
    ):
        (h3 / name).write_text(value, encoding="utf-8")
    artifact_names = [
        "u001_h3_frame_map.csv", "u001_h3_frame_quality.json",
        "u001_h3_compiled_signal_policy.csv", "u001_h3_policy_quality.json",
        "u001_h3_canonical_updates.csv", "u001_h3_canonical_quality.json",
    ]
    artifacts = [
        {"FileName": name, "SizeBytes": (h3 / name).stat().st_size, "SHA256": sha256_file(h3 / name)}
        for name in artifact_names
    ]
    write_json(h3 / "u001_h3_run_manifest.json", {
        "ManifestSchema": "U001_H3_RUN_MANIFEST_V1_0",
        "OutputBoundary": "U001_H3_CANONICAL_UPDATE_PACKAGE_V1_0",
        "DatasetId": "DATASET", "RunId": "RUN", "SegmentId": "SEGMENT",
        "Artifacts": artifacts,
        "Counts": {"InputUpdateRows": 9, "SourceRows": 5, "DistinctFrames": 3, "Signals": 3, "ValidUpdates": 8, "InvalidUpdates": 1},
        "Status": "COMPLETE", "CompletionCode": 0,
    })
    (h3 / "u001_h3_completion_capsule.txt").write_text("U1H3-R9-F3-S3-X0-C0\n", encoding="utf-8")

    policy = root / "frame_policy.csv"
    with policy.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows([
            {"PolicySchema": POLICY_SCHEMA, "CanonicalName": "FRAME", "ValueKind": "INTEGER", "SignalRole": "FRAME_KEY", "IncludeInFrameView": 0, "WithinFramePolicy": "KEEP_STREAM_ONLY", "Required": 1, "PolicyStatus": "APPROVED", "Notes": ""},
            {"PolicySchema": POLICY_SCHEMA, "CanonicalName": "DIST", "ValueKind": "FLOAT", "SignalRole": "MEASUREMENT", "IncludeInFrameView": 1, "WithinFramePolicy": "LAST_UPDATE", "Required": 1, "PolicyStatus": "APPROVED", "Notes": ""},
            {"PolicySchema": POLICY_SCHEMA, "CanonicalName": "FLAG", "ValueKind": "BOOLEAN", "SignalRole": "EVENT_FLAG", "IncludeInFrameView": 1, "WithinFramePolicy": "ANY_TRUE", "Required": 0, "PolicyStatus": "APPROVED", "Notes": ""},
        ])
    return h3, policy


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_h4_frame_") as temporary:
        root = Path(temporary)
        h3, policy = _write_fixture(root)
        source_hash = sha256_file(h3 / "u001_h3_canonical_updates.csv")
        quality = build_raw_frame_view(h3, policy, root / "output")
        rows = read_csv_rows(root / "output" / OUTPUT_FRAME_VIEW, LEADING_COLUMNS, "SELF_FRAME")
        check(len(rows) == 3, "T01")
        check([row["FrameCount"] for row in rows] == ["100", "101", "102"], "T02")
        check(rows[0]["SourceUpdateCount"] == "4", "T03")
        check(rows[0]["FLAG__value"] == "1" and rows[0]["FLAG__update_count"] == "2", "T04")
        check(rows[0]["FLAG__missing_reason"] == "VALID_AGGREGATED", "T05")
        check(rows[1]["FLAG__value"] == "" and rows[1]["FLAG__updated"] == "0", "T06")
        check(rows[1]["FLAG__missing_reason"] == "NO_UPDATE", "T07")
        check(rows[1]["DIST__value"] == "327.66" and rows[1]["DIST__valid"] == "0", "T08")
        check(rows[1]["DIST__missing_reason"] == "USER_INVALID_RULE", "T09")
        check(rows[2]["DIST__value"] == "12.0" and rows[2]["DIST__age"] == "0", "T10")
        check("FRAME__value" not in rows[0], "T11")
        check(quality["InputUpdateRowCount"] == 9, "T12")
        check(quality["OutputFrameRowCount"] == 3, "T13")
        check(quality["IncludedSignalCount"] == 2, "T14")
        check(quality["SyntheticFrameCount"] == 0, "T15")
        check(quality["CrossFrameHeldCellCount"] == 0, "T16")
        check(quality["ZeroFillCount"] == 0, "T17")
        check(quality["WholeFileMemoryLoadRequired"] is False, "T18")
        check(source_hash == sha256_file(h3 / "u001_h3_canonical_updates.csv"), "T19")
        check((root / "output" / OUTPUT_CAPSULE).read_text().strip().endswith("C0"), "T20")
        manifest = load_json_object(root / "output" / OUTPUT_MANIFEST, "SELF_MANIFEST")
        check(manifest["OutputBoundary"] == OUTPUT_BOUNDARY, "T21")
        check(manifest["Counts"]["OutputFrames"] == 3, "T22")
        check(len(manifest["Artifacts"]) == 2, "T23")
        check(all((root / "output" / item["FileName"]).is_file() for item in manifest["Artifacts"]), "T24")
    if checks != 24:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4-RAW-FRAME-BUILDER-SELFTEST-PASS-24")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="U001 H4 raw Frame View builder")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--build", action="store_true")
    result.add_argument("--h3-package", type=Path)
    result.add_argument("--frame-policy", type=Path)
    result.add_argument("--out", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.h3_package is None or args.frame_policy is None or args.out is None:
            raise H4FrameError("ARGUMENTS")
        quality = build_raw_frame_view(args.h3_package, args.frame_policy, args.out)
        print(
            f"U1H4A-R{quality['InputUpdateRowCount']}-F{quality['OutputFrameRowCount']}-"
            f"I{quality['IncludedSignalCount']}-G{quality['MissingFrameGapCount']}-H0-Z0-X0-C0"
        )
        return 0
    except (H4FrameError, H4ContractError, AssertionError, OSError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        print(f"U1H4AE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
