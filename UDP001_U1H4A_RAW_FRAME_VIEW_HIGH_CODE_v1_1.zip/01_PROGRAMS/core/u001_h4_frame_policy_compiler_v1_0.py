#!/usr/bin/env python3
"""Create and compile the explicit U001 H4 within-frame policy."""

from __future__ import annotations

import argparse
import csv
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

from u001_h4_contract_core_v1_0 import (
    H3_POLICY_REQUIRED_COLUMNS,
    H4ContractError,
    read_csv_rows,
    require_empty_output,
    sha256_file,
    validate_h3_package,
    write_json,
)


PROGRAM_NAME = "u001_h4_frame_policy_compiler"
PROGRAM_VERSION = "1.0.0"
POLICY_SCHEMA = "U001_H4_FRAME_POLICY_V1_0"

POLICY_COLUMNS = [
    "PolicySchema",
    "CanonicalName",
    "ValueKind",
    "SignalRole",
    "IncludeInFrameView",
    "WithinFramePolicy",
    "Required",
    "PolicyStatus",
    "Notes",
]

WITHIN_FRAME_POLICIES = {
    "LAST_UPDATE",
    "FIRST_UPDATE",
    "ANY_TRUE",
    "BITWISE_OR",
    "KEEP_STREAM_ONLY",
}

COMPILED_POLICY_FILE = "u001_h4_compiled_frame_policy.csv"
QUALITY_FILE = "u001_h4_frame_policy_quality.json"
CAPSULE_FILE = "u001_h4_frame_policy_capsule.txt"


class H4PolicyError(RuntimeError):
    """Fail-closed H4 frame-policy error."""


def _read_h3_policy(h3_package: Path) -> list[dict[str, str]]:
    validate_h3_package(h3_package)
    rows = read_csv_rows(
        h3_package / "u001_h3_compiled_signal_policy.csv",
        H3_POLICY_REQUIRED_COLUMNS,
        "H3_POLICY",
    )
    if not rows:
        raise H4PolicyError("H3_POLICY_EMPTY")
    names = [row["CanonicalName"].strip() for row in rows]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise H4PolicyError("H3_POLICY_IDENTITY")
    return rows


def proposal_rows(h3_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in h3_rows:
        role = row["SignalRole"].strip().upper()
        kind = row["ValueKind"].strip().upper()
        if role == "FRAME_KEY":
            include, policy = 0, "KEEP_STREAM_ONLY"
        elif role == "EVENT_FLAG" and kind == "BOOLEAN":
            include, policy = 1, "ANY_TRUE"
        else:
            include, policy = 1, "LAST_UPDATE"
        result.append(
            {
                "PolicySchema": POLICY_SCHEMA,
                "CanonicalName": row["CanonicalName"].strip(),
                "ValueKind": kind,
                "SignalRole": role,
                "IncludeInFrameView": include,
                "WithinFramePolicy": policy,
                "Required": row["Required"].strip(),
                "PolicyStatus": "PROVISIONAL",
                "Notes": "Engineer review required before controlled build",
            }
        )
    return result


def write_template(h3_package: Path, output_path: Path) -> int:
    rows = proposal_rows(_read_h3_policy(h3_package))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists():
        raise H4PolicyError("TEMPLATE_ALREADY_EXISTS")
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def _read_candidate(path: Path) -> list[dict[str, str]]:
    return read_csv_rows(path, POLICY_COLUMNS, "FRAME_POLICY")


def validate_policy_rows(
    candidate_rows: list[dict[str, str]],
    h3_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    if not candidate_rows:
        raise H4PolicyError("POLICY_EMPTY")
    source = {row["CanonicalName"].strip(): row for row in h3_rows}
    names = [row["CanonicalName"].strip() for row in candidate_rows]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise H4PolicyError("POLICY_IDENTITY")
    if set(names) != set(source):
        raise H4PolicyError(
            f"POLICY_SIGNAL_SET:MISSING={sorted(set(source)-set(names))}:"
            f"EXTRA={sorted(set(names)-set(source))}"
        )
    compiled: list[dict[str, str]] = []
    for row in candidate_rows:
        name = row["CanonicalName"].strip()
        reference = source[name]
        schema = row["PolicySchema"].strip()
        kind = row["ValueKind"].strip().upper()
        role = row["SignalRole"].strip().upper()
        include = row["IncludeInFrameView"].strip()
        policy = row["WithinFramePolicy"].strip().upper()
        required = row["Required"].strip()
        status = row["PolicyStatus"].strip().upper()
        if schema != POLICY_SCHEMA:
            raise H4PolicyError(f"POLICY_SCHEMA:{name}")
        if kind != reference["ValueKind"].strip().upper() or role != reference["SignalRole"].strip().upper():
            raise H4PolicyError(f"POLICY_H3_SEMANTIC_DRIFT:{name}")
        if required != reference["Required"].strip():
            raise H4PolicyError(f"POLICY_REQUIRED_DRIFT:{name}")
        if include not in {"0", "1"}:
            raise H4PolicyError(f"POLICY_INCLUDE:{name}")
        if policy not in WITHIN_FRAME_POLICIES:
            raise H4PolicyError(f"POLICY_METHOD:{name}")
        if status != "APPROVED":
            raise H4PolicyError(f"POLICY_NOT_APPROVED:{name}")
        if include == "0" and policy != "KEEP_STREAM_ONLY":
            raise H4PolicyError(f"POLICY_EXCLUDED_METHOD:{name}")
        if include == "1" and policy == "KEEP_STREAM_ONLY":
            raise H4PolicyError(f"POLICY_INCLUDED_METHOD:{name}")
        if role == "FRAME_KEY" and (include != "0" or policy != "KEEP_STREAM_ONLY"):
            raise H4PolicyError(f"POLICY_FRAME_KEY:{name}")
        if policy == "ANY_TRUE" and kind != "BOOLEAN":
            raise H4PolicyError(f"POLICY_ANY_TRUE_KIND:{name}")
        if policy == "BITWISE_OR" and kind not in {"INTEGER", "BITFIELD"}:
            raise H4PolicyError(f"POLICY_BITWISE_KIND:{name}")
        compiled.append(
            {
                "PolicySchema": POLICY_SCHEMA,
                "CanonicalName": name,
                "ValueKind": kind,
                "SignalRole": role,
                "IncludeInFrameView": include,
                "WithinFramePolicy": policy,
                "Required": required,
                "PolicyStatus": status,
                "Notes": row.get("Notes", "").strip(),
            }
        )
    return compiled


def compile_policy(h3_package: Path, candidate_path: Path, output_dir: Path) -> dict[str, Any]:
    require_empty_output(output_dir)
    h3_rows = _read_h3_policy(h3_package)
    compiled = validate_policy_rows(_read_candidate(candidate_path), h3_rows)
    output_path = output_dir / COMPILED_POLICY_FILE
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=POLICY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(compiled)
    included = [row for row in compiled if row["IncludeInFrameView"] == "1"]
    quality = {
        "QualitySchema": "U001_H4_FRAME_POLICY_QUALITY_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "H3PackageManifestSHA256": sha256_file(h3_package / "u001_h3_run_manifest.json"),
        "CandidatePolicySHA256": sha256_file(candidate_path),
        "CompiledPolicySHA256": sha256_file(output_path),
        "PolicyRowCount": len(compiled),
        "IncludedSignalCount": len(included),
        "StreamOnlySignalCount": len(compiled) - len(included),
        "UnapprovedPolicyCount": 0,
        "Status": "COMPILED",
        "CompletionCode": 0,
        "Warnings": [],
        "Errors": [],
    }
    write_json(output_dir / QUALITY_FILE, quality)
    capsule = f"U1H4P-N{len(compiled)}-I{len(included)}-S{len(compiled)-len(included)}-X0-C0"
    (output_dir / CAPSULE_FILE).write_text(capsule + "\n", encoding="utf-8")
    return quality


def _write_policy_fixture(path: Path) -> None:
    rows = [
        {"CanonicalName": "FRAME", "PolicyStatus": "APPROVED", "ValueKind": "INTEGER", "SignalRole": "FRAME_KEY", "Required": "1"},
        {"CanonicalName": "DIST", "PolicyStatus": "APPROVED", "ValueKind": "FLOAT", "SignalRole": "MEASUREMENT", "Required": "1"},
        {"CanonicalName": "FLAG", "PolicyStatus": "APPROVED", "ValueKind": "BOOLEAN", "SignalRole": "EVENT_FLAG", "Required": "0"},
    ]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["CanonicalName", "PolicyStatus", "ValueKind", "SignalRole", "Required"])
        writer.writeheader()
        writer.writerows(rows)


def self_test() -> None:
    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    with tempfile.TemporaryDirectory(prefix="u001_h4_policy_") as temporary:
        root = Path(temporary)
        h3_policy = root / "h3_policy.csv"
        _write_policy_fixture(h3_policy)
        h3_rows = read_csv_rows(h3_policy, H3_POLICY_REQUIRED_COLUMNS, "SELF_H3")
        proposed = proposal_rows(h3_rows)
        check(len(proposed) == 3, "T01")
        check(proposed[0]["WithinFramePolicy"] == "KEEP_STREAM_ONLY", "T02")
        check(proposed[1]["WithinFramePolicy"] == "LAST_UPDATE", "T03")
        check(proposed[2]["WithinFramePolicy"] == "ANY_TRUE", "T04")
        check(all(row["PolicyStatus"] == "PROVISIONAL" for row in proposed), "T05")
        approved = [{**row, "PolicyStatus": "APPROVED"} for row in proposed]
        compiled = validate_policy_rows([{k: str(v) for k, v in row.items()} for row in approved], h3_rows)
        check(len(compiled) == 3, "T06")
        check(sum(row["IncludeInFrameView"] == "1" for row in compiled) == 2, "T07")
        check(compiled[0]["Required"] == "1", "T08")
        bad = [dict(row) for row in approved]
        bad[1]["PolicyStatus"] = "PROVISIONAL"
        try:
            validate_policy_rows([{k: str(v) for k, v in row.items()} for row in bad], h3_rows)
        except H4PolicyError as exc:
            check("NOT_APPROVED" in str(exc), "T09")
        else:
            raise AssertionError("T09")
        bad = [dict(row) for row in approved]
        bad[1]["WithinFramePolicy"] = "ANY_TRUE"
        try:
            validate_policy_rows([{k: str(v) for k, v in row.items()} for row in bad], h3_rows)
        except H4PolicyError as exc:
            check("ANY_TRUE_KIND" in str(exc), "T10")
        else:
            raise AssertionError("T10")
        bad = [dict(row) for row in approved]
        bad[0]["IncludeInFrameView"] = 1
        try:
            validate_policy_rows([{k: str(v) for k, v in row.items()} for row in bad], h3_rows)
        except H4PolicyError as exc:
            check("INCLUDED_METHOD" in str(exc) or "FRAME_KEY" in str(exc), "T11")
        else:
            raise AssertionError("T11")
        check(POLICY_SCHEMA.endswith("V1_0"), "T12")
        check(len(WITHIN_FRAME_POLICIES) == 5, "T13")
        check("COUNT_UPDATES" not in WITHIN_FRAME_POLICIES, "T14")
        check(POLICY_COLUMNS[1] == "CanonicalName", "T15")
        check(PROGRAM_VERSION == "1.0.0", "T16")
    if checks != 16:
        raise AssertionError(f"SELFTEST_COUNT:{checks}")
    print("U001-H4-FRAME-POLICY-SELFTEST-PASS-16")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="U001 H4 frame-policy compiler")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--make-template", action="store_true")
    action.add_argument("--compile", action="store_true")
    result.add_argument("--h3-package", type=Path)
    result.add_argument("--policy", type=Path)
    result.add_argument("--out", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.h3_package is None or args.out is None:
            raise H4PolicyError("ARGUMENTS")
        if args.make_template:
            count = write_template(args.h3_package, args.out)
            print(f"U1H4PT-N{count}-X0-C0")
            return 0
        if args.policy is None:
            raise H4PolicyError("POLICY_ARGUMENT")
        quality = compile_policy(args.h3_package, args.policy, args.out)
        print(
            f"U1H4P-N{quality['PolicyRowCount']}-I{quality['IncludedSignalCount']}-"
            f"S{quality['StreamOnlySignalCount']}-X0-C0"
        )
        return 0
    except (H4PolicyError, H4ContractError, AssertionError, OSError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        print(f"U1H4PE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
