#!/usr/bin/env python3
"""Headless installed-source acceptance gate for the U3M8 Frame Mask Module."""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import tempfile
from pathlib import Path


MODULE_ID = "CameraRadar.U003.FrameMask"
MODULE_VERSION = "0.3.0"
ACTION_ID = "CREATE_MASKED_SCREENSHOT"


def load_module(path: Path):
    specification = importlib.util.spec_from_file_location("u003_u3m8_frame_mask_impl", path)
    if specification is None or specification.loader is None:
        raise RuntimeError("Frame Mask implementation could not be loaded.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def run_gate(root: Path) -> int:
    import numpy as np

    root = root.resolve()
    program_root = root / "01_PROGRAMS"
    module_root = root / "02_MODULES"
    if str(program_root) not in sys.path:
        sys.path.insert(0, str(program_root))
    import u003_module_plan_core_v0_2 as plan_core
    import u003_module_runtime_v0_2 as runtime
    import u003_module_action_gui_v0_1 as action_gui

    implementation_path = (
        module_root
        / "EVIDENCE_VIEW"
        / MODULE_ID
        / MODULE_VERSION
        / "implementation.py"
    )
    implementation = load_module(implementation_path)
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    check(root.name.upper() == "U-UDP003", "U003 root", "company topology is explicit")
    check((program_root / "u003_evidence_review_workbench_v0_19.py").is_file(), "U3M7 composition", "Frame Mask depends on the accepted Action interface")
    check(callable(action_gui.ModuleActionWindow._widgets_alive), "Action lifecycle guard", "closed Action windows are not refreshed after a blocking Module returns")
    catalog = runtime.discover_modules(module_root)
    descriptor = plan_core.find_descriptor(catalog, MODULE_ID, MODULE_VERSION)
    check(descriptor.module_slot == "EVIDENCE_VIEW", "module slot", "masking is review-evidence presentation, not analysis")
    check(descriptor.execution_kind == "PROCESS", "process isolation", "interactive GUI runs outside U003 core")
    check(descriptor.manifest_contract_version == "0.2", "manifest version", "UserAction declaration is explicit")
    check(len(descriptor.user_actions) == 1, "one action", "engineer sees one bounded operation")
    action = descriptor.user_actions[0]
    check(action.action_id == ACTION_ID, "action identity", "execution binds the expected behavior")
    check(action.timeout_seconds == 3600, "interactive timeout", "engineer has time to draw and review masks")
    check("CurrentFrameImagePath" in action.required_context_fields, "image context", "Module receives the exact reviewed frame")
    check("CurrentCANFrameCount" in action.required_context_fields, "FrameCount context", "output is traceable to CAN/video mapping")
    check("ProfileDirectory" in action.required_context_fields, "Profile context", "mask layout can be reused")
    check("MaskedScreenshotPath" in action.produced_fields, "masked output", "shareable artifact is explicit")
    check("OriginalScreenshotPath" in action.produced_fields, "original output", "unmodified evidence copy remains paired")
    check(not (set(action.produced_fields) & set(runtime.PROTECTED_FIELDS)), "protected boundary", "masking cannot change review decisions")

    rectangle = implementation.NormalizedRectangle(0.75, 0.8, 0.25, 0.2).normalized()
    check(rectangle.x0 == 0.25 and rectangle.x1 == 0.75, "coordinate normalization", "drag direction does not affect result")
    image = np.full((120, 200, 3), 173, dtype=np.uint8)
    masked = implementation.apply_black_masks(image, [rectangle])
    check(bool((masked[24:96, 50:150] == 0).all()), "mask pixels", "selected region becomes black")
    check(bool((masked[0:10, 0:10] == 173).all()), "outside pixels", "unselected evidence is unchanged")
    check(bool((image == 173).all()), "source immutable", "masking does not alter the input array")
    moved = implementation.move_rectangle(
        implementation.NormalizedRectangle(0.2, 0.2, 0.4, 0.4),
        0.9,
        -0.5,
    )
    check(moved == implementation.NormalizedRectangle(0.8, 0.0, 1.0, 0.2), "bounded move", "dragging preserves size and remains inside the image")
    resized = implementation.resize_rectangle(
        implementation.NormalizedRectangle(0.2, 0.2, 0.6, 0.6),
        "SE",
        0.9,
        0.8,
    )
    check(resized == implementation.NormalizedRectangle(0.2, 0.2, 0.9, 0.8), "corner resize", "selected geometry can be enlarged without redraw")

    with tempfile.TemporaryDirectory(prefix="u003_u3m8_gate_") as temporary:
        temporary_root = Path(temporary)
        profile_path = temporary_root / "profile.json"
        profile = implementation.profile_payload("gate", [rectangle], 200, 120)
        implementation.write_json_atomic(profile_path, profile)
        name, loaded = implementation.read_profile(profile_path)
        check(name == "gate", "Profile name", "engineer-defined identity is retained")
        check(loaded == [rectangle], "Profile round trip", "normalized regions reload exactly")
        original_path = temporary_root / "original.png"
        masked_path = temporary_root / "masked.png"
        implementation.write_rgb_image(original_path, image)
        implementation.write_rgb_image(masked_path, masked)
        check(original_path.is_file(), "original file", "image backend writes an evidence copy")
        check(masked_path.is_file(), "masked file", "image backend writes a shareable copy")
        loaded_original = implementation.load_rgb_image(original_path)
        loaded_masked = implementation.load_rgb_image(masked_path)
        check(bool((loaded_original == image).all()), "original round trip", "original image remains pixel-identical")
        check(bool((loaded_masked == masked).all()), "masked round trip", "black masks survive file serialization")

    card_path = Path(descriptor.algorithm_card_path)
    card = json.loads(card_path.read_text(encoding="utf-8-sig"))
    check("RealityMeaning" in card, "Algorithm Card reality", "engineer can understand operational meaning")
    check("The engineer remains responsible" in " ".join(card["Limitations"]), "human responsibility", "automatic masking is not treated as approval")
    check(implementation.PROFILE_VERSION == "0.2", "Profile version", "new interaction preferences are released without losing normalized geometry")
    legacy_profile = dict(profile)
    legacy_profile["ProfileVersion"] = "0.1"
    legacy_path = temporary_root / "legacy_profile.json"
    implementation.write_json_atomic(legacy_path, legacy_profile)
    legacy_name, legacy_rectangles = implementation.read_profile(legacy_path)
    check(legacy_name == "gate" and legacy_rectangles == [rectangle], "Profile compatibility", "v0.1 Profiles remain reusable")
    check(callable(implementation.MaskEditor.export_pair), "interactive export", "GUI can create paired artifacts")
    check(callable(implementation.MaskEditor.open_profile), "Profile load", "saved layouts are reusable")
    check(callable(implementation.MaskEditor.save_profile_as), "Profile save", "engineer can create named layouts")
    check(callable(implementation.MaskEditor.toggle_preview), "masked preview", "engineer can inspect the masked result before export")
    check(callable(implementation.MaskEditor.zoom_mousewheel), "Ctrl-wheel zoom", "small regions can be positioned precisely")
    check(callable(implementation.MaskEditor.browse_output_directory), "output selection", "artifact destination is engineer controlled")
    check(callable(implementation.MaskEditor.open_output_folder), "open output", "post-export review is one explicit option")
    source = implementation_path.read_text(encoding="utf-8")
    check("<Control-MouseWheel>" in source, "Windows zoom binding", "company workstation interaction is explicit")
    check("outline_width_var" in source, "outline control", "selection borders are thin by default and adjustable")
    check(callable(implementation.MaskEditor.hit_test_rectangle), "rectangle selection", "existing masks can be selected directly on the image")
    check(callable(implementation.MaskEditor.hit_test_handle), "resize handles", "selected masks expose draggable corner controls")
    check(callable(implementation.MaskEditor.record_history), "edit history", "destructive geometry changes preserve a bounded snapshot")
    check(callable(implementation.MaskEditor.undo), "undo", "Clear All and other edits can be reverted")
    check(callable(implementation.MaskEditor.redo), "redo", "an undone edit can be restored deliberately")
    check("<Control-z>" in source and "<Control-y>" in source, "history shortcuts", "standard keyboard recovery is available")
    print(f"U3M8G N-M1-A1-R1-P1-T{checks}-X0 C-0")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        return run_gate(arguments.root)
    except Exception as error:
        print(f"U3M8GE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
