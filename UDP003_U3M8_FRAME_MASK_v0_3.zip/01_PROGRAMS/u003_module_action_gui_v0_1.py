#!/usr/bin/env python3
"""Visual launcher for engineer-triggered actions in the active U003 Module Plan."""

from __future__ import annotations

import json
from typing import Any, Callable


ACTION_GUI_VERSION = "0.1"


class ModuleActionWindow:
    """List governed actions, explain them, and execute one explicit click."""

    def __init__(
        self,
        parent: Any,
        language: str,
        coordinator_provider: Callable[[], Any],
        context_provider: Callable[[Any], dict[str, Any]],
        on_completed: Callable[[Any], None] | None = None,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk
        from tkinter.scrolledtext import ScrolledText

        self.tk = tk
        self.ttk = ttk
        self.language = language.upper()
        self.coordinator_provider = coordinator_provider
        self.context_provider = context_provider
        self.on_completed = on_completed
        self.actions: list[Any] = []

        self.window = tk.Toplevel(parent)
        self.window.title(self._text("Module Actions", "モジュールアクション"))
        self.window.geometry("940x620")
        self.window.minsize(760, 500)
        self.window.protocol("WM_DELETE_WINDOW", self.window.withdraw)

        main = ttk.Frame(self.window, padding=10)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)

        header = ttk.Frame(main)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(
            header,
            text=self._text(
                "Actions are available only from exact Module versions in the active plan.",
                "アクティブプランで選択された正確なモジュール版のアクションのみ実行できます。",
            ),
        ).pack(side="left")
        ttk.Button(
            header,
            text=self._text("Refresh", "更新"),
            command=self.refresh,
        ).pack(side="right")

        body = ttk.Panedwindow(main, orient="horizontal")
        body.grid(row=1, column=0, sticky="nsew")

        list_panel = ttk.Frame(body)
        list_panel.columnconfigure(0, weight=1)
        list_panel.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(
            list_panel,
            columns=("slot", "module", "action"),
            show="headings",
            selectmode="browse",
        )
        for column, heading, width in (
            ("slot", self._text("Slot", "スロット"), 120),
            ("module", self._text("Module", "モジュール"), 230),
            ("action", self._text("Action", "アクション"), 210),
        ):
            self.tree.heading(column, text=heading)
            self.tree.column(column, width=width, anchor="w")
        scroll = ttk.Scrollbar(list_panel, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.tree.bind("<<TreeviewSelect>>", self._selection_changed)

        detail_panel = ttk.Frame(body, padding=(10, 0, 0, 0))
        detail_panel.columnconfigure(0, weight=1)
        detail_panel.rowconfigure(0, weight=1)
        self.detail = ScrolledText(detail_panel, wrap="word", height=15)
        self.detail.grid(row=0, column=0, sticky="nsew")
        self.detail.configure(state="disabled")
        self.run_button = ttk.Button(
            detail_panel,
            text=self._text("Run Selected Action", "選択したアクションを実行"),
            command=self.run_selected,
            state="disabled",
        )
        self.run_button.grid(row=1, column=0, sticky="e", pady=(8, 0))
        body.add(list_panel, weight=3)
        body.add(detail_panel, weight=2)

        self.status_var = tk.StringVar(value=self._text("Ready", "準備完了"))
        ttk.Label(main, textvariable=self.status_var, relief="sunken", anchor="w").grid(
            row=2, column=0, sticky="ew", pady=(8, 0)
        )
        self.refresh()

    def _text(self, english: str, japanese: str) -> str:
        return japanese if self.language == "JA" else english

    @staticmethod
    def _widget_exists(widget: Any) -> bool:
        """Return False when a blocking Module action outlives its GUI window."""

        try:
            return bool(widget.winfo_exists())
        except Exception:
            return False

    def _widgets_alive(self) -> bool:
        return self._widget_exists(self.window) and self._widget_exists(self.tree)

    def show(self) -> None:
        if not self._widgets_alive():
            return
        self.refresh()
        self.window.deiconify()
        self.window.lift()
        self.window.focus_force()

    def refresh(self) -> None:
        if not self._widgets_alive():
            return
        self.tree.delete(*self.tree.get_children())
        try:
            self.actions = list(self.coordinator_provider().available_actions())
            for index, action in enumerate(self.actions):
                self.tree.insert(
                    "",
                    "end",
                    iid=f"ACTION_{index}",
                    values=(
                        action.module_slot,
                        f"{action.module_id} v{action.module_version}",
                        action.display_name,
                    ),
                )
            self.status_var.set(
                self._text(
                    f"{len(self.actions)} qualified actions available",
                    f"実行可能なアクション: {len(self.actions)}件",
                )
            )
            self.run_button.configure(state="disabled")
            self._set_detail("")
        except Exception as error:
            self.actions = []
            self.status_var.set(f"ERROR: {error}")

    def _selected_action(self) -> Any:
        selected = self.tree.selection()
        if len(selected) != 1:
            raise RuntimeError(self._text("Select one action.", "アクションを1件選択してください。"))
        index = int(selected[0].split("_")[-1])
        return self.actions[index]

    def _selection_changed(self, _event: Any = None) -> None:
        try:
            action = self._selected_action()
            detail = "\n".join(
                [
                    action.display_name,
                    "",
                    action.description,
                    "",
                    f"Module: {action.module_id} v{action.module_version}",
                    f"ActionId: {action.action_id}",
                    f"Required context: {', '.join(action.required_context_fields) or 'None'}",
                    f"Produced fields: {', '.join(action.produced_fields) or 'None'}",
                    "",
                    self._text(
                        "Every click creates a new request, result and trace. No cached result is reused.",
                        "クリックするたびに新しいrequest、result、traceを生成し、キャッシュを再利用しません。",
                    ),
                ]
            )
            self._set_detail(detail)
            self.run_button.configure(state="normal")
        except Exception:
            self.run_button.configure(state="disabled")

    def _set_detail(self, text: str) -> None:
        if not self._widget_exists(self.detail):
            return
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        if text:
            self.detail.insert("1.0", text)
        self.detail.configure(state="disabled")

    def run_selected(self) -> None:
        from tkinter import messagebox

        try:
            action = self._selected_action()
            context = self.context_provider(action)
            run_id = str(context.pop("_RunId"))
            event_id = str(context.pop("_EventId"))
            self.run_button.configure(state="disabled")
            self.status_var.set(self._text("Running action…", "アクション実行中…"))
            self.window.update_idletasks()
            report = self.coordinator_provider().execute_user_action(
                module_id=action.module_id,
                action_id=action.action_id,
                run_id=run_id,
                event_id=event_id,
                context=context,
            )
            if not self._widgets_alive():
                if self.on_completed is not None:
                    self.on_completed(report)
                return
            visible = json.dumps(report.outputs, ensure_ascii=False, indent=2)
            self._set_detail(
                f"{action.display_name}\n\nStatus: {report.status}\n"
                f"Trace: {report.trace_path}\n\nOutputs\n{visible}"
            )
            self.status_var.set(
                self._text("Action completed successfully", "アクションが完了しました")
            )
            if self.on_completed is not None:
                self.on_completed(report)
            if not self._widgets_alive():
                return
            messagebox.showinfo(
                self._text("Module Action completed", "モジュールアクション完了"),
                self._text(
                    f"Action completed.\n\nTrace:\n{report.trace_path}",
                    f"アクションが完了しました。\n\nTrace:\n{report.trace_path}",
                ),
                parent=self.window,
            )
        except Exception as error:
            if self._widgets_alive():
                self.status_var.set(f"ERROR: {error}")
                messagebox.showerror(
                    self._text("Module Action error", "モジュールアクションエラー"),
                    str(error),
                    parent=self.window,
                )
        finally:
            if self._widgets_alive() and self._widget_exists(self.run_button):
                try:
                    if self.tree.selection():
                        self.run_button.configure(state="normal")
                except Exception:
                    # The parent may be destroyed between winfo_exists and the Tcl call.
                    pass


def run_self_test() -> int:
    checks = 0

    def check(condition: bool) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(f"check {checks + 1}")
        checks += 1

    check(ACTION_GUI_VERSION == "0.1")
    check(callable(ModuleActionWindow.refresh))
    check(callable(ModuleActionWindow.run_selected))
    check(callable(ModuleActionWindow._selected_action))
    check(callable(ModuleActionWindow._widget_exists))
    check(callable(ModuleActionWindow._widgets_alive))
    print(f"U003-U3M7-ACTION-GUI-SELFTEST-PASS-{checks} C-0")
    return 0


if __name__ == "__main__":
    raise SystemExit(run_self_test())
