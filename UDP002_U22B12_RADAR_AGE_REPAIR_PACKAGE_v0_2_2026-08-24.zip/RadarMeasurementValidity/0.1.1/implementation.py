#!/usr/bin/env python3
"""Governed runtime for one U22 B2 Module."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


MODE = 'RADAR'
MODULE_ID = 'CameraRadar.S1.RadarMeasurementValidity'
MODULE_VERSION = "0.1.1"
STAGE = 'S1'
ARTIFACT_TYPE = 'RADAR_VALIDITY'
REQUIRED_ARTIFACTS = ['U001_INTAKE_ACCEPTED']
CONTRACT_VERSION = "U22.0.1"
PROTOCOL = "U002_U22_MODULE_RUNTIME"
PROTOCOL_VERSION = "0.1"
FORMAL = "FORMAL_ELIGIBLE"
INVESTIGATION = "INVESTIGATION_ONLY"
INELIGIBLE = "INELIGIBLE"
OUTCOME_DIRECTION = "RADAR_MINUS_CAMERA"
OUTCOME_UNIT = "m"


class ModuleError(RuntimeError):
    """Represent one deterministic runtime failure."""


def stable(value: object) -> str:
    text = re.sub(r"[^A-Z0-9_]+", "_", str(value).upper())
    return text.strip("_")[:80] or "INTERNAL"


def canonical_bytes(value: object) -> bytes:
    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    return (text + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink()


def inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def load_json(path: Path, reason: str) -> Dict[str, object]:
    if not regular_file(path):
        raise ModuleError(reason + "_MISSING")
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise ModuleError(reason + "_JSON") from exc
    if not isinstance(value, dict):
        raise ModuleError(reason + "_TYPE")
    return value


def write_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + ".writing")
    temporary.write_bytes(canonical_bytes(value))
    os.replace(temporary, path)


def safe_relative(value: object, field: str) -> PurePosixPath:
    text = str(value)
    if "\\" in text:
        raise ModuleError(field + "_SEPARATOR")
    path = PurePosixPath(text)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ModuleError(field + "_PATH")
    return path


def parse_boolean(value: object, field: str) -> bool:
    text = str(value if value is not None else "").strip().lower()
    if text in {"true", "false"}:
        return text == "true"
    try:
        number = float(text)
    except ValueError as exc:
        raise ModuleError("BOOLEAN_" + field) from exc
    if not math.isfinite(number) or number not in {0.0, 1.0}:
        raise ModuleError("BOOLEAN_" + field)
    return number == 1.0


def parse_integer(value: object, field: str) -> int:
    try:
        number = float(str(value).strip())
    except ValueError as exc:
        raise ModuleError("INTEGER_" + field) from exc
    if not math.isfinite(number) or not number.is_integer():
        raise ModuleError("INTEGER_" + field)
    return int(number)


def parse_nullable_age(value: object, valid: bool, field: str) -> Optional[int]:
    """Parse one U001 age value using the coupled validity contract.

    A blank age is legal only when the corresponding signal is invalid because
    no valid upstream update may have existed yet.  It must remain null; it is
    never converted to zero.  Every nonblank age must still be a nonnegative
    integer, even when the signal is invalid.
    """
    text = str(value if value is not None else "").strip()
    if not text:
        if valid:
            raise ModuleError("VALID_AGE_MISSING_" + field)
        return None
    age = parse_integer(text, field)
    if age < 0:
        raise ModuleError("NEGATIVE_" + field)
    return age


def optional_float(value: object) -> Optional[float]:
    text = str(value if value is not None else "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except ValueError:
        return None
    return number if math.isfinite(number) else None


def blank(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, float):
        return format(value, ".12g")
    return value


def validate_request(request: Mapping[str, object]) -> None:
    expected = {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Stage": STAGE,
    }
    for field, expected_value in expected.items():
        if request.get(field) != expected_value:
            raise ModuleError("REQUEST_" + field.upper())
    if request.get("ExpectedOutputTypes") != [ARTIFACT_TYPE]:
        raise ModuleError("REQUEST_OUTPUT_TYPE")
    artifacts = request.get("InputArtifacts")
    if not isinstance(artifacts, list):
        raise ModuleError("REQUEST_INPUT_ARTIFACTS")
    observed = sorted(str(item.get("ArtifactType")) for item in artifacts)
    if observed != sorted(REQUIRED_ARTIFACTS):
        raise ModuleError("REQUEST_INPUT_ARTIFACT_TYPES")


def workspace_root_from_module(module_root: Path) -> Path:
    try:
        root = module_root.resolve().parents[4]
    except IndexError as exc:
        raise ModuleError("MODULE_ROOT_DEPTH") from exc
    if root.name != "U-UDP002":
        raise ModuleError("WORKSPACE_IDENTITY")
    return root


def artifact_record(request: Mapping[str, object], artifact_type: str) -> Mapping[str, object]:
    matches = [
        item for item in request["InputArtifacts"]
        if item.get("ArtifactType") == artifact_type
    ]
    if len(matches) != 1:
        raise ModuleError("ARTIFACT_COUNT_" + artifact_type)
    return matches[0]


def artifact_manifest(
    request: Mapping[str, object],
    artifact_type: str,
) -> Tuple[Path, Dict[str, object], Mapping[str, object]]:
    record = artifact_record(request, artifact_type)
    run_root = Path(str(request["RunRoot"])).resolve()
    relative = safe_relative(record.get("ManifestRelativePath"), "MANIFEST")
    path = run_root.joinpath(*relative.parts).resolve()
    if not regular_file(path) or not inside(path, run_root):
        raise ModuleError("MANIFEST_MISSING_" + artifact_type)
    if sha256_file(path) != record.get("ManifestSha256"):
        raise ModuleError("MANIFEST_HASH_" + artifact_type)
    manifest = load_json(path, "MANIFEST")
    if manifest.get("ArtifactId") != record.get("ArtifactId"):
        raise ModuleError("ARTIFACT_ID_" + artifact_type)
    if manifest.get("ArtifactType") != artifact_type:
        raise ModuleError("ARTIFACT_TYPE_" + artifact_type)
    return path.parent, manifest, record


def primary_csv(
    request: Mapping[str, object],
    artifact_type: str,
) -> Tuple[Path, str]:
    package_root, manifest, _ = artifact_manifest(request, artifact_type)
    candidates = [
        item for item in manifest.get("Payloads", [])
        if item.get("PayloadKind") == "PRIMARY"
        and item.get("MediaType") == "text/csv"
    ]
    if len(candidates) != 1:
        raise ModuleError("PRIMARY_CSV_COUNT_" + artifact_type)
    payload = candidates[0]
    relative = safe_relative(payload.get("RelativePath"), "PAYLOAD")
    path = package_root.joinpath(*relative.parts).resolve()
    if not regular_file(path) or not inside(path, package_root):
        raise ModuleError("PRIMARY_CSV_MISSING_" + artifact_type)
    if sha256_file(path) != payload.get("Sha256"):
        raise ModuleError("PRIMARY_CSV_HASH_" + artifact_type)
    return path, str(manifest["ArtifactId"])


def read_scope(run_root: Path, run_id: object) -> Tuple[Optional[int], Optional[int]]:
    plan = load_json(run_root / "00_CONFIG/resolved_run_plan.json", "RESOLVED_PLAN")
    if plan.get("RunId") != run_id:
        raise ModuleError("RESOLVED_PLAN_RUN_ID")
    scope = plan.get("RunScope")
    start = plan.get("FrameStart")
    end = plan.get("FrameEnd")
    if scope == "FULL_CASE":
        if start is not None or end is not None:
            raise ModuleError("RESOLVED_PLAN_FULL_SCOPE")
        return None, None
    if scope != "FRAME_RANGE" or not isinstance(start, int) or not isinstance(end, int) or start > end:
        raise ModuleError("RESOLVED_PLAN_SCOPE")
    return start, end


def find_frame_view(input_root: Path) -> Path:
    if not input_root.is_dir() or input_root.is_symlink():
        raise ModuleError("INPUT_PACKAGE_DIRECTORY")
    matches = sorted(
        path for path in input_root.rglob("u001_frame_values.csv")
        if regular_file(path)
    )
    if len(matches) != 1:
        raise ModuleError("FRAME_VIEW_COUNT")
    return matches[0]


def binding_profile(
    workspace_root: Path,
    configuration: Mapping[str, object],
) -> Dict[str, object]:
    required = {"BindingProfilePath", "BindingProfileSha256"}
    if set(configuration) != required:
        raise ModuleError("CONFIGURATION_SHAPE")
    relative = safe_relative(configuration["BindingProfilePath"], "BINDING_PROFILE")
    path = workspace_root.joinpath(*relative.parts).resolve()
    if not regular_file(path) or not inside(path, workspace_root):
        raise ModuleError("BINDING_PROFILE_MISSING")
    if sha256_file(path) != configuration["BindingProfileSha256"]:
        raise ModuleError("BINDING_PROFILE_HASH")
    profile = load_json(path, "BINDING_PROFILE")
    if profile.get("ContractVersion") != "U002_SIGNAL_BINDING_PROFILE_V0_1":
        raise ModuleError("BINDING_PROFILE_CONTRACT")
    if profile.get("DuplicateRoleCount") != 0 or profile.get("BlockingIssues") != []:
        raise ModuleError("BINDING_PROFILE_BLOCKING")
    return profile


def role_binding(profile: Mapping[str, object], role: str) -> Dict[str, object]:
    bindings = profile.get("Bindings")
    if not isinstance(bindings, dict):
        raise ModuleError("BINDINGS")
    selected = bindings.get(role)
    if not isinstance(selected, list) or len(selected) != 1:
        raise ModuleError("BINDING_COUNT_" + role)
    binding = dict(selected[0])
    name = str(binding.get("CanonicalName", "")).strip()
    if not name:
        raise ModuleError("BINDING_CANONICAL_" + role)
    if not parse_boolean(binding.get("IncludeInFrameView"), role + "_FRAME"):
        raise ModuleError("BINDING_NOT_IN_FRAME_" + role)
    maximum_age = parse_integer(binding.get("MaxAgeFrames"), role + "_MAX_AGE")
    if maximum_age < 0:
        raise ModuleError("BINDING_MAX_AGE_" + role)
    binding["CanonicalName"] = name
    binding["MaxAgeFramesParsed"] = maximum_age
    return binding


def radar_decision(
    distance: Optional[float],
    distance_valid: bool,
    distance_reason: str,
    distance_age: Optional[int],
    distance_max_age: int,
    flag_value: Optional[float],
    flag_valid: bool,
    flag_age: Optional[int],
    flag_max_age: int,
) -> Dict[str, object]:
    if not distance_valid or distance is None:
        suffix = ":" + distance_reason if distance_reason else ""
        return {
            "RadarMeasurementValid": False,
            "RadarValidityReason": "UPSTREAM_DISTANCE_INVALID" + suffix,
            "RadarEvidenceClass": "INVALID_MEASUREMENT",
            "RadarDetectionFlag": None,
        }
    if distance_age is None:
        raise ModuleError("VALID_AGE_MISSING_DISTANCE_AGE")
    if distance_age > distance_max_age:
        return {
            "RadarMeasurementValid": False,
            "RadarValidityReason": "STALE_DISTANCE",
            "RadarEvidenceClass": "INVALID_MEASUREMENT",
            "RadarDetectionFlag": None,
        }
    if not flag_valid or flag_value is None:
        return {
            "RadarMeasurementValid": False,
            "RadarValidityReason": "DETECTION_FLAG_INVALID",
            "RadarEvidenceClass": "INVALID_STATUS",
            "RadarDetectionFlag": None,
        }
    if flag_age is None:
        raise ModuleError("VALID_AGE_MISSING_FLAG_AGE")
    if flag_age > flag_max_age:
        return {
            "RadarMeasurementValid": False,
            "RadarValidityReason": "DETECTION_FLAG_INVALID",
            "RadarEvidenceClass": "INVALID_STATUS",
            "RadarDetectionFlag": None,
        }
    detected = parse_boolean(flag_value, "RADAR_DETECTION_FLAG")
    if not detected:
        return {
            "RadarMeasurementValid": False,
            "RadarValidityReason": "TARGET_NOT_DETECTED",
            "RadarEvidenceClass": "TARGET_LOSS_EVIDENCE",
            "RadarDetectionFlag": False,
        }
    return {
        "RadarMeasurementValid": True,
        "RadarValidityReason": "VALID_MEASUREMENT",
        "RadarEvidenceClass": "MEASUREMENT",
        "RadarDetectionFlag": True,
    }


def population_decision(
    radar_valid: bool,
    radar_class: str,
    camera_valid: bool,
    camera_status: str,
    camera_distance: Optional[float],
) -> Tuple[str, str]:
    confident = {"SEEDED", "CONFIDENT"}
    uncertain = {"ACQUIRING", "SWITCH_PENDING", "AMBIGUOUS", "SEGMENT_RESET"}
    if camera_valid and (camera_distance is None or camera_status not in confident):
        return INELIGIBLE, "CAMERA_CONTRACT_VIOLATION"
    if camera_valid and radar_valid:
        return FORMAL, "BOTH_MEASUREMENTS_VALID"
    if camera_valid and radar_class == "TARGET_LOSS_EVIDENCE":
        return INVESTIGATION, "RADAR_TARGET_LOSS_WITH_CAMERA_TRACK"
    if camera_status in uncertain and (radar_valid or radar_class == "TARGET_LOSS_EVIDENCE"):
        return INVESTIGATION, "CAMERA_SELECTION_UNCERTAIN"
    if camera_valid and radar_class in {"INVALID_MEASUREMENT", "INVALID_STATUS"}:
        return INVESTIGATION, "RADAR_DATA_INVALID_WITH_CAMERA_TRACK"
    if radar_valid and not camera_valid:
        return INVESTIGATION, "CAMERA_NOT_FORMAL_WITH_RADAR_MEASUREMENT"
    return INELIGIBLE, "NO_COMPARABLE_MEASUREMENT_PAIR"


def outcome_decision(
    eligibility: str,
    radar_distance: Optional[float],
    camera_distance: Optional[float],
) -> Tuple[Optional[float], bool]:
    if eligibility != FORMAL:
        return None, False
    if radar_distance is None or camera_distance is None:
        raise ModuleError("FORMAL_VALUE_MISSING")
    return radar_distance - camera_distance, True


def open_reader(path: Path, required: Sequence[str]) -> Tuple[object, csv.DictReader]:
    stream = path.open("r", encoding="utf-8-sig", newline="")
    reader = csv.DictReader(stream)
    header = reader.fieldnames or []
    missing = [name for name in required if name not in header]
    if missing:
        stream.close()
        raise ModuleError("CSV_COLUMN_" + missing[0])
    return stream, reader


def write_quality(path: Path, quality: Mapping[str, object]) -> None:
    write_json(path, quality)


def package_manifest(
    request: Mapping[str, object],
    package_root: Path,
    primary_path: Path,
    quality_path: Path,
    row_count: int,
    parent_ids: Sequence[str],
    metadata: Mapping[str, object],
) -> str:
    artifact_id = str(request["RunId"]) + "." + MODULE_ID + "." + str(request["Sequence"])
    payloads = [
        {
            "RelativePath": primary_path.name,
            "MediaType": "text/csv",
            "RowCount": row_count,
            "Sha256": sha256_file(primary_path),
            "ByteSize": primary_path.stat().st_size,
            "PayloadKind": "PRIMARY",
        },
        {
            "RelativePath": quality_path.name,
            "MediaType": "application/json",
            "RowCount": None,
            "Sha256": sha256_file(quality_path),
            "ByteSize": quality_path.stat().st_size,
            "PayloadKind": "AUXILIARY",
        },
    ]
    manifest = {
        "ContractVersion": CONTRACT_VERSION,
        "ArtifactId": artifact_id,
        "ArtifactType": ARTIFACT_TYPE,
        "SchemaId": "U002_" + ARTIFACT_TYPE,
        "SchemaVersion": "0.1",
        "RunId": request["RunId"],
        "Stage": STAGE,
        "ProducerModuleId": MODULE_ID,
        "ProducerModuleVersion": MODULE_VERSION,
        "ParentArtifactIds": list(parent_ids),
        "Payloads": payloads,
        "Metadata": dict(metadata),
    }
    write_json(package_root / "artifact_manifest.json", manifest)
    return artifact_id


def execute_radar(request: Mapping[str, object], package_root: Path) -> Dict[str, object]:
    module_root = Path(str(request["ModuleRoot"])).resolve()
    workspace_root = workspace_root_from_module(module_root)
    profile = binding_profile(workspace_root, request["Configuration"])
    distance_binding = role_binding(profile, "RADAR_DISTANCE")
    flag_binding = role_binding(profile, "RADAR_DETECTION_FLAG")
    frame_view = find_frame_view(Path(str(request["InputPackage"])).resolve())
    start, end = read_scope(Path(str(request["RunRoot"])), request["RunId"])
    distance_name = str(distance_binding["CanonicalName"])
    flag_name = str(flag_binding["CanonicalName"])
    required = ["FrameCount"]
    for name in (distance_name, flag_name):
        required.extend([name + "__value", name + "__age", name + "__valid", name + "__missing_reason"])
    output_columns = [
        "FrameCount", "RadarDistance", "RadarDistanceAge", "RadarDistanceUpstreamValid",
        "RadarDistanceMissingReason", "RadarDetectionFlag", "RadarDetectionFlagAge",
        "RadarDetectionFlagUpstreamValid", "RadarMeasurementValid", "RadarValidityReason",
        "RadarEvidenceClass",
    ]
    primary = package_root / "radar_validity.csv"
    source, reader = open_reader(frame_view, required)
    count = valid_count = target_loss_count = invalid_count = 0
    distance_invalid_blank_age_count = flag_invalid_blank_age_count = 0
    previous = None
    try:
        with primary.open("w", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=output_columns, lineterminator="\n")
            writer.writeheader()
            for row in reader:
                frame = parse_integer(row["FrameCount"], "FRAMECOUNT")
                if previous is not None and frame <= previous:
                    raise ModuleError("FRAME_ORDER")
                previous = frame
                if start is not None and frame < start:
                    continue
                if end is not None and frame > end:
                    continue
                distance_valid = parse_boolean(row[distance_name + "__valid"], "DISTANCE_VALID")
                distance = optional_float(row[distance_name + "__value"])
                distance_age = parse_nullable_age(
                    row[distance_name + "__age"], distance_valid, "DISTANCE_AGE"
                )
                distance_reason = str(row[distance_name + "__missing_reason"]).strip()
                flag_valid = parse_boolean(row[flag_name + "__valid"], "FLAG_VALID")
                flag_value = optional_float(row[flag_name + "__value"])
                flag_age = parse_nullable_age(
                    row[flag_name + "__age"], flag_valid, "FLAG_AGE"
                )
                if distance_valid and distance is None:
                    raise ModuleError("VALID_VALUE_MISSING_DISTANCE")
                if flag_valid and flag_value is None:
                    raise ModuleError("VALID_VALUE_MISSING_FLAG")
                decision = radar_decision(
                    distance, distance_valid, distance_reason, distance_age,
                    int(distance_binding["MaxAgeFramesParsed"]), flag_value,
                    flag_valid, flag_age, int(flag_binding["MaxAgeFramesParsed"]),
                )
                writer.writerow({
                    "FrameCount": frame,
                    "RadarDistance": blank(distance),
                    "RadarDistanceAge": blank(distance_age),
                    "RadarDistanceUpstreamValid": int(distance_valid),
                    "RadarDistanceMissingReason": distance_reason,
                    "RadarDetectionFlag": blank(decision["RadarDetectionFlag"]),
                    "RadarDetectionFlagAge": blank(flag_age),
                    "RadarDetectionFlagUpstreamValid": int(flag_valid),
                    "RadarMeasurementValid": int(bool(decision["RadarMeasurementValid"])),
                    "RadarValidityReason": decision["RadarValidityReason"],
                    "RadarEvidenceClass": decision["RadarEvidenceClass"],
                })
                count += 1
                valid_count += int(bool(decision["RadarMeasurementValid"]))
                target_loss_count += decision["RadarEvidenceClass"] == "TARGET_LOSS_EVIDENCE"
                invalid_count += not bool(decision["RadarMeasurementValid"])
                distance_invalid_blank_age_count += int(
                    not distance_valid and distance_age is None
                )
                flag_invalid_blank_age_count += int(
                    not flag_valid and flag_age is None
                )
    finally:
        source.close()
    if count == 0:
        raise ModuleError("FRAME_RANGE_EMPTY")
    parent = artifact_record(request, "U001_INTAKE_ACCEPTED")
    quality = {
        "Contract": "U002_RADAR_VALIDITY_QUALITY_V0_1",
        "FrameRows": count,
        "RadarValidRows": valid_count,
        "RadarInvalidRows": invalid_count,
        "RadarTargetLossEvidenceRows": target_loss_count,
        "HardcodedNumericInvalidValues": False,
        "UpstreamValidityAuthoritative": True,
        "RadarDistanceInvalidBlankAgeRows": distance_invalid_blank_age_count,
        "RadarDetectionFlagInvalidBlankAgeRows": flag_invalid_blank_age_count,
        "BlankAgeZeroFilled": False,
        "NullableAgeCoupledState": True,
    }
    quality_path = package_root / "radar_validity_quality.json"
    write_quality(quality_path, quality)
    package_manifest(
        request, package_root, primary, quality_path, count,
        [str(parent["ArtifactId"])], quality,
    )
    return quality


def execute_population(request: Mapping[str, object], package_root: Path) -> Dict[str, object]:
    camera_path, camera_parent = primary_csv(request, "CAMERA_TARGET_RECONSTRUCTION")
    radar_path, radar_parent = primary_csv(request, "RADAR_VALIDITY")
    camera_required = [
        "FrameCount", "CanonicalCameraDistance", "CanonicalCameraValid",
        "SelectionStatus", "SelectionReason",
    ]
    radar_required = [
        "FrameCount", "RadarDistance", "RadarDetectionFlag", "RadarMeasurementValid",
        "RadarValidityReason", "RadarEvidenceClass",
    ]
    camera_stream, camera_reader = open_reader(camera_path, camera_required)
    radar_stream, radar_reader = open_reader(radar_path, radar_required)
    output_columns = [
        "FrameCount", "RadarDistance", "RadarDetectionFlag", "RadarMeasurementValid",
        "RadarValidityReason", "RadarEvidenceClass", "CanonicalCameraDistance",
        "CanonicalCameraValid", "CameraSelectionStatus", "CameraSelectionReason",
        "ComparisonEligibility", "EligibilityReason",
    ]
    primary = package_root / "comparison_population.csv"
    counts = {FORMAL: 0, INVESTIGATION: 0, INELIGIBLE: 0}
    rows = 0
    try:
        with primary.open("w", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=output_columns, lineterminator="\n")
            writer.writeheader()
            pairs = itertools.zip_longest(camera_reader, radar_reader)
            for camera_row, radar_row in pairs:
                if camera_row is None or radar_row is None:
                    raise ModuleError("FRAME_ROW_COUNT_MISMATCH")
                camera_frame = parse_integer(camera_row["FrameCount"], "CAMERA_FRAME")
                radar_frame = parse_integer(radar_row["FrameCount"], "RADAR_FRAME")
                if camera_frame != radar_frame:
                    raise ModuleError("FRAME_ALIGNMENT")
                camera_distance = optional_float(camera_row["CanonicalCameraDistance"])
                camera_valid = parse_boolean(camera_row["CanonicalCameraValid"], "CAMERA_VALID")
                camera_status = str(camera_row["SelectionStatus"]).strip().upper()
                radar_distance = optional_float(radar_row["RadarDistance"])
                radar_valid = parse_boolean(radar_row["RadarMeasurementValid"], "RADAR_VALID")
                radar_class = str(radar_row["RadarEvidenceClass"]).strip().upper()
                eligibility, reason = population_decision(
                    radar_valid, radar_class, camera_valid, camera_status, camera_distance,
                )
                writer.writerow({
                    "FrameCount": camera_frame,
                    "RadarDistance": blank(radar_distance),
                    "RadarDetectionFlag": radar_row["RadarDetectionFlag"],
                    "RadarMeasurementValid": int(radar_valid),
                    "RadarValidityReason": radar_row["RadarValidityReason"],
                    "RadarEvidenceClass": radar_class,
                    "CanonicalCameraDistance": blank(camera_distance),
                    "CanonicalCameraValid": int(camera_valid),
                    "CameraSelectionStatus": camera_status,
                    "CameraSelectionReason": camera_row["SelectionReason"],
                    "ComparisonEligibility": eligibility,
                    "EligibilityReason": reason,
                })
                counts[eligibility] += 1
                rows += 1
    finally:
        camera_stream.close()
        radar_stream.close()
    if rows == 0:
        raise ModuleError("POPULATION_EMPTY")
    quality = {
        "Contract": "U002_COMPARISON_POPULATION_QUALITY_V0_1",
        "FrameRows": rows,
        "FormalEligibleRows": counts[FORMAL],
        "InvestigationOnlyRows": counts[INVESTIGATION],
        "IneligibleRows": counts[INELIGIBLE],
        "ThreeLanePolicy": True,
        "GroundTruthClaim": False,
    }
    quality_path = package_root / "comparison_population_quality.json"
    write_quality(quality_path, quality)
    package_manifest(
        request, package_root, primary, quality_path, rows,
        [camera_parent, radar_parent], quality,
    )
    return quality


def execute_outcome(request: Mapping[str, object], package_root: Path) -> Dict[str, object]:
    population_path, parent = primary_csv(request, "COMPARISON_POPULATION")
    required = [
        "FrameCount", "RadarDistance", "CanonicalCameraDistance",
        "ComparisonEligibility", "EligibilityReason", "RadarValidityReason",
        "CameraSelectionStatus",
    ]
    source, reader = open_reader(population_path, required)
    output_columns = [
        "FrameCount", "RadarDistance", "CanonicalCameraDistance",
        "ComparisonEligibility", "EligibilityReason", "RadarValidityReason",
        "CameraSelectionStatus", "CameraRadarDiscrepancy", "OutcomeValid",
        "OutcomeDirection", "OutcomeUnit",
    ]
    primary = package_root / "primary_outcome.csv"
    rows = valid_rows = 0
    try:
        with primary.open("w", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=output_columns, lineterminator="\n")
            writer.writeheader()
            for row in reader:
                frame = parse_integer(row["FrameCount"], "FRAMECOUNT")
                radar_distance = optional_float(row["RadarDistance"])
                camera_distance = optional_float(row["CanonicalCameraDistance"])
                eligibility = str(row["ComparisonEligibility"]).strip()
                discrepancy, outcome_valid = outcome_decision(
                    eligibility, radar_distance, camera_distance,
                )
                writer.writerow({
                    "FrameCount": frame,
                    "RadarDistance": blank(radar_distance),
                    "CanonicalCameraDistance": blank(camera_distance),
                    "ComparisonEligibility": eligibility,
                    "EligibilityReason": row["EligibilityReason"],
                    "RadarValidityReason": row["RadarValidityReason"],
                    "CameraSelectionStatus": row["CameraSelectionStatus"],
                    "CameraRadarDiscrepancy": blank(discrepancy),
                    "OutcomeValid": int(outcome_valid),
                    "OutcomeDirection": OUTCOME_DIRECTION,
                    "OutcomeUnit": OUTCOME_UNIT,
                })
                rows += 1
                valid_rows += int(outcome_valid)
    finally:
        source.close()
    if rows == 0:
        raise ModuleError("OUTCOME_EMPTY")
    quality = {
        "Contract": "U002_PRIMARY_OUTCOME_QUALITY_V0_1",
        "FrameRows": rows,
        "OutcomeValidRows": valid_rows,
        "OutcomeInvalidRows": rows - valid_rows,
        "OutcomeFormula": "RadarDistance-CanonicalCameraDistance",
        "OutcomeDirection": OUTCOME_DIRECTION,
        "OutcomeUnit": OUTCOME_UNIT,
        "RadarIsGroundTruth": False,
        "BaselineApplied": False,
        "ZeroFillApplied": False,
    }
    quality_path = package_root / "primary_outcome_quality.json"
    write_quality(quality_path, quality)
    package_manifest(request, package_root, primary, quality_path, rows, [parent], quality)
    return quality


def runtime_result(request: Mapping[str, object], quality: Mapping[str, object]) -> Dict[str, object]:
    rows = int(quality["FrameRows"])
    if MODE == "RADAR":
        detail = "-V" + str(quality["RadarValidRows"]) + "-L" + str(quality["RadarTargetLossEvidenceRows"])
    elif MODE == "POPULATION":
        detail = "-F" + str(quality["FormalEligibleRows"]) + "-I" + str(quality["InvestigationOnlyRows"])
    else:
        detail = "-O" + str(quality["OutcomeValidRows"])
    return {
        "Protocol": PROTOCOL,
        "ProtocolVersion": PROTOCOL_VERSION,
        "ContractVersion": CONTRACT_VERSION,
        "RunId": request["RunId"],
        "Sequence": request["Sequence"],
        "Stage": request["Stage"],
        "ModuleId": MODULE_ID,
        "ModuleVersion": MODULE_VERSION,
        "Status": "SUCCEEDED",
        "ProducedPackages": ["artifact_01"],
        "Capsule": "B2BM-" + MODE[0] + " N-R" + str(rows) + detail + "-X0 C-0",
        "Diagnostics": [],
    }


def execute(request: Mapping[str, object]) -> Dict[str, object]:
    output_root = Path(str(request["OutputRoot"])).resolve()
    package_root = output_root / "artifact_01"
    package_root.mkdir(parents=True)
    if MODE == "RADAR":
        quality = execute_radar(request, package_root)
    elif MODE == "POPULATION":
        if request["Configuration"] != {}:
            raise ModuleError("CONFIGURATION_NOT_EMPTY")
        quality = execute_population(request, package_root)
    elif MODE == "OUTCOME":
        if request["Configuration"] != {}:
            raise ModuleError("CONFIGURATION_NOT_EMPTY")
        quality = execute_outcome(request, package_root)
    else:
        raise ModuleError("MODE")
    return runtime_result(request, quality)


def semantic_selftest() -> int:
    checks = []
    def ck(value: bool) -> None:
        if not value:
            raise AssertionError("SEMANTIC_SELFTEST")
        checks.append(True)
    valid = radar_decision(12.0, True, "", 0, 1, 1.0, True, 0, 1)
    loss = radar_decision(11.5, True, "", 0, 1, 0.0, True, 0, 1)
    invalid = radar_decision(327.66, False, "INVALID_DEFAULT", 0, 1, 1.0, True, 0, 1)
    ck(valid["RadarMeasurementValid"] is True)
    ck(loss["RadarEvidenceClass"] == "TARGET_LOSS_EVIDENCE")
    ck(invalid["RadarMeasurementValid"] is False)
    ck(population_decision(True, "MEASUREMENT", True, "CONFIDENT", 10.0)[0] == FORMAL)
    ck(population_decision(False, "TARGET_LOSS_EVIDENCE", True, "CONFIDENT", 10.0)[0] == INVESTIGATION)
    ck(population_decision(False, "INVALID_MEASUREMENT", False, "INVALID", None)[0] == INELIGIBLE)
    ck(outcome_decision(FORMAL, 12.0, 10.0) == (2.0, True))
    ck(outcome_decision(INVESTIGATION, 0.0, 10.0) == (None, False))
    ck(parse_boolean("0.0", "T") is False)
    ck(parse_boolean("1", "T") is True)
    ck(optional_float("") is None)
    ck(OUTCOME_DIRECTION == "RADAR_MINUS_CAMERA")
    ck(parse_nullable_age("", False, "T") is None)
    ck(parse_nullable_age("0", False, "T") == 0)
    ck(parse_nullable_age("0", True, "T") == 0)

    invalid_age_values = ["", "-1", "1.5", "bad", "nan"]
    expected_reasons = [
        "VALID_AGE_MISSING_T",
        "NEGATIVE_T",
        "INTEGER_T",
        "INTEGER_T",
        "INTEGER_T",
    ]
    observed_reasons = []
    for index, value in enumerate(invalid_age_values):
        try:
            parse_nullable_age(value, index == 0, "T")
        except ModuleError as exc:
            observed_reasons.append(str(exc))
    ck(observed_reasons == expected_reasons)

    invalid_blank_distance = radar_decision(
        None, False, "NO_UPDATE", None, 1, 1.0, True, 0, 1
    )
    invalid_blank_flag = radar_decision(
        12.0, True, "", 0, 1, None, False, None, 1
    )
    ck(invalid_blank_distance["RadarMeasurementValid"] is False)
    ck(invalid_blank_flag["RadarEvidenceClass"] == "INVALID_STATUS")

    missing_distance_age_rejected = missing_flag_age_rejected = False
    try:
        radar_decision(12.0, True, "", None, 1, 1.0, True, 0, 1)
    except ModuleError as exc:
        missing_distance_age_rejected = str(exc) == "VALID_AGE_MISSING_DISTANCE_AGE"
    try:
        radar_decision(12.0, True, "", 0, 1, 1.0, True, None, 1)
    except ModuleError as exc:
        missing_flag_age_rejected = str(exc) == "VALID_AGE_MISSING_FLAG_AGE"
    ck(missing_distance_age_rejected)
    ck(missing_flag_age_rejected)
    ck(blank(parse_nullable_age("", False, "T")) == "")
    ck(parse_nullable_age("2", False, "T") == 2)
    ck(parse_nullable_age("2", True, "T") == 2)
    ck(radar_decision(12.0, True, "", 2, 1, 1.0, True, 0, 1)["RadarValidityReason"] == "STALE_DISTANCE")
    if len(checks) != 24:
        raise AssertionError("SELFTEST_COUNT")
    return len(checks)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request-json", required=True)
    parser.add_argument("--result-json", required=True)
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        request = load_json(Path(args.request_json), "REQUEST")
        validate_request(request)
        result = execute(request)
        write_json(Path(args.result_json), result)
        print(result["Capsule"])
        return 0
    except Exception as exc:
        print("B2BME-" + MODE[0] + " K-" + stable(exc) + "-X1 C-7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
