#!/usr/bin/env python3
"""Independent black-box acceptance for U001 H4A raw Frame View."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any


PROGRAM_NAME = "u001_h4a_raw_frame_view_acceptance"
PROGRAM_VERSION = "1.0.0"


class H4AcceptanceError(RuntimeError):
    """Independent H4A acceptance error."""


def _load(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise H4AcceptanceError(f"IMPORT_SPEC:{path.name}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _write_policy(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate(
    h4_core_dir: Path,
    h3_core_dir: Path,
    h3_acceptance_path: Path,
    output_root: Path,
) -> dict[str, Any]:
    output_root.mkdir(parents=True, exist_ok=False)
    required_h4 = [
        "u001_h4_contract_core_v1_0.py",
        "u001_h4_frame_policy_compiler_v1_0.py",
        "u001_h4_raw_frame_view_builder_v1_0.py",
    ]
    missing = [name for name in required_h4 if not (h4_core_dir / name).is_file()]
    if missing or not h3_acceptance_path.is_file():
        raise H4AcceptanceError(f"PROGRAM_FILESET:{missing}")
    for folder in (h4_core_dir, h3_core_dir):
        if str(folder.resolve()) not in sys.path:
            sys.path.insert(0, str(folder.resolve()))

    contract = _load(h4_core_dir / required_h4[0], "u1h4_accept_contract")
    policy = _load(h4_core_dir / required_h4[1], "u1h4_accept_policy")
    builder = _load(h4_core_dir / required_h4[2], "u1h4_accept_builder")
    h3_acceptance = _load(h3_acceptance_path, "u1h4_accept_h3_gate")

    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise H4AcceptanceError(label)
        checks += 1

    contract.self_test()
    policy.self_test()
    builder.self_test()
    check(True, "T01_COMPONENT_SELFTESTS")

    h3_root = output_root / "h3_acceptance"
    h3_receipt = h3_acceptance.validate(h3_core_dir, h3_root)
    check(h3_receipt["Status"] == "PASS", "T02_H3_ACCEPTANCE")
    h3_package = h3_root / "run_a"
    h3_source = h3_package / "u001_h3_canonical_updates.csv"
    source_hash = contract.sha256_file(h3_source)

    template = output_root / "frame_policy_template.csv"
    template_count = policy.write_template(h3_package, template)
    template_rows = _read_csv(template)
    check(template_count == len(template_rows) == 3, "T03_TEMPLATE")
    check(all(row["PolicyStatus"] == "PROVISIONAL" for row in template_rows), "T04_TEMPLATE_PROVISIONAL")
    for row in template_rows:
        row["PolicyStatus"] = "APPROVED"
    approved = output_root / "approved_frame_policy.csv"
    _write_policy(approved, template_rows)

    compiled_dir = output_root / "compiled_policy"
    compiled_quality = policy.compile_policy(h3_package, approved, compiled_dir)
    compiled_policy = compiled_dir / policy.COMPILED_POLICY_FILE
    check(compiled_quality["Status"] == "COMPILED", "T05_POLICY_COMPILED")
    check(compiled_quality["IncludedSignalCount"] == 2, "T06_INCLUDED_SIGNALS")
    check(compiled_quality["StreamOnlySignalCount"] == 1, "T07_STREAM_ONLY_FRAME_KEY")

    run_a = output_root / "run_a"
    quality_a = builder.build_raw_frame_view(h3_package, compiled_policy, run_a)
    frame_rows = _read_csv(run_a / builder.OUTPUT_FRAME_VIEW)
    check(quality_a["OutputFrameRowCount"] == 2, "T08_FRAME_COUNT")
    check([row["FrameCount"] for row in frame_rows] == ["100", "101"], "T09_FRAME_ORDER")
    check(len({row["FrameCount"] for row in frame_rows}) == 2, "T10_FRAME_UNIQUE")
    check(frame_rows[0]["DIST__value"] == "327.66" and frame_rows[0]["DIST__valid"] == "0", "T11_LAST_INVALID_PRESERVED")
    check(frame_rows[1]["FLAG__updated"] == "0" and frame_rows[1]["FLAG__missing_reason"] == "NO_UPDATE", "T12_EXPLICIT_NO_UPDATE")
    check(quality_a["CrossFrameHeldCellCount"] == 0 and quality_a["ZeroFillCount"] == 0, "T13_NO_HOLD_ZERO_FILL")
    check(quality_a["WholeFileMemoryLoadRequired"] is False, "T14_STREAMING_MEMORY")
    check(source_hash == contract.sha256_file(h3_source), "T15_SOURCE_IMMUTABLE")

    run_b = output_root / "run_b"
    builder.build_raw_frame_view(h3_package, compiled_policy, run_b)
    check(
        contract.sha256_file(run_a / builder.OUTPUT_FRAME_VIEW)
        == contract.sha256_file(run_b / builder.OUTPUT_FRAME_VIEW),
        "T16_DETERMINISTIC",
    )

    provisional = [dict(row) for row in template_rows]
    provisional[1]["PolicyStatus"] = "PROVISIONAL"
    provisional_path = output_root / "provisional_policy.csv"
    _write_policy(provisional_path, provisional)
    try:
        policy.compile_policy(h3_package, provisional_path, output_root / "provisional_compile")
    except Exception as exc:
        check("NOT_APPROVED" in str(exc), "T17_PROVISIONAL_BLOCKED")
    else:
        raise H4AcceptanceError("T17_PROVISIONAL_BLOCKED")

    tampered = output_root / "tampered_h3"
    shutil.copytree(h3_package, tampered)
    with (tampered / "u001_h3_canonical_updates.csv").open("a", encoding="utf-8") as stream:
        stream.write("\n")
    try:
        builder.build_raw_frame_view(tampered, compiled_policy, output_root / "tampered_run")
    except Exception as exc:
        check("IDENTITY" in str(exc), "T18_H3_HASH_BLOCKED")
    else:
        raise H4AcceptanceError("T18_H3_HASH_BLOCKED")

    if checks != 18:
        raise H4AcceptanceError(f"CHECK_COUNT:{checks}")
    receipt = {
        "AcceptanceSchema": "U001_H4A_RAW_FRAME_VIEW_ACCEPTANCE_V1_0",
        "ProgramName": PROGRAM_NAME,
        "ProgramVersion": PROGRAM_VERSION,
        "CheckCount": checks,
        "FrameCount": quality_a["OutputFrameRowCount"],
        "IncludedSignalCount": quality_a["IncludedSignalCount"],
        "CrossFrameHeldCellCount": 0,
        "ZeroFillCount": 0,
        "Status": "PASS",
        "CompletionCode": 0,
    }
    (output_root / "u001_h4a_acceptance_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8"
    )
    (output_root / "u001_h4a_acceptance_capsule.txt").write_text(
        f"U1H4AQ-T{checks}-F{receipt['FrameCount']}-I{receipt['IncludedSignalCount']}-H0-Z0-X0-C0\n",
        encoding="utf-8",
    )
    return receipt


def self_test() -> None:
    root = Path(__file__).resolve().parents[2]
    h4_core = root / "01_PROGRAMS" / "core"
    h3_core = h4_core
    h3_acceptance = root / "05_TESTS" / "tools" / "u001_h3_sync_semantic_acceptance_v1_0.py"
    with tempfile.TemporaryDirectory(prefix="u001_h4a_acceptance_") as temporary:
        receipt = validate(h4_core, h3_core, h3_acceptance, Path(temporary) / "acceptance")
        if receipt["Status"] != "PASS" or receipt["CheckCount"] != 18:
            raise AssertionError("ACCEPTANCE_RECEIPT")
    print("U001-H4A-RAW-FRAME-ACCEPTANCE-SELFTEST-PASS-18")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Independently qualify U001 H4A")
    action = result.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--validate", action="store_true")
    result.add_argument("--h4-core-dir", type=Path)
    result.add_argument("--h3-core-dir", type=Path)
    result.add_argument("--h3-acceptance", type=Path)
    result.add_argument("--output", type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if any(value is None for value in (args.h4_core_dir, args.h3_core_dir, args.h3_acceptance, args.output)):
            raise H4AcceptanceError("ARGUMENTS")
        receipt = validate(args.h4_core_dir, args.h3_core_dir, args.h3_acceptance, args.output)
        print(f"U1H4AQ-T{receipt['CheckCount']}-F{receipt['FrameCount']}-I{receipt['IncludedSignalCount']}-H0-Z0-X0-C0")
        return 0
    except (H4AcceptanceError, AssertionError, OSError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        print(f"U1H4AQE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7")
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
