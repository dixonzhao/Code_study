#!/usr/bin/env python3
"""Independent acceptance gate for FrameMask v0.5.0 external-image support."""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


MODULE_ID = "CameraRadar.U003.FrameMask"
MODULE_VERSION = "0.5.0"
MODULE_SELFTEST = "U3M10A-MODULE-SELFTEST-PASS-28 C-0"


class GateError(RuntimeError):
    """Raised when the new Action is not independently installable or traceable."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise GateError(message)


def import_path(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    require(spec is not None and spec.loader is not None, f"Cannot import {path.name}.")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def run_gate(root: Path, module_dir: Path) -> int:
    root = root.resolve()
    module_dir = module_dir.resolve()
    runtime_path = root / "01_PROGRAMS" / "u003_module_runtime_v0_2.py"
    required = (
        runtime_path,
        module_dir / "implementation.py",
        module_dir / "module_manifest.json",
        module_dir / "algorithm_card.json",
    )
    for path in required:
        require(path.is_file(), f"Required artifact is missing: {path}")

    manifest = json.loads((module_dir / "module_manifest.json").read_text(encoding="utf-8"))
    card = json.loads((module_dir / "algorithm_card.json").read_text(encoding="utf-8"))
    require(manifest["ModuleId"] == MODULE_ID, "ModuleId differs.")
    require(manifest["ModuleVersion"] == MODULE_VERSION, "ModuleVersion differs.")
    actions = {item["ActionId"]: item for item in manifest["UserActions"]}
    require(set(actions) == {"EXPORT_REDACTED_EVIDENCE", "MASK_EXTERNAL_IMAGE"}, "Action inventory differs.")
    external = actions["MASK_EXTERNAL_IMAGE"]
    require(
        external["RequiredContextFields"] == ["OutputDirectory", "ProfileDirectory"],
        "Standalone Action must not require video, FrameCount or live context.",
    )
    require(card["AlgorithmCardId"].endswith("0.5.0"), "Algorithm Card version differs.")

    runtime = import_path(runtime_path, "u3m10a_runtime")
    descriptor = runtime.validate_module_manifest(
        module_dir / "module_manifest.json",
        module_dir.parents[2],
    )
    require(descriptor.module_id == MODULE_ID, "Runtime discovery rejected ModuleId.")
    require(len(descriptor.user_actions) == 2, "Runtime did not discover both Actions.")

    implementation_path = module_dir / "implementation.py"
    child = subprocess.run(
        [sys.executable, str(implementation_path), "--self-test"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
        check=False,
    )
    require(child.returncode == 0, f"Module self-test failed: {child.stderr[-500:]}")
    require(MODULE_SELFTEST in child.stdout, "Expected Module self-test capsule is missing.")

    implementation = import_path(implementation_path, "u3m10a_implementation")
    with tempfile.TemporaryDirectory(prefix="u3m10a_gate_") as temporary:
        temporary_root = Path(temporary)
        source_path = temporary_root / "historical_case.jpg"
        source_path.write_bytes(b"gate-fixture-path-only")
        captured: dict[str, Any] = {}

        class FakeEditor:
            def __init__(self, **kwargs: Any) -> None:
                captured.update(kwargs)

            def run(self) -> dict[str, Any]:
                return {
                    "ArtifactPaths": [str(temporary_root / "masked.png")],
                    "OriginalScreenshotPath": str(temporary_root / "original.png"),
                    "MaskedScreenshotPath": str(temporary_root / "masked.png"),
                    "MaskProfilePath": str(temporary_root / "profile.json"),
                    "ExportCount": 1,
                    "ExportRecords": [
                        {
                            "SourceMode": "EXTERNAL_IMAGE",
                            "SourceImagePath": str(source_path),
                            "FrameCount": None,
                        }
                    ],
                    "ActionSummary": "standalone gate",
                }

        implementation.choose_external_image = lambda _language, _initial: source_path
        implementation.load_rgb_image = lambda _path: object()
        implementation.MaskEditor = FakeEditor
        request_path = temporary_root / "request.json"
        result_path = temporary_root / "result.json"
        request = {
            "ContractId": "U003_MODULE_ACTION_REQUEST",
            "ContractVersion": "0.1",
            "RequestId": "GATE_REQUEST",
            "RunId": "GATE_RUN",
            "EventId": "NO_EVENT",
            "ActionId": "MASK_EXTERNAL_IMAGE",
            "ModuleId": MODULE_ID,
            "ModuleVersion": MODULE_VERSION,
            "Language": "EN",
            "Context": {
                "OutputDirectory": str(temporary_root / "out"),
                "ProfileDirectory": str(temporary_root / "profiles"),
            },
        }
        request_path.write_text(json.dumps(request), encoding="utf-8")
        require(implementation.execute(request_path, result_path) == 0, "Standalone execute failed.")
        result = json.loads(result_path.read_text(encoding="utf-8"))
        require(result["Status"] == "SUCCESS", "Standalone result was not SUCCESS.")
        require(captured["source_mode"] == "EXTERNAL_IMAGE", "Source mode differs.")
        require(captured["framecount"] is None, "Standalone mode invented FrameCount.")
        require(captured["live_context_path"] is None, "Standalone mode retained live context.")
        record = result["Outputs"]["ExportRecords"][0]
        require(record["FrameCount"] is None, "Standalone record invented FrameCount.")

    print("U3M10AG N-M1-A2-R1-E1-F0-X0 C-0")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--module-dir", type=Path, required=True)
    arguments = parser.parse_args()
    return run_gate(arguments.root, arguments.module_dir)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M10AGE K-{type(error).__name__.upper()} D-{error} X1 C-7")
        raise SystemExit(7)
