#!/usr/bin/env python3
"""Independent black-box acceptance gate for the U001 H2 source adapter."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


EXPECTED_ADAPTER_ID = "CameraRadar.U001.MatlabCanCsvDbc"
EXPECTED_VERSION = "1.0.0"
EXPECTED_FILES = {
    "u001_adapter_source_updates.csv",
    "u001_adapter_signal_catalog.csv",
    "u001_adapter_quality.json",
    "u001_adapter_run_manifest.json",
    "u001_adapter_completion_capsule.txt",
}


class AcceptanceError(RuntimeError):
    """Fail-closed acceptance error."""


def _run(command: list[str], timeout: int = 90) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True, timeout=timeout, check=False)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip().replace("\n", " | ")[:600]
        raise AcceptanceError(f"CHILD_EXIT:{result.returncode}:{detail}")
    return result


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AcceptanceError(f"JSON_OBJECT:{path.name}")
    return value


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _fixture(root: Path) -> tuple[Path, Path, Path]:
    source = root / "CANDump.csv"
    dbc1 = root / "DBC1.dbc"
    dbc2 = root / "DBC2.dbc"
    dbc1.write_text(
        'VERSION ""\n'
        'BO_ 896 RadarObject: 8 Vector\n'
        ' SG_ DistanceToObject : 0|16@1+ (0.01,0) [0|655.35] "m" Vector\n'
        ' SG_ PrecedingVehicleDetectionFlag : 16|1@1+ (1,0) [0|1] "" Vector\n',
        encoding="utf-8",
    )
    dbc2.write_text(
        'VERSION ""\n'
        'BO_ 1568 FrameMessage: 8 Vector\n'
        ' SG_ FrameCount : 0|16@1+ (1,0) [0|65535] "count" Vector\n'
        'BO_ 545 CameraTarget: 8 Vector\n'
        ' SG_ Distance : 0|16@1+ (0.01,0) [0|655.35] "m" Vector\n'
        ' SG_ LateralPosition : 16|16@1- (0.01,0) [-327.68|327.67] "m" Vector\n'
        ' SG_ ObjectType : 32|4@1+ (1,0) [0|15] "" Vector\n',
        encoding="utf-8",
    )
    header = [
        "DateTime",
        "Time[us]",
        *[f"ID620_2_8_{index}" for index in range(8)],
        *[f"ID221_2_8_{index}" for index in range(8)],
        *[f"ID380_1_8_{index}" for index in range(8)],
    ]
    rows = [
        ["T0", 0, 100, 0, 0, 0, 0, 0, 0, 0,
         210, 4, 25, 0, 1, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["T1", 1000, "", "", "", "", "", "", "", "",
         "", "", "", "", "", "", "", "", 15, 4, 1, 0, 0, 0, 0, 0],
        ["T2", 2000, 101, 0, 0, 0, 0, 0, 0, 0,
         220, 4, 20, 0, 1, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["T3", 3000, "", "", "", "", "", "", "", "",
         230, 4, "", "", 1, 0, 0, 0, "", "", "", "", "", "", "", ""],
        ["T4", 4000, "", "", "", "", "", "", "", "",
         "", "", "", "", "", "", "", "", 999, 0, 0, 0, 0, 0, 0, 0],
    ]
    with source.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)
    return source, dbc1, dbc2


def _request(source: Path, dbc1: Path, dbc2: Path, max_rows: int | None = None) -> dict[str, Any]:
    return {
        "RequestSchemaVersion": "U001_INPUT_ADAPTER_REQUEST_V0_1",
        "RequestId": "U001_H2_INDEPENDENT_ACCEPTANCE",
        "DatasetId": "INDEPENDENT_FIXTURE",
        "RunId": "RUN_001",
        "SegmentId": "SEGMENT_001",
        "SourceId": "SOURCE_001",
        "TestMode": False,
        "Inputs": [
            {"Kind": "MATLAB_CAN_CSV", "Path": str(source)},
            {"Kind": "DBC_CHANNEL", "Channel": 1, "Path": str(dbc1)},
            {"Kind": "DBC_CHANNEL", "Channel": 2, "Path": str(dbc2)},
        ],
        "Configuration": {
            "SelectionMode": "CONTROLLED_PROFILE",
            "SelectedSignals": [
                {"Channel": 2, "CAN_ID": "0x221", "SignalName": "Distance", "Required": True},
                {"Channel": 1, "CAN_ID": "0x380", "SignalName": "DistanceToObject", "Required": True},
                {
                    "Channel": 1,
                    "CAN_ID": "0x380",
                    "SignalName": "PrecedingVehicleDetectionFlag",
                    "Required": True,
                },
            ],
            "FrameKey": {"Channel": 2, "CAN_ID": "0x620", "SignalName": "FrameCount"},
            "MaxSourceRows": max_rows,
            "ChunkRows": 2,
        },
    }


def validate(adapter_dir: Path, output_dir: Path) -> dict[str, Any]:
    adapter = adapter_dir / "adapter.py"
    card = adapter_dir / "adapter_card.json"
    core = adapter_dir / "u001_matlab_can_csv_dbc_core_v1_0.py"
    if not all(path.is_file() for path in (adapter, card, core)):
        raise AcceptanceError("ADAPTER_FILESET")
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise AcceptanceError("OUTPUT_NOT_EMPTY")

    checks = 0

    def check(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AcceptanceError(label)
        checks += 1

    description = json.loads(_run([sys.executable, str(adapter), "--describe"]).stdout)
    check(description["AdapterId"] == EXPECTED_ADAPTER_ID, "A01")
    check(description["AdapterVersion"] == EXPECTED_VERSION, "A02")
    check("SELFTEST-PASS-30" in _run([sys.executable, str(adapter), "--self-test"]).stdout, "A03")

    with tempfile.TemporaryDirectory(prefix="u001_h2_independent_") as temporary:
        root = Path(temporary)
        source, dbc1, dbc2 = _fixture(root)
        request_path = root / "request.json"
        _write_json(request_path, _request(source, dbc1, dbc2))
        preflight = output_dir / "preflight"
        _run([
            sys.executable, str(adapter), "--preflight", "--request", str(request_path),
            "--out", str(preflight),
        ])
        preflight_value = _read_json(preflight / "u001_adapter_preflight.json")
        check(preflight_value["Status"] == "READY", "A04")
        check(preflight_value["SelectedSignalCount"] == 4, "A05")

        run_a = output_dir / "run_a"
        run_b = output_dir / "run_b"
        for target in (run_a, run_b):
            _run([
                sys.executable, str(adapter), "--run", "--request", str(request_path),
                "--out", str(target),
            ])
        check({path.name for path in run_a.iterdir()} == EXPECTED_FILES, "A06")
        check({path.name for path in run_b.iterdir()} == EXPECTED_FILES, "A07")
        check(
            all(_sha256(run_a / name) == _sha256(run_b / name) for name in EXPECTED_FILES),
            "A08",
        )

        rows = _read_csv(run_a / "u001_adapter_source_updates.csv")
        check(len(rows) == 6, "A09")
        check([int(row["SourceRowIndex"]) for row in rows] == [0, 0, 1, 1, 2, 2], "A10")
        check(sum(bool(row["SyncKeyCandidate"]) for row in rows) == 2, "A11")
        check(all(row["DecodeValid"] == "1" for row in rows), "A12")
        camera = next(
            row for row in rows
            if row["SourceRowIndex"] == "0" and row["SourceSignalName"] == "Distance"
        )
        check(camera["RawCode"] == "1234" and camera["PhysicalValue"] == "12.34", "A13")
        radar = next(row for row in rows if row["SourceSignalName"] == "DistanceToObject")
        check(radar["RawCode"] == "1039" and radar["PhysicalValue"] == "10.39", "A14")
        check({row["NativeTimestamp"] for row in rows} == {"T0", "T1", "T2"}, "A15")

        catalog = _read_csv(run_a / "u001_adapter_signal_catalog.csv")
        check(len(catalog) == 4, "A16")
        check(len({row["CanonicalNameCandidate"] for row in catalog}) == 4, "A17")
        quality = _read_json(run_a / "u001_adapter_quality.json")
        check(quality["SourceRowCount"] == 5, "A18")
        check(quality["DecodedUpdateCount"] == 6, "A19")
        check(quality["IncompleteMessageCount"] == 1, "A20")
        check(quality["InvalidByteMessageCount"] == 1, "A21")
        check(quality["DecodeFailureCount"] == 0, "A22")
        check(quality["FrameKeyUpdateCount"] == 2, "A23")
        check(quality["AbsolutePathLeakCount"] == 0 and not quality["Errors"], "A24")
        manifest = _read_json(run_a / "u001_adapter_run_manifest.json")
        check(manifest["InputBasenames"] == ["CANDump.csv", "DBC1.dbc", "DBC2.dbc"], "A25")
        check(str(root) not in json.dumps(manifest), "A26")
        check(manifest["Status"] == "COMPLETE" and manifest["CompletionCode"] == 0, "A27")

        limited_request_path = root / "limited_request.json"
        _write_json(limited_request_path, _request(source, dbc1, dbc2, max_rows=2))
        limited = output_dir / "limited"
        _run([
            sys.executable, str(adapter), "--run", "--request", str(limited_request_path),
            "--out", str(limited),
        ])
        limited_rows = _read_csv(limited / "u001_adapter_source_updates.csv")
        limited_quality = _read_json(limited / "u001_adapter_quality.json")
        check(len(limited_rows) == 4, "A28")
        check(limited_quality["SourceRowCount"] == 2, "A29")
        check(max(int(row["SourceRowIndex"]) for row in limited_rows) == 1, "A30")

    receipt = {
        "AcceptanceSchema": "U001_H2_MATLAB_CAN_DBC_ACCEPTANCE_V1_0",
        "AdapterId": EXPECTED_ADAPTER_ID,
        "AdapterVersion": EXPECTED_VERSION,
        "CheckCount": checks,
        "IndependentProductionRequestPassed": True,
        "SourceOrderPreserved": True,
        "NoSortNoFillBoundaryPassed": True,
        "FrameKeyIsolationPassed": True,
        "MessageClassificationPassed": True,
        "DeterministicReplayPassed": True,
        "AbsolutePathLeakCount": 0,
        "Status": "ACCEPTED",
        "CompletionCode": 0,
    }
    _write_json(output_dir / "u001_h2_acceptance_receipt.json", receipt)
    (output_dir / "u001_h2_acceptance_capsule.txt").write_text(
        f"U1H2Q-N1-T{checks}-D1-P1-X0-C0\n", encoding="utf-8"
    )
    return receipt


def self_test() -> None:
    adapter_dir = (
        Path(__file__).resolve().parents[2]
        / "01_PROGRAMS"
        / "adapters"
        / EXPECTED_ADAPTER_ID
        / EXPECTED_VERSION
    )
    with tempfile.TemporaryDirectory(prefix="u001_h2_gate_selftest_") as temporary:
        receipt = validate(adapter_dir, Path(temporary) / "acceptance")
        if receipt["CheckCount"] != 30 or receipt["Status"] != "ACCEPTED":
            raise AssertionError("SELFTEST_RECEIPT")
    print("U001-H2-ACCEPTANCE-GATE-SELFTEST-PASS-30")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="U001 H2 independent acceptance gate")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--self-test", action="store_true")
    action.add_argument("--validate", action="store_true")
    parser.add_argument("--adapter-dir", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.adapter_dir is None or args.output is None:
            raise AcceptanceError("VALIDATE_ARGUMENTS")
        receipt = validate(args.adapter_dir, args.output)
        print(f"U1H2Q-N1-T{receipt['CheckCount']}-D1-P1-X0-C0")
        return 0
    except (AcceptanceError, AssertionError, OSError, ValueError, KeyError) as exc:
        print(f"U1H2QE-K{type(exc).__name__.upper()}-D{str(exc)}-X1-C7", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
