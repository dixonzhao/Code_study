#!/usr/bin/env python3
"""Independent installed-source acceptance gate for U3M9C XLSX action."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


MODULE_ID = "CameraRadar.U003.EditableXlsxCharts"
MODULE_VERSION = "0.1.0"
CORE_NAME = "u003_editable_xlsx_export_core_v0_1.py"
EXPECTED_CORE_SHA256 = "6a5a15a6979b13a15c7f637431b95d96bd2f67e78ac7f2a266518558059afddd"


class GateError(RuntimeError):
    """Raised when installed U3M9C evidence is incomplete."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_foundation(program_root: Path) -> Any:
    path = program_root / "u003_module_runtime_v0_2.py"
    if not path.is_file():
        raise GateError(f"U003 module runtime is missing: {path}")
    specification = importlib.util.spec_from_file_location("u003_module_runtime_v0_2", path)
    if specification is None or specification.loader is None:
        raise GateError("U003 module runtime could not be loaded.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def run_child(command: list[str], environment: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
        check=False,
        env=environment,
    )


def run_gate(root: Path, module_directory: Path) -> int:
    root = root.resolve()
    module_directory = module_directory.resolve()
    program_root = root / "01_PROGRAMS"
    core_path = program_root / CORE_NAME
    checks = 0

    def check(condition: bool, name: str, reason: str) -> None:
        nonlocal checks
        if not condition:
            raise GateError(name)
        checks += 1
        print(f"[CHECK {checks:02d}] {name} - {reason}")

    required = (
        core_path,
        program_root / "u003_module_runtime_v0_2.py",
        program_root / "u003_module_executor_v0_3.py",
        program_root / "u003_module_action_gui_v0_2.py",
        program_root / "u003_live_review_context_v0_1.py",
        module_directory / "module_manifest.json",
        module_directory / "algorithm_card.json",
        module_directory / "implementation.py",
    )
    for path in required:
        check(path.is_file(), f"required file {path.name}", "installed and prepared topology is complete")

    check(sha256_file(core_path) == EXPECTED_CORE_SHA256, "accepted U3M9B core identity", "GUI cannot change frozen export semantics")
    manifest = json.loads((module_directory / "module_manifest.json").read_text(encoding="utf-8"))
    card = json.loads((module_directory / "algorithm_card.json").read_text(encoding="utf-8"))
    check(manifest["ModuleId"] == MODULE_ID, "Module identity", "registry key is stable")
    check(manifest["ModuleVersion"] == MODULE_VERSION, "Module version", "first governed GUI release is exact")
    check(manifest["ModuleSlot"] == "EXPORT", "Module slot", "chart export stays outside review semantics")
    check(manifest["EnabledByDefault"] is False, "explicit activation", "engineer selects optional export capability")
    check(len(manifest["UserActions"]) == 1, "one action", "action inventory is deterministic")
    action = manifest["UserActions"][0]
    check(action["ActionId"] == "EXPORT_EDITABLE_XLSX_CHARTS", "action identity", "GUI intent is explicit")
    check(action["TimeoutSeconds"] == 3600, "interactive timeout", "one bounded working session is available")
    for field in ("SignalDataPath", "LiveReviewContextPath", "OutputDirectory", "ProfileDirectory"):
        check(field in action["RequiredContextFields"], f"required context {field}", "U003 owns the source and session context")
    for field in ("WorkbookPath", "ProfilePath", "ExportRecords", "ActionSummary"):
        check(field in action["ProducedFields"], f"produced trace {field}", "every export remains explainable")
    check(card["AlgorithmCardId"].endswith("0.1.0"), "Algorithm Card identity", "design and Module agree")
    check(len(card["Validation"]) >= 12, "validation coverage", "business and technical invariants are explicit")

    foundation = load_foundation(program_root)
    descriptor = foundation.validate_module_manifest(
        module_directory / "module_manifest.json",
        module_directory.parents[2],
    )
    check(descriptor.module_id == MODULE_ID, "runtime discovery", "existing U003 registry accepts the Module")
    check(descriptor.process_transport == "PYTHON_SOURCE", "source transport", "current high-code release remains inspectable")
    check(len(descriptor.user_actions) == 1, "runtime action count", "manifest and runtime interpretation agree")

    source = (module_directory / "implementation.py").read_text(encoding="utf-8")
    check("POLL_MILLISECONDS = 500" in source, "live-context polling", "latest U003 position is visible without restarting")
    check("detect_csv_header" in source and "read_review_table" not in source.split("class EditableXlsxActionWindow", 1)[0], "header-only startup", "opening the GUI does not load the full Review Data CSV")
    check("MAX_CHARTS = 12" in source and "MAX_SERIES = 12" in source, "bounded chart form", "human comparison remains controlled")
    check("asksaveasfilename" in source and "askopenfilename" in source, "visual Profile lifecycle", "engineer never needs to edit JSON directly")
    check("export_editable_xlsx" in source, "accepted-core delegation", "Module contains no second workbook algorithm")
    check("CurrentCANFrameCount" in source and "ReviewStartFrame" not in source.split("def _export", 1)[1].split("def _error", 1)[0], "live context authority", "range semantics remain inside the accepted core")

    environment = dict(os.environ)
    environment["U003_EDITABLE_XLSX_CORE_PATH"] = str(core_path)
    completed = run_child([sys.executable, str(module_directory / "implementation.py"), "--self-test"], environment)
    if completed.stdout:
        print(completed.stdout.strip())
    if completed.stderr:
        print(completed.stderr.strip())
    check(completed.returncode == 0, "Module self-test exit", "headless model and engine integration pass")
    check("U3M9C-SELFTEST-PASS-23 C-0" in completed.stdout, "Module self-test capsule", "expected coverage executed")

    with tempfile.TemporaryDirectory(prefix="u3m9c_gate_") as temporary:
        fixture = Path(temporary) / "review.csv"
        fixture.write_text("FrameCount,A,B\n1,2,3\n", encoding="utf-8")
        probe = run_child(
            [sys.executable, str(module_directory / "implementation.py"), "--execute"],
            environment,
        )
        check(probe.returncode == 7, "fail-closed CLI", "incomplete action invocation cannot open an ungoverned GUI")
        check("--execute requires --request and --result" in probe.stderr, "action diagnostic", "failure identifies the missing contract inputs")

    print(f"U3M9CG1 N-M1-A1-E1-L1-P1-T{checks}-X0 C-0")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--module-dir", type=Path, required=True)
    arguments = parser.parse_args(sys.argv[1:] if argv is None else argv)
    return run_gate(arguments.root, arguments.module_dir)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"U3M9CGE K-{type(error).__name__.upper()} D-{error} X1 C-7", file=sys.stderr)
        raise SystemExit(7)
