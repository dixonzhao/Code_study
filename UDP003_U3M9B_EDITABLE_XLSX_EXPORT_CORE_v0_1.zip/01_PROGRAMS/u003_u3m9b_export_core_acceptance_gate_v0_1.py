#!/usr/bin/env python3
"""Independent synthetic acceptance gate for U3M9B."""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


class GateError(RuntimeError):
    """Raised when exact U3M9B evidence is not acceptable."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise GateError(message)


def load_module(path: Path) -> Any:
    require(path.is_file(), f"Core source missing: {path}")
    specification = importlib.util.spec_from_file_location("u3m9b_core_candidate", path)
    require(specification is not None and specification.loader is not None, "Core import specification failed.")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def run_gate(core_path: Path, profile_path: Path, output_root: Path) -> int:
    checks = 0

    def check(condition: bool, message: str) -> None:
        nonlocal checks
        require(condition, message)
        checks += 1

    selftest = subprocess.run(
        [sys.executable, str(core_path), "--self-test"],
        text=True,
        capture_output=True,
        timeout=60,
        check=False,
    )
    check(selftest.returncode == 0, "Core self-test process failed.")
    check("U3M9B-SELFTEST-PASS-26 C-0" in selftest.stdout, "Core self-test capsule is missing.")
    module = load_module(core_path)
    check(module.ENGINE_ID == "CameraRadar.U003.EditableXlsxExportCore", "Core identity differs.")
    check(module.ENGINE_VERSION == "0.1.0", "Core version differs.")

    with tempfile.TemporaryDirectory(prefix="u3m9b_gate_") as temporary:
        root = Path(temporary)
        review_path = root / "review.csv"
        review_path.write_text(
            "FrameCount,CameraDistance_m,RadarDistance_m\n"
            "41478,21.4,19.3\n"
            "41479,21.3,19.2\n"
            "41480,21.2,19.1\n"
            "41481,21.1,19.0\n"
            "41482,21.0,18.9\n"
            "41483,20.9,18.8\n"
            "41484,20.8,18.7\n"
            "41485,20.7,\n"
            "41486,20.6,\n"
            "41487,20.5,18.35\n"
            "41488,20.4,18.25\n"
            "41489,20.3,18.15\n"
            "41490,20.2,18.05\n"
            "41491,20.1,17.95\n"
            "41492,20.0,17.85\n",
            encoding="utf-8",
        )
        context_path = root / "live_context.json"
        context_path.write_text(
            json.dumps(
                {
                    "ContractId": "U003_LIVE_REVIEW_CONTEXT",
                    "ContractVersion": "0.1",
                    "Sequence": 1,
                    "CurrentCANFrameCount": 41485,
                    "EventID": "SYNTHETIC_C001",
                    "ReviewStartFrame": 41480,
                    "PeakFrameCount": 41485,
                    "ReviewEndFrame": 41490,
                    "EffectivePeakFrame": 41485,
                    "Language": "EN",
                }
            ),
            encoding="utf-8",
        )
        artifact_root = output_root.resolve() / "U3M9B_GATE_ARTIFACTS"
        result = module.export_editable_xlsx(
            review_data_path=review_path,
            live_context_path=context_path,
            profile_path=profile_path,
            output_directory=artifact_root,
            output_name="U3M9B_company_synthetic_acceptance.xlsx",
        )
        check(result.workbook_path.is_file(), "Synthetic workbook was not created.")
        check(result.range_source == "EVENT", "Event range was not selected.")
        check(result.row_count == 11, "Selected row count differs.")
        check(result.start_framecount == 41480, "Start FrameCount differs.")
        check(result.end_framecount == 41490, "End FrameCount differs.")
        check(result.effective_peak_framecount == 41485, "Peak FrameCount differs.")
        check(result.chart_count == 1, "Native chart count differs.")
        check(result.copied_columns == ("FrameCount", "CameraDistance_m", "RadarDistance_m"), "Copied columns differ.")

        try:
            from openpyxl import load_workbook
        except ImportError as error:
            raise GateError("openpyxl is unavailable in the company development runtime.") from error
        workbook = load_workbook(result.workbook_path, data_only=False)
        check(workbook.sheetnames == [
            "Summary",
            "Source Data",
            "Chart Profile",
            "Trace",
            "Chart DISTANCE_COMPARISON",
        ], "Workbook sheet order differs.")
        check(len(workbook["Chart DISTANCE_COMPARISON"]._charts) == 1, "Native chart object is missing.")
        check(workbook["Source Data"]["C7"].value is None, "First missing Radar value became nonblank.")
        check(workbook["Source Data"]["C8"].value is None, "Second missing Radar value became nonblank.")
        check(workbook["Source Data"]["D7"].value == 20.7, "Peak helper value differs.")
        check(not workbook._external_links, "Workbook contains an external link.")
        check(workbook["Trace"]["B15"].value == "EVENT", "Trace RangeSource differs.")
        check(workbook["Trace"]["B18"].value == 41485, "Trace requested Peak differs.")
        check(workbook["Trace"]["B19"].value == 41485, "Trace effective Peak differs.")
        check(workbook["Summary"]["B8"].value == "41480–41490", "Summary range differs.")
        check(result.workbook_path.stat().st_size > 8000, "Workbook file is unexpectedly small.")

    print(f"U3M9BG1 N-S1-R11-C1-B2-T1-Q{checks}-X0 C-0")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--core", required=True, type=Path)
    parser.add_argument("--profile", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    return run_gate(args.core, args.profile, args.out)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (GateError, OSError, ValueError, subprocess.SubprocessError) as error:
        print(f"U3M9BG1E K-{type(error).__name__.upper()} D-{error} X1 C-7")
        raise SystemExit(7)
